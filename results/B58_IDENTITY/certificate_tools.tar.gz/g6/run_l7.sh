#!/usr/bin/env bash
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
date +%H:%M:%S > $S/L7/cand_start.txt
date +%s > $S/L7/cand_start_epoch.txt
cd $REPO && $PY evaluate.py --engine b58 --out $SW/L7/cand_eval.txt $SW/L7/cand_model/sighted_seed0 > $S/L7/cand_stdout.txt 2>&1
rc=$?
{ echo "exit $rc"; date +%H:%M:%S; } > $S/L7/cand_exit.txt
date +%s > $S/L7/cand_end_epoch.txt
echo "L7 evaluate exit $rc"
