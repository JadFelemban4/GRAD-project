import json, glob, os, sys
for f in sorted(glob.glob(os.path.join(sys.argv[1], "L6_*.json"))):
    d = json.load(open(f))
    n = os.path.basename(f)
    if "per_step" in d:
        print(n, "identical", d["identical"], "scores", d["scores"]["equal"], "/", d["scores"]["compared"], "per_step", d["per_step"]["fields"], d["per_step"]["values"], len(d["per_step"]["differences"]))
    else:
        print(n, {k: v for k, v in d.items() if not isinstance(v, (list, dict))})
