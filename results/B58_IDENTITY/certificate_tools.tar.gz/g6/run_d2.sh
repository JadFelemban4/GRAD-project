#!/usr/bin/env bash
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
cd $REPO
date +%s > $S/F11/cand_d2_start_epoch.txt
$PY evaluate.py --engine b58 --protocol d2 --out $SW/F11/cand_d2.txt > $S/F11/cand_d2_stdout.txt 2>&1; echo "exit $?" > $S/F11/cand_d2_exit.txt
date +%s > $S/F11/cand_d2_end_epoch.txt
$PY evaluate.py --engine b58 --protocol d2 --out $SW/F11/cand_d2_x1.txt $SW/L7/cand_model/sighted_seed0 > $S/F11/cand_d2_x1_stdout.txt 2>&1; echo "exit $?" >> $S/F11/cand_d2_x1_stdout.txt
date +%s > $S/F11/cand_d2_x1_end_epoch.txt
echo "d2 done"; cat $S/F11/cand_d2_exit.txt; tail -3 $S/F11/cand_d2_x1_stdout.txt
