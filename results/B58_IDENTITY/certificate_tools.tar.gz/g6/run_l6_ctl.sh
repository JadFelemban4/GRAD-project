#!/usr/bin/env bash
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
date +%s > $S/L6/A_G6_ctl_start_epoch.txt
for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do set -- $c
  ( HARNESS_PERTURB=$1 $PY -I $SW/tools/l6_agents.py $RW sighted_seed0 $SW/L6/A_G6_ctl_$3.npz $2 > $S/L6/A_G6_ctl_$3.log 2>&1; echo "$? $3" >> $S/L6/A_G6_ctl_status.txt ) &
done; wait
for n in mass cturb mass1e-9 mass1e-6; do $PY -I $SW/tools/l6_check.py $SW/L6/A_G6_ctl_$n.npz sighted_seed0 --json $SW/cmp/A_G6_L6_ctl_${n}_committed.json > $S/L6/A_G6_ctl_${n}_check.txt; echo "check exit $?" >> $S/L6/A_G6_ctl_${n}_check.txt; done
date +%s > $S/L6/A_G6_ctl_end_epoch.txt
echo "controls done"; cat $S/L6/A_G6_ctl_status.txt
