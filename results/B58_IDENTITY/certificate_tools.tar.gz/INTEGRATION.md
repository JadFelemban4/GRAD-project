# P's B58 certificate kit: how p_gate.sh uses it

Drafted 7 November 2026 for P_GATE_PLAN.md section 5.2 (K1-K8) and section 8 (R1.B3, R2.B2). **Nothing in the kit
has run.** The only command run on it was `bash -n` on the shell files (all parse). No Python file of the kit was
executed, and no JSON file was parsed by a JSON reader. The authorities were CERT_PLAN_P.md (at 4dd0c09 in
build/clone_p), the interface sheet 6.8, CERT_PLAN_A.md and the tools in results/B58_IDENTITY/certificate_tools.tar.gz
(read with `tar -xO`, never extracted), and commit A's own S (scratchpad/cert2: its tools are the archive's byte for
byte, checked member by member; its records give what really ran and how long it took).

`{{NAME}}` is a value only a run can give. "ASSUMED" marks a duration or a behaviour not measured.

**Revised 7 November 2026 after the kit's review (P_GATE_PLAN.md section 11, "Review fixes 2").** What changed in
the kit: the six shell tools whose `-B` edit had lost a space (compare_all.sh, check_l6.sh, run_l6.sh, run_l4.sh,
and the cosmetic run_writer.sh and run_drift.sh) restored, each now the archive's but for the `-B` tokens, the
`CAND` default and its header lines; cert_final_driver_P.sh's 3.6.19 record no longer FAIL by construction, and a
FAIL record that a later PASS re-checks accepted there as make_cert.py accepts it; cert_driver_P.sh refuses any
CERT_GROUPS but one-at-a-time, runs one group again with CERT_ONLY (and pairs re-run PASS records with the FAIL
records they re-check, CERT_RECHECK_MAP), checks G1.7's two extractions against their own archive_members.txt
before anything in them runs, judges G5 against cf43fbb's runs alone (commit A's and RV's for information), and
kills a launcher server left on port 8765 (since the settle step of 7 November 2026: the listener and its recorded
descendants, each by its pid, without taskkill /T); failing_sets_P.py names a setUpClass error alike in both invocations.
Sections 2-8 below are updated; the items p_gate.sh now does (section 8) are marked done.

**Revised again 7 November 2026 after the two re-reviews of that revision (P_GATE_PLAN.md section 12, "Review fixes
3").** What changed in the kit: every group of cert_driver_P.sh that counts or compares files an earlier run of it
leaves (G1's harness folders, G5's lab dumps, G6's L6, L7 and d2 outputs, G7's second test_epa_map output) starts
from none of them, so that a `CERT_ONLY` re-run (cert-recheck) is judged on its own files (G6's re-run always read
"L6 done: 16 of 16" and FAILed; G1's would have counted every job twice); every lab_dump.py exit is recorded and
required; G5 requires the three ignored local paths p_gate.sh cert-prep now copies into the clone and the node tests'
`ℹ skipped 0`; npm ci and the launcher's port fail closed (a FAIL record that cert-recheck g5 re-checks); the
launcher's left-over server is found by the port it listens on, not by its command line; cert_final_driver_P.sh
refuses (exit 3, no record written) while a FAIL record is open; run_l6.sh's and make_meta.py's comments corrected;
cert_P.json's not_covered says where the clone's ignored data came from.

The orchestrator's decisions of 7 November 2026, as the kit implements them:
- The certificate runs in the clean clone `GD/cert/candg` at P's candidate (git_dirty False). The kit gives the clone
  REPO's role everywhere (env_P.sh), and make_cert.py asks git there (cert_P.json's `candidate.tree`), so the
  certificate names P_CAND. The check that P's final commit differs from P_CAND only by documents and reverify.json
  is p_gate.sh's (phase commit).
- The certificate's groups run one at a time beside the roads check: the driver runs G1, G2, ..., G7 in order, and
  refuses to start unless CERT_GROUPS is one-at-a-time. Inside a group, what CERT_PLAN_A.md runs together runs
  together: up to six processes in most steps, eight in L6 (run_l6.sh), and up to 18 in check_roads.py's own pool
  plus two test_reward.py runs in G3, so that G3 puts about 20 processes beside the check's 14 jobs on the laptop's
  20 threads (numbers do not change: every process is single-threaded; the check's time grows; section 5).
- test_epa_tightenings MODE ok and the commit-failure route are p_gate.sh's and P's; the kit does not touch them.
- The kit owns `cert_kit/` only; it does not write P_GATE_PLAN.md, `decisions/` or p_gate.sh. Section 8 lists what
  the kit asks of them.

## 1. The files

p_gate.sh's phase `cert-kit` installs every file under `cert_kit/` at the same relative path under S (over the
archive's copy), and appends `TOOL_EDITS_commit_P.md` and a diff of every other file to S/TOOL_EDITS.md.

| kit file | installed as | what it is | new or edited |
|---|---|---|---|
| `env_P.sh` | S/env_P.sh | the variables (K3), sourced by both drivers | new (from env_A.sh) |
| `cert_P.json` | S/cert_P.json | make_cert.py's config (K6); `date` empty (D19) | new (from cert_A.json) |
| `reproduce_P.json` | S/reproduce_P.json | the reproduce block cert_P.json names | new |
| `TOOL_EDITS_commit_P.md` | appended to S/TOOL_EDITS.md | why each file changed, and each diff against the archive (K2) | rewritten |
| `INTEGRATION.md` | S/INTEGRATION.md | this page (archived with the rest; section 8, item 1) | new |
| `tools/cert_driver_P.sh` | S/tools/ | CERT_DRIVER: G1-G7 (K7) | new |
| `tools/cert_final_driver_P.sh` | S/tools/ | CERT_FINAL_DRIVER: F.1, HP7.6, the 3.6.19 record, F.2 (K8) | new |
| `tools/make_meta.py` | S/tools/ | schema-4 live block, for_arm (K1) | edited |
| `tools/make_cert.py` | S/tools/ | the candidate's tree; schema 4; a format-2 previous certificate; page_text (K5 and more) | edited |
| `tools/make_md.py` | S/tools/ | the page's own words from page_text; schema 4's backends | edited |
| `tools/run_jobs.py` | S/tools/ | `-I -B` for every harness job (K4) | edited |
| `tools/compare_all.sh`, `tools/check_l6.sh` | S/tools/ | `-I -B` (K4) | edited |
| `tools/run_writer.sh`, `run_l4.sh`, `run_l6.sh`, `run_app.sh`, `run_app_extra.sh`, `run_drift.sh` | S/tools/ | `-B` (K4); CAND has no default (contract item 2) | edited |
| `tools/l7_expect.py` | S/tools/ | `--agent`, `--repo` (L7's blind_seed0) | edited |
| `tools/cert_record.py` | S/tools/ | optional `--rechecks` (a FAIL's re-check route) | edited |
| `tools/road_json_diff.py` | S/tools/ | commit A's g3/road_json_diff.py, unchanged, moved into tools/ | new in tools/ |
| `tools/failing_sets_P.py` | S/tools/ | G5's failing sets against several reference runs | new |
| `tools/stated_counts_P.py` | S/tools/ | HP7.6 as a check that can fail | new |

## 2. What p_gate.sh calls

### 2.1 Phase `cert` (beside the check)

p_gate.sh already does, in this order: `cert_ready`, `records_fresh`, `cert_tree_clean`, G1.0 (`g1_identity`: two
G1-harness records; `out/P_G1_fp_cand.txt`, `pip_freeze_P.txt`), G7.3 (`g7_help`: one G7-suites record), then

```bash
export CERT_S CERT_TREE P_CAND RV_SHA; export LIVE_REPO=$REPO
in_dir "$CERT_TREE" bash "$CERT_DRIVER"          # CERT_DRIVER=$CERT_S/tools/cert_driver_P.sh
```

That is the whole contract: no argument. The driver sources `$CERT_S/env_P.sh`, which refuses unless CERT_TREE's
HEAD is P_CAND and CERT_S is the folder env_P.sh lies in. Optional environment (defaults in brackets):

| variable | default | what |
|---|---|---|
| `CERT_PAR_L1` | 6 | run_jobs.py's parallel jobs for G1.1 (CERT_PLAN_A: 6) |
| `CERT_L9_PROCS` | 6 | `ecu_shift.run_all(N)` (CERT_PLAN_A: 20; commit A ran 16 with 25 of 25) |
| `COMMIT_A_S` | `scratchpad/cert2` | commit A's S: its `tcl/` (G7.1's lists and package zips) |
| `P_GATE_OUT` | `GD/out` (CERT_ROOT's sibling `out`) | p_gate.sh's G: RV's base app logs, read as references in G5 |
| `NODE`, `NPM` | `command -v node`/`npm`, else `/c/Program Files/nodejs/` | G5 |
| `CERT_GROUPS` | (none: required) | must be `one-at-a-time` (decisions/cert_groups.txt); any other value: exit 2 |
| `CERT_ONLY` | (unset: all seven) | `g1` ... `g7`: that group alone (p_gate.sh cert-recheck); S/commitA is then checked against its `_sha256.txt`, not copied again |
| `CERT_RECHECK_MAP` | (unset) | with CERT_ONLY: lines `<what><TAB><group>.json record <n>`; a re-run PASS record whose `--what` is listed gets `--rechecks "<group>.json record <n>"` (make_cert.py's `_rechecks` pairs it with that earlier FAIL); when several lines share the `what` (the same check failed on the first run and on a re-run: settle step, 7 November 2026), the PASS is written once per line, each with its own `--rechecks` |

Exit: 0 when every record was written (whatever their verdicts); 3 when cert_record.py refused a record, a
precondition of its own failed (the clone's HEAD~1 is not RV_SHA, the clone is not clean, an input is missing),
or the clone is not clean at P_CAND at the end; 2 when it cannot start. p_gate.sh stops on any non-zero exit
("the certificate's driver, exit N") but one: exit 3 whose report (this run's lines) holds no `REFUSED` line but
`REFUSED by cert_record.py (group <G>)` lines. Then cert passes, the groups that lost a record are listed in
`GD/out/cert_recheck_needed.txt`, and post refuses until `cert-recheck <g>` has run each of them again. p_gate.sh
then checks the clone clean and REPO's status unchanged, and lists every FAIL record (`GD/out/cert_fail_records.txt`).

Inputs the driver refuses without (from cert-prep, cert-kit and G1.0): `S/tools/{run_jobs.py, compare_all.sh,
control_verdict.py, cert_record.py, make_meta.py, failing_sets_P.py, stated_counts_P.py, road_json_diff.py,
l7_expect.py}`, `S/out/ref/_status.txt`, `S/out/fp_ref.txt`, `S/out/P_G1_fp_cand.txt`, `S/manifest_start_P.txt`,
`S/L7/ref_eval.txt`, `S/F11/ref_d2.txt`, `S/lab/lab_ref_A.json`, the trees `S/{ref,refw,pre,cand,candd,candw,candt}`,
and `CERT_ROOT/X` (the archive extracted whole). It reads, never writes: X (commit A's candidate evidence, copied
into `S/commitA/` with sha256 against `X/archive_members.txt`), P_GATE_OUT, and in the live repository (LIVE_REPO;
P changes none of these files): `runs/extremes_dt1` (L6, L7), the committed raw scores and agent files
`l6_check.py` reads (`results/phase_d_extremes_dt1_raw.json`, `results/agents/...`; archive tools/l6_check.py:19,
25, 43), and `git rev-parse HEAD` there (make_cert.py:68, every make). (review fixes 3) Also read there, read-only:
every make reads cert_P.json's `x1_meta` (make_cert.py:431-433, relative to REPO, the live repository: of runs/ the clone holds only the copy of X1's sighted_seed0 meta.json cert-prep makes, and make_cert.py does not read it there; make_cert.py:15's "runs/ is in no clone" predates that copy); and G1.7(b)'s
two makes on commit A's own cert_A.json, which names no `candidate.tree`, ask git in the live repository for HEAD,
the branch, `log c47907b..HEAD`, `show c47907b:results/B58_IDENTITY.json` and `archive cf43fbb`
(make_cert.py:208-210, 449-458). G1.7 reads committed blobs through the clone (`git cat-file`). The clone itself holds,
from p_gate.sh cert-prep, three gitignored paths copied from the live repository (`app/node_modules`,
`app/static/vendor`, `runs/extremes_dt1/sighted_seed0/meta.json`: a G0-prepare record), as commit A's run in the
repository had them; G5 checks they are there and ignored.

A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
(review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
`cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
`suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
`S/F11/ref_d2.txt`, `S/lab/lab_ref_A.json`, `out/ref/`) are never removed.

### 2.1b Phase `cert-recheck <g>` (only when a FAIL record, or a lost record, needs it)

The team writes `decisions/cert_recheck_<g>.txt`: `MODE recheck`, `REASON <the cause, read in the FAIL's
evidence>`, and one `FAIL <group>.json record <n>` line per FAIL record the re-run re-checks (none when the group only
lost records). p_gate.sh checks each named record is a FAIL, not re-checked yet, and has a `what` that names only
records of the same check in its file (the same level, item and command), and that the decision names every OPEN
FAIL of that check; copies every earlier record's evidence of that file to `S/recheck/<group>_<stamp>/` and points
those records at the copies (the re-run writes the same paths; a FAIL record keeps the first run's evidence); writes
CERT_RECHECK_MAP; runs the driver with CERT_ONLY=<g>; then requires a PASS record naming each FAIL in `rechecks`. It
runs beside the check or after it, before cert-docs (cert-docs removes S's extra trees, which the driver needs), and
clears post and every phase after it, so that G7.0 runs again after it.

(settle step, 7 November 2026) A group can be re-checked more than once. After one re-run every check of the group
has two records with the same `what` (the first run's and the re-run's): that is one check run twice, so the rule is
"the same check", not "one record of the file" (round 3's rule, under which a FAIL a re-run wrote, or a second FAIL
of a check re-run once, could never be re-checked: npm ci without the network twice, for one). When a check failed
on the first run and again on the re-run, both FAILs are OPEN: the next decision names both, and the next re-run's
PASS of that check is written once per FAIL, each with its own `rechecks` (make_cert.py pairs one PASS with one FAIL).
The re-run deletes the group's raw outputs that no record names as evidence (G1's `out/P_G1_*/` dumps, G6's
`L6/*.npz`): recheck_prep copies only `evidence_files` aside, so whoever needs the first run's raw dumps to read a
FAIL's cause reads them, or copies them aside by hand, before cert-recheck.

(review fixes 3) Only the driver's groups g1 ... g7 can be re-run, and a FAIL is re-checked only by a re-run PASS of
the same check (the same `what`). So a FAIL of a record no driver group writes again needs a new S (move GD/cert
aside, cert-prep, cert-kit, cert, post): G0-prepare's, G1.0's (cert stops on it anyway), G7.3's, G7.0's (written by
post), HP7.6's (G7-suites, written by the final driver) and every F-certificate record (the final driver's F.1 and
3.6.19; cert-docs' drift control). post refuses while any FAIL record is open (it lists them again from S first,
`GD/out/cert_fail_records.txt`), and the final driver refuses before its first record (2.2), so that an open FAIL
never turns into a 3.6.19 FAIL that nothing can re-check.

### 2.2 Phase `cert-final`

```bash
export CERT_S CERT_TREE P_CAND RV_SHA; export LIVE_REPO=$REPO
in_dir "$CERT_TREE" bash "$CERT_FINAL_DRIVER"    # $CERT_S/tools/cert_final_driver_P.sh
```

It needs post's `S/suites/P_test_engine_threading.txt` (G7.0's record). Same exit codes; (review fixes 3) before its
first record it reads every `S/cert_results/*.json` (`$PY -I -B`, make_cert.py's pairing rule: a FAIL is closed only
by a later PASS of the same file naming it in `rechecks`) and exits 3, writing no record, if a FAIL is open or a
file does not parse (`S/out/P_F0_open_fails.txt`). Then p_gate.sh checks
`S/cert_out/B58_IDENTITY.json` and `.md`, `make_cert_ok S/cert_out/make_cert_stdout.txt`, and that the JSON names
P_CAND: the driver writes all three for exactly those checks. make_cert_ok (and the driver's own 3.6.19 test)
accepts a `  FAIL {...}` line only when its dict ends with a non-empty `'rechecked_by': [...]` (a FAIL record a later
PASS re-checks) and the line `  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)` is
printed; any other `  NO  `, `  PROBLEM `, `  FAIL ` or `  MISSING ` line refuses.

### 2.3 Phase `cert-docs` (no driver)

p_gate.sh's own F.3 calls the kit's tools with unchanged interfaces: `tools/drift_control.py`, `make_archive.py`,
`make_cert.py <json> <archive> --config S/cert_P.json`, `make_md.py`. make_cert.py now asks git in cert_P.json's
`candidate.tree` = `GD/cert/candg`: the clone must still exist at cert-docs (H8 deletes it only after the push).

## 3. What each driver writes, and where

Every record goes to `S/cert_results/<group>.json` through `rec` (cert_record.py, `-I -B`). Own reports:
`S/out/P_driver_report.txt` (every group's start, end and seconds; every "NO RECORD" line; refusals),
`S/out/P_driver_records.log` (cert_record.py's lines), and `S/out/P_final_driver_report.txt`,
`S/out/P_final_driver_records.log`.

| group | records (driver) | evidence, under S | scratch outside S (removed by the driver) |
|---|---|---|---|
| G0-prepare | 1: commit A's evidence copied into `commitA/` (none on a CERT_ONLY run); p_gate.sh adds 1 per cert-recheck | `commitA/**`, `commitA/_sha256.txt`; `recheck/<group>_<stamp>/**`, `recheck/<group>_<stamp>_{sha256,decision}.txt` | |
| G1-harness | 3 (L1, B3, HA.9) + 20 controls + the lhv keys + divergent + 3 for G1.7 = 28 | `out/P_G1_*/` (dumps, logs, `_status.txt`), `out/P_G1_*_run.txt`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`, `cmp/P_G1_*.txt`, `out/P_G1_lamf32_first_rows.txt`, `out/P_G1_bind_lines.txt`, `out/P_G1_tool_hashes.txt`, `out/P_G1_b9_*.txt` (with `out/P_G1_b9_{bs1,commitA}_members.txt`: each extraction against its own archive_members.txt) | `CERT_ROOT/g17` |
| G2-writers | 7: check_premise, generality_test, L9, item 16's tree, model_vs_data, substep_fit_check, make_page | `L5/cand_premise_*`, `L5/cand_generality_*`, `L5/cand_P16{pre,candw}_{mvd,substep,page}_*`, `L5/P_G2_*`, `L9/P_G2_*`, `prep/P_G2_preRV_tar_compare.txt` | `CERT_ROOT/preRV` |
| G3-roads | 7: S/cand before, test_reward (both), extremes, wideair, terrain, check_random_road, S/cand after | `L4/cand{,_random}_*`, `L5/cand_roads_*`, `L5/P_G3_*`, `F11/cand_roads_terrain_*`, `F11/cand_random_road_*`, `F11/P_G3_*`, `prep/P_G3_*` | |
| G4-data | 4: validate, build_dataset, new_drive, derive_params | `L5/P_G4_*`, `F2/{cand,ref}.txt`, `F2/{cand,ref}.npz`, `F2/cmp.*`, `F2/new_drive_candd.txt`, `L5/derive_cand.txt`, `L5/derived_*` | |
| G5-app-lab | 15 with the network (12 without: npm ci's record a FAIL, and the build, the launcher and the lab's node tests get none; with the port 8765 taken, 15 with the launcher's a FAIL: review fixes 3) | `app/cand_*`, `app/P_G5_*` (`app/P_G5_failing_*_info.txt`: the information-only comparisons), `lab/P_G5_*`, `lab/lab_{ref,cand}_P.*`, `lab/lab_P_ctl_*`, `lab/compare_P_*` | |
| G6-agents | 15: L6 run, 4 agents, 4 controls, 2 make_meta, 2 L7, d2, d2's refusal | `L6/{cand,ref}_*`, `L6/P_G6_*`, `cmp/L6_*`, `cmp/P_G6_*`, `L7/cand_model/*`, `L7/{make_meta*,cand_*,ref_eval_blind.txt,ref_blind_*,l7_*}`, `F11/cand_d2*`, `F11/d2_diff.*` | |
| G7-suites | 19: G7.1, 12 suites, HA.4, HA.5, HA.6, HA.11, verify_docs, run_drift (+1 when the second test_epa_map runs) | `suites/cand_*.txt`, `suites/_status.txt`, `suites/P_G7_*`, `suites/drift_*`, `tcl/` (not archived: SKIP_DIRS) | |
| F-certificate (K8) | 3: F.1 fingerprint, F.1 manifest, 3.6.19 (draft0) | `out/P_end_fp_cand.txt`, `manifest_end_P.txt`, `out/P_F1_*`, `cert_out/P_F2_draft0*` | `CERT_ROOT/vdcheck_P` |
| G7-suites (K8) | 1: HP7.6 | `suites/P_F_stated_counts.txt` | |
| (K8, no record) | the draft | `cert_out/B58_IDENTITY.json`, `.md`, `make_cert_stdout.txt`, `make_md_stdout.txt`, `P_F2_verify_docs_precheck.txt` | |

With the gate's own records (G0-prepare 6, the sixth the ignored data copied into the clone: review fixes 3; G1.0 2,
G7.3 1, G7.0 1), the draft holds about {{N_RECORDS}} records
(about 110 by the counts above; the second test_epa_map run and the network move it). cert-docs adds one (the drift
control with the certificate, F-certificate, item 3.6.18) before the final make.

Names: harness labels `P_G1_*`; the driver's own files `P_<group>_*`; the tools that name their own files write
`cand_*` (S holds none from commit A: cert-prep left them in X); commit A's files a check compares with are in
`S/commitA/` under their archive paths.

## 4. Expected outputs

The driver's report ends with `END cert_driver_P.sh after {{CERT_SECONDS}} s; records: {{N_PASS}} PASS,
{{N_FAIL}} FAIL; driver refusals: none` (review fixes 3: "none" or "at least one", not the 0/1 flag it printed).
p_gate.sh's cert phase notes the same two counts.

make_cert.py's print-out at F.2 (`S/cert_out/make_cert_stdout.txt`), as p_gate.sh's `make_cert_ok` needs it:

```
written C:/.../p_gate/cert/S/cert_out/B58_IDENTITY.json | BIT-IDENTICAL at every level run on this machine (pending: L8 on the training device at ORDER step 18, and app.test_results on P itself after the commit)
  ok  every record well formed
  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)
  ok  every item of the re-run list answered
  ok  harness jobs BIT-IDENTICAL (compare_all.sh's reports)
  ok  every control as expected (compare_all.sh's reports)
  ok  the plant's fingerprint the same at the start and the end
  ok  derived_sha and the shared FATAL fields equal the reference's
  ok  engine_sha over build step 1's keys is build step 1's (B11)
  ok  the repository unchanged during the run (manifests), but for the files the config declares, none a plant file
  ok  every value count read
  ok  engine_sha is the previous certificate's candidate's (row 94: plant_sha moves, engine_sha does not)
```

and no `  PROBLEM`, `  FAIL` or `  MISSING item` line. The JSON: `candidate.head` = {{P_CAND_SHA}}, `candidate.base_commit`
= {{RV_SHA}}, `candidate.commits_on_base` = one line, P_CAND's; `identity.plant_sha.candidate` =
{{PLANT_SHA_B58_P}} (the port printed 36655cab94800e30), `.previous_certificate` 865f8e7b7e5c2dbe (commit A's),
`.reference` 3c48890dd15bc116; `derived_sha` 326c0835548975e2 on all sides; `engine_sha.candidate` 023f5589215ee68e
= `.previous_certificate`; `over_build_step_1_keys` = `over_build_step_1_keys_in_previous_certificate` =
99d2a9658b1258a7 (commit A's reading, read at run time from RV's results/B58_IDENTITY.json); `backends` train cycle,
score cycle, contract {{BACKEND_CONTRACT}}; `shared_read_from_transmission` [gears, final_drive];
`values_compared_byte_for_byte` harness {{N_HARNESS_VALUES}} (= commit A's comparison's sum, 2 685 037, if every
job is BIT-IDENTICAL), l6_agents {{N_L6_VALUES}}, build_dataset_columns {{N_BD_VALUES}} (commit A: 3 617 501).
`different.fingerprint` will list `gears`, `final_drive` and `backend` (a value against none: schema 4 moved them,
cert_P.json's note says so) and the schema-4 fields, as provenance.

## 5. Durations

Commit A's records give wall times under a load it states as 100 to 180 Python processes at 100 % CPU; P's groups
run one at a time beside the check's 14 jobs (with up to about six of their own, eight in L6, up to 18 in
check_roads.py's pool). "P, ASSUMED" is CERT_PLAN_A.md's unloaded time times about 1.3, plus what P adds.

| group | CERT_PLAN_A.md (all groups at once) | commit A's records, s (loaded) | P, ASSUMED |
|---|---|---|---|
| G1 | about 1 h | L1 8258 (plan: about 1970 at 6 jobs); ref2 3108, cturb 2455, mass 2075, afr 1812, lhv 953, divergent 32, bind 473, lamf32 304, lamf64 474, ceilf32 473, census 853, census_rest 1829, form controls 384-867 each, refside 962; G1.7 117 | 2-2.5 h (L1 about 45 min, ten waves of controls, G1.7 a few minutes) |
| G2 | about 2.5 h | premise 4006, generality 9203, L9 7778 (16 processes), item 16: model_vs_data 2518, substep 4311, page 403 | about 2 h (generality about 55 min beside premise and L9 at 6 processes, then item 16 twice each) |
| G3 | about 2.5 h | test_reward 6528 and 5952 (random), extremes 3754, wideair 2931, terrain 1527, check_random_road 3372 | about 1.6-2 h (the roads one after another: about 996 + 1296 + 608 + 2777 s unloaded) |
| G4 | about 15 min | validate 1282, bd_dump 160, new_drive 118, derive_params 1121 | about 20 min |
| G5 | about 1 h | test_replay --full 4625, test_simulation 78, test_agents 1228, test_results 690, lab tests 151, the eleven 386, node 15, npm ci 633, build 632, launcher 300, lab node 191, lab dumps 507-640 each | about 1.3 h (network for npm ci) |
| G6 | about 2.6 h | L6 3194, check_l6 86, controls 300-735, L7 11991, d2 13460, refusal 2 | about 3.5-4 h (L6 about 1 h; four evaluate.py at once: sighted, blind, cf43fbb's blind, d2) |
| G7 | about 45 min | test_wide_air 5077, test_fuel_forms 2736, test_trainable 379, test_plant_guards 142, test_epa_map 131, test_cars 100, fingerprint 66, random_road 49, test_carried 26, verify_docs 221-399, run_drift 839-1404 | about 1.3 h (test_preview_horizon alone after the waves: 611-767 s) |
| K8 | about 30 min with F.3 | F records 2-60 s; make_cert seconds | about 10-15 min (two makes, a copy of the clone and verify_docs in it) |

Sum for P: about 12-14 h (ASSUMED), inside the check's 17.7 h (ASSUMED). If the check ends first, the certificate
goes on alone; post needs both.

## 6. To settle before `check` (the certificate's window is the check's)

1. **HP7.6 fails at 4dd0c09, by reading.** README.md:830 and full_run.py:86 state test_plant_guards "19 tests (9 skip
   until the EPA plants are calibrated)"; the port ran it `Ran 47 tests ... OK`, no skip (port_p/out). README.md:827
   and full_run.py:130 state app.test_agents "135 tests OK, 14 skipped"; P edits app/test_agents.py, so that count is
   {{N_TEST_AGENTS}}. stated_counts_P.py would print `DIFFERENT` on those lines, the HP7.6 record would FAIL, the draft
   would print a FAIL line, and p_gate.sh's cert-final would stop. full_run.py is a .py: after apply, docs_only refuses
   its edit. **Settled (review fixes 2):** the counts go into P's re-made candidate at H-S (P_GATE_PLAN.md 5.3),
   from the survey's applied-stage runs, which run stated_counts_P.py (`stated_counts` in GD/survey/summary.txt); and
   p_gate.sh pre runs the same check on its own runs (`stated_counts_pre`, step 8b) and stops on a DIFFERENT line or
   on any statement but test_wide_air.py's without a run (pre does not run test_wide_air.py; P does not edit it; G7
   does), before the window opens.
2. **verify_docs.py on P's candidate tree** (G7.5, item 3.6.18) is a record. **Settled:** p_gate.sh pre now runs it
   as a gate (step 8c) on the same documents and stops on a failure; the survey's run shows it before H-S.
3. **The kit's Python was never executed** (make_cert.py, make_md.py, l7_expect.py, cert_record.py, run_jobs.py,
   failing_sets_P.py, stated_counts_P.py, make_meta.py) and its JSON (cert_P.json, reproduce_P.json) was parsed by no
   JSON reader. **Settled as far as can be before the window:** cert_ready ast-parses every kit .py and json-loads
   both JSON files; cert-kit's smoke step (p_gate.sh `kit_smoke`) checks the edited shell tools by text and by an
   argv run with PY=echo against the archive's, and replays compare_all.sh and check_l6.sh on commit A's own dumps
   against commit A's reports; the survey runs stated_counts_P.py and failing_sets_P.py on real logs. make_cert.py,
   make_md.py, make_meta.py, l7_expect.py, run_jobs.py and the drivers still run first inside the window.
4. `decisions/cert_kit_reviewed.txt` lists every file under cert_kit/, INTEGRATION.md and TOOL_EDITS_commit_P.md
   among them (cert_ready requires each): 24 files. TOOL_EDITS_commit_P.md's sha256 table was written last; any later
   kit edit means regenerating its diffs. (review fixes 3) Written 7 November 2026 by the fixer and signer of the two
   re-reviews of review fixes 2, after their fixes (P_GATE_PLAN.md section 12): its `#` lines name the re-reviews and
   the date (sha256sum -c skips them), and its other lines are `sha256sum` over the 24 files as they stand then. Any
   later kit edit voids it: cert_ready then refuses (review-sha256), and the reviewers write it again.
5. G5 needs the network (npm ci) and a free port 8765. (review fixes 3) Without the network npm ci's record is a
   FAIL (the build, the launcher and the lab's node tests then get no record); with the port taken the launcher's
   record is a FAIL; either stands until cert-recheck g5 runs G5 again, so the certificate cannot pass without the
   lab's runs (before, a missing record let 3.6.12 and B12 read as answered). G5 also needs the three ignored local
   paths p_gate.sh cert-prep copies into the clone (2.1). G7.1 needs `COMMIT_A_S/tcl` (present in scratchpad
   cert2: commit A's lists and package zips) or the network.
6. Nothing else may use the venv's python during `cert` but the check (no_other_python is skipped for cert).

## 7. Expectations the kit writes down (P_GATE_PLAN.md 7.23, and where P moves an expectation no sheet amends)

- **G1.1, values**: the sum of the comparison lines equals commit A's comparison's sum (read from the archive), not a
  typed 2 685 037.
- **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
  takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
  runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
  extraction of build step 1's archive (`c47907b`'s), build step 1's
  make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
  committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
  since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
  cert_A.json: byte-identical JSON and page. (c) The control: P's make_cert.py on cert_A.json with `candidate.tree` =
  the clone writes another JSON whose candidate.head is P_CAND.
- **G2.3, item 16 at P**: before = a git archive of RV (outside S, `CERT_ROOT/preRV`), after = S/candw, for
  CERT_PLAN_A.md's three scripts (model_vs_data.py, substep_fit_check.py, make_page.py): byte-identical,
  equal apart from `seconds`, identical pages. c47907b (commit A's "before") would compare WP1's edits, not P's.
  S/pre (c47907b) is left unused. HA.7: the candidate's page still carries commit A's two glossary sources.
- **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
- **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
  cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
  road. The reward is safe to train against on the randomised climb.' (`--road random`).
- **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
  each committed file (road_json_diff.py) is a `--difference` text, not judged.
- **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
  only be failures that cf43fbb's git clone (app/refgit_*) also has (`failing_sets_P.py`: candidate only []). The
  eleven: against build step 1's cf43fbb copy run (app/ref_*) alone. The node tests: against cf43fbb's clone's run
  alone; the lab's node tests (G5.3): against commit A's run of them on cf43fbb's tree alone. Commit A's candidate
  runs and RV's base runs (P_GATE_OUT/base_app_*.log) are compared too, for information only (`*_info.txt`, named in
  the record's got): a failure RV's ancestors brought in after cf43fbb is a FAIL, not excused. The survey predicts
  this verdict before the window (`g5_predict_*` in GD/survey/summary.txt). The lab's pin: the value in
  tests/test_catalog.py equals G1.0's plant_sha, and its test passes. (review fixes 3) The clone holds the three
  ignored local paths commit A's run in the repository had (cert-prep), so G5 runs what commit A's run ran: each app
  record requires them, and the node tests' record requires `ℹ skipped 0` (commit A: 306 tests, 306 pass, 0
  skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
  configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
  second time, so that a failure RV already has reads as such.
- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
  cycle, which passed, used this trigger. The record's
  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
  original), and the trigger would fire on it before the new server is up.
- **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
  block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
  strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
- **G6.3**: blind_seed0 beside sighted_seed0 (CERT_PLAN_P.md); no reference report exists for it, so the driver runs
  cf43fbb's evaluate.py on X1's original blind_seed0 in S/ref and diffs the two (`NO DIFFERENCE`), and l7_expect.py
  rebuilds its rows (`--agent blind_seed0`).
- **G6.4**: X1's scratch sighted_seed0 under d2 is refused with a PLANT MISMATCH on exactly `scenario` and
  `episodes_sha` (the protocol's two FATAL fields; schema 4's other FATAL fields agree).
- **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
  `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
  SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
  result pending until the next test header.
- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
  runs.
- **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
- **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
  record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
  list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
  (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
  no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
- **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
  eight processes as run_l6.sh starts them; four evaluate.py at once in G6.

## 8. What the kit asks of p_gate.sh and the plan (all done on 7 November, review fixes 2)

1. Done as it was: `cert-kit` installs INTEGRATION.md into S (so it is archived) and appends a /dev/null diff of every
   new file to S/TOOL_EDITS.md, beside the diffs TOOL_EDITS_commit_P.md already holds (the two must agree).
2. Done: `cert_ready` ast-parses every kit `.py` and json-loads `reproduce_P.json` and cert_P.json, and requires
   cert-kit's smoke step to have passed on the tools installed (`G/cert_kit_smoke.ok`).
3. Done: `archive_ok`'s member list adds `reproduce_P.json`, `tools/failing_sets_P.py`, `tools/stated_counts_P.py`.
4. Done: P_GATE_PLAN.md 5.2 marks K4-K8 written (drafts, reviewed once, revised); 7.2 and 7.23 point here; HP7.6 and
   G7.5 are gates of pre (section 6, items 1-2).
5. Also in p_gate.sh now: the cert-recheck phase (2.1b); make_cert_ok's acceptance of a re-checked FAIL (2.2); cert's
   handling of the driver's exit 3 (2.1); check no longer depends on cert-kit's marker (a certificate redone on a new
   S never clears the check's), and still refuses to start without the kit.

The full-tree copies the kit makes outside S hold logs/epa/ like the clone (never opened): `CERT_ROOT/preRV` (G2.3,
removed by the driver), `CERT_ROOT/vdcheck_P` (K8's pre-check, removed), and S/tcl holds commit A's EPA Test Car
Lists and the NCAT folder (G7.1; not archived: SKIP_DIRS). P_GATE_PLAN.md's H4 discloses them and H8 deletes what
is left.

## 9. UNKNOWN

1. Every expectation of section 7 holds on P's tree: nothing ran. In particular whether harness.py, l6_agents.py and
   lab_dump.py still run at P (they call engine_env's constructors and records P edited: a crash reads as fewer
   than N exit 0, or a failed run, never as identical), and whether P's evaluate.py, test_reward.py and check_roads.py
   print what cf43fbb's printed (P edits all three; G3.1, G3.2, G6.3 and G6.4 would read a moved line as a FAIL).
2. Whether the app suites, test_epa_map.py and fetch_engine_data.py behave in a clone as in the repository: the clone
   has no runs/ (but X1's sighted_seed0 meta.json), runs_c4/ or other gitignored local data beyond the three paths
   cert-prep copies (review fixes 3). A test that needs more may fail only in the clone, which failing_sets_P.py
   reads as "candidate only" unless one of the references failed it too; the survey's committed_data stage shows it
   before the window.
3. ~~Whether cf43fbb's evaluate.py takes `--out` with X1's blind_seed0 by absolute path and labels it as P's does.~~
   Answered by reading (review fixes 3): cf43fbb's evaluate.py:467-470 labels a model path containing "blind" as
   `agent (blind) <path>`, and :556-557 writes only `--out` (its folder made if needed), nothing into the X1 run
   directory.
4. Whether the lab's node tests and launch.py behave in S/cand at P (B12 anchors on engine_env.py's text, which P
   edits), and whether `timeout 300` stops launch.py's server so that port 8765 is free afterwards.
5. Whether a class the driver judges by name has a test skipped by design (it would read FAIL).
6. Whether test_preview_horizon.py, test_tit_cap.py and test_epa_plants.py accept `-v` (unittest's main does).
7. The durations of section 5 (ASSUMED), and so whether the certificate ends inside the check's window.
8. make_md.py's page for P beyond the edited lines: it was written for commit A's certificate; other sentences may
   read oddly for P (read the draft).
9. Whether verify_docs.py accepts the page: cert_P.json carries commit A's three page_markers; K8's pre-check runs
   verify_docs.py with the draft in a copy of the clone and reports, without a record, before cert-docs.
10. The base of TOOL_EDITS' diffs is the archive at the time of drafting (REPO's committed archive = RV's); if RV's
    amendment replaced the archive, cert-kit's own diffs (against X) are the ones that count.
