#!/usr/bin/env bash
# env_P.sh -- the variables every command of P's certificate uses (CERT_PLAN_P.md; commit A's env_A.sh as P
# amends it; build step 2, ORDER step 14). DRAFT of 7 November 2026, not run. Git Bash: `source <S>/env_P.sh`
# at the top of every block (shell state does not persist between calls). S is this file's own folder.
#
# REPO's role -- the candidate every entry point, writer and suite runs in -- is taken by the git clone at P's
# candidate, CERT_TREE (committed and clean; row 139 (2): every entry-point command in REPO or a git clone),
# which p_gate.sh exports. The live repository is LIVE_REPO: read for runs/extremes_dt1 (gitignored, so not in
# the clone: L6 and L7 read X1's agents there by absolute path, as l6_agents.py already does) and never
# written by the certificate's runs; only F.3 (p_gate.sh cert-docs) writes the certificate's three files there.
# CAND is the clone. Every archived tool fell back to the live repository's path when CAND was unset; the
# tools the drivers run (TOOL_EDITS.md, commit P) now stop instead, and a writer still names its copy per call
# (CAND=$S/candw ...).
#
# Exported for the drivers (P_GATE_PLAN.md 5.2, item 1): S and SW; PY; REPO and RW (the clone); LIVE_REPO and
# LRW; X1_RUNS; CAND; CERT_ROOT (the folder above S: candg, X, and the drivers' scratch outside S); CERT_X (the
# archive extracted whole, read only); COMMIT_A_S (commit A's own S: its tcl/ lists); P_GATE_OUT (p_gate.sh's
# out/: RV's base logs, read only); NODE and NPM; the thread and bytecode variables; and rec.
S=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export S
export SW=$(cygpath -m "$S")                                  # S for Python arguments
export PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
[ -n "${CERT_TREE:-}" ] || { echo "env_P.sh: CERT_TREE is unset (p_gate.sh exports the clone at the candidate)" >&2; return 2 2>/dev/null || exit 2; }
if [ -n "${CERT_S:-}" ] && [ "$(cd "$CERT_S" 2>/dev/null && pwd)" != "$S" ]; then
  echo "env_P.sh: sourced from $S, and p_gate.sh's CERT_S is $CERT_S" >&2; return 2 2>/dev/null || exit 2
fi
export REPO="$CERT_TREE"                                       # the candidate, the clone (bash paths)
export RW=$(cygpath -m "$CERT_TREE")                           # the same, for Python arguments
export LIVE_REPO=/c/Users/badcl/Desktop/GRAD-project           # the live repository: runs/ read, nothing written
export LRW=C:/Users/badcl/Desktop/GRAD-project
export X1_RUNS="$LRW/runs/extremes_dt1"                        # X1's agents (L6, L7), by absolute path
export CAND="$CERT_TREE"                                       # the tools' tree: the clone, never the live one
export CERT_ROOT=$(dirname "$S")                               # p_gate.sh's GD/cert: S, X and candg live here
export CERT_X="$CERT_ROOT/X"                                   # the archive extracted whole: read, never run, never packed
export COMMIT_A_S="${COMMIT_A_S:-/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2}"
export P_GATE_OUT="${P_GATE_OUT:-$(dirname "$CERT_ROOT")/out}" # p_gate.sh's G: RV's base logs (base_app_*.log)
export NODE="${NODE:-$(command -v node 2>/dev/null || echo '/c/Program Files/nodejs/node.exe')}"
export NPM="${NPM:-$(command -v npm 2>/dev/null || echo '/c/Program Files/nodejs/npm')}"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONIOENCODING=utf-8 PYTHONDONTWRITEBYTECODE=1
export PIP_DISABLE_PIP_VERSION_CHECK=1
# -I ignores PYTHONDONTWRITEBYTECODE: every `$PY -I` call of the plan is written `$PY -I -B` (the task's rule:
# every python call with -B), and every tool that starts python itself passes -B (TOOL_EDITS.md, commit P)
rec() { "$PY" -I -B "$SW/tools/cert_record.py" "$@"; }        # rec <group> --level ... (cert_record.py)
[ "$(git -C "$CERT_TREE" rev-parse HEAD 2>/dev/null)" = "${P_CAND:-}" ] \
  || { echo "env_P.sh: CERT_TREE's HEAD is not P_CAND (${P_CAND:-unset})" >&2; return 2 2>/dev/null || exit 2; }
