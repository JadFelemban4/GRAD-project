#!/usr/bin/env bash
# env_A.sh -- the variables every command of CERT_PLAN_A.md uses (commit A's certificate run,
# build step 2, 22 October 2026). Git Bash: `source <S>/env_A.sh` at the top of every block
# (shell state does not persist between calls). S is this file's own folder, so the plan's
# commands also run from the unpacked certificate archive.
S=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export S
export SW=$(cygpath -m "$S")                                  # S for Python arguments
export PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
export REPO=/c/Users/badcl/Desktop/GRAD-project                # the candidate (bash paths)
export RW=C:/Users/badcl/Desktop/GRAD-project                  # the same, for Python arguments
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONIOENCODING=utf-8
unset CAND                                                     # each writer sets CAND itself
rec() { "$PY" -I "$SW/tools/cert_record.py" "$@"; }            # rec <group> --level ... (cert_record.py)
