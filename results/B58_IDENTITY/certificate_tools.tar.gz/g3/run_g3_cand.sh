#!/usr/bin/env bash
# G3-roads, the candidate half of tools/run_roads_review.sh (CERT_PLAN_A.md G3.2), in S/cand.
# The commands are the plan's, one after another; each step's start and end go to g3/cand_chain.log.
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
L=$S/g3/cand_chain.log
echo "start $(date '+%F %T') epoch $(date +%s)" > $L
echo "step extremes start $(date +%s)" >> $L
CAND=$S/cand bash $S/tools/run_writer.sh cand roads_extremes results/training_roads_extremes.json check_roads.py --road extremes >> $L 2>&1
echo "step extremes end $(date +%s)" >> $L
echo "step wideair start $(date +%s)" >> $L
CAND=$S/cand bash $S/tools/run_writer.sh cand roads_wideair  results/training_roads_wideair.json  check_roads.py --road wideair >> $L 2>&1
echo "step wideair end $(date +%s)" >> $L
echo "step terrain start $(date +%s)" >> $L
( cd $S/cand && cp -p results/training_roads.json $S/F11/cand_training_roads_committed.json && s=$(date +%s) \
  && $PY check_roads.py > $S/F11/cand_roads_terrain_stdout.txt 2> $S/F11/cand_roads_terrain_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/cand_roads_terrain_exit.txt; \
  cp -p results/training_roads.json $S/F11/cand_roads_terrain_OUT_training_roads.json; \
  cp -p $S/F11/cand_training_roads_committed.json results/training_roads.json )
echo "step terrain end $(date +%s): $(cat $S/F11/cand_roads_terrain_exit.txt)" >> $L
echo "step random start $(date +%s)" >> $L
( cd $S/cand && s=$(date +%s) && $PY check_random_road.py > $S/F11/cand_random_road_stdout.txt 2> $S/F11/cand_random_road_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/cand_random_road_exit.txt )
echo "step random end $(date +%s): $(cat $S/F11/cand_random_road_exit.txt)" >> $L
echo "done $(date '+%F %T')" >> $L
