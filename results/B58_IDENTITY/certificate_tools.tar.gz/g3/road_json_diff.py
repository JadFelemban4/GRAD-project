"""road_json_diff.py -- what differs between two check_roads.py outputs (G3-roads, commit A).

    python -I road_json_diff.py <a.json> <b.json> [--json out.json]

Exact comparison (==, no tolerance) of the top-level fields and of every road, key by key:
keys only in a, keys only in b, keys in both with a different value (the first such value
is printed). Prints IDENTICAL when the two parsed documents are equal, else a summary.
Used for the comparison against the committed file, which the byte comparison (cmp) cannot
explain; the identity against the reference is cmp's, byte for byte.
"""
import json
import sys

a_path, b_path = sys.argv[1], sys.argv[2]
out = sys.argv[sys.argv.index("--json") + 1] if "--json" in sys.argv else None
with open(a_path, encoding="utf-8") as fh:
    A = json.load(fh)
with open(b_path, encoding="utf-8") as fh:
    B = json.load(fh)

res = dict(a=a_path, b=b_path, identical=(A == B))
top = sorted(set(A) | set(B))
res["top_only_a"] = [k for k in top if k not in B]
res["top_only_b"] = [k for k in top if k not in A]
res["top_changed"] = {k: [A[k], B[k]] for k in top if k in A and k in B and k != "roads" and A[k] != B[k]}
ra, rb = A.get("roads", []), B.get("roads", [])
res["n_roads"] = [len(ra), len(rb)]
only_a, only_b, changed, first = {}, {}, {}, None
for i, (x, y) in enumerate(zip(ra, rb)):
    for k in sorted(set(x) | set(y)):
        if k not in y:
            only_a[k] = only_a.get(k, 0) + 1
        elif k not in x:
            only_b[k] = only_b.get(k, 0) + 1
        elif x[k] != y[k]:
            changed[k] = changed.get(k, 0) + 1
            if first is None:
                first = dict(road=i, seed=x.get("seed"), key=k, a=x[k] if not isinstance(x[k], list) else x[k][:3],
                             b=y[k] if not isinstance(y[k], list) else y[k][:3])
res.update(keys_only_a=only_a, keys_only_b=only_b, keys_changed=changed, first_changed=first)
if res["identical"]:
    print(f"IDENTICAL: {len(ra)} roads, {len(top)} top-level fields")
else:
    print(f"DIFFERENT: roads {len(ra)} / {len(rb)}")
    print(f"  top-level only in a: {res['top_only_a']}; only in b: {res['top_only_b']}; changed: {res['top_changed']}")
    print(f"  road keys only in a (count of roads): {only_a}")
    print(f"  road keys only in b (count of roads): {only_b}")
    print(f"  road keys with another value (count of roads): {changed}")
    print(f"  first changed value: {first}")
if out:
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(res, fh, indent=1, default=str)
        fh.write("\n")
