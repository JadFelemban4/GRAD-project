#!/usr/bin/env bash
# G3-roads, the reference half of tools/run_roads_review.sh (the 40 terrain roads and
# check_random_road.py), run again in a private git archive of cf43fbb ($1, outside S, so that
# S/ref, which G1 and G6 read, never has a file rewritten, and make_archive does not pack it).
# The commands are run_roads_review.sh's for t=ref, with the outputs named A_G3_ref_* so that build
# step 1's reference evidence (F11/ref_*) is kept and compared against.
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
R=$1; t=A_G3_ref
L=$S/g3/ref_chain.log
echo "start $(date '+%F %T') epoch $(date +%s) tree $R" > $L
echo "step terrain start $(date +%s)" >> $L
( cd $R && cp -p results/training_roads.json $S/F11/${t}_training_roads_committed.json && s=$(date +%s) \
  && $PY check_roads.py > $S/F11/${t}_roads_terrain_stdout.txt 2> $S/F11/${t}_roads_terrain_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/${t}_roads_terrain_exit.txt; \
  cp -p results/training_roads.json $S/F11/${t}_roads_terrain_OUT_training_roads.json; \
  cp -p $S/F11/${t}_training_roads_committed.json results/training_roads.json )
echo "step terrain end $(date +%s): $(cat $S/F11/${t}_roads_terrain_exit.txt)" >> $L
echo "step random start $(date +%s)" >> $L
( cd $R && s=$(date +%s) && $PY check_random_road.py > $S/F11/${t}_random_road_stdout.txt 2> $S/F11/${t}_random_road_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/${t}_random_road_exit.txt )
echo "step random end $(date +%s): $(cat $S/F11/${t}_random_road_exit.txt)" >> $L
echo "done $(date '+%F %T')" >> $L
