"""Compare the page-data JSON blobs of two built pages, meta aside (G5, commit A)."""
import json, re, sys
def blob(p):
    t = open(p, encoding="utf-8").read()
    m = re.search(r'<script type="application/json" id="page-data">(.*?)</script>', t, re.S)
    return json.loads(m.group(1))   # JSON reads the page's "<\/" as "</"
a, b = blob(sys.argv[1]), blob(sys.argv[2])
print("meta a:", a.pop("meta")); print("meta b:", b.pop("meta"))
keys = sorted(set(a) | set(b))
diff = [k for k in keys if a.get(k) != b.get(k)]
print(len(keys), "top-level keys besides meta;", "differing:", diff)
for k in diff:
    if k == "gl":
        ga, gb = a[k], b[k]
        print("  gl keys differing:", sorted(x for x in set(ga) | set(gb) if ga.get(x) != gb.get(x)))
sys.exit(1 if diff else 0)
