"""trace_fuel_route.py <tree>: derive_params.derive_thermal's drive loading (calibrate_thermal.usable_drives and
load_drive, no fit), with car_thermal.measured_fuel_gps wrapped to record each call's afr_st (its double's hex)
and the plant's fuel afr_st beside it. Read only: nothing is written into the tree."""
import os, sys
tree = os.path.abspath(sys.argv[1]); os.chdir(tree); sys.path.insert(0, tree)
os.environ["DERIVING_PARAMS"] = "1"           # as derive_params.py sets it
import car_thermal as CT, calibrate_thermal as K, engines
calls = []
orig = CT.measured_fuel_gps
def wrapped(*a, **kw):
    calls.append(kw.get("afr_st", "<positional or absent>"))
    return orig(*a, **kw)
CT.measured_fuel_gps = wrapped
names, excluded = K.usable_drives()
drives = [d for d in (K.load_drive(s) for s in names) if d is not None]
own = engines.typed_engine("b58").fuel.afr_st
print(f"usable drives {len(names)}, loaded {len(drives)} (derive_params printed '7 drives')")
print(f"measured_fuel_gps calls: {len(calls)}; afr_st values: {sorted({c.hex() if isinstance(c, float) else c for c in calls})}")
print(f"typed_engine('b58').fuel.afr_st = {own!r} ({own.hex()})")
ok = len(calls) == len(names) and all(isinstance(c, float) and c.hex() == own.hex() for c in calls)
print("ROUTE:", "every drive's fuel through measured_fuel_gps(afr_st=the B58 fuel's afr_st)" if ok else "NOT AS EXPECTED")
sys.exit(0 if ok else 1)
