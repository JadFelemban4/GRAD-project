#!/usr/bin/env bash
# run_l6.sh -- L6: four X1 agents x twenty frozen episodes, in both trees, 8 processes at once
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
SW=$(cygpath -m "$S")
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
CAND=$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")
REF="$SW/ref"
for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
  for t in cand ref; do
    tree=$CAND; [ $t = ref ] && tree=$REF
    ( $PY -I "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
  done
done
wait
echo "L6 done: $(grep -c '^0 ' $S/L6/_status.txt) of $(wc -l < $S/L6/_status.txt) exit 0"
