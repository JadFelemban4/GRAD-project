#!/usr/bin/env bash
# run_drift.sh -- drift_test.py in six parts at once (rows 1-3, 4-6, ..., 16-18; rows 17 and 18
# joined on 21 October 2026). Each part runs drift_test's own control on an undrifted copy first,
# then its rows, each on a fresh copy; the rows are independent, so the six parts are the one
# command split for time. The verdict line sums the parts.
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
cd "${CAND:-/c/Users/badcl/Desktop/GRAD-project}" || exit 9
export PYTHONIOENCODING=utf-8
mkdir -p $S/suites
rm -f $S/suites/drift_part*.txt
s=$(date +%s)
i=0
for rows in "1 2 3" "4 5 6" "7 8 9" "10 11 12" "13 14 15" "16 17 18"; do
  i=$((i+1))
  ( $PY drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
done
wait
{ for j in $(seq 1 $i); do echo "### part $j"; cat $S/suites/drift_part$j.txt; done; } > $S/suites/drift_test.txt
caught=$(grep -h "drifts CAUGHT" $S/suites/drift_part*.txt | awk '{s+=$1; t+=$3} END {print s " of " t}')
echo "exit codes: $(grep -h '^exit' $S/suites/drift_part*.txt | tr '\n' ';') in $(( $(date +%s) - s )) s; $caught drifts CAUGHT" > $S/suites/drift_test_exit.txt
echo "$caught drifts CAUGHT (all parts)" >> $S/suites/drift_test.txt
cat $S/suites/drift_test_exit.txt
