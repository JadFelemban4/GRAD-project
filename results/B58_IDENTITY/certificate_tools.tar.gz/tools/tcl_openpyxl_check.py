"""tcl_openpyxl_check.py -- the cars' EPA Test Car List rows, read with openpyxl / csv
(not epa_map.read_xlsx), against engine_specs/cars/*.toml.

    <anaconda python> -I tcl_openpyxl_check.py <repo> <data folder> <extra folder>
"""
import csv
import glob
import hashlib
import io
import os
import sys
import tomllib

import openpyxl

repo, data, extra = sys.argv[1], sys.argv[2], sys.argv[3]
COLS = {
    "model_year": "Model Year", "represented_model": "Represented Test Veh Model",
    "test_vehicle_id": "Test Vehicle ID", "engine_code": "Engine Code",
    "equivalent_test_weight_lb": "Equivalent Test Weight (lbs.)", "target_coef_a_lbf": "Target Coef A (lbf)",
    "target_coef_b_lbf_per_mph": "Target Coef B (lbf/mph)", "target_coef_c_lbf_per_mph2": "Target Coef C (lbf/mph**2)",
    "axle_ratio": "Axle Ratio", "n_over_v_rpm_per_mph": "N/V Ratio", "rated_hp": "Rated Horsepower",
    "tested_transmission": "Tested Transmission Type",
}
src = {}
with open(os.path.join(repo, "logs", "epa", "D3_AND_EPA_SOURCES.csv"), encoding="utf-8", newline="") as fh:
    for r in csv.DictReader(fh):
        src[r["url"]] = r


def sha(p):
    with open(p, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


cache = {}


def rows_of(path):
    if path in cache:
        return cache[path]
    if path.lower().endswith(".xlsx"):
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.worksheets[0]
        grid = {i + 1: list(r) for i, r in enumerate(ws.iter_rows(values_only=True))}
        names = (wb.sheetnames, ws.title)
        wb.close()
    else:
        raw = open(path, "rb").read()
        for enc in ("utf-8-sig", "cp1252"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        grid = {i + 1: r for i, r in enumerate(csv.reader(io.StringIO(text)))}
        names = ("csv", enc)
    head = [str(h).strip() if h is not None else "" for h in grid[1]]
    out = {n: dict(zip(head, r)) for n, r in grid.items() if n > 1}
    cache[path] = (out, names, head)
    return cache[path]


for p in sorted(glob.glob(os.path.join(repo, "engine_specs", "cars", "*.toml"))):
    spec = tomllib.load(open(p, "rb"))
    for row in [spec["epa_test_car"]] + spec.get("epa_test_car_other_rows", []):
        url = spec["sources"][row["source"]]["url"]
        s = src[url]
        cands = [os.path.join(data, s["rel_path"]), os.path.join(extra, os.path.basename(s["rel_path"]))]
        path = next((c for c in cands if os.path.exists(c) and sha(c) == s["sha256"]), None)
        if path is None:
            print(f"{spec['car_id']}: {os.path.basename(url)} not found on this machine")
            continue
        rows, names, head = rows_of(path)
        missing = [c for k, c in COLS.items() if k in row and c not in head]
        print(f"{spec['car_id']}: {os.path.basename(path)} sheets={names} rows {row['file_rows']}"
              + (f"  COLUMNS NOT IN FILE: {missing}" if missing else ""))
        for n in row["file_rows"]:
            got = rows.get(n)
            diffs = []
            for k, c in COLS.items():
                if k not in row:
                    continue
                v = got.get(c)
                a = row[k]
                try:
                    ok = float(a) == float(v)
                except (TypeError, ValueError):
                    ok = str(a).strip() == str(v).strip()
                if not ok:
                    diffs.append(f"{k}: toml {a!r} file {v!r}")
            print(f"   row {n}: " + ("all fields equal" if not diffs else "; ".join(diffs)))
            print("     by hand: " + ", ".join(f"{c}={got.get(c)!r}" for c in
                                            ("Model Year", "Represented Test Veh Model", "Test Vehicle ID",
                                             "Equivalent Test Weight (lbs.)", "Target Coef A (lbf)",
                                             "Target Coef B (lbf/mph)", "Target Coef C (lbf/mph**2)",
                                             "Axle Ratio", "N/V Ratio")))
