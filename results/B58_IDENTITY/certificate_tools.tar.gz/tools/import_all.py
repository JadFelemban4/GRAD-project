"""import_all.py -- import every .py of a tree copy, one subprocess each, and report failures.

    python import_all.py <tree> <out.json>

Root files import as their stem with cwd=<tree>; app/*.py as app.<stem>; Explanatory
Simulation/backend/*.py as backend.<stem> with cwd=<tree>/Explanatory Simulation;
everything else (tests, presentation) by file location with its own folder on sys.path,
which is how `python <file>` would see it. The __main__ block never runs.
"""
import json
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

tree, out = sys.argv[1], sys.argv[2]
FROZEN = {"drive_c_analysis.py", "drive_c_rule_numbers.py", "drive_c_check.py", "test_drive_c_analysis.py"}
names = subprocess.run(["git", "-C", "C:/Users/badcl/Desktop/GRAD-project", "ls-files", "--cached", "--others",
                        "--exclude-standard", "*.py"], capture_output=True, text=True, check=True).stdout.split("\n")
jobs = []
for rel in (n for n in names if n):
    if rel in FROZEN:
        continue
    parts = rel.split("/")
    if len(parts) == 1:
        jobs.append((rel, tree, f"import {parts[0][:-3]}"))
    elif parts[0] == "app" and len(parts) == 2:
        jobs.append((rel, tree, f"import app.{parts[1][:-3]}"))
    elif parts[:2] == ["Explanatory Simulation", "backend"]:
        jobs.append((rel, os.path.join(tree, "Explanatory Simulation"), f"import backend.{parts[2][:-3]}"))
    else:
        path = os.path.join(tree, rel).replace("\\", "/")
        folder = os.path.dirname(path)
        code = ("import sys, importlib.util; sys.path.insert(0, %r); "
                "s = importlib.util.spec_from_file_location('_probe_mod', %r); "
                "m = importlib.util.module_from_spec(s); s.loader.exec_module(m)") % (folder, path)
        jobs.append((rel, folder, code))

env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", PYTHONDONTWRITEBYTECODE="1")


def run(job):
    rel, cwd, code = job
    try:
        r = subprocess.run([sys.executable, "-c", code], cwd=cwd, env=env, capture_output=True,
                           text=True, timeout=300)
        tail = (r.stderr.strip().splitlines() or [""])[-1]
        return rel, r.returncode, tail
    except subprocess.TimeoutExpired:
        return rel, "timeout", ""


with ThreadPoolExecutor(6) as ex:
    res = list(ex.map(run, jobs))
bad = [r for r in res if r[1] != 0]
for r in bad:
    print(f"FAIL {r[0]}: {r[1]} {r[2]}")
print(f"{len(res)} imported, {len(bad)} failed")
with open(out, "w", encoding="utf-8") as fh:
    json.dump(res, fh, indent=1)
