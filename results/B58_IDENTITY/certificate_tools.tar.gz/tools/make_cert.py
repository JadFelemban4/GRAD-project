"""make_cert.py -- results/B58_IDENTITY.json from the certification's own evidence files.

    python -I make_cert.py <out.json> [<archive.tar.gz>]

Every value below is READ from a file the certification wrote (the dumps'
comparisons, the suites' outputs, the manifests, review.json); nothing is typed
except the descriptions. A level whose evidence file is missing is written as
MISSING, never as passed.

THIS IS THE SECOND CERTIFICATE (21 October 2026). Build step 1 was certified once
(scratchpad build1b/certify, 00:29-03:43); two reviews then found 21 things, and
the fixes changed the plant's code (not one of its numbers is meant to move), so
every level ran again on the corrected tree. The reference side did not change --
the same git archive of cf43fbb, the same reference-side code in the same tools --
so its evidence is the first run's, copied into this folder (S/out/ref, S/L4/ref_*,
S/L5/ref_*, S/L6/ref_*, S/L7/ref_*, S/app/ref*, S/lab/lab_ref.json); L8's reference
runs, deleted after the first certificate, were made again. S is the folder above
tools/: it holds the evidence of this run.
"""
import difflib
import hashlib
import json
import os
import re
import sys

S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SW = S.replace("\\", "/")
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = sys.argv[1]
ARCHIVE = sys.argv[2] if len(sys.argv) > 2 else None
HEAD = __import__("subprocess").run(["git", "rev-parse", "HEAD"], cwd=REPO, capture_output=True,
                                    text=True).stdout.strip() or None
MISSING = "MISSING"


def p(*parts):
    return os.path.join(S, *parts)


def read(*parts, default=None):
    try:
        with open(p(*parts), encoding="utf-8", errors="replace") as fh:
            return fh.read().replace("\r\n", "\n")
    except OSError:
        return default


def js(*parts):
    t = read(*parts)
    return None if t is None else json.loads(t)


def sha_bytes(path, n=64):
    try:
        with open(path, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()[:n]
    except OSError:
        return None


def text_sha(t):
    return hashlib.sha256(t.encode()).hexdigest()[:16]


def slug(job):
    return re.sub(r"[^A-Za-z0-9.-]+", "_", job).strip("_")


def first_diffs(cmpjson):
    """Every DIFFERENT key of a cmp.py JSON, with its first differing value."""
    return [{x: k.get(x) for x in ("key", "status", "n", "n_differ", "first_flat", "first_index",
                                   "first_a", "first_b", "max_abs") if x in k}
            for k in cmpjson["keys"] if k["status"] != "IDENTICAL"]


def harness(label_a, label_b, jobs):
    rows = []
    for j in jobs:
        c = js("cmp", f"{label_a}_vs_{label_b}", slug(j) + ".json")
        if c is None:
            rows.append(dict(job=j, result=MISSING))
            continue
        row = dict(job=j, values=c["values"], arrays=len(c["keys"]),
                   result="BIT-IDENTICAL" if c["identical"] else "DIFFERENT")
        if not c["identical"]:
            d = first_diffs(c)
            row.update(arrays_different=len(d), first_different=d[0], different=d)
        rows.append(row)
    return rows


def summary(rows):
    ok = [r for r in rows if r["result"] == "BIT-IDENTICAL"]
    return dict(jobs=len(rows), identical=len(ok), values=sum(r.get("values", 0) for r in rows),
                result=("BIT-IDENTICAL" if len(ok) == len(rows) else
                        MISSING if any(r["result"] == MISSING for r in rows) else "DIFFERENT"))


def unittest_summary(text):
    """Ran / OK / FAILED (...) and the ids of failing tests, from unittest's output."""
    if text is None:
        return MISSING
    ran = re.findall(r"^Ran (\d+) tests? in ([\d.]+)s", text, re.M)
    tail = re.findall(r"^(OK(?: \([^)]*\))?|FAILED \([^)]*\))\s*$", text, re.M)
    fails = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\S+ \([^)]*\))", text, re.M)))
    return dict(ran=int(ran[-1][0]) if ran else None, verdict=tail[-1] if tail else None,
                failing=[f.split(" (")[0] + " (" + f.split(" (")[1] for f in fails])


def status(*parts):
    """{label: (exit, seconds)} from a "<exit> <seconds> <label>" status file."""
    out = {}
    for ln in (read(*parts, default="") or "").splitlines():
        bits = ln.split(maxsplit=2)
        if len(bits) == 3 and bits[0].lstrip("-").isdigit() and bits[1].isdigit():
            out[bits[2]] = dict(exit=int(bits[0]), seconds=int(bits[1]))
    return out


def same_file(a, b):
    ta, tb = read(*a), read(*b)
    if ta is None or tb is None:
        return MISSING
    return ta == tb


def line_diff(a, b, n=6):
    ta, tb = read(*a), read(*b)
    if ta is None or tb is None:
        return MISSING
    return [ln for ln in difflib.unified_diff(ta.splitlines(), tb.splitlines(), "reference", "candidate",
                                              lineterm="", n=0)][:n * 4]


def lines_matching(text, pattern):
    return None if text is None else [ln.strip() for ln in text.splitlines() if re.search(pattern, ln)]


cert = {}
cert["what"] = ("Build step 1's identity certificate, made again after its review: the B58 built "
                "through engines.get('b58') on branch GRA-test (the uncommitted working tree of build "
                "step 1 with the review's fixes) against the plant of commit cf43fbb (a git archive), on "
                "one interpreter, every number compared by its bytes (numpy tobytes()).")
cert["date"] = "2026-10-21"
cert["asked_by"] = ("decision 24, results/VALIDATION_DECISIONS.md section F: the four-engine build threads "
                    "Engine and Car objects through the code with no default engine; the B58 built that way "
                    "must be bit-identical to cf43fbb (build step 1). Made again after the review of 21 "
                    "October 2026, whose fixes changed the plant's code")

# ------------------------------------------------------------- the two trees
m0, m1 = read("manifest_start.txt", default=""), read("manifest_end.txt")


def manifest_rows(t):
    return dict(reversed(ln.split("  ", 1)) for ln in (t or "").splitlines() if "  " in ln)


r0, r1 = manifest_rows(m0), manifest_rows(m1)
changed = sorted(n for n in set(r0) | set(r1) if r0.get(n) != r1.get(n))
cert["reference"] = dict(
    commit="cf43fbb0442125d48cee2316bb96fdeb52b4e145",
    how=("git archive --format=tar cf43fbb (certify/cf43fbb.tar), extracted into scratch trees and checked "
         "with tar --compare (no content or size difference). Its evidence is the first certificate's, "
         "copied here: the reference tree and the reference-side code of the tools did not change. L8's "
         "reference runs were made again in a fresh extraction (S/ref)."),
    archive_sha256=sha_bytes(os.path.join(os.path.dirname(S), "certify", "cf43fbb.tar")))
cert["candidate"] = dict(
    tree=r"C:\Users\badcl\Desktop\GRAD-project (the working tree)", branch="GRA-test",
    head=HEAD,
    head_note=("build step 1 and the review's fixes, uncommitted. HEAD was 96884f1 (a session report) when "
               "the runs began and moved to e9e16ed during them: another session committed "
               "results/VALIDATION_DECISIONS.md (decisions 27, 32 and 34 revised), a document, and nothing "
               "else; cf43fbb..HEAD touches four documents and no code"),
    files=len([ln for ln in m0.splitlines() if ln.strip()]),
    manifest="sha256 of every file git ls-files --cached --others --exclude-standard lists",
    manifest_sha256_start=text_sha(m0),
    manifest_sha256_end=None if m1 is None else text_sha(m1),
    files_changed_during_the_runs=changed,
    files_changed_note=("none of them is code a level computes with: CHECKPOINT.md, README.md and "
                        "STATE_HISTORY.md are the documents swept with the review's results; "
                        "results/VALIDATION_DECISIONS.md was committed by another session (e9e16ed: decisions "
                        "27, 32 and 34 revised); fingerprint.py changed in its docstring only (its code, "
                        "_code_only, is the same), wide_air.py in a comment, and engine_specs/a90_supra.toml in "
                        "a comment that named decision 34 before its revision (its values, which plant_sha "
                        "and engine_sha hash, are the same: ded8da308863d394 and 99d2a9658b1258a7 printed "
                        "after it); full_run.py in the expected-output text of three blocks (the test counts); "
                        "test_wide_air.py in a stand-in's parameter, renamed so the name scan does not take it "
                        "for plant.py (its 17 tests ran after the change)"))

fp_ref, fp_cand = read("out", "fp_ref.txt", default=""), read("out", "fp_cand.txt", default="")


def fpfield(t, k):
    m = re.search(rf"^\s+{k}\s+(.+?)\s*$", t, re.M)
    return m.group(1) if m else None


first = js("first_certificate.json") or {}
cert["identity"] = dict(
    plant_sha=dict(reference=fpfield(fp_ref, "plant_sha"), candidate=fpfield(fp_cand, "plant_sha"),
                   x1_meta_json="3c48890dd15bc116", first_certificate=first.get("plant_sha")),
    derived_sha=dict(reference=fpfield(fp_ref, "derived_sha"), candidate=fpfield(fp_cand, "derived_sha")),
    engine=fpfield(fp_cand, "engine"), engine_sha=fpfield(fp_cand, "engine_sha"),
    engine_sha_first_certificate=first.get("engine_sha"),
    backend=fpfield(fp_cand, "backend"),
    episodes_sha=dict(reference=fpfield(fp_ref, "episodes_sha"), candidate=fpfield(fp_cand, "episodes_sha")),
    shared_fatal_fields={k: [fpfield(fp_ref, k), fpfield(fp_cand, k)] for k in
                         ("gears", "final_drive", "dtheta_deg", "turb_protect_k", "oil_protect_k", "scenario")},
    schema=dict(reference=2, candidate=3),
    why_plant_sha_moves=("the B58's plant files are fingerprint.plant_files('b58'): the code of plant.py, "
                         "thermal.py, engine_env.py, derived.py and engines.py, and the values of "
                         "engine_specs/b58.toml and a90_supra.toml. engines.py and the specs are new, and the "
                         "code of the others changed form (literals became record fields): plant_sha moves "
                         "although every number is the same. It moved again with the review's fixes."),
    why_engine_sha_moves=("engine_sha hashes every value of the plant as built. The review moved the "
                          "deliverable-torque table's conditions -- its grid, 42 C, the 365 K block, 30 "
                          "settling steps -- from measure_deliverable_torque's defaults into the car's record "
                          "(engines.Car.table_*), so the record holds six more values; every value it held "
                          "before is the same"),
    printed_by={"reference": "python fingerprint.py (in the archive)",
                "candidate": "python fingerprint.py --engine b58; python engines.py"})

freeze = read("pip_freeze.txt", default="")
cert["environment"] = dict(
    interpreter=r"C:\Users\badcl\Desktop\GRAD-project\.venv\Scripts\python.exe, for every run in both trees",
    python="3.13.2 (tags/v3.13.2:4f8bb39, Feb  4 2025, 15:23:48) [MSC v.1942 64 bit (AMD64)]",
    packages={ln.split("==")[0]: ln.split("==")[1] for ln in freeze.splitlines() if "==" in ln and
              ln.split("==")[0].lower() in ("numpy", "scipy", "pandas", "torch", "stable_baselines3",
                                            "gymnasium", "matplotlib")},
    pip_freeze=dict(lines=len(freeze.splitlines()), sha256=text_sha(freeze)),
    torch_build="2.14.0+cpu",
    node=(read("lab", "versions.txt") or MISSING).strip(),
    machine="Windows 11 Home 10.0.26200; 12th Gen Intel Core i9-12900H (6 P-cores, 8 E-cores, 20 threads)",
    threads=("OMP_NUM_THREADS=1 and MKL_NUM_THREADS=1 for the harness, L6 (with torch.set_num_threads(1)), "
             "L7 and L8; the suites as their own code sets it. Every process is single-threaded, so how many "
             "ran at once changes the time, not a number"),
    rule_4=("CLAUDE.md rule 4 asks for Python 3.12; this machine has 3.11 and 3.13 only. Decision 32 "
            "(revised 21 October, both columns open) would amend rule 4 to the versions the training "
            "device records, pinned, and re-run this certificate on that device. Every run here is 3.13.2, "
            "the interpreter behind X1's stored numbers, on this laptop."))

# ------------------------------------------------------------- the controls
jobs_ctl = [ln.strip() for ln in (read("tools", "jobs_ctl.txt") or "").splitlines() if ln.strip()]
ctl = {}
ctl["reference_against_reference"] = dict(
    expect="BIT-IDENTICAL", what="the harness's control jobs run a second time in the reference (first run)",
    jobs=harness("ref", "ref2", jobs_ctl))
for name, lab, fld in (("one_ulp_thermal_c_turb", "ctl_cturb", "thermal.c_turb"),
                       ("one_ulp_car_mass", "ctl_mass", "car.mass")):
    ctl[name] = dict(
        expect="DIFFERENT",
        what=(f"the corrected candidate with HARNESS_PERTURB={fld}: that one field moved by one ulp through the "
              "frozen records (dataclasses.replace) and put into engines.get's cache, so every call that "
              "fetches the B58 gets it"),
        jobs=harness("cand", lab, jobs_ctl))
l6c = {}
for name, f in (("one_ulp_car_mass_5_episodes", "L6_ctl_mass_committed.json"),
                ("one_ulp_thermal_c_turb_5_episodes", "L6_ctl_cturb_committed.json"),
                ("car_mass_x_1e-9_2_episodes", "L6_ctl_mass1e-9_committed.json"),
                ("car_mass_x_1e-6_2_episodes", "L6_ctl_mass1e-6_committed.json")):
    c = js("cmp", f)
    if c is None:
        l6c[name] = MISSING
        continue
    l6c[name] = dict(scores_equal=f"{c['scores']['equal']} of {c['scores']['compared']}",
                     first_score_difference=c["scores"]["first_difference"],
                     per_step_fields_different=f"{len(c['per_step']['differences'])} of {c['per_step']['fields']}",
                     per_step_first_difference=(c["per_step"]["differences"][0]
                                                if c["per_step"]["differences"] else None),
                     verdict="NOT EQUAL" if not c["identical"] else "EQUAL")
ctl["L6_against_the_committed_files"] = dict(
    expect="NOT EQUAL", what="sighted_seed0 on a perturbed corrected candidate, checked by l6_check.py",
    runs=l6c,
    reading=("the full-precision score check sees a one-ulp change; the per-step check against "
             "eval_record.npz (float32, float16 observation) does not, a 1e-9 relative change it does"))
lab_ulp, lab_rel = read("lab", "compare_lab_ctl_cturb_ulp.txt"), read("lab", "compare_lab_ctl_cturb.txt")
ctl["learning_lab"] = {
    "what": "lab_dump.py with LAB_PERTURB, against the unperturbed corrected candidate",
    "one_ulp_thermal_c_turb": None if lab_ulp is None else lab_ulp.splitlines()[0],
    "one_ulp_verdict": None if lab_ulp is None else lab_ulp.strip().splitlines()[-1],
    "thermal_c_turb_x_(1+1e-9)": None if lab_rel is None else lab_rel.splitlines()[0],
    "relative_verdict": None if lab_rel is None else lab_rel.strip().splitlines()[-1],
    "reading": "the lab's 40-step sessions round one ulp of c_turb away; a 1e-9 relative change moves values"}
l8c = {}
for name, f in (("wrapper_alone", "L8_ctl_none.json"), ("one_ulp_car_mass", "L8_ctl_mass.json"),
                ("one_ulp_thermal_c_turb", "L8_ctl_cturb.json")):
    c = js("cmp", f)
    l8c[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors_not_identical=len(c["weights"]["differing"]),
        train_record_fields_different=len(c["train_record"]["differing"]), identical=c["identical"])
l8x = {}
for name, f in (("car.mass x (1 + 1e-9)", "L8_ctl_mass1e-9.json"), ("car.mass x (1 + 1e-6)", "L8_ctl_mass1e-6.json")):
    c = js("cmp", f)
    l8x[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors_not_identical=len(c["weights"]["differing"]),
        first_tensor_difference=c["weights"]["differing"][0] if c["weights"]["differing"] else None,
        train_record_fields_different=len(c["train_record"]["differing"]),
        identical=c["identical"])
ids8 = js("L8", "run_identities.json") or {}
ctl["L8_training"] = dict(
    what=("the corrected candidate's train.py through l8_perturbed.py (engines.get('b58') replaced before "
          "train.main() runs), against the plain candidate run of the same arguments"),
    expect=dict(wrapper_alone="IDENTICAL", one_ulp="IDENTICAL or DIFFERENT (float32 training)",
                relative_steps="DIFFERENT"),
    runs=l8c, relative_steps=l8x,
    engine_sha_of_each_run={k: v.get("engine_sha") or f"(schema {v.get('schema')})" for k, v in ids8.items()},
    engine_sha_note="read from each run's meta.json before the run directories were deleted")
cert["controls"] = ctl

# ------------------------------------------------------------- the levels
jobs_all = [ln.strip() for ln in (read("tools", "jobs_all.txt") or "").splitlines() if ln.strip()]
L = {}
L["L1_units"] = dict(
    what=("harness job 'units': run_cycle on 1200 operating points x 16 fields, predict, the crank-step pair, "
          "the boost ceiling at three inlets, charge temperature, airflow inversion, the thermal network at "
          "three housings (1801 steps each) and its cold reset, the ECU over 400 steps with knock (both "
          "enrichment modes), the gearbox and road load, the damage model, the locked climb at three steps, "
          "every terrain family's road and speed profile, the deliverable-torque table re-measured (on the "
          "candidate since the review: on the car's own grid and conditions, Car.table_*), the MAP ceiling "
          "and the load loop"),
    rows=harness("ref", "cand", ["units"]))
fam = dict(extremes=[j for j in jobs_all if j.startswith("extremes:")],
           terrain=[j for j in jobs_all if j.startswith("terrain:")],
           random_road=[j for j in jobs_all if j.startswith(("rr:", "rrwrap:"))],
           wideair=[j for j in jobs_all if j.startswith(("wideair:", "wideseq:"))],
           conditions=[j for j in jobs_all if j.startswith("cond:")])
L["L2_roads"] = {k: dict(rows=harness("ref", "cand", v)) for k, v in fam.items()}
for k in list(L["L2_roads"]):
    L["L2_roads"][k]["summary"] = summary(L["L2_roads"][k]["rows"])
L["L2_roads"]["what"] = (
    "every road family: ExtremesTrainingEnv (5 families x neutral and seeded random actions, 900 + 200 steps), "
    "TerrainTrainingEnv (5 families), random_road.climb at dt 0.2 and its RandomClimb wrapper, "
    "WideAirTrainingEnv at the four corners of 0-45 C x 80-101.3 kPa plus a 4-episode sequence (the thin-air "
    "table and the closed-throttle floor, measured in the car's own table conditions since the review), and "
    "conditions_test._run; every step's observation, reward, info and 21 internal state values, the roads")
L["L3_premise"] = dict(
    harness=harness("ref", "cand", ["premise"]),
    check_premise=dict(
        candidate=(read("L5", "cand_premise_exit.txt") or MISSING).strip(),
        reference=(read("L5", "ref_premise_exit.txt") or MISSING).strip(),
        premise_json_cand_equals_ref=same_file(("L5", "cand_premise_OUT_premise.json"),
                                               ("L5", "ref_premise_OUT_premise.json")),
        premise_json_equals_committed=(sha_bytes(p("L5", "cand_premise_OUT_premise.json"))
                                       == sha_bytes(os.path.join(REPO, "results", "premise.json"))),
        premise_json_sha256=sha_bytes(p("L5", "cand_premise_OUT_premise.json"), 16),
        stdout_difference=line_diff(("L5", "ref_premise_stdout.txt"), ("L5", "cand_premise_stdout.txt")),
        where="run in S/cand, a copy of the candidate's file set (copy_tree.py), not the working tree"))
l4 = {}
for tag, name in (("", "test_reward"), ("_random", "test_reward --road random")):
    l4[name] = dict(candidate=(read("L4", f"cand{tag}_exit.txt") or MISSING).strip(),
                    reference=(read("L4", f"ref{tag}_exit.txt") or MISSING).strip(),
                    stdout_identical=same_file(("L4", f"ref{tag}_stdout.txt"), ("L4", f"cand{tag}_stdout.txt")),
                    stdout_bytes_on_disk=(os.path.getsize(p("L4", f"cand{tag}_stdout.txt"))
                                          if os.path.exists(p("L4", f"cand{tag}_stdout.txt")) else MISSING),
                    stdout_sha256=text_sha(read("L4", f"cand{tag}_stdout.txt") or ""),
                    verdict=lines_matching(read("L4", f"cand{tag}_stdout.txt"), r"checks pass|FAIL"))
L["L4_test_reward"] = l4
l5 = {}
for road in ("extremes", "wideair"):
    out_c, out_r = ("L5", f"cand_roads_{road}_OUT_training_roads_{road}.json"), \
                   ("L5", f"ref_roads_{road}_OUT_training_roads_{road}.json")
    committed = os.path.join(REPO, "results", f"training_roads_{road}.json")
    l5[f"check_roads --road {road}"] = dict(
        candidate=(read("L5", f"cand_roads_{road}_exit.txt") or MISSING).strip(),
        reference=(read("L5", f"ref_roads_{road}_exit.txt") or MISSING).strip(),
        output_cand_equals_ref=same_file(out_c, out_r),
        output_sha256=sha_bytes(p(*out_c), 16), committed_sha256=sha_bytes(committed, 16),
        output_equals_committed=sha_bytes(p(*out_c)) == sha_bytes(committed),
        stdout_identical=same_file(("L5", f"ref_roads_{road}_stdout.txt"), ("L5", f"cand_roads_{road}_stdout.txt")),
        verdict_line=lines_matching(read("L5", f"cand_roads_{road}_stdout.txt"), r"^(PASS|FAIL|baseline past)"))
l5["check_roads --road extremes"]["committed_file_note"] = (
    "the committed results/training_roads_extremes.json is older than the code that writes it (06f4686 added "
    "floor_nm and p_kpa to every road): both trees write the same file, which differs from the committed one "
    "by those keys only, on cf43fbb as well")
l5["validate.py"] = dict(
    stdout_identical=same_file(("L5", "ref_validate.txt"), ("L5", "cand_validate.txt")),
    candidate=(read("L5", "cand_validate_exit.txt") or MISSING).strip(),
    reference=(read("L5", "ref_validate_exit.txt") or MISSING).strip(),
    rows=lines_matching(read("L5", "cand_validate.txt"), r"quantities inside"),
    validation_table_md="unchanged: validate.py prints and writes nothing")
dc = js("L5", "derived_check.json")
l5["derive_params.py"] = MISSING if dc is None else dict(
    how=("run in a scratch copy of each tree (S/candd; the reference's in the first certificate); the copies' "
         "data/derived_params.json compared with the committed one"),
    derived_sha=dict(zip(("committed", "candidate_copy", "reference_copy"), dc["derived_sha"])),
    differences={k: [d["path"] for d in v] for k, v in dc["differences"].items()},
    candidate_and_reference_files_byte_identical=same_file(("L5", "derived_params_DERIVED_cand.json"),
                                                           ("L5", "derived_params_DERIVED_ref.json")),
    candidate_and_reference_differ_only_in=sorted({d["path"] for d in dc["differences"].get(
        "derived in the candidate copy vs derived in the reference copy", [])}))
gen = {t: (read("L5", f"{t}_generality_exit.txt") or MISSING).strip() for t in ("cand", "ref")}
l5["generality_test.py"] = dict(
    candidate=gen["cand"], reference=gen["ref"],
    output_cand_equals_ref=same_file(("L5", "cand_generality_OUT_generality.json"),
                                     ("L5", "ref_generality_OUT_generality.json")),
    output_equals_committed=(sha_bytes(p("L5", "cand_generality_OUT_generality.json"))
                             == sha_bytes(os.path.join(REPO, "results", "generality.json"))),
    stdout_difference=line_diff(("L5", "ref_generality_stdout.txt"), ("L5", "cand_generality_stdout.txt")))


def suite(t, label):
    return unittest_summary(read("app", f"{t}_{label}.txt"))


apps = {}
for label in ("test_simulation", "test_agents", "test_results", "lab_tests"):
    apps[label] = dict(candidate=suite("cand", label), reference_git_clone=suite("refgit", label),
                       reference_archive=suite("ref", label))
tr = {t: read("app", f"{t}_test_replay_full.txt") for t in ("cand", "ref")}
apps["test_replay --full"] = dict(
    candidate=None if tr["cand"] is None else re.findall(r"^(\d+ of \d+ checks pass.*)$", tr["cand"], re.M),
    reference_archive=None if tr["ref"] is None else re.findall(r"^(\d+ of \d+ checks pass.*)$", tr["ref"], re.M),
    differing_lines=line_diff(("app", "ref_test_replay_full.txt"), ("app", "cand_test_replay_full.txt")))
for m in ("test_agent_generations", "test_agent_sources", "test_artifact_api", "test_artifacts",
          "test_graphics_revisions", "test_launcher", "test_records", "test_results_comparisons",
          "test_results_graphics", "test_results_records", "test_results_sets"):
    apps[m] = dict(candidate=suite("cand", m), reference_archive=suite("ref", m))
node = {t: read("app", f"{t}_node_tests.txt") for t in ("cand", "ref", "refgit")}


def node_summary(t):
    if node[t] is None:
        return MISSING
    return {k: int(v) for k, v in re.findall(r"^\S+ (tests|pass|fail|skipped) (\d+)$", node[t], re.M)}


apps["node --test static/sim/*.test.mjs"] = dict(
    candidate=node_summary("cand"), reference_archive=node_summary("ref"),
    reference_git_clone=node_summary("refgit"),
    note="the 12 skipped in any checkout of cf43fbb need app/static/vendor/three.js, which git ignores")
l5["app_and_learning_lab_suites"] = dict(
    how=("every app/test_*.py suite and the learning lab's tests in the corrected candidate; the reference's "
         "from the first certificate (the archive, and a git clone of cf43fbb for the suites that read git)"),
    suites=apps)
lab = read("lab", "compare_cand_ref.txt")
l5["learning_lab_outputs"] = dict(
    how=("lab_dump.py: catalog metadata in both languages, /api/plant at three points, /api/thermal, four "
         "sessions stepped 40 times, in the archive (first certificate) and in the corrected candidate"),
    result=None if lab is None else lab.splitlines()[0],
    verdict=None if lab is None else lab.strip().splitlines()[-1],
    reworded=None if lab is None else [ln.strip() for ln in lab.splitlines() if ln.strip().startswith("re-worded")])
L["L5_suites_that_write_or_pin"] = l5
l6 = {}
for tag in ("sighted_seed0", "sighted_seed4", "blind_seed2", "blind_seed6"):
    c = js("cmp", f"L6_{tag}.json")
    row = dict(cand_vs_ref=MISSING if c is None else dict(
        values=c["values"], arrays=len(c["keys"]), result="BIT-IDENTICAL" if c["identical"] else "DIFFERENT",
        **({} if c["identical"] else {"different": first_diffs(c)})))
    for t in ("cand", "ref"):
        k = js("cmp", f"L6_{t}_{tag}_committed.json")
        row[f"{t}_vs_committed"] = MISSING if k is None else dict(
            scores=f"{k['scores']['equal']} of {k['scores']['compared']} equal at full precision",
            per_step=(f"{k['per_step']['fields']} fields, {k['per_step']['values']} values, "
                      + ("all identical" if not k["per_step"]["differences"] else
                         f"{len(k['per_step']['differences'])} fields DIFFERENT")),
            result="EQUAL" if k["identical"] else "NOT EQUAL",
            **({} if k["identical"] else {"first_score_difference": k["scores"]["first_difference"],
                                          "per_step_differences": k["per_step"]["differences"]}))
    l6[tag] = row
L["L6_x1_agents"] = dict(
    what=("four X1 agents (runs/extremes_dt1: sighted_seed0, sighted_seed4, blind_seed2, blind_seed6) on all "
          "twenty frozen episodes through evaluate.run_episode with a record, as record_agents.py's workers run "
          "them (OMP 1, torch 1 thread, SAC.load on CPU). Compared: the two trees' dumps, every array by "
          "tobytes(); each tree's scores against results/phase_d_extremes_dt1_raw.json by float equality "
          "(7 values x 20 episodes); each tree's cast records against "
          "results/agents/extremes_dt1/<tag>/eval_record.npz, field by field"),
    agents=l6)
d7 = js("L7", "l7_diff.json")
exp7 = read("L7", "l7_expect.txt")
L["L7_evaluate_end_to_end"] = MISSING if d7 is None else dict(
    how=("evaluate.py for X1's sighted_seed0: the three hand-written policies and the agent on the twenty "
         "frozen episodes, OMP/MKL threads 1. The reference scored runs/extremes_dt1/sighted_seed0 itself "
         "(first certificate); the corrected candidate scored a scratch copy with the byte-identical "
         "final.zip and a meta.json re-stamped by make_meta.py with this tree's schema-3 FATAL block and an "
         "explicit identity_override. No --force-plant-mismatch. Before the comparison the fingerprint block "
         "and each run's model directory were removed, nothing else"),
    candidate=(read("L7", "cand_exit.txt") or MISSING).split("\n")[0],
    reference=(read("L7", "ref_exit.txt") or MISSING).split("\n")[0],
    meta_json_sha256=dict(original=sha_bytes(os.path.join(REPO, "runs", "extremes_dt1", "sighted_seed0",
                                                          "meta.json"), 16),
                          final_zip=sha_bytes(os.path.join(REPO, "runs", "extremes_dt1", "sighted_seed0",
                                                           "final.zip"), 16),
                          scratch_final_zip=sha_bytes(p("L7", "cand_model", "sighted_seed0", "final.zip"), 16)),
    lines_compared=d7["lines_ref"], identical=d7["identical"], diff=d7["diff"],
    fingerprint_blocks=dict(reference=d7["ref_fingerprint"], candidate=d7["cand_fingerprint"]),
    rows_against_the_committed_raw_scores=None if exp7 is None else exp7.strip().splitlines()[-1])
l8 = {}
for name, f in (("extremes, sighted (X1's design)", "L8_extremes_sighted_seed0.json"),
                ("extremes, blinded (--no-preview)", "L8_extremes_blind_seed0.json"),
                ("wideair, sighted (X2's design)", "L8_wideair_sighted_seed0.json")):
    c = js("cmp", f)
    l8[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors=c["weights"]["tensors"], values=c["weights"]["values"],
        tensors_not_byte_identical=len(c["weights"]["differing"]),
        sb3_counters={k: v["a"] for k, v in c["data"].items()},
        counters_equal=all(v["equal"] for v in c["data"].values()),
        train_record=f"{c['train_record']['fields']} fields, {c['train_record']['values']} values, "
                     + ("all identical" if not c["train_record"]["differing"] else
                        f"{len(c['train_record']['differing'])} DIFFERENT"),
        curve_identical=c["curve_identical"], result="IDENTICAL" if c["identical"] else "DIFFERENT")
L["L8_training"] = dict(
    how=("train.py --steps 600 --seed 0 --device cpu --road <road> [--no-preview] --out <scratch>, OMP/MKL "
         "threads 1, in each tree (the candidate adds --engine b58); both trees run again for this "
         "certificate. Compared: every tensor of final.zip by its bytes and by the largest absolute "
         "difference; stable-baselines3's counters; every field of the recorded 600 steps; curve.csv. The "
         "run directories were deleted afterwards: an identity test, not an experiment"),
    runs=l8)
cert["levels"] = L

# ------------------------------------------------------------- the review's own runs
st = status("suites", "_status.txt")
x = {}
x["build_dataset without a derived file (finding 2)"] = dict(
    how=("tools/bd_dump.py: build_dataset.read_drive and derive on all eleven drives of logs/raw, in a copy of "
         "each tree whose data/derived_params.json is moved aside, every numeric column dumped and compared"),
    candidate=lines_matching(read("F2", "cand.txt"), r"exit|FAILED"),
    reference=lines_matching(read("F2", "ref.txt"), r"exit|FAILED"),
    comparison=(js("F2", "cmp.json") or {}).get("identical"),
    values=(js("F2", "cmp.json") or {}).get("values"),
    before_the_fix=lines_matching(read("repro", "f2_build_dataset_no_derived_before.txt"), r"derive FAILED"),
    new_drive=dict(identical_to_the_reference=same_file(("F2", "new_drive_ref.txt"), ("F2", "new_drive_candd.txt")),
                   before_the_fix=lines_matching(read("F2", "new_drive_before.txt"), r"skipped")))
roads_t = {t: read("F11", f"{t}_roads_terrain_exit.txt") for t in ("cand", "ref")}
x["check_roads.py, the 40 terrain roads (finding 11)"] = dict(
    candidate=(roads_t["cand"] or MISSING).strip(), reference=(roads_t["ref"] or MISSING).strip(),
    output_cand_equals_ref=same_file(("F11", "cand_roads_terrain_OUT_training_roads.json"),
                                     ("F11", "ref_roads_terrain_OUT_training_roads.json")),
    stdout_identical=same_file(("F11", "ref_roads_terrain_stdout.txt"), ("F11", "cand_roads_terrain_stdout.txt")),
    output_equals_committed=(sha_bytes(p("F11", "cand_roads_terrain_OUT_training_roads.json"))
                             == sha_bytes(os.path.join(REPO, "results", "training_roads.json"))),
    committed_note=js("F11", "terrain_vs_committed.json"),
    verdict_line=lines_matching(read("F11", "cand_roads_terrain_stdout.txt"), r"^(PASS|FAIL|baseline past)"))
x["check_random_road.py (finding 11)"] = dict(
    candidate=(read("F11", "cand_random_road_exit.txt") or MISSING).strip(),
    reference=(read("F11", "ref_random_road_exit.txt") or MISSING).strip(),
    stdout_difference=line_diff(("F11", "ref_random_road_stdout.txt"), ("F11", "cand_random_road_stdout.txt"), 12))
x["evaluate.py --protocol d2 (finding 11)"] = dict(
    how=("no D2 agent is on this machine (runs_d2/ is not), so the three hand-written policies on the twenty "
         "frozen D2 episodes, end to end, in both trees; and X1's sighted_seed0, re-stamped as in L7, under "
         "--protocol d2: refused on the FATAL scenario"),
    candidate=(read("F11", "cand_d2_exit.txt") or MISSING).strip(),
    reference=(read("F11", "ref_d2_exit.txt") or MISSING).strip(),
    report=js("F11", "d2_diff.json"),
    phase_d_agent_under_d2=lines_matching(read("F11", "cand_d2_x1_stdout.txt"), r"REFUSING|scenario"))
x["the learning lab's build and launcher (finding 11)"] = dict(
    npm_ci=lines_matching(read("lab", "npm_ci.txt"), r"^exit|added \d+ packages|vulnerab"),
    npm_build=lines_matching(read("lab", "npm_build.txt"), r"^exit|built in"),
    launch_no_browser=lines_matching(read("lab", "launch_no_browser.txt"), r"ready|exit"),
    launch_check=lines_matching(read("lab", "launch_check.txt"), r"healthy|running|exit"),
    where="in S/cand, a copy of the candidate's file set (node_modules and dist are git-ignored there)")
cert["review_runs"] = x

suites = {}
for label in ("cand_test_engine_threading", "cand_test_epa_map", "cand_test_plant_guards", "ref_test_plant_guards",
              "cand_test_wide_air", "cand_test_epa_map_with_2021_2023"):
    suites[label] = dict(status=st.get(label, MISSING), result=unittest_summary(read("suites", f"{label}.txt")))
for label in ("cand_random_road", "ref_random_road"):
    t = read("suites", f"{label}.txt")
    suites[label] = dict(status=st.get(label, MISSING), output=None if t is None else t.strip().splitlines()[-3:])
suites["cand_verify_docs"] = dict(status=st.get("cand_verify_docs", MISSING),
                                  verdict=lines_matching(read("suites", "cand_verify_docs.txt"), r"checks (pass|failed)"))
suites["ref_verify_docs"] = dict(status=(read("suites", "ref_verify_docs_exit.txt") or MISSING).strip(),
                                 verdict=lines_matching(read("suites", "ref_verify_docs.txt"), r"checks (pass|failed)"),
                                 tree="the archive (first certificate)")
vc = read("suites", "cand_verify_docs.txt") or ""
vr = read("suites", "ref_verify_docs.txt") or ""
lab_c = {re.sub(r"\s+data .*$", "", ln.strip()[3:].strip()) for ln in vc.splitlines() if ln.strip().startswith("ok ")}
lab_r = {re.sub(r"\s+data .*$", "", ln.strip()[3:].strip()) for ln in vr.splitlines() if ln.strip().startswith("ok ")}
suites["verify_docs_checks_only_in_the_reference"] = sorted(z for z in lab_r - lab_c if "figure mentions" not in z
                                                            and "retired figures" not in z)
suites["verify_docs_checks_only_in_the_candidate"] = sorted(z for z in lab_c - lab_r if "figure mentions" not in z
                                                            and "retired figures" not in z)
dt = read("suites", "drift_test.txt")
suites["drift_test"] = dict(
    status=(read("suites", "drift_test_exit.txt") or MISSING).strip(),
    control=None if dt is None else [ln.strip() for ln in dt.splitlines() if "control" in ln][:1],
    verdict=None if dt is None else [ln.strip() for ln in dt.splitlines() if "drifts CAUGHT" in ln],
    rows=None if dt is None else [ln.strip() for ln in dt.splitlines() if re.match(r"\s*row\s+\d+", ln)])
dc2 = read("suites", "drift_control_with_certificate.txt")
suites["drift_control_with_the_certificate_present"] = MISSING if dc2 is None else dc2.strip().splitlines()[-1]
fpt = read("suites", "cand_fingerprint.txt")
suites["cand_fingerprint"] = None if fpt is None else fpt.strip().splitlines()
cert["suites"] = suites


def failing(t, label):
    s = unittest_summary(read("app", f"{t}_{label}.txt"))
    return set() if s == MISSING else {f.split(" (")[0] for f in s["failing"]}


diff_list = []
diff_list.append(dict(
    where="check_premise.py, stdout (L3)", kind="a printed line, no number",
    first_difference=line_diff(("L5", "ref_premise_stdout.txt"), ("L5", "cand_premise_stdout.txt")),
    why="the candidate prints the plant it names before the table; results/premise.json is byte-identical"))
if d7 is not None:
    diff_list.append(dict(
        where="evaluate.py's report, the fingerprint block (L7)", kind="provenance, removed before the comparison",
        first_difference=["cf43fbb: " + (d7["ref_fingerprint"][1] if len(d7["ref_fingerprint"]) > 1 else MISSING),
                          "candidate: " + (d7["cand_fingerprint"][1] if len(d7["cand_fingerprint"]) > 1 else MISSING)],
        why="schema 2 against schema 3: plant_sha moves (section 1), engine / engine_sha / backend are new FATAL "
            "fields, the git fields are None in the archive, plant_text_sha hashes other bytes"))
diff_list.append(dict(
    where="check_roads.py --road extremes, against the committed results/training_roads_extremes.json (L5)",
    kind="a committed file older than the code that writes it, on cf43fbb as well",
    first_difference="road 0 (seed 100) gains 'floor_nm': 15.0 and 'p_kpa': 101.3; so does every road",
    why="both trees write the same file; the committed one predates 06f4686, which added the two keys"))
diff_list.append(dict(
    where="check_roads.py (the 40 terrain roads), against the committed results/training_roads.json",
    kind="a committed file older than the plant, on cf43fbb as well; finding 13, for main",
    first_difference=(js("F11", "terrain_vs_committed.json") or {}).get("first_difference"),
    why="the file was last written by cbb8d09 (29 September), before 75ca65f (8 October) sub-stepped the "
        "thermal network and ramped the grade; both trees write the same new file"))
trd = line_diff(("app", "ref_test_replay_full.txt"), ("app", "cand_test_replay_full.txt"))
diff_list.append(dict(
    where="python -m app.test_replay --full (L5)", kind="a check's label, same value",
    first_difference=[ln for ln in (trd if isinstance(trd, list) else []) if ln.startswith(("-  ", "+  "))],
    why="the M7 check reads the damage knee from the plant now (engine_env.TURB_PROTECT_K is gone)"))
if lab is not None:
    diff_list.append(dict(
        where="the learning lab's outputs (L5)", kind="source-line numbers and three texts",
        first_difference=[ln.strip() for ln in lab.splitlines()[1:7]],
        why="lab_compare.py: no value differs; source-line numbers moved with the edited files, and the "
            "re-worded strings are three distinct texts, one under each key it lists, each naming a default "
            "which no longer exists"))
diff_list.append(dict(
    where="verify_docs.py, the list of checks", kind="checks renamed or replaced",
    first_difference=dict(only_in_the_reference=suites["verify_docs_checks_only_in_the_reference"],
                          only_in_the_candidate=suites["verify_docs_checks_only_in_the_candidate"]),
    counts=dict(reference=suites["ref_verify_docs"]["verdict"], candidate=suites["cand_verify_docs"]["verdict"]),
    why=("make_grade_climb has no defaults, so the two checks that read its duration= and dt= defaults (900 s, "
         "0.2 s) read the values where they live now: train.DURATION_S and EngineEnv's climb, train.DESIGN_DT "
         "for Phase D's and D2's roads, SupervisoryTunerEnv's dt (the review: build step 1 had merged them into "
         "one structural check that nothing could fail independently); the others read the plant's records")))
# Why a test fails on cf43fbb and not on the candidate, read in the two outputs and the test files on
# 21 October; each reason is printed only while the set it explains is exactly the one read then.
REF_ONLY_WHY = {
    "test_results": ({"test_a_schema_1_record_is_read_by_schema_1s_rule_and_never_called_this_plant",
                      "test_the_git_route_recomputes_plant_and_road"},
                     "the two that fail on cf43fbb only are skipped on the candidate while its plant files are "
                     "uncommitted (app/test_results.py: 'the plant files or random_road.py have uncommitted changes')"),
    "lab_tests": ({"test_results_are_current_and_inconclusive_with_explicit_caveats"},
                  "the one that fails on cf43fbb only is the premise pin build step 1 corrected, -0.32 to -0.01 "
                  "(results/premise.json since 75ca65f; the comment beside it in test_catalog.py)"),
}
for label in ("test_results", "test_agents", "test_simulation", "lab_tests"):
    fc, fr = failing("cand", label), failing("refgit", label)
    k = len(fc & fr)
    why = (f"no test fails on the candidate alone; {k} {'fails' if k == 1 else 'fail'} on cf43fbb as well (a git "
           "clone, the same interpreter)" if not fc - fr else f"{len(fc - fr)} FAIL ON THE CANDIDATE ALONE")
    if fr - fc:
        known, reason = REF_ONLY_WHY.get(label, (None, None))
        why += f"; {reason}" if fr - fc == known else f"; {len(fr - fc)} fail on cf43fbb only, not explained here"
    diff_list.append(dict(
        where=f"{label}: failing tests (L5)",
        kind="pre-existing failures" if not fc - fr else "failures on the candidate alone",
        candidate_only=sorted(fc - fr), reference_only=sorted(fr - fc), both=sorted(fc & fr), why=why))
rrd = line_diff(("suites", "ref_random_road.txt"), ("suites", "cand_random_road.txt"))
diff_list.append(dict(
    where="python random_road.py, the self-test", kind="a code hash: the D2 protocol's road_sha",
    first_difference=[ln.strip() for ln in (rrd if isinstance(rrd, list) else []) if ln.startswith(("-  ", "+  "))],
    why=("random_road.code_sha() hashes the module's code: its self-checks build the B58's locked climb by name, "
         "and since the review RandomClimb and evaluate.episode_cycle refuse a plant whose locked climb is not "
         "the Supra's (check_plant); climb() is unchanged and every random-road job is bit-identical")))
crr = line_diff(("F11", "ref_random_road_stdout.txt"), ("F11", "cand_random_road_stdout.txt"), 12)
diff_list.append(dict(
    where="check_random_road.py, stdout (finding 11)", kind="the D2 road_sha and the run time",
    first_difference=[ln for ln in (crr if isinstance(crr, list) else [])
                      if ln.startswith(("-", "+")) and not ln.startswith(("---", "+++"))],
    why="road_sha hashes random_road.py's code (the self-test above); the run time is the machine's. Every "
        "figure and the verdict, PASS, are the same in both trees"))
diff_list.append(dict(
    where="training's final.zip files (L8)", kind="zip bytes", first_difference="the 'data' member",
    why="stable-baselines3 stores run metadata there; every tensor and every counter is compared"))
cert["different"] = diff_list

cert["review"] = js("review.json") or MISSING
cert["first_certificate"] = first or MISSING

cert["tools"] = {os.path.basename(f): sha_bytes(f, 16) for f in sorted(
    os.path.join(S, "tools", z) for z in os.listdir(p("tools")) if z.endswith((".py", ".sh", ".txt")))}
cert["tools_note"] = (
    "Every tool and the small evidence files are archived in the repository, in "
    "results/B58_IDENTITY/certificate_tools.tar.gz (finding 12 of the review: they lived in a session's "
    "scratch only), its sha256 below. The tools derive their folder from their own location, so the archive "
    "unpacked anywhere is S. tools/certify_original/ holds the first certificate's tools as they ran; "
    "harness.py differs from its first form in one line on the candidate side (the table measured on the "
    "car's grid, Car.table_rpms), make_meta.py in passing backend=, and the shell scripts in finding their "
    "folder instead of naming it. The reference-side code is unchanged.")
cert["archive"] = None if ARCHIVE is None else dict(
    path="results/B58_IDENTITY/certificate_tools.tar.gz", sha256=sha_bytes(ARCHIVE),
    bytes=os.path.getsize(ARCHIVE) if os.path.exists(ARCHIVE) else MISSING,
    members=len((read("archive_members.txt") or "").splitlines()) + 1)       # + the listing itself
cert["reproduce"] = js("reproduce.json") or MISSING

# ------------------------------------------------------------- the verdict, from the levels above
harness_rows = L["L1_units"]["rows"] + L["L3_premise"]["harness"] + [
    r for k, v in L["L2_roads"].items() if k != "what" for r in v["rows"]]
l6_rows = list(L["L6_x1_agents"]["agents"].values())
checks = {
    "harness jobs (L1, L2, L3)": all(r["result"] == "BIT-IDENTICAL" for r in harness_rows),
    "premise.json (L3)": L["L3_premise"]["check_premise"]["premise_json_cand_equals_ref"] is True,
    "test_reward stdout (L4)": all(v["stdout_identical"] is True for v in L["L4_test_reward"].values()),
    "check_roads outputs (L5)": all(L["L5_suites_that_write_or_pin"][f"check_roads --road {r}"]["output_cand_equals_ref"]
                                    is True for r in ("extremes", "wideair")),
    "validate.py stdout (L5)": L["L5_suites_that_write_or_pin"]["validate.py"]["stdout_identical"] is True,
    "derive_params output (L5)": (L["L5_suites_that_write_or_pin"]["derive_params.py"] != MISSING and
                                  L["L5_suites_that_write_or_pin"]["derive_params.py"]
                                  ["candidate_and_reference_differ_only_in"] in ([], ["/_generated"])),
    "generality output (L5)": L["L5_suites_that_write_or_pin"]["generality_test.py"]["output_cand_equals_ref"] is True,
    "L6 agents": all(r["cand_vs_ref"] != MISSING and r["cand_vs_ref"]["result"] == "BIT-IDENTICAL" and
                     r["cand_vs_committed"] != MISSING and r["cand_vs_committed"]["result"] == "EQUAL" and
                     r["ref_vs_committed"] != MISSING and r["ref_vs_committed"]["result"] == "EQUAL" for r in l6_rows),
    "L7 report": L["L7_evaluate_end_to_end"] != MISSING and L["L7_evaluate_end_to_end"]["identical"] is True,
    "L8 training": all(v != MISSING and v["result"] == "IDENTICAL" for v in L["L8_training"]["runs"].values()),
    "controls DIFFERENT (harness)": all(r["result"] == "DIFFERENT" for n in ("one_ulp_thermal_c_turb", "one_ulp_car_mass")
                                        for r in ctl[n]["jobs"]),
    "control IDENTICAL (reference against itself)": all(r["result"] == "BIT-IDENTICAL"
                                                        for r in ctl["reference_against_reference"]["jobs"]),
    "build_dataset without a derived file": x["build_dataset without a derived file (finding 2)"]["comparison"] is True,
}
cert["verdict"] = dict(
    result="BIT-IDENTICAL at every level" if all(checks.values()) else "NOT CERTIFIED: see checks",
    checks=checks,
    values_compared_byte_for_byte=dict(
        harness=sum(r.get("values", 0) for r in harness_rows),
        l6_agents=sum(r["cand_vs_ref"]["values"] for r in l6_rows if r["cand_vs_ref"] != MISSING),
        l8_tensor_values=sum(v["values"] for v in L["L8_training"]["runs"].values() if v != MISSING),
        build_dataset_columns=x["build_dataset without a derived file (finding 2)"]["values"]))
order = ["what", "date", "asked_by", "verdict", "reference", "candidate", "identity", "environment", "controls",
         "levels", "review_runs", "suites", "different", "review", "first_certificate", "tools", "tools_note",
         "archive", "reproduce"]
cert = {k: cert[k] for k in order if k in cert}

with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
    json.dump(cert, fh, indent=1, ensure_ascii=False)
    fh.write("\n")
print("written", OUT, "|", cert["verdict"]["result"])
for k, v in checks.items():
    print(f"  {'ok ' if v else 'NO '} {k}")
