#!/usr/bin/env bash
# run_controls.sh -- the harness controls (mistake 12): the reference against itself must be
# IDENTICAL; the candidate with one ulp on thermal.c_turb or car.mass must be DIFFERENT
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
SW='C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify'
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
$PY -I $SW/tools/run_jobs.py "$SW/ref" ref2 "$SW/tools/jobs_ctl.txt" 2 &
$PY -I $SW/tools/run_jobs.py "C:/Users/badcl/Desktop/GRAD-project" ctl_cturb "$SW/tools/jobs_ctl.txt" 2 HARNESS_PERTURB=thermal.c_turb &
$PY -I $SW/tools/run_jobs.py "C:/Users/badcl/Desktop/GRAD-project" ctl_mass "$SW/tools/jobs_ctl.txt" 2 HARNESS_PERTURB=car.mass &
wait
echo "== reference against reference (must be IDENTICAL)"; bash $S/tools/compare_all.sh ref ref2
echo "== candidate against candidate + one ulp on thermal.c_turb (must be DIFFERENT)"; bash $S/tools/compare_all.sh cand ctl_cturb
echo "== candidate against candidate + one ulp on car.mass (must be DIFFERENT)"; bash $S/tools/compare_all.sh cand ctl_mass
