"""l7_diff.py -- L7: evaluate.py's report from each tree, compared line by line.

    python l7_diff.py <ref_report.txt> <ref_model_dir> <cand_report.txt> <cand_model_dir> [--json out.json]

Two things are removed before the comparison, and nothing else:
  1. the fingerprint block ("--- PLANT FINGERPRINT (this run) ---" to its closing
     rule of dashes): schema 2 against schema 3, a different plant_sha by
     construction (PLANT_FILES gained engines.py and the specs), and the git fields;
  2. each run's own model directory, replaced by <MODEL> (the reference scored
     runs/extremes_dt1/sighted_seed0, the candidate a scratch copy of it whose
     final.zip is byte-identical and whose meta.json carries the schema-3 block).
Both blocks are printed, so a reader sees what was stripped.
"""
import difflib
import json
import re
import sys


def load(path, model_dir):
    lines = open(path, encoding="utf-8").read().splitlines()
    out, block, inside = [], [], False
    for ln in lines:
        if ln.startswith("--- PLANT FINGERPRINT"):
            inside = True
        if inside:
            block.append(ln)
            if re.fullmatch(r"-{62}", ln):
                inside = False
            continue
        for form in {model_dir, model_dir.replace("/", "\\"), model_dir.replace("\\", "/")}:
            ln = ln.replace(form, "<MODEL>")
        out.append(ln)
    return out, block


ref, ref_block = load(sys.argv[1], sys.argv[2])
cand, cand_block = load(sys.argv[3], sys.argv[4])
diff = list(difflib.unified_diff(ref, cand, "reference (cf43fbb)", "candidate (GRA-test)", lineterm=""))
print("stripped from the reference:", *ref_block, sep="\n  ")
print("stripped from the candidate:", *cand_block, sep="\n  ")
print(f"\ncompared {len(ref)} and {len(cand)} lines after stripping")
print("\n".join(diff) if diff else "NO DIFFERENCE: the two reports are identical line for line")
if "--json" in sys.argv:
    with open(sys.argv[sys.argv.index("--json") + 1], "w", encoding="utf-8") as fh:
        json.dump(dict(identical=not diff, lines_ref=len(ref), lines_cand=len(cand), diff=diff,
                       ref_fingerprint=ref_block, cand_fingerprint=cand_block, compared=ref), fh, indent=1)
sys.exit(0 if not diff else 1)
