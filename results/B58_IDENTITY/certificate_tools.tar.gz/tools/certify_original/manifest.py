"""manifest.py -- sha256 of every file git would commit from a working tree.

    python manifest.py <repo> <out.txt>

Tracked plus untracked-not-ignored files (git ls-files --cached --others
--exclude-standard), so the untracked engines.py and engine_specs/ are in it.
Run at the start and at the end of the certification: if the two differ, the
candidate tree changed under the runs and no level of the certificate holds.
"""
import hashlib
import os
import subprocess
import sys

repo, out = sys.argv[1], sys.argv[2]
names = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
                       cwd=repo, capture_output=True, check=True).stdout.decode("utf-8").split("\0")
rows = []
for n in sorted(x for x in names if x):
    p = os.path.join(repo, n)
    if not os.path.isfile(p):
        rows.append(f"{'MISSING':<64}  {n}")
        continue
    with open(p, "rb") as fh:
        rows.append(f"{hashlib.sha256(fh.read()).hexdigest()}  {n}")
text = "\n".join(rows) + "\n"
with open(out, "w", encoding="utf-8", newline="\n") as fh:
    fh.write(text)
print(f"{len(rows)} files, manifest sha256 {hashlib.sha256(text.encode()).hexdigest()[:16]} -> {out}")
