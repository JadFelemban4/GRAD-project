"""l6_agents.py -- L6: one X1 agent on the twenty frozen episodes, every step kept.

    python -I l6_agents.py <tree_dir> <tag> <out.npz> [first_n_episodes]

Runs in the tree given (the reference, a git archive of cf43fbb, or the
candidate, the GRA-test working tree; the candidate is the tree that holds
engines.py), exactly as record_agents.py's workers do: OMP_NUM_THREADS=1 and
torch.set_num_threads(1), SAC.load(runs/extremes_dt1/<tag>/final, device="cpu")
from the main repository (the agents are inputs, not code), and for every
frozen episode evaluate.run_episode(..., record=evaluate.new_record()) -- the
function that produced results/phase_d_extremes_dt1_raw.json and, through
record_agents.py, results/agents/extremes_dt1/<tag>/eval_record.npz.

Dumped: score (episode x 7, float64: ret, damage, damage_thermal, fuel,
torque_viol, peak_turb, knock), raw_<field> (every recorded field as
record_agents stacks it, before any cast), cast_<field> (after step_record.cast,
the form eval_record.npz stores), episode_seed and weights.

HARNESS_PERTURB=car.mass or thermal.c_turb moves that one field of the B58 by
one ulp in the candidate, through the records and engines.get, as harness.py
does: the control that the comparisons against the committed files can fail.
"""
import os
import sys
import time

os.environ["OMP_NUM_THREADS"] = "1"
tree, tag, out = os.path.abspath(sys.argv[1]), sys.argv[2], os.path.abspath(sys.argv[3])
n_ep = int(sys.argv[4]) if len(sys.argv) > 4 else 20
os.chdir(tree)
sys.path.insert(0, tree)

import numpy as np  # noqa: E402
import torch  # noqa: E402

torch.set_num_threads(1)
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
SCORE_KEYS = ("ret", "damage", "damage_thermal", "fuel", "torque_viol", "peak_turb", "knock")

NEW = os.path.exists(os.path.join(tree, "engines.py"))
KW = {}
if NEW:
    import engines
    PLANT = engines.get("b58")
    _pert = os.environ.get("HARNESS_PERTURB")
    if _pert:
        # "car.mass" moves the field by one ulp; "car.mass:1e-6" by that relative step
        # (the committed eval_record.npz is float32, which a one-ulp change can round away)
        from dataclasses import replace
        spec, _, rel = _pert.partition(":")
        rec_name, field = spec.split(".")
        old = getattr(PLANT.car if rec_name == "car" else getattr(PLANT.engine, rec_name), field)
        new = float(old * (1.0 + float(rel))) if rel else float(np.nextafter(old, np.inf))
        if rec_name == "car":
            PLANT = replace(PLANT, car=replace(PLANT.car, **{field: new}))
        else:
            sub = getattr(PLANT.engine, rec_name)
            PLANT = replace(PLANT, engine=replace(PLANT.engine, **{rec_name: replace(sub, **{field: new})}))
        engines._BUILT["b58"] = PLANT
        print(f"PERTURBED {_pert}: {old!r} -> {new!r}")
    KW = dict(plant=PLANT)
elif os.environ.get("HARNESS_PERTURB"):
    raise SystemExit("HARNESS_PERTURB is for the candidate tree only")

import evaluate as E  # noqa: E402
import step_record  # noqa: E402
from stable_baselines3 import SAC  # noqa: E402

t0 = time.time()
model = SAC.load(os.path.join(REPO, "runs", "extremes_dt1", tag, "final"), device="cpu")
pol = E.agent_policy(model)
prev = "blind" not in tag
scores, recs = [], []
for i in range(n_ep):
    seed, w = E.EPISODES[i]
    rec = E.new_record()
    row = E.run_episode(pol, seed, w, prev, record=rec, **KW)
    scores.append([float(row[k]) for k in SCORE_KEYS])
    recs.append({k: np.asarray(v) for k, v in rec.items()})        # record_agents._job
    print(f"  {tag} episode {i}: damage {row['damage']!r} ({time.time() - t0:.0f} s)", flush=True)

arrays = dict(score=np.array(scores, dtype=np.float64),
              episode_seed=np.array([E.EPISODES[i][0] for i in range(n_ep)]),
              weights=np.array([E.EPISODES[i][1] for i in range(n_ep)]))
for k in recs[0]:
    stacked = np.stack([r[k] for r in recs])                       # record_agents.main
    arrays["raw_" + k] = stacked
    arrays["cast_" + k] = step_record.cast(k, stacked)             # record_agents.save_record
np.savez(out, **arrays, _seconds=time.time() - t0)
print(f"{tag} in {tree}: {n_ep} episodes, {time.time() - t0:.1f} s, {len(recs[0])} fields")
