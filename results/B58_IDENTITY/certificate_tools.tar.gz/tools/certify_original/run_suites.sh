#!/usr/bin/env bash
# run_suites.sh -- the candidate's own suites, as their docstrings say to run them
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
CAND=/c/Users/badcl/Desktop/GRAD-project
export PYTHONIOENCODING=utf-8
one() {   # one <label> <dir> <command...>
  local label=$1 dir=$2; shift 2
  local s=$(date +%s)
  ( cd "$dir" && "$@" ) > $S/suites/$label.txt 2>&1
  echo "$? $(( $(date +%s) - s )) $label" >> $S/suites/_status.txt
}
rm -f $S/suites/_status.txt
one cand_test_wide_air $CAND $PY test_wide_air.py &
one cand_test_engine_threading $CAND $PY test_engine_threading.py -v &
one cand_test_epa_map $CAND $PY test_epa_map.py -v &
one cand_test_plant_guards $CAND $PY test_plant_guards.py -v &
one ref_test_plant_guards $S/refv $PY test_plant_guards.py -v &
one cand_random_road $CAND $PY random_road.py &
one ref_random_road $S/refv $PY random_road.py &
one cand_fingerprint $CAND $PY fingerprint.py --engine b58 &
one cand_verify_docs $CAND $PY verify_docs.py &
wait
cat $S/suites/_status.txt
