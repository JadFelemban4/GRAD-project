"""harness.py -- run one job in one tree and dump every number it produced, float64.

    python harness.py <tree_dir> <job> <out.npz>

The tree is the reference (git archive cf43fbb, untouched) or the candidate (the
GRA-test working tree, Engine objects). The same job in both trees must give
identical bytes. A tree is the candidate when it holds engines.py.

jobs
  units                                   L1: plant, thermal, ECU, gearbox, damage, roads, table
  premise                                 L3: check_premise's five rollouts, every step
  extremes:<family>:<seed>:<policy>       L2
  terrain:<family>:<seed>:<policy>        L2
  rr:<start_s>:<grade>:<policy>           L2: random_road.climb at dt 0.2 (test_reward's D2 roll)
  rrwrap:<seed>:<n_resets>                L2: the RandomClimb wrapper's drawn roads
  wideair:<family>:<t_c>:<p_kpa>:<seed>:<policy>   L2: one forced-air WideAir episode
  wideseq:<seed>:<n>:<steps>              L2: n drawn WideAir episodes in sequence
  cond:<ref>:<t_amb_k>:<p_baro>:<grade>:<profile>  L2: conditions_test._run, every step
  x1:<tag>:<episode>                      L6: one X1 agent on one frozen episode
policy: neutral | random
"""
import os
import sys
import time

tree, job, out = os.path.abspath(sys.argv[1]), sys.argv[2], os.path.abspath(sys.argv[3])
os.chdir(tree)
sys.path.insert(0, tree)

import numpy as np  # noqa: E402

NEW = os.path.exists(os.path.join(tree, "engines.py"))
if NEW:
    import engines
    PLANT = engines.get("b58")
    # THE CONTROL (mistake 12): HARNESS_PERTURB="thermal.c_turb" or "car.mass"
    # moves that one field by one ulp THROUGH THE RECORDS, so a dump that does not
    # change would mean the field never reached the output (mistake 25).
    _pert = os.environ.get("HARNESS_PERTURB")
    if _pert:
        from dataclasses import replace
        rec_name, field = _pert.split(".")
        if rec_name == "car":
            old = getattr(PLANT.car, field)
            PLANT = replace(PLANT, car=replace(PLANT.car, **{field: float(np.nextafter(old, np.inf))}))
        else:
            sub = getattr(PLANT.engine, rec_name)
            old = getattr(sub, field)
            PLANT = replace(PLANT, engine=replace(PLANT.engine, **{rec_name: replace(
                sub, **{field: float(np.nextafter(old, np.inf))})}))
        print(f"PERTURBED {_pert}: {old!r} -> {float(np.nextafter(old, np.inf))!r}")
        # certify (21 Oct): code that fetches the plant itself (conditions_test._plant,
        # anything calling engines.get("b58")) gets the perturbed one too, so the
        # control reaches every job, not only those handed PLANT by keyword
        engines._BUILT["b58"] = PLANT
    KW = dict(plant=PLANT)
else:
    PLANT = None
    KW = {}

import engine_env as E  # noqa: E402

rec = {}


def put(name, value):
    rec.setdefault(name, []).append(np.asarray(value, dtype=np.float64))


def info_keys(info):
    return sorted(k for k, v in info.items() if isinstance(v, (int, float, np.floating, np.integer, bool)))


def policy_fn(pol, seed=0):
    if pol == "neutral":
        n = E.neutral_action()
        return lambda e, o: n
    rng = np.random.default_rng(seed)
    return lambda e, o: rng.uniform(-1.0, 1.0, 5).astype(np.float32)


def state_of(env):
    return [env.rpm, env.map_kpa, env.tps, env.iat_k, env.map_b_prev,
            env.ecu.knock_retard, env.ecu.hot_dwell, env.thermal_base.t_turb,
            env.thermal_base.t_oil, env.thermal_base.t_block,
            env.thermal.t_turb, env.thermal.t_oil, env.thermal.t_block,
            env.ep["damage"], env.ep["damage_base"], env.ep["fuel"], env.ep["fuel_base"],
            env.thermal.p.c_turb, env.thermal_base.p.c_turb, env.MAP_CEIL_KPA, env.torque_req]


def run_env(env, act, reset_kw, n_max=100000):
    obs, _ = env.reset(**reset_kw)
    put("obs0", obs)
    keys = None
    for _ in range(n_max):
        a = act(env, obs)
        obs, r, term, trunc, info = env.step(a)
        keys = keys or info_keys(info)
        put("obs", obs)
        put("reward", r)
        put("info", [float(info[k]) for k in keys])
        put("state", state_of(env))
        if term or trunc:
            put("summary", [float(v) for _, v in sorted(info["episode_summary"].items())])
            break
    return keys


def put_cycle(c, tag="cycle"):
    for k in ("t", "v_mps", "grade"):
        put(f"{tag}_{k}", c[k])
    put(f"{tag}_scalars", [float(c["t_amb"]), float(c.get("p_baro", np.nan)), float(c.get("humidity", np.nan))])
    if "elev_m" in c:
        put(f"{tag}_elev", c["elev_m"])


t0 = time.time()
if job == "units":
    import plant as P
    import thermal as T
    eng = PLANT.engine if NEW else None
    # 1. the cycle model on a grid, run_cycle and predict
    for rpm in (900.0, 1500.0, 2706.0, 3800.0, 5200.0, 6500.0):
        for mp in (25.0, 60.0, 100.0, 175.0, 249.8):
            for sp in (-10.0, 0.0, 8.0, 20.0, 40.0):
                for lam in (0.70, 0.85, 1.0, 1.12):
                    for iat in (300.0, 330.0):
                        kw = dict(rpm=rpm, map_kpa=mp, iat_k=iat, ect_k=365.0, spark_btdc=sp, lam=lam,
                                  p_exh_kpa=max(105.0, mp * 1.15))
                        r = (P.run_cycle(P.Operating(**kw), engine=eng) if NEW
                             else P.run_cycle(P.Operating(**kw), geo=P.b58()))
                        put("cycle", [getattr(r, f) for f in (
                            "torque_nm", "power_kw", "bmep_bar", "imep_bar", "fmep_bar", "bsfc_gpkwh",
                            "egt_c", "p_max_bar", "knock_integral", "knock_prob", "mfb50_deg",
                            "mdot_fuel_gps", "t_max_k", "mdot_air_gps", "eta_v", "f_res")])
    for rpm in (1200.0, 2706.0, 4800.0):
        for mp in (40.0, 120.0, 210.0):
            for p_exh in (None, 150.0):
                d = (P.predict(rpm, mp, 330.0, 363.0, 12.0, 0.95, p_exh_kpa=p_exh, engine=eng) if NEW
                     else P.predict(rpm, mp, 330.0, 363.0, 12.0, 0.95, p_exh_kpa=p_exh))
                put("predict", [d[k] for k in sorted(d)])
    # coarser and finer crank steps (validate.test_convergence's use)
    for dth in (0.125, 0.5):
        kw = dict(rpm=3000.0, map_kpa=140.0, iat_k=320.0, ect_k=363.0, spark_btdc=14.0, lam=1.0,
                  p_exh_kpa=161.0)
        r = (P.run_cycle(P.Operating(**kw), engine=eng, dtheta=dth) if NEW
             else P.run_cycle(P.Operating(**kw), geo=P.b58(), dtheta=dth))
        put("cycle_dtheta", [r.torque_nm, r.egt_c, r.knock_integral])
    # 2. the boost ceiling, the charge temperature, the airflow inversion
    for m in np.linspace(0.0, 400.0, 41):
        for t in (288.0, 315.0):
            for pin in (78.4, 79.0, 99.3):
                put("ceiling", P.boost_ceiling_kpa(m, t, pin, engine=eng) if NEW
                    else P.boost_ceiling_kpa(m, t, pin))
            put("charge", [P.charge_temperature(t, 365.0, engine=eng) if NEW else P.charge_temperature(t, 365.0),
                           P.charge_temperature(t, None, engine=eng) if NEW else P.charge_temperature(t)])
            if m > 0:
                put("inv", P.map_from_airflow(m, 2706.0, t, engine=eng) if NEW
                    else P.map_from_airflow(m, 2706.0, t))
    # 3. the thermal network, thermal.py's own worked example, and a swept housing
    for c_turb in (None, 800.0, 60000.0):
        if NEW:
            from dataclasses import replace
            p = eng.thermal if c_turb is None else replace(eng.thermal, c_turb=c_turb)
            tn = T.ThermalNetwork(p)
        else:
            tn = T.ThermalNetwork() if c_turb is None else T.ThermalNetwork(T.ThermalParams(c_turb=c_turb))
        tn.reset(t_amb=315.0)
        for i in range(1801):
            climbing = i > 300
            mf = 7.5 if climbing else 1.6
            tn.step(1.0, mf, mf * 15.0, 1150.0 if climbing else 950.0, 315.0, 22.0 if climbing else 33.0,
                    1.0 if tn.t_block > 373.0 else 0.0, rpm=3000.0 if climbing else 2200.0)
            put(f"thermal_{c_turb}", tn.state())
        put("thermal_cold_reset", tn.reset(t_amb=301.0, warm=False))
    # 4. the ECU over a scripted sequence: a pull with knock, enrichment dwell, a cold start
    for emap in (False, True):
        ecu = E.BaselineECU(eng.ecu, enrichment_map=emap) if NEW else E.BaselineECU(enrichment_map=emap)
        for i in range(400):
            rpm = 1500.0 + 10.0 * i
            mp = 60.0 + 0.5 * i
            knock = (i % 37) in (5, 6, 7)
            put(f"ecu_{emap}", ecu.step(rpm, mp, 300.0 + 0.1 * i, 330.0 + 0.1 * i, knock, 1.0))
            put(f"ecu_parts_{emap}", [ecu.base_spark(rpm, mp), ecu.knock_limited_spark(rpm, mp),
                                      ecu.iat_compensation(300.0 + 0.1 * i), ecu.base_lambda(rpm, mp, 0.05 * i)])
    # 5. the gearbox and the road load
    veh = E.Vehicle(PLANT.car) if NEW else E.Vehicle()
    put("upshift_speeds", veh._upshift_speeds())
    for v in np.linspace(0.0, 45.0, 46):
        put("gear_light", veh.gear_for(float(v)))
        for a in (-1.0, 0.0, 0.8):
            for g in (-0.05, 0.0, 0.06, 0.12, 0.16, 0.20):
                put("demand", veh.demand(v, a, g, rho=1.12))
    for rpm in range(800, 6801, 100):
        put("shift_ceiling", veh.shift_ceiling_nm(float(rpm)))
    put("table", np.array(veh.DELIVERABLE_TORQUE, dtype=float))
    # 6. the damage model
    for tt in np.linspace(900.0, 1250.0, 36):
        for to in (380.0, 410.0):
            for ki in (None, 0.5, 0.9, 2.1):
                put("damage", E.damage_rate(tt, to, ki, cal=eng.damage) if NEW else E.damage_rate(tt, to, ki))
    # 7. the roads: the locked climb at both steps, every terrain family, the extremes builders
    for dur, dt in ((900.0, 0.2), (720.0, 1.0), (60.0, 1.0)):
        c = E.locked_climb(PLANT, duration=dur, dt=dt) if NEW else E.make_grade_climb(duration=dur, dt=dt)
        put_cycle(c, f"locked_{dur:g}_{dt:g}")
    for fam in ("locked", "single", "rolling", "double", "flat"):
        for seed in (3, 4):
            rng = np.random.default_rng(seed)
            c = (E.make_terrain(rng, plant=PLANT, duration=900.0, dt=1.0, family=fam) if NEW
                 else E.make_terrain(rng, duration=900.0, dt=1.0, family=fam))
            put_cycle(c, f"terrain_{fam}")
            rng2 = np.random.default_rng(seed + 50)
            t_amb = 300.0 + 3.0 * seed
            if NEW:
                fl = PLANT.engine.loop.torque_floor_nm
                v = E.extreme_speed_profile(rng2, len(c["t"]), 1.0, c["grade"], t_amb, veh, fl)
                gf = E.grade_floor(v, t_amb, 1.0, veh, fl)
                mtf = [E.min_tractive_force(veh, x, fl) for x in v[::7]]
            else:
                v = E.extreme_speed_profile(rng2, len(c["t"]), 1.0, c["grade"], t_amb, veh)
                gf = E.grade_floor(v, t_amb, 1.0, veh)
                mtf = [E.min_tractive_force(veh, x) for x in v[::7]]
            put(f"xspeed_{fam}", v)
            put(f"xfloor_{fam}", gf)
            put(f"xmtf_{fam}", mtf)
    # 8. the deliverable-torque table, re-measured through the load loop
    put("deliverable", E.measure_deliverable_torque(plant=PLANT) if NEW else E.measure_deliverable_torque())
    put("deliverable_probe", E.measure_deliverable_torque(rpms=[1600, 2200, 2600, 3200, 4400], **KW))
    put("neutral", E.neutral_action())
    env = (E.SupervisoryTunerEnv(E.locked_climb(PLANT, duration=60.0, dt=1.0), plant=PLANT, dt=1.0, seed=0)
           if NEW else E.SupervisoryTunerEnv(E.make_grade_climb(duration=60.0, dt=1.0), dt=1.0, seed=0))
    put("map_ceil", env.MAP_CEIL_KPA)
    put("map_for", [env._map_for(tq, 2706.0, bt) for tq in (0.0, 100.0, 340.0, 600.0) for bt in (-40.0, 0.0, 15.0)])

elif job == "premise":
    import check_premise as C
    trace = []
    _orig = E.SupervisoryTunerEnv.step

    def traced(self, action):
        o, r, te, tr, info = _orig(self, action)
        trace.append((np.asarray(action, dtype=np.float64), o, r, info))
        return o, r, te, tr, info
    E.SupervisoryTunerEnv.step = traced
    rows = [("baseline", C.p_neutral, True), ("reactive", C.p_reactive, True),
            ("current-grade", C.p_grade_now, True), ("predictive", C.p_predictive, True),
            ("predictive-blind", C.p_predictive, False)]
    for name, pol, prev in rows:
        trace.clear()
        r = C.rollout(pol, use_preview=prev, **KW)
        put("summary", [r[k] for k in ("fuel", "fuel_base", "damage", "damage_base", "peak_turb",
                                       "peak_oil", "knock")])
        for a, obs, rew, info in trace:
            put("action", a)
            put("obs", obs)
            put("reward", rew)
            put("info", [float(info[k]) for k in info_keys(info)])

elif job.startswith(("extremes:", "terrain:")):
    kind, fam, seed, pol = job.split(":")
    seed = int(seed)
    cls = E.ExtremesTrainingEnv if kind == "extremes" else E.TerrainTrainingEnv
    env = cls(duration=900.0, dt=1.0, seed=seed, **KW)
    run_env(env, policy_fn(pol), dict(seed=seed, options={"family": fam}))
    put_cycle(env.cycle)
    # a second, unseeded episode from the same stream
    run_env(env, policy_fn(pol, 1), dict(seed=None), n_max=200)
    put_cycle(env.cycle, "cycle2")
    put("c_turb_scale", getattr(env, "c_turb_scale", 1.0))

elif job.startswith("rr:"):
    import random_road as RR
    _, start_s, grade, pol = job.split(":")
    c = RR.climb(float(start_s), float(grade), duration=480.0, dt=0.2)
    put_cycle(c)
    env = (E.SupervisoryTunerEnv(c, plant=PLANT, dt=0.2, seed=0) if NEW
           else E.SupervisoryTunerEnv(c, seed=0))
    run_env(env, policy_fn(pol), dict(seed=1))

elif job.startswith("rrwrap:"):
    import random_road as RR
    _, seed, n = job.split(":")
    base = (E.SupervisoryTunerEnv(E.locked_climb(PLANT, duration=900.0, dt=0.2), plant=PLANT, seed=0) if NEW
            else E.SupervisoryTunerEnv(E.make_grade_climb(), seed=0))
    env = RR.RandomClimb(base, seed=int(seed), duration=600.0)
    act = policy_fn("random", 5)
    for i in range(int(n)):
        obs, info = env.reset(seed=int(seed) if i == 0 else None)
        put("road", [info["road"]["start_s"], info["road"]["grade"]])
        put_cycle(env.unwrapped.cycle, f"rr{i}")
        for _ in range(200):
            obs, r, term, trunc, inf = env.step(act(env, obs))
            put("obs", obs)
            put("reward", r)
            put("info", [float(inf[k]) for k in info_keys(inf)])

elif job.startswith("wideair:"):
    import wide_air as W
    _, fam, t_c, p_k, seed, pol = job.split(":")
    seed = int(seed)
    env = W.WideAirTrainingEnv(duration=900.0, dt=1.0, seed=seed, **KW)
    run_env(env, policy_fn(pol), dict(seed=seed, options={"family": fam, "t_amb_c": float(t_c),
                                                          "p_kpa": float(p_k)}))
    put_cycle(env.cycle)
    put("floor", env.floor_nm)
    put("inlet", env.inlet_kpa if NEW else env._p_inlet)
    put("thin_table", np.array(env.veh.DELIVERABLE_TORQUE, dtype=float))

elif job.startswith("wideseq:"):
    import wide_air as W
    _, seed, n, steps = job.split(":")
    env = W.WideAirTrainingEnv(duration=900.0, dt=1.0, seed=int(seed), **KW)
    act = policy_fn("random", 7)
    for i in range(int(n)):
        obs, _ = env.reset(seed=int(seed) if i == 0 else None)
        put("obs0", obs)
        put_cycle(env.cycle, f"ep{i}")
        put("floor", env.floor_nm)
        put("inlet", env.inlet_kpa if NEW else env._p_inlet)
        put("c_turb", [env.thermal.p.c_turb, env.thermal_base.p.c_turb])
        for _ in range(int(steps)):
            obs, r, term, trunc, inf = env.step(act(env, obs))
            put("obs", obs)
            put("reward", r)
            put("info", [float(inf[k]) for k in info_keys(inf)])
            put("state", state_of(env))

elif job.startswith("cond:"):
    import conditions_test as CT
    import step_record
    _, ref, t_amb, p_baro, grade, profile = job.split(":")
    r = step_record.new()
    jb, row = CT._run((ref, 1, float(t_amb), float(p_baro), float(grade), profile), r)
    fin = step_record.finish(r)
    for k in sorted(fin):
        try:
            put(f"rec_{k}", np.asarray(fin[k], dtype=np.float64))
        except (TypeError, ValueError):
            pass
    put("row", [float(row[k]) for k in ("ret", "damage", "damage_thermal", "fuel", "torque_viol",
                                        "peak_turb", "knock", "short_steps", "s_above")])
    put("acts", row["act_climb"])

elif job.startswith("x1:"):
    _, tag, ep = job.split(":")
    import evaluate as V
    from stable_baselines3 import SAC
    model = SAC.load(r"C:/Users/badcl/Desktop/GRAD-project/runs/extremes_dt1/" + tag + "/final", device="cpu")
    seed, weights = V.EPISODES[int(ep)]
    use_preview = "blind" not in tag
    cyc = (E.locked_climb(PLANT, duration=720.0, dt=1.0) if NEW
           else E.make_grade_climb(duration=720.0, dt=1.0))
    env = E.SupervisoryTunerEnv(cyc, dt=1.0, seed=seed, use_preview=use_preview, **KW)
    obs, _ = env.reset(seed=seed)
    env.w = np.asarray(weights, dtype=np.float32)
    obs = env._obs()
    ret, peak, thermal = 0.0, 0.0, 0.0
    dmg = ((lambda tt, to: E.damage_rate(tt, to, cal=PLANT.engine.damage)) if NEW else E.damage_rate)
    while True:
        a, _ = model.predict(obs, deterministic=True)
        obs, r, term, trunc, info = env.step(a)
        put("action", a)
        put("obs", obs)
        put("reward", r)
        put("info", [float(info[k]) for k in info_keys(info)])
        ret += r
        peak = max(peak, info["t_turb"])
        thermal += dmg(info["t_turb"], info["t_oil"]) * env.dt
        if term or trunc:
            break
    s = info["episode_summary"]
    put("score", [ret, s["damage"], thermal, s["fuel"], s["torque_viol"], peak - 273.15, s["knock_events"]])
else:
    raise SystemExit(f"unknown job {job}")

def _stack(v):
    """One array per key; ragged lists are flattened, with their lengths saved beside."""
    try:
        return {"": np.array(v)}
    except ValueError:
        return {"": np.concatenate([np.ravel(x) for x in v]),
                "__lens": np.array([np.size(x) for x in v], dtype=np.float64)}


arrays = {}
for k, v in rec.items():
    for suffix, arr in _stack(v).items():
        arrays[k + suffix] = arr
np.savez(out, **arrays, _seconds=time.time() - t0)
print(f"{job} in {tree}: {time.time() - t0:.1f} s, " + ", ".join(f"{k} {a.shape}" for k, a in arrays.items()))
