#!/usr/bin/env bash
# compare_all.sh <label_a> <label_b> -- every harness job finished in both, compared (cmp.py), one line each
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
A=$1; B=$2; mkdir -p $S/cmp/${A}_vs_$B
tr -d '\r' < $S/out/$B/_status.txt > $S/cmp/${A}_vs_$B/_b_status.txt
tr -d '\r' < $S/out/$A/_status.txt | while read -r rc secs job; do
  f=$(echo "$job" | sed -E 's/[^A-Za-z0-9.-]+/_/g; s/^_+|_+$//g')
  grep -q " $job\$" $S/cmp/${A}_vs_$B/_b_status.txt || continue
  line=$($PY -I $S/tools/cmp.py $S/out/$A/$f.npz $S/out/$B/$f.npz --quiet --json $S/cmp/${A}_vs_$B/$f.json | tail -1)
  echo "$job | $line"
done
