"""make_cert.py -- results/B58_IDENTITY.json from the certification's own evidence files.

    python -I make_cert.py <out.json>

Every value below is READ from a file the certification wrote in scratch (the
dumps' comparisons, the suites' outputs, the manifests); nothing is typed except
the descriptions. A level whose evidence file is missing is written as MISSING,
never as passed.
"""
import difflib
import hashlib
import json
import os
import re
import sys

S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SW = S.replace("\\", "/")
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = sys.argv[1]
MISSING = "MISSING"


def p(*parts):
    return os.path.join(S, *parts)


def read(*parts, default=None):
    try:
        with open(p(*parts), encoding="utf-8", errors="replace") as fh:
            return fh.read().replace("\r\n", "\n")
    except OSError:
        return default


def js(*parts):
    t = read(*parts)
    return None if t is None else json.loads(t)


def sha_bytes(path, n=64):
    try:
        with open(path, "rb") as fh:
            return hashlib.sha256(fh.read()).hexdigest()[:n]
    except OSError:
        return None


def text_sha(t):
    return hashlib.sha256(t.encode()).hexdigest()[:16]


def slug(job):
    return re.sub(r"[^A-Za-z0-9.-]+", "_", job).strip("_")


def first_diffs(cmpjson):
    """Every DIFFERENT key of a cmp.py JSON, with its first differing value."""
    return [{x: k.get(x) for x in ("key", "status", "n", "n_differ", "first_flat", "first_index",
                                   "first_a", "first_b", "max_abs") if x in k}
            for k in cmpjson["keys"] if k["status"] != "IDENTICAL"]


def harness(label_a, label_b, jobs):
    rows = []
    for j in jobs:
        c = js("cmp", f"{label_a}_vs_{label_b}", slug(j) + ".json")
        if c is None:
            rows.append(dict(job=j, result=MISSING))
            continue
        row = dict(job=j, values=c["values"], arrays=len(c["keys"]),
                   result="BIT-IDENTICAL" if c["identical"] else "DIFFERENT")
        if not c["identical"]:
            d = first_diffs(c)
            row.update(arrays_different=len(d), first_different=d[0], different=d)
        rows.append(row)
    return rows


def summary(rows):
    ok = [r for r in rows if r["result"] == "BIT-IDENTICAL"]
    return dict(jobs=len(rows), identical=len(ok), values=sum(r.get("values", 0) for r in rows),
                result=("BIT-IDENTICAL" if len(ok) == len(rows) else
                        MISSING if any(r["result"] == MISSING for r in rows) else "DIFFERENT"))


def unittest_summary(text):
    """Ran / OK / FAILED (...) and the ids of failing tests, from unittest's output."""
    if text is None:
        return MISSING
    ran = re.findall(r"^Ran (\d+) tests? in ([\d.]+)s", text, re.M)
    tail = re.findall(r"^(OK(?: \([^)]*\))?|FAILED \([^)]*\))\s*$", text, re.M)
    fails = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\S+ \([^)]*\))", text, re.M)))
    return dict(ran=int(ran[-1][0]) if ran else None, verdict=tail[-1] if tail else None,
                failing=[f.split(" (")[0] + " (" + f.split(" (")[1] for f in fails])


def status(*parts):
    """{label: (exit, seconds)} from a "<exit> <seconds> <label>" status file."""
    out = {}
    for ln in (read(*parts, default="") or "").splitlines():
        bits = ln.split(maxsplit=2)
        if len(bits) == 3:
            out[bits[2]] = dict(exit=int(bits[0]), seconds=int(bits[1]))
    return out


def same_file(a, b):
    ta, tb = read(*a), read(*b)
    if ta is None or tb is None:
        return MISSING
    return ta == tb


def line_diff(a, b, n=6):
    ta, tb = read(*a), read(*b)
    if ta is None or tb is None:
        return MISSING
    return [ln for ln in difflib.unified_diff(ta.splitlines(), tb.splitlines(), "reference", "candidate",
                                              lineterm="", n=0)][:n * 4]


cert = {}
cert["what"] = ("Build step 1's identity certificate: the B58 built through engines.get('b58') on "
                "branch GRA-test (the uncommitted working tree of build step 1) against the plant of "
                "commit cf43fbb (a git archive), on one interpreter, every number compared by its bytes "
                "(numpy tobytes()).")
cert["date"] = "2026-10-21"
cert["asked_by"] = ("decision 24, results/VALIDATION_DECISIONS.md section F: the four-engine build "
                    "threads Engine and Car objects through the code with no default engine; the B58 "
                    "built that way must be bit-identical to cf43fbb (build step 1)")

# ------------------------------------------------------------- the two trees
m0, m1 = read("manifest_start.txt", default=""), read("manifest_end.txt")
cert["reference"] = dict(
    commit="cf43fbb0442125d48cee2316bb96fdeb52b4e145",
    how=("git archive --format=tar cf43fbb, extracted into five scratch trees (ref: harness, L4, "
         "L6, L7, L8; refw: the scripts that rewrite committed files; refa: the app suites and the "
         "learning lab; refd: derive_params.py; refv: verify_docs.py, random_road.py, "
         "test_plant_guards.py), each checked with tar --compare: no content or size difference"),
    archive_sha256=sha_bytes(p("cf43fbb.tar")))
cert["candidate"] = dict(
    tree=r"C:\Users\badcl\Desktop\GRAD-project (the working tree)", branch="GRA-test",
    head="96884f1d7db48ee982e5702b9ed1e2ab1a75914d",
    head_note=("the task named d9c3758; HEAD moved to 96884f1 (a session report). cf43fbb..96884f1 "
               "touches three documents only (results/VALIDATION_DECISIONS.md, HISTORY.md, "
               "SESSION_REPORT_2026-10-20_four-engines.md); the code under test is the uncommitted "
               "working tree of build step 1"),
    files=len([ln for ln in m0.splitlines() if ln.strip()]),
    manifest="sha256 of every file git ls-files --cached --others --exclude-standard lists",
    manifest_sha256_start=text_sha(m0),
    manifest_sha256_end=None if m1 is None else text_sha(m1),
    unchanged_during_certification=None if m1 is None else (m0 == m1))

fp_ref, fp_cand = read("out", "fp_ref.txt", default=""), read("out", "fp_cand.txt", default="")


def fpfield(t, k):
    m = re.search(rf"^\s+{k}\s+(.+?)\s*$", t, re.M)
    return m.group(1) if m else None


cert["identity"] = dict(
    plant_sha=dict(reference=fpfield(fp_ref, "plant_sha"), candidate=fpfield(fp_cand, "plant_sha"),
                   x1_meta_json="3c48890dd15bc116"),
    derived_sha=dict(reference=fpfield(fp_ref, "derived_sha"), candidate=fpfield(fp_cand, "derived_sha")),
    engine=fpfield(fp_cand, "engine"), engine_sha=fpfield(fp_cand, "engine_sha"),
    backend=fpfield(fp_cand, "backend"),
    episodes_sha=dict(reference=fpfield(fp_ref, "episodes_sha"), candidate=fpfield(fp_cand, "episodes_sha")),
    shared_fatal_fields={k: [fpfield(fp_ref, k), fpfield(fp_cand, k)] for k in
                         ("gears", "final_drive", "dtheta_deg", "turb_protect_k", "oil_protect_k", "scenario")},
    schema=dict(reference=2, candidate=3),
    why_plant_sha_moves=("fingerprint.PLANT_FILES gained engines.py and the two typed specs "
                         "(engine_specs/b58.toml, engine_specs/a90_supra.toml), and the code of "
                         "plant.py, thermal.py, engine_env.py and derived.py changed form (literals "
                         "became record fields): plant_sha moves although every number is the same. "
                         "derived_sha does not: data/derived_params.json is byte-identical in both trees."),
    printed_by={"reference": "python fingerprint.py (in the archive)",
                "candidate": "python fingerprint.py --engine b58; python engines.py"})

freeze = read("pip_freeze.txt", default="")
cert["environment"] = dict(
    interpreter=r"C:\Users\badcl\Desktop\GRAD-project\.venv\Scripts\python.exe, for every run in both trees",
    python="3.13.2 (tags/v3.13.2:4f8bb39, Feb  4 2025, 15:23:48) [MSC v.1942 64 bit (AMD64)]",
    packages={ln.split("==")[0]: ln.split("==")[1] for ln in freeze.splitlines() if "==" in ln and
              ln.split("==")[0].lower() in ("numpy", "scipy", "pandas", "torch", "stable_baselines3",
                                            "gymnasium", "matplotlib")},
    pip_freeze=dict(lines=len(freeze.splitlines()), sha256=text_sha(freeze)),
    torch_build="2.14.0+cpu",
    x1=("X1's config.json (runs/extremes_dt1/sighted_seed0) records python 3.13.2, "
        "stable_baselines3 2.9.0, torch 2.14.0+cpu, gymnasium 1.3.0, numpy 2.5.3, omp_threads 1: the same"),
    machine="Windows 11 Home 10.0.26200; 12th Gen Intel Core i9-12900H (6 P-cores, 8 E-cores, 20 threads)",
    threads=("OMP_NUM_THREADS=1 and MKL_NUM_THREADS=1 for the harness, L6 (with torch.set_num_threads(1), "
             "as record_agents.py), L7 and L8 (as run_phase_d.py and train_all.py); the suites as their "
             "own code sets it"),
    scheduling=("L7's two evaluate.py processes were pinned to P-cores 0 and 2 from 00:55 (Windows "
                "processor affinity, siblings idle) and every other process to logical CPUs 4-19, for "
                "speed only: one thread per process, so no result depends on where it ran"),
    rule_4=("CLAUDE.md rule 4 asks for Python 3.12; this machine has 3.11 and 3.13 only (py -0p), and "
            "decision 32 proposes 3.13.2, the interpreter behind X1's stored numbers. Every run here is 3.13.2."))

# ------------------------------------------------------------- the controls
jobs_ctl = [ln.strip() for ln in (read("tools", "jobs_ctl.txt") or "").splitlines() if ln.strip()]
ctl = {}
ctl["reference_against_reference"] = dict(
    expect="BIT-IDENTICAL", what="the harness's control jobs run a second time in the reference",
    jobs=harness("ref", "ref2", jobs_ctl))
for name, lab in (("one_ulp_thermal_c_turb", "ctl_cturb"), ("one_ulp_car_mass", "ctl_mass")):
    ctl[name] = dict(
        expect="DIFFERENT",
        what=(f"the candidate with HARNESS_PERTURB={lab[4:].replace('cturb', 'thermal.c_turb').replace('mass', 'car.mass')}: "
              "that one field moved by one ulp through the frozen records (dataclasses.replace) and "
              "put into engines.get's cache, so every call that fetches the B58 gets it"),
        jobs=harness("cand", lab, jobs_ctl))
l6c = {}
for name, f in (("one_ulp_car_mass_5_episodes", "L6_ctl_mass_committed.json"),
                ("one_ulp_thermal_c_turb_5_episodes", "L6_ctl_cturb_committed.json"),
                ("car_mass_x_1e-9_2_episodes", "L6_ctl_mass1e-9_committed.json"),
                ("car_mass_x_1e-6_2_episodes", "L6_ctl_mass1e-6_committed.json")):
    c = js("cmp", f)
    if c is None:
        l6c[name] = MISSING
        continue
    l6c[name] = dict(scores_equal=f"{c['scores']['equal']} of {c['scores']['compared']}",
                     first_score_difference=c["scores"]["first_difference"],
                     per_step_fields_different=f"{len(c['per_step']['differences'])} of {c['per_step']['fields']}",
                     per_step_first_difference=(c["per_step"]["differences"][0]
                                                if c["per_step"]["differences"] else None),
                     verdict="NOT EQUAL" if not c["identical"] else "EQUAL")
ctl["L6_against_the_committed_files"] = dict(
    expect="NOT EQUAL", what="sighted_seed0 on a perturbed candidate, checked by l6_check.py",
    runs=l6c,
    reading=("the full-precision score check sees a one-ulp change; the per-step check against "
             "eval_record.npz (float32, float16 observation) does not: a one-ulp change rounds away in "
             "the cast, a 1e-9 relative change does not. The per-step level is therefore exact to the "
             "record's own precision, and the cand-against-ref comparison of the uncast float64 "
             "records is the exact one"))
lab_ulp, lab_rel = read("lab", "compare_lab_ctl_cturb_ulp.txt"), read("lab", "compare_lab_ctl_cturb.txt")
ctl["learning_lab"] = {
    "what": "lab_dump.py with LAB_PERTURB, against the unperturbed candidate",
    "one_ulp_thermal_c_turb": None if lab_ulp is None else lab_ulp.splitlines()[0],
    "one_ulp_verdict": None if lab_ulp is None else lab_ulp.strip().splitlines()[-1],
    "thermal_c_turb_x_(1+1e-9)": None if lab_rel is None else lab_rel.splitlines()[0],
    "relative_verdict": None if lab_rel is None else lab_rel.strip().splitlines()[-1],
    "reading": ("the lab's 40-step sessions round a one-ulp change of c_turb away (no output moves); "
                "a 1e-9 relative change moves 1212 values. The lab level detects 1e-9, not one ulp")}
l8c = {}
for name, f in (("wrapper_alone", "L8_ctl_none.json"), ("one_ulp_car_mass", "L8_ctl_mass.json"),
                ("one_ulp_thermal_c_turb", "L8_ctl_cturb.json")):
    c = js("cmp", f)
    l8c[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors_not_identical=len(c["weights"]["differing"]),
        train_record_fields_different=len(c["train_record"]["differing"]), identical=c["identical"])
ctl["L8_training"] = dict(
    what=("the candidate's train.py through l8_perturbed.py (engines.get('b58') replaced before "
          "train.main() runs), against the plain candidate run of the same arguments"),
    expect=dict(wrapper_alone="IDENTICAL", one_ulp_car_mass="DIFFERENT", one_ulp_thermal_c_turb="DIFFERENT",
                relative_steps="DIFFERENT"),
    measured=dict(wrapper_alone="IDENTICAL", one_ulp="IDENTICAL: training cannot see one ulp of the plant",
                  relative_steps="DIFFERENT"),
    runs=l8c)
cert["controls"] = ctl

# ------------------------------------------------------------- the levels
jobs_all = [ln.strip() for ln in (read("tools", "jobs_all.txt") or "").splitlines() if ln.strip()]
L = {}
L["L1_units"] = dict(
    what=("harness job 'units': run_cycle on 1200 operating points x 16 fields, predict, the crank-step "
          "pair, the boost ceiling at three inlets, charge temperature, airflow inversion, the thermal "
          "network at three housings (1801 steps each) and its cold reset, the ECU over 400 steps with "
          "knock (both enrichment modes), the gearbox and road load, the damage model, the locked climb "
          "at three steps, every terrain family's road and speed profile, the deliverable-torque table "
          "re-measured, the environment's MAP ceiling and load loop"),
    rows=harness("ref", "cand", ["units"]))
fam = dict(extremes=[j for j in jobs_all if j.startswith("extremes:")],
           terrain=[j for j in jobs_all if j.startswith("terrain:")],
           random_road=[j for j in jobs_all if j.startswith(("rr:", "rrwrap:"))],
           wideair=[j for j in jobs_all if j.startswith(("wideair:", "wideseq:"))],
           conditions=[j for j in jobs_all if j.startswith("cond:")])
L["L2_roads"] = {k: dict(rows=harness("ref", "cand", v)) for k, v in fam.items()}
for k in L["L2_roads"]:
    L["L2_roads"][k]["summary"] = summary(L["L2_roads"][k]["rows"])
L["L2_roads"]["what"] = (
    "every road family: ExtremesTrainingEnv (5 families x neutral and seeded random actions, 900 + 200 "
    "steps), TerrainTrainingEnv (5 families), random_road.climb at dt 0.2 and its RandomClimb wrapper, "
    "WideAirTrainingEnv at the four corners of 0-45 C x 80-101.3 kPa plus a 4-episode sequence, and "
    "conditions_test._run (50 C, 76/82/90 kPa, 12-20 %, the four hand policies); every step's "
    "observation, reward, info and 21 internal state values, the roads themselves")
L["L3_premise"] = dict(
    harness=harness("ref", "cand", ["premise"]),
    check_premise=dict(
        candidate=(read("L5", "cand_premise_exit.txt") or MISSING).strip(),
        reference=(read("L5", "ref_premise_exit.txt") or MISSING).strip(),
        premise_json_cand_equals_ref=same_file(("L5", "cand_premise_OUT_premise.json"),
                                               ("L5", "ref_premise_OUT_premise.json")),
        premise_json_sha256=sha_bytes(p("L5", "cand_premise_OUT_premise.json"), 16),
        git_diff_results_premise_json="empty (the run rewrote the file with the same bytes)",
        stdout_difference=line_diff(("L5", "ref_premise_stdout.txt"), ("L5", "cand_premise_stdout.txt")),
        baseline="848.1 damage at 883 C peak housing, the committed figure"))
l4 = {}
for tag, name in (("", "test_reward"), ("_random", "test_reward --road random")):
    l4[name] = dict(candidate=(read("L4", f"cand{tag}_exit.txt") or MISSING).strip(),
                    reference=(read("L4", f"ref{tag}_exit.txt") or MISSING).strip(),
                    stdout_identical=same_file(("L4", f"ref{tag}_stdout.txt"), ("L4", f"cand{tag}_stdout.txt")),
                    stdout_bytes_on_disk=os.path.getsize(p("L4", f"cand{tag}_stdout.txt")) if os.path.exists(p("L4", f"cand{tag}_stdout.txt")) else MISSING,
                    stdout_sha256=text_sha(read("L4", f"cand{tag}_stdout.txt") or ""),
                    stderr_lines=dict(candidate=len((read("L4", f"cand{tag}_stderr.txt") or "").splitlines()),
                                      reference=len((read("L4", f"ref{tag}_stderr.txt") or "").splitlines())))
L["L4_test_reward"] = l4
l5 = {}
for road in ("extremes", "wideair"):
    out_c, out_r = ("L5", f"cand_roads_{road}_OUT_training_roads_{road}.json"), \
                   ("L5", f"ref_roads_{road}_OUT_training_roads_{road}.json")
    committed = os.path.join(REPO, "results", f"training_roads_{road}.json")
    l5[f"check_roads --road {road}"] = dict(
        candidate=(read("L5", f"cand_roads_{road}_exit.txt") or MISSING).strip(),
        reference=(read("L5", f"ref_roads_{road}_exit.txt") or MISSING).strip(),
        output_cand_equals_ref=same_file(out_c, out_r),
        output_bytes_on_disk=os.path.getsize(p(*out_c)) if os.path.exists(p(*out_c)) else MISSING, output_sha256=sha_bytes(p(*out_c), 16),
        committed_sha256=sha_bytes(committed, 16),
        output_equals_committed=sha_bytes(p(*out_c)) == sha_bytes(committed),
        stdout_identical=same_file(("L5", f"ref_roads_{road}_stdout.txt"), ("L5", f"cand_roads_{road}_stdout.txt")),
        verdict_line=[ln for ln in (read("L5", f"cand_roads_{road}_stdout.txt") or "").splitlines()
                      if ln.startswith(("PASS", "FAIL", "baseline past"))])
l5["check_roads --road extremes"]["committed_file_note"] = (
    "the committed results/training_roads_extremes.json is older than the code that writes it: "
    "both trees write the same 167157 bytes, which add floor_nm (15.0) and p_kpa (101.3) to each "
    "of the 40 roads; the 600 values the two share are identical. cf43fbb's own check_roads.py "
    "writes the new file too, so the committed one has been stale since 06f4686 (11 October), "
    "not since build step 1. The committed file was put back in the working tree (git diff empty)")
l5["validate.py"] = dict(
    stdout_identical=same_file(("L5", "ref_validate.txt"), ("L5", "cand_validate.txt")),
    candidate=(read("L5", "cand_validate_exit.txt") or MISSING).strip(),
    reference=(read("L5", "ref_validate_exit.txt") or MISSING).strip(),
    rows=[ln for ln in (read("L5", "cand_validate.txt") or "").splitlines() if "quantities inside" in ln],
    validation_table_md="unchanged: validate.py prints and writes nothing; git diff validation_table.md is empty")
dc = js("L5", "derived_check.json")
l5["derive_params.py"] = MISSING if dc is None else dict(
    how=("run in a scratch copy of each tree (copy_tree.py for the candidate, the archive for the "
         "reference); the copies' data/derived_params.json compared with the committed one"),
    derived_sha=dict(zip(("committed", "candidate_copy", "reference_copy"), dc["derived_sha"])),
    differences={k: [d["path"] for d in v] for k, v in dc["differences"].items()},
    candidate_and_reference_files_byte_identical=same_file(("L5", "derived_params_DERIVED_cand.json"),
                                                           ("L5", "derived_params_DERIVED_ref.json")))


def suite(t, label):
    return unittest_summary(read("app", f"{t}_{label}.txt"))


apps = {}
for label in ("test_simulation", "test_agents", "test_results", "lab_tests"):
    apps[label] = dict(candidate=suite("cand", label), reference_git_clone=suite("refgit", label),
                       reference_archive=suite("ref", label))
tr = {t: read("app", f"{t}_test_replay_full.txt") for t in ("cand", "ref")}
apps["test_replay --full"] = dict(
    candidate=None if tr["cand"] is None else re.findall(r"^(\d+ of \d+ checks pass.*)$", tr["cand"], re.M),
    reference_archive=None if tr["ref"] is None else re.findall(r"^(\d+ of \d+ checks pass.*)$", tr["ref"], re.M),
    differing_lines=line_diff(("app", "ref_test_replay_full.txt"), ("app", "cand_test_replay_full.txt")))
for m in ("test_agent_generations", "test_agent_sources", "test_artifact_api", "test_artifacts",
          "test_graphics_revisions", "test_launcher", "test_records", "test_results_comparisons",
          "test_results_graphics", "test_results_records", "test_results_sets"):
    apps[m] = dict(candidate=suite("cand", m), reference_archive=suite("ref", m))
l5["app_and_learning_lab_suites"] = dict(
    how=("every app/test_*.py suite and the learning lab's tests, in the candidate, in the archive "
         "(refa) and, for the four whose results depend on git, in a git clone of cf43fbb checked out "
         "detached in scratch (refgit; its files equal the archive's, git status clean)"),
    suites=apps)
lab = read("lab", "compare_cand_ref.txt")
l5["learning_lab_outputs"] = dict(
    how=("lab_dump.py (the build step's own tool): catalog metadata in both languages, /api/plant at "
         "three points, /api/thermal, four sessions stepped 40 times, in refa and in the candidate"),
    result=None if lab is None else lab.splitlines()[0], verdict=None if lab is None else lab.strip().splitlines()[-1],
    reworded=None if lab is None else [ln.strip() for ln in lab.splitlines() if ln.strip().startswith("re-worded")])
gen = {t: (read("L5", f"{t}_generality_exit.txt") or MISSING).strip() for t in ("cand", "ref")}
l5["generality_test.py"] = dict(
    candidate=gen["cand"], reference=gen["ref"],
    output_cand_equals_ref=same_file(("L5", "cand_generality_OUT_generality.json"),
                                     ("L5", "ref_generality_OUT_generality.json")),
    output_equals_committed=(sha_bytes(p("L5", "cand_generality_OUT_generality.json"))
                             == sha_bytes(os.path.join(REPO, "results", "generality.json"))),
    stdout_difference=line_diff(("L5", "ref_generality_stdout.txt"), ("L5", "cand_generality_stdout.txt")))
L["L5_suites_that_write_or_pin"] = l5
l6 = {}
for tag in ("sighted_seed0", "sighted_seed4", "blind_seed2", "blind_seed6"):
    c = js("cmp", f"L6_{tag}.json")
    row = dict(cand_vs_ref=MISSING if c is None else dict(
        values=c["values"], arrays=len(c["keys"]), result="BIT-IDENTICAL" if c["identical"] else "DIFFERENT",
        **({} if c["identical"] else {"different": first_diffs(c)})))
    for t in ("cand", "ref"):
        k = js("cmp", f"L6_{t}_{tag}_committed.json")
        row[f"{t}_vs_committed"] = MISSING if k is None else dict(
            scores=f"{k['scores']['equal']} of {k['scores']['compared']} equal at full precision",
            per_step=(f"{k['per_step']['fields']} fields, {k['per_step']['values']} values, "
                      + ("all identical" if not k["per_step"]["differences"] else
                         f"{len(k['per_step']['differences'])} fields DIFFERENT")),
            result="EQUAL" if k["identical"] else "NOT EQUAL",
            **({} if k["identical"] else {"first_score_difference": k["scores"]["first_difference"],
                                          "per_step_differences": k["per_step"]["differences"]}))
    l6[tag] = row
L["L6_x1_agents"] = dict(
    what=("four X1 agents (runs/extremes_dt1: sighted_seed0, sighted_seed4, blind_seed2, blind_seed6) on "
          "all twenty frozen episodes through evaluate.run_episode with a record, as record_agents.py's "
          "workers run them (OMP 1, torch 1 thread, SAC.load on CPU), in both trees. Compared: the two "
          "trees' dumps, every array by tobytes() (scores in float64, every recorded field uncast and "
          "after step_record.cast); each tree's scores against results/phase_d_extremes_dt1_raw.json "
          "by float equality (7 values x 20 episodes); each tree's cast records against "
          "results/agents/extremes_dt1/<tag>/eval_record.npz, field by field (46 fields, 1 064 200 values)"),
    agents=l6)
d7 = js("L7", "l7_diff.json")
exp7 = read("L7", "l7_expect.txt")
L["L7_evaluate_end_to_end"] = MISSING if d7 is None else dict(
    how=("evaluate.py in each tree for X1's sighted_seed0: the three hand-written policies and the "
         "agent on the twenty frozen episodes, OMP/MKL threads 1. The reference scored "
         "runs/extremes_dt1/sighted_seed0 itself (schema-2 meta.json, plant_sha 3c48890dd15bc116); "
         "the candidate scored a scratch copy with the byte-identical final.zip and a meta.json "
         "re-stamped by make_meta.py with this tree's schema-3 FATAL block and an explicit "
         "identity_override (original schema 2, original plant_sha, the original file's sha256). "
         "No --force-plant-mismatch. Before the comparison the fingerprint block and each run's "
         "model directory were removed, nothing else"),
    candidate=(read("L7", "cand_exit.txt") or MISSING).split("\n")[0],
    reference=(read("L7", "ref_exit.txt") or MISSING).split("\n")[0],
    meta_json_sha256=dict(original=sha_bytes(os.path.join(REPO, "runs", "extremes_dt1", "sighted_seed0",
                                                          "meta.json"), 16),
                          final_zip=sha_bytes(os.path.join(REPO, "runs", "extremes_dt1", "sighted_seed0",
                                                           "final.zip"), 16),
                          scratch_final_zip=sha_bytes(p("L7", "cand_model", "sighted_seed0", "final.zip"), 16)),
    lines_compared=d7["lines_ref"], identical=d7["identical"], diff=d7["diff"],
    fingerprint_blocks=dict(reference=d7["ref_fingerprint"], candidate=d7["cand_fingerprint"]),
    rows_against_the_committed_raw_scores=None if exp7 is None else exp7.strip().splitlines()[-1],
    reading=("the printed rows carry one decimal, so this level is exact to the report's own precision; "
             "L6 compares the same episodes at full precision"))
l8 = {}
for name, f in (("extremes, sighted (X1's design)", "L8_extremes_sighted_seed0.json"),
                ("extremes, blinded (--no-preview)", "L8_extremes_blind_seed0.json"),
                ("wideair, sighted (X2's design)", "L8_wideair_sighted_seed0.json")):
    c = js("cmp", f)
    l8[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors=c["weights"]["tensors"], values=c["weights"]["values"],
        tensors_not_byte_identical=len(c["weights"]["differing"]),
        sb3_counters={k: v["a"] for k, v in c["data"].items()},
        counters_equal=all(v["equal"] for v in c["data"].values()),
        train_record=f"{c['train_record']['fields']} fields, {c['train_record']['values']} values, "
                     + ("all identical" if not c["train_record"]["differing"] else
                        f"{len(c['train_record']['differing'])} DIFFERENT"),
        curve_identical=c["curve_identical"], result="IDENTICAL" if c["identical"] else "DIFFERENT")
L["L8_training"] = dict(
    how=("train.py --steps 600 --seed 0 --device cpu --road <road> [--no-preview] --out <scratch>, "
         "OMP/MKL threads 1, in each tree (the candidate adds --engine b58). Compared: every tensor "
         "of final.zip (policy, the three optimizers' state, log_ent_coef) by its bytes and by the "
         "largest absolute difference; stable-baselines3's counters; every field of the recorded "
         "600 steps (train_record.npz); curve.csv. The run directories were deleted afterwards: an "
         "identity test, not an experiment"),
    runs=l8,
    reading=("600 steps is 500 gradient updates (learning starts at 100) inside the first episode. The "
             "network sees float32 observations and rewards, and a one-ulp change of the car's mass or "
             "the housing's capacity never reached float32 in 600 steps: the controls with one ulp "
             "train IDENTICAL weights although their engine_sha differs. Relative changes of 1e-9 and "
             "1e-6 are seen. L8 certifies the training loop on the plant; the plant itself is "
             "certified at full precision by L1-L3 and L6"))
l8x = {}
for name, f in (("car.mass x (1 + 1e-9)", "L8_ctl_mass1e-9.json"), ("car.mass x (1 + 1e-6)", "L8_ctl_mass1e-6.json")):
    c = js("cmp", f)
    l8x[name] = MISSING if c is None else dict(
        largest_weight_difference=c["weights"]["largest_abs_difference"],
        tensors_not_identical=len(c["weights"]["differing"]),
        first_tensor_difference=c["weights"]["differing"][0] if c["weights"]["differing"] else None,
        train_record_fields_different=len(c["train_record"]["differing"]),
        first_record_difference=c["train_record"]["differing"][0] if c["train_record"]["differing"] else None,
        identical=c["identical"])
cert["controls"]["L8_training"]["relative_steps"] = l8x
ids8 = js("L8", "run_identities.json") or {}
cert["controls"]["L8_training"]["engine_sha_of_each_run"] = {k: v.get("engine_sha") or f"(schema {v.get('schema')})"
                                                             for k, v in ids8.items()}
cert["controls"]["L8_training"]["engine_sha_note"] = (
    "read from each run's meta.json before the run directories were deleted: the perturbed plant "
    "reached train.main (its engine_sha differs), and still trained the same weights at one ulp")
L["L8_training"]["final_zip_note"] = (
    "the zip files themselves differ in bytes (stable-baselines3 stores run metadata in its 'data' "
    "member); the tensors and the counters are what is compared")
cert["levels"] = L
st = status("suites", "_status.txt")


def last_lines(label, pattern):
    t = read("suites", f"{label}.txt")
    return None if t is None else [ln.strip() for ln in t.splitlines() if re.search(pattern, ln)]


suites = {}
for label in ("cand_test_engine_threading", "cand_test_epa_map", "cand_test_plant_guards", "ref_test_plant_guards",
              "cand_test_wide_air"):
    suites[label] = dict(status=st.get(label, MISSING), result=unittest_summary(read("suites", f"{label}.txt")))
for label in ("cand_random_road", "ref_random_road"):
    t = read("suites", f"{label}.txt")
    suites[label] = dict(status=st.get(label, MISSING),
                         output=None if t is None else [ln for ln in t.strip().splitlines()][-3:])
suites["cand_verify_docs"] = dict(status=st.get("cand_verify_docs", MISSING),
                                  verdict=last_lines("cand_verify_docs", r"checks (pass|failed)"))
suites["ref_verify_docs"] = dict(status=(read("suites", "ref_verify_docs_exit.txt") or MISSING).strip(),
                                 verdict=last_lines("ref_verify_docs", r"checks (pass|failed)"),
                                 tree="refv, the archive (verify_docs.py falls back to a glob without .git)")
vc = read("suites", "cand_verify_docs.txt") or ""
vr = read("suites", "ref_verify_docs.txt") or ""
lab_c = {re.sub(r"\s+data .*$", "", ln.strip()[3:].strip()) for ln in vc.splitlines() if ln.strip().startswith("ok ")}
lab_r = {re.sub(r"\s+data .*$", "", ln.strip()[3:].strip()) for ln in vr.splitlines() if ln.strip().startswith("ok ")}
suites["verify_docs_checks_only_in_the_reference"] = sorted(x for x in lab_r - lab_c if "figure mentions" not in x
                                                            and "retired figures" not in x)
suites["verify_docs_checks_only_in_the_candidate"] = sorted(x for x in lab_c - lab_r if "figure mentions" not in x
                                                            and "retired figures" not in x)
dt = read("suites", "drift_test.txt")
suites["drift_test"] = dict(
    status=(read("suites", "drift_test_exit.txt") or MISSING).strip(),
    control=None if dt is None else [ln.strip() for ln in dt.splitlines() if "control" in ln][:1],
    verdict=None if dt is None else [ln.strip() for ln in dt.splitlines() if "drifts CAUGHT" in ln],
    rows=None if dt is None else [ln.strip() for ln in dt.splitlines() if re.match(r"\s*row\s+\d+", ln)])
dc2 = read("suites", "drift_control_with_certificate.txt")
suites["drift_control_with_the_certificate_present"] = MISSING if dc2 is None else dc2.strip().splitlines()[-1]
fpt = read("suites", "cand_fingerprint.txt")
suites["cand_fingerprint"] = None if fpt is None else fpt.strip().splitlines()
cert["suites"] = suites
node = {t: read("app", f"{t}_node_tests.txt") for t in ("cand", "ref", "refgit")}


def node_summary(t):
    if node[t] is None:
        return MISSING
    return {k: int(v) for k, v in re.findall(r"^\S+ (tests|pass|fail|skipped) (\d+)$", node[t], re.M)}


l5["app_and_learning_lab_suites"]["suites"]["node --test static/sim/*.test.mjs"] = dict(
    candidate=node_summary("cand"), reference_archive=node_summary("ref"), reference_git_clone=node_summary("refgit"),
    note=("the 12 skipped in cf43fbb need three.js from app/static/vendor/, which git ignores: it is in "
          "the working tree and in no checkout (skip condition !THREE in engine-inspector.test.mjs and its "
          "neighbours)"))


def failing(t, label):
    s = unittest_summary(read("app", f"{t}_{label}.txt"))
    return set() if s == MISSING else {f.split(" (")[0] for f in s["failing"]}


diff_list = []
diff_list.append(dict(
    where="check_premise.py, stdout (L3)", kind="a printed line, no number",
    first_difference=line_diff(("L5", "ref_premise_stdout.txt"), ("L5", "cand_premise_stdout.txt")),
    why="the candidate prints the plant it names before the table; every other byte of the 2187 is identical, "
        "and results/premise.json is byte-identical"))
if d7 is not None:
    diff_list.append(dict(
        where="evaluate.py's report, the fingerprint block (L7)", kind="provenance, removed before the comparison",
        first_difference=["  plant_sha                3c48890dd15bc116", "  plant_sha                c276354cff16132c"],
        why="schema 2 against schema 3: plant_sha moves (section 1), engine / engine_sha / backend are new "
            "FATAL fields, git_head / git_dirty / git_dirty_plant_files are None in the archive and "
            "plant_text_sha is the byte hash of different files; every other line of the report is identical"))
diff_list.append(dict(
    where="check_roads.py --road extremes, against the committed results/training_roads_extremes.json (L5)",
    kind="a committed file older than the code that writes it, on cf43fbb as well",
    first_difference="road 0 (seed 100) gains 'floor_nm': 15.0 and 'p_kpa': 101.3; so does every road",
    why="both trees write the same 167157 bytes; the 600 shared values are identical. Not a build-step-1 "
        "difference: the committed file predates 06f4686, which added the two keys"))
trd = line_diff(("app", "ref_test_replay_full.txt"), ("app", "cand_test_replay_full.txt"))
diff_list.append(dict(
    where="python -m app.test_replay --full (L5)", kind="a check's label, same value",
    first_difference=[ln for ln in (trd if isinstance(trd, list) else []) if ln.startswith(("-  ", "+  "))],
    why="the M7 check reads the damage knee from the plant now (engine_env.TURB_PROTECT_K is gone); "
        "turb_c 849.9 in both; 59 of 59 checks pass in both, every pin unchanged"))
if lab is not None:
    diff_list.append(dict(
        where="the learning lab's outputs (L5)", kind="source-line numbers and three texts",
        first_difference=[ln.strip() for ln in lab.splitlines()[1:7]],
        why="lab_compare.py: 0 of 36 325 values differ; 178 source-line numbers moved with the edited files "
            "and 88 strings repeat three texts that named defaults which no longer exist"))
only_ref = suites.get("verify_docs_checks_only_in_the_reference")
only_cand = suites.get("verify_docs_checks_only_in_the_candidate")
diff_list.append(dict(
    where="verify_docs.py, the list of checks", kind="checks merged",
    first_difference=dict(only_in_the_reference=only_ref, only_in_the_candidate=only_cand),
    counts=dict(reference=suites["ref_verify_docs"]["verdict"], candidate=suites["cand_verify_docs"]["verdict"]),
    why=("make_grade_climb has no defaults any more, so the two checks that read its duration= and dt= "
         "defaults (900 s, 0.2 s) became one check that it has none; seven others were relabelled with "
         "the same values. The documents' 900 s training episode and 0.2 s step are no longer checked "
         "against anything")))
for label in ("test_results", "test_agents", "test_simulation", "lab_tests"):
    fc, fr = failing("cand", label), failing("refgit", label)
    diff_list.append(dict(
        where=f"{label}: failing tests (L5)", kind="pre-existing failures",
        candidate_only=sorted(fc - fr), reference_only=sorted(fr - fc), both=sorted(fc & fr),
        why={"test_results": "the same tests fail with the same assertions in a git clone of cf43fbb: they take "
                             "Python 3.13.2 as 'another Python', and this venv is 3.13.2; the error is pwsh "
                             "missing. Two of cf43fbb's failures are skipped in the candidate, whose plant "
                             "files are not committed yet",
             "test_agents": "test_page_assets_ids (an asset the page names is missing) and the lab launcher "
                            "(pwsh missing), on cf43fbb as well",
             "test_simulation": "the page's asset test, on cf43fbb as well",
             "lab_tests": "three tests broken by the 8 October grade ramp, on cf43fbb as well; cf43fbb's "
                          "fourth, the catalog's stale premise pin, was updated in build step 1"}[label]))
rrd = line_diff(("suites", "ref_random_road.txt"), ("suites", "cand_random_road.txt"))
diff_list.append(dict(
    where="python random_road.py, the self-test", kind="a code hash: the D2 protocol's road_sha",
    first_difference=[ln.strip() for ln in (rrd if isinstance(rrd, list) else []) if ln.startswith(("-  ", "+  "))],
    why=("random_road.code_sha() hashes the module's code, and its two self-checks now build the B58's "
         "locked climb by name (locked_climb(engines.get('b58'), ...)) instead of make_grade_climb()'s "
         "defaults; climb() is unchanged, the self-test passes in both trees and every random_road job of "
         "L2 is bit-identical. road_sha is part of the 'scenario' FATAL field under --protocol d2, so a "
         "D2 or C4 agent of cf43fbb would be refused there on scenario as well as on its schema")))
diff_list.append(dict(
    where="training's final.zip files (L8)", kind="zip bytes", first_difference="the 'data' member",
    why="stable-baselines3 stores run metadata there; every tensor and every counter is identical"))
cert["different"] = diff_list
cert["tools"] = {os.path.basename(f): sha_bytes(f, 16) for f in sorted(
    os.path.join(S, "tools", x) for x in os.listdir(p("tools")) if x.endswith((".py", ".sh", ".txt")))}
cert["tools_note"] = ("The harness and every comparison tool live in scratch "
                      f"({SW}/tools), not in the repository: they run cf43fbb's engine-less calls on the "
                      "reference side, which test_engine_threading.py's scan would refuse in the tree. "
                      "harness.py is build step 1's own (scratchpad build1/refactor/tools, sha256 "
                      "826e992f5f5c3be9...) with one addition: under HARNESS_PERTURB the perturbed plant "
                      "also goes into engines.get's cache, so the control reaches code that fetches the "
                      "plant itself (conditions_test._plant). Edited during the certification, and how: "
                      "l6_agents.py and l8_perturbed.py gained the relative step (car.mass:1e-9) after the "
                      "unperturbed runs, in the HARNESS_PERTURB branch only; l8_compare.py detaches tensors "
                      "(log_ent_coef is saved with requires_grad); run_l4.sh names its --road output after "
                      "the --road random run, whose four files were renamed by hand to match. The sha256 "
                      "listed are the final files.")
cert["reproduce"] = js("reproduce.json") or MISSING

# ------------------------------------------------------------- the verdict, from the levels above
harness_rows = L["L1_units"]["rows"] + L["L3_premise"]["harness"] + [
    r for k, v in L["L2_roads"].items() if k != "what" for r in v["rows"]]
l6_rows = list(L["L6_x1_agents"]["agents"].values())
checks = {
    "harness jobs (L1, L2, L3)": all(r["result"] == "BIT-IDENTICAL" for r in harness_rows),
    "premise.json (L3)": L["L3_premise"]["check_premise"]["premise_json_cand_equals_ref"] is True,
    "test_reward stdout (L4)": all(v["stdout_identical"] is True for v in L["L4_test_reward"].values()),
    "check_roads outputs (L5)": all(L["L5_suites_that_write_or_pin"][f"check_roads --road {r}"]["output_cand_equals_ref"]
                                    is True for r in ("extremes", "wideair")),
    "validate.py stdout (L5)": L["L5_suites_that_write_or_pin"]["validate.py"]["stdout_identical"] is True,
    "derive_params output (L5)": (L["L5_suites_that_write_or_pin"]["derive_params.py"] != MISSING and
                                  L["L5_suites_that_write_or_pin"]["derive_params.py"]
                                  ["candidate_and_reference_files_byte_identical"] is True),
    "generality output (L5)": L["L5_suites_that_write_or_pin"]["generality_test.py"]["output_cand_equals_ref"] is True,
    "L6 agents": all(r["cand_vs_ref"] != MISSING and r["cand_vs_ref"]["result"] == "BIT-IDENTICAL" and
                     r["cand_vs_committed"] != MISSING and r["cand_vs_committed"]["result"] == "EQUAL" and
                     r["ref_vs_committed"] != MISSING and r["ref_vs_committed"]["result"] == "EQUAL" for r in l6_rows),
    "L7 report": L["L7_evaluate_end_to_end"] != MISSING and L["L7_evaluate_end_to_end"]["identical"] is True,
    "L8 training": all(v != MISSING and v["result"] == "IDENTICAL" for v in L["L8_training"]["runs"].values()),
    "candidate tree unchanged": cert["candidate"]["unchanged_during_certification"] is True,
}
cert["verdict"] = dict(
    result="BIT-IDENTICAL at every level" if all(checks.values()) else "NOT CERTIFIED: see checks",
    checks=checks,
    values_compared_byte_for_byte=dict(
        harness=sum(r.get("values", 0) for r in harness_rows),
        l6_agents=sum(r["cand_vs_ref"]["values"] for r in l6_rows if r["cand_vs_ref"] != MISSING),
        l8_tensor_values=sum(v["values"] for v in L["L8_training"]["runs"].values() if v != MISSING)))
order = ["what", "date", "asked_by", "verdict", "reference", "candidate", "identity", "environment", "controls",
         "levels", "suites", "different", "tools", "tools_note", "reproduce"]
cert = {k: cert[k] for k in order if k in cert}

with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
    json.dump(cert, fh, indent=1, ensure_ascii=False)
    fh.write("\n")
print("written", OUT)
