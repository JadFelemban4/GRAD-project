"""make_meta.py -- L7's candidate model directory: X1's sighted_seed0, its meta.json
re-stamped with this tree's schema-3 fingerprint for the identity test only.

    python -I make_meta.py <candidate_tree> <src_run_dir> <dest_run_dir>

final.zip is copied byte for byte (sha256 printed for both). meta.json keeps
every ADVISORY field of the original (train_dt, steps_requested, seed, tag, ...)
and takes the FATAL fields and the schema from the live candidate fingerprint
(fingerprint.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d")),
so evaluate.py's check passes without --force-plant-mismatch. The re-stamp is
declared inside the file, in "identity_override": the original schema and
plant_sha, the original meta.json's sha256, and why. This is not a result
directory; it lives in scratch and nothing under runs/ is touched.
"""
import hashlib
import json
import os
import shutil
import sys

tree, src, dest = (os.path.abspath(p) for p in sys.argv[1:4])
os.chdir(tree)
sys.path.insert(0, tree)
import engines  # noqa: E402
import fingerprint as FP  # noqa: E402


def sha(p):
    with open(p, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


os.makedirs(dest, exist_ok=True)
shutil.copyfile(os.path.join(src, "final.zip"), os.path.join(dest, "final.zip"))
orig = FP.read(os.path.join(src, "meta.json"))
live = FP.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d")
meta = {k: v for k, v in orig.items() if k not in FP.FATAL}
meta.update({k: live[k] for k in FP.FATAL})
meta["schema"] = live["schema"]
meta["identity_override"] = dict(
    reason=("build step 1's identity certificate (results/B58_IDENTITY.md, level L7): X1's "
            "sighted_seed0 scored end to end by this tree's evaluate.py and diffed against "
            "cf43fbb's evaluate.py on the original directory. Its FATAL fields are this tree's "
            "schema-3 block, stamped by make_meta.py so that no --force-plant-mismatch is "
            "needed; whether the plant behind them is cf43fbb's is what the certificate's "
            "levels measure. Not a result directory"),
    original_schema=orig.get("schema"), original_plant_sha=orig.get("plant_sha"),
    original_derived_sha=orig.get("derived_sha"),
    original_meta_sha256=sha(os.path.join(src, "meta.json")),
    original_dir=src.replace(os.sep, "/"))
FP.write(os.path.join(dest, "meta.json"), meta)
print("final.zip sha256", sha(os.path.join(src, "final.zip")), "->", sha(os.path.join(dest, "final.zip")))
print("FATAL disagreements with the live tree:", FP.compare(meta, live) or "none")
print("schema_problem:", FP.schema_problem(meta))
print(json.dumps(meta["identity_override"], indent=1))
