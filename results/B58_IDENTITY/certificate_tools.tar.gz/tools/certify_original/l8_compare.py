"""l8_compare.py -- L8: two 600-step SAC runs, one per tree, compared.

    python l8_compare.py <run_dir_a> <run_dir_b> [--json out.json]

<run_dir> is train.py's OUT/<tag>/. Compared:
  final.zip   every tensor of policy.pth (actor, critics, target critics), of
              the three optimizers' state and of pytorch_variables.pth
              (log_ent_coef): the largest |a - b| over all of them is THE
              number (train.py's own check, ActionRecorder's docstring: "largest
              weight difference 0.0"), and every tensor is also compared by its
              bytes
  data        stable-baselines3's own counters (num_timesteps, _n_updates, ...)
  train_record.npz   every recorded training step, field by field, tobytes()
  curve.csv   byte for byte
"""
import io
import json
import sys
import zipfile

import numpy as np
import torch

a_dir, b_dir = sys.argv[1], sys.argv[2]
out = dict(a=a_dir, b=b_dir)


def tensors(obj, prefix=""):
    """Every tensor inside a (nested) state dict, by dotted path."""
    if torch.is_tensor(obj):
        yield prefix, obj.detach()         # log_ent_coef is saved with requires_grad
    elif isinstance(obj, dict):
        for k in sorted(obj, key=str):
            yield from tensors(obj[k], f"{prefix}.{k}" if prefix else str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            yield from tensors(v, f"{prefix}[{i}]")


def load_zip(d):
    z = zipfile.ZipFile(f"{d}/final.zip")
    parts = {n: torch.load(io.BytesIO(z.read(n)), map_location="cpu", weights_only=True)
             for n in z.namelist() if n.endswith(".pth")}
    return parts, json.loads(z.read("data"))


pa, da = load_zip(a_dir)
pb, db = load_zip(b_dir)
worst, n_t, n_vals, differing = 0.0, 0, 0, []
for member in sorted(set(pa) | set(pb)):
    ta, tb = dict(tensors(pa.get(member, {}))), dict(tensors(pb.get(member, {})))
    for k in sorted(set(ta) | set(tb)):
        if k not in ta or k not in tb:
            differing.append(dict(tensor=f"{member}:{k}", why="missing in one"))
            continue
        x, y = ta[k], tb[k]
        n_t += 1
        n_vals += x.numel()
        if x.shape != y.shape or x.dtype != y.dtype:
            differing.append(dict(tensor=f"{member}:{k}", why=f"{x.shape} {x.dtype} vs {y.shape} {y.dtype}"))
            continue
        d = float((x.double() - y.double()).abs().max()) if x.numel() else 0.0
        if x.is_floating_point():
            worst = max(worst, d)
        if x.numpy().tobytes() != y.numpy().tobytes():
            flat = np.flatnonzero(x.numpy().reshape(-1) != y.numpy().reshape(-1))
            i = int(flat[0]) if len(flat) else -1
            differing.append(dict(tensor=f"{member}:{k}", max_abs=d, n_differ=int(len(flat)),
                                  first_flat=i, first_a=repr(x.reshape(-1)[i].item()) if i >= 0 else None,
                                  first_b=repr(y.reshape(-1)[i].item()) if i >= 0 else None))
out["weights"] = dict(members=sorted(set(pa) | set(pb)), tensors=n_t, values=n_vals,
                      largest_abs_difference=worst, differing=differing)
print(f"final.zip: {n_t} tensors, {n_vals} values in {sorted(set(pa) | set(pb))}")
print(f"  LARGEST WEIGHT DIFFERENCE {worst!r}; tensors not byte-identical: {len(differing)}")
for x in differing[:10]:
    print("   ", x)

keys = ("num_timesteps", "_total_timesteps", "_n_updates", "_episode_num", "seed", "learning_starts",
        "buffer_size", "batch_size")
dd = {k: (da.get(k), db.get(k)) for k in keys}
out["data"] = {k: dict(a=v[0], b=v[1], equal=v[0] == v[1]) for k, v in dd.items()}
print("  data:", ", ".join(f"{k} {v[0]}{'' if v[0] == v[1] else ' vs ' + str(v[1])}" for k, v in dd.items()))

ra, rb = np.load(f"{a_dir}/train_record.npz"), np.load(f"{b_dir}/train_record.npz")
rec_bad, rec_vals = [], 0
for k in sorted(set(ra.files) | set(rb.files)):
    if k not in ra.files or k not in rb.files:
        rec_bad.append(dict(field=k, why="missing in one"))
        continue
    x, y = ra[k], rb[k]
    rec_vals += x.size
    if x.dtype != y.dtype or x.shape != y.shape or x.tobytes() != y.tobytes():
        i = int(np.flatnonzero(x.reshape(-1) != y.reshape(-1))[0]) if x.shape == y.shape else -1
        rec_bad.append(dict(field=k, first_flat=i, a=repr(x.reshape(-1)[i].item()) if i >= 0 else None,
                            b=repr(y.reshape(-1)[i].item()) if i >= 0 else None))
out["train_record"] = dict(fields=len(set(ra.files) | set(rb.files)), values=int(rec_vals), differing=rec_bad)
print(f"  train_record.npz: {len(set(ra.files) | set(rb.files))} fields, {rec_vals} values, "
      + ("all identical" if not rec_bad else f"{len(rec_bad)} DIFFERENT: {rec_bad[:3]}"))

ca, cb = open(f"{a_dir}/curve.csv", "rb").read(), open(f"{b_dir}/curve.csv", "rb").read()
out["curve_identical"] = ca == cb
print(f"  curve.csv: {'identical' if ca == cb else 'DIFFERENT'} ({ca.count(b'\n') - 1} episodes)")
ok = worst == 0.0 and not differing and not rec_bad and ca == cb and all(v["equal"] for v in out["data"].values())
out["identical"] = ok
print("VERDICT:", "IDENTICAL TRAINING" if ok else "NOT IDENTICAL")
if "--json" in sys.argv:
    with open(sys.argv[sys.argv.index("--json") + 1], "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)
sys.exit(0 if ok else 1)
