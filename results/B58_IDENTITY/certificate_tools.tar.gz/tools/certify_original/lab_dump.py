"""lab_dump.py -- the learning lab's outputs in one tree, as JSON, for a byte comparison.

    python -I lab_dump.py <tree_dir> <out.json>

catalog.metadata (en, ar) without the source refs this build re-points, the
/api/plant and /api/thermal answers, and three sessions (locked, flat, terrain)
stepped 40 times each with a hand policy, every frame kept."""
import json
import math
import os
import sys

tree, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
lab = os.path.join(tree, "Explanatory Simulation")
os.chdir(lab)
sys.path[:0] = [lab, tree]

# THE CONTROL (mistake 12): LAB_PERTURB="thermal.c_turb" moves that field of the
# B58 by one ulp before the lab builds from it, "thermal.c_turb:1e-9" by that
# relative step (one ulp is lost to rounding in a 40-step session), so a dump
# that does not change would mean the lab never read the plant it names.
if os.environ.get("LAB_PERTURB"):
    from dataclasses import replace

    import engines
    import numpy as np
    spec, _, rel = os.environ["LAB_PERTURB"].partition(":")
    rec_name, field = spec.split(".")
    pl = engines.get("b58")
    sub = getattr(pl.engine, rec_name)
    old = getattr(sub, field)
    new = float(old * (1.0 + float(rel))) if rel else float(np.nextafter(old, np.inf))
    engines._BUILT["b58"] = replace(pl, engine=replace(pl.engine, **{rec_name: replace(sub, **{field: new})}))
    print(f"PERTURBED {rec_name}.{field}: {old!r} -> {new!r}")

from backend import catalog, simulation  # noqa: E402
from backend.server import PlantRequest, ThermalRequest, api_plant, api_thermal  # noqa: E402

res = {}


def clean(x):
    if isinstance(x, float) and not math.isfinite(x):
        return repr(x)
    if isinstance(x, dict):
        return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    return x


for loc in ("en", "ar"):
    m = catalog.metadata(loc)
    # the three refs build step 1 re-points (vehicle, engine, thermal_time_constant)
    m["vehicle"].pop("source", None)
    for c in m["concepts"]:
        if c["id"] in ("engine", "thermal_time_constant"):
            c.pop("source", None)
            c.pop("evidence_note", None)
    res[f"meta_{loc}"] = m
for rpm, mp, amb, sp, lam in ((3000, 250, 35, 8, 0.95), (2000, 60, 25, 20, 1.0), (5200, 180, 42, 6, 0.85)):
    res[f"plant_{rpm}_{mp}"] = api_plant(PlantRequest(rpm=rpm, map_kpa=mp, ambient_c=amb, ect_c=90, spark=sp, lam=lam))
res["thermal"] = api_thermal(ThermalRequest(rpm=3000, map_kpa=180, ambient_c=42, spark=8, lam=0.92,
                                            fan=0.7, pump=0.8, heat_s=60, cool_s=30))
for scen, pol, seed in (("locked", "predictive", 3), ("flat", "baseline", 7), ("terrain", "reactive", 11),
                        ("locked", "manual", 0)):
    s = simulation.create_session(scenario=scen, preview=True, policy=pol, seed=seed)
    frames = [simulation.reset_frame(s), simulation.initial_frame(s)]
    if scen == "locked" and pol == "manual":
        s.env.k = 170
    for _ in range(4):
        frames += simulation.step_session(s, steps=10)["frames"]
    prov = dict(s.provenance)
    prov.pop("scenario_source", None)          # a provenance string this build re-words
    res[f"session_{scen}_{pol}"] = dict(road=s.road, provenance=prov, frames=frames,
                                        cycle={k: s.env.cycle[k].tolist() for k in ("t", "v_mps", "grade")})
res["derived_inputs"] = simulation._current_derived_inputs()
with open(out, "w", encoding="utf-8") as fh:
    json.dump(clean(res), fh, sort_keys=True, ensure_ascii=False)
print(f"{tree}: {len(res)} parts written to {out}")
