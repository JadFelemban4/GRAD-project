"""cmp.py -- are two dumps bit-identical?  python cmp.py a.npz b.npz [--quiet] [--json out.json]

Every array is compared with tobytes() (dtype and shape first). On a DIFFERENT
key it prints how many elements differ, the FIRST differing element (flat index
and its index in the array) with both values as repr, and the largest |a - b|.
Elements are compared bit for bit (viewed as unsigned integers of their own
width), so two NaNs with the same bits are equal and -0.0 differs from 0.0, as
tobytes() would have it. Keys starting with "_" are bookkeeping (run time) and
skipped. Exit 0 when every key is identical, 1 otherwise.
"""
import json
import sys

import numpy as np


def first_difference(x, y):
    """(count, flat index, index tuple, x value, y value, max |d|) for two arrays
    of the same dtype and shape that are not byte-identical."""
    u = np.dtype(f"u{x.dtype.itemsize}") if x.dtype.kind in "fiub" and x.dtype.itemsize in (1, 2, 4, 8) else None
    if u is not None:
        diff = np.ascontiguousarray(x).view(u) != np.ascontiguousarray(y).view(u)
    else:
        diff = np.ascontiguousarray(x) != np.ascontiguousarray(y)
    flat = np.flatnonzero(diff)
    i = int(flat[0])
    idx = np.unravel_index(i, x.shape) if x.ndim else ()
    xv, yv = x.reshape(-1)[i], y.reshape(-1)[i]
    try:
        d = np.abs(np.nan_to_num(x.astype(np.float64) - y.astype(np.float64)))
        dmax = float(d.max())
    except (TypeError, ValueError):
        dmax = float("nan")
    return int(diff.sum()), i, tuple(int(k) for k in idx), xv, yv, dmax


def compare(pa, pb, quiet=False):
    a, b = np.load(pa, allow_pickle=False), np.load(pb, allow_pickle=False)
    keys = sorted(k for k in set(a.files) | set(b.files) if not k.startswith("_"))
    total, report = 0, []
    for k in keys:
        if k not in a.files or k not in b.files:
            report.append(dict(key=k, status="MISSING", where="a" if k not in a.files else "b"))
            print(f"  {k:<26} MISSING in {'a' if k not in a.files else 'b'}")
            continue
        x, y = a[k], b[k]
        n = int(x.size)
        total += n
        if x.dtype == y.dtype and x.shape == y.shape and x.tobytes() == y.tobytes():
            report.append(dict(key=k, status="IDENTICAL", n=n))
            if not quiet:
                print(f"  {k:<26} {n:>9} values   IDENTICAL")
            continue
        if x.shape != y.shape or x.dtype != y.dtype:
            report.append(dict(key=k, status="DIFFERENT", n=n, shape_a=list(x.shape), shape_b=list(y.shape),
                               dtype_a=str(x.dtype), dtype_b=str(y.dtype)))
            print(f"  {k:<26} DIFFERENT: shape/dtype {x.shape} {x.dtype} vs {y.shape} {y.dtype}")
            continue
        c, i, idx, xv, yv, dmax = first_difference(x, y)
        report.append(dict(key=k, status="DIFFERENT", n=n, n_differ=c, first_flat=i, first_index=list(idx),
                           first_a=repr(xv.item() if hasattr(xv, "item") else xv),
                           first_b=repr(yv.item() if hasattr(yv, "item") else yv), max_abs=dmax))
        print(f"  {k:<26} {n:>9} values   DIFFERENT: {c} differ; first at flat {i} {idx}: "
              f"{xv!r} vs {yv!r}; max |d| {dmax:.3e}")
    ok = all(r["status"] == "IDENTICAL" for r in report)
    verdict = "BIT-IDENTICAL" if ok else "NOT IDENTICAL"
    print(f"VERDICT: {verdict} ({total} values in {len(keys)} keys)")
    return ok, total, report


if __name__ == "__main__":
    args = [x for x in sys.argv[1:] if not x.startswith("--")]
    quiet = "--quiet" in sys.argv
    ok, total, report = compare(args[0], args[1], quiet)
    if "--json" in sys.argv:
        out = sys.argv[sys.argv.index("--json") + 1]
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(dict(a=args[0], b=args[1], identical=ok, values=total, keys=report), fh, indent=1)
    sys.exit(0 if ok else 1)
