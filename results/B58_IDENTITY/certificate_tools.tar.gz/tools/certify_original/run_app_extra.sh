#!/usr/bin/env bash
# run_app_extra.sh <cand|ref> -- the other eleven app/test_*.py suites (mistake 25: every suite that
# may read the plant), each with python -m unittest -v, in one tree
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
t=$1; tree=/c/Users/badcl/Desktop/GRAD-project; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
export PYTHONIOENCODING=utf-8
rm -f $S/app/${t}_extra_status.txt
for m in test_agent_generations test_agent_sources test_artifact_api test_artifacts test_graphics_revisions \
         test_launcher test_records test_results_comparisons test_results_graphics test_results_records test_results_sets; do
  s=$(date +%s)
  ( cd "$tree" && $PY -m unittest -v app.$m ) > $S/app/${t}_$m.txt 2>&1
  echo "$? $(( $(date +%s) - s )) $m" >> $S/app/${t}_extra_status.txt
done
cat $S/app/${t}_extra_status.txt
