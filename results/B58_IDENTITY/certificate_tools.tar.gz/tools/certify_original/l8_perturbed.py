"""l8_perturbed.py -- L8's control: the candidate's train.py on a B58 one ulp off.

    python -I l8_perturbed.py <candidate_tree> <record.field> <train.py arguments ...>

engines.get("b58") is replaced, before train.py runs, by the B58 with that one
field moved by one ulp (dataclasses.replace through the frozen records, as
harness.py's HARNESS_PERTURB does), then train.main() runs with the arguments
given. If the weights of this run equal the unperturbed run's, the L8
comparison could not have seen a plant difference (mistake 12).
"""
import os
import sys
from dataclasses import replace

tree, pert = os.path.abspath(sys.argv[1]), sys.argv[2]
os.chdir(tree)
sys.path.insert(0, tree)
import numpy as np  # noqa: E402

import engines  # noqa: E402

plant = engines.get("b58")
if pert == "none":
    # the wrapper alone, nothing moved: must train exactly what train.py does
    print("PERTURBED nothing (the wrapper's own check)", flush=True)
else:
    # "car.mass" moves the field by one ulp; "car.mass:1e-9" by that relative step. One
    # ulp never reaches the float32 observations and rewards the network trains on in
    # 600 steps (measured: weights identical), so the relative steps are the control
    spec, _, rel = pert.partition(":")
    rec_name, field = spec.split(".")
    old = getattr(plant.car if rec_name == "car" else getattr(plant.engine, rec_name), field)
    new = float(old * (1.0 + float(rel))) if rel else float(np.nextafter(old, np.inf))
    if rec_name == "car":
        plant = replace(plant, car=replace(plant.car, **{field: new}))
    else:
        sub = getattr(plant.engine, rec_name)
        plant = replace(plant, engine=replace(plant.engine, **{rec_name: replace(sub, **{field: new})}))
    engines._BUILT["b58"] = plant
    print(f"PERTURBED {pert}: {old!r} -> {new!r}", flush=True)

import train  # noqa: E402

sys.argv = [os.path.join(tree, "train.py")] + sys.argv[3:]
train.main()
