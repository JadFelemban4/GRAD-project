#!/usr/bin/env bash
# run_drift.sh -- drift_test.py in four parts at once (rows 1-4, 5-8, 9-12, 13-16). Each part
# runs drift_test's own control on an undrifted copy first, then its rows, each on a fresh
# copy; the rows are independent, so the four parts are the one command split for time.
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
cd /c/Users/badcl/Desktop/GRAD-project || exit 9
export PYTHONIOENCODING=utf-8
s=$(date +%s)
i=0
for rows in "1 2 3 4" "5 6 7 8" "9 10 11 12" "13 14 15 16"; do
  i=$((i+1))
  ( $PY drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
done
wait
{ for i in 1 2 3 4; do echo "### part $i"; cat $S/suites/drift_part$i.txt; done; } > $S/suites/drift_test.txt
caught=$(grep -h "drifts CAUGHT" $S/suites/drift_part*.txt | awk '{s+=$1; t+=$3} END {print s " of " t}')
echo "exit codes: $(grep -h '^exit' $S/suites/drift_part*.txt | tr '\n' ';') in $(( $(date +%s) - s )) s; $caught drifts CAUGHT" > $S/suites/drift_test_exit.txt
cat $S/suites/drift_test_exit.txt
