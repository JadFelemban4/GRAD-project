#!/usr/bin/env bash
# run_l4.sh <cand|ref> [extra test_reward args] -- L4: test_reward.py in one tree, stdout and stderr kept apart
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
t=$1; shift; tag=""; [ "$1" = "--road" ] && tag="_$2"
tree=/c/Users/badcl/Desktop/GRAD-project; [ $t = ref ] && tree=$S/ref
cd $tree || exit 9
s=$(date +%s)
PYTHONIOENCODING=utf-8 $PY test_reward.py "$@" > $S/L4/${t}${tag}_stdout.txt 2> $S/L4/${t}${tag}_stderr.txt
rc=$?
echo "exit $rc in $(( $(date +%s) - s )) s" > $S/L4/${t}${tag}_exit.txt
cat $S/L4/${t}${tag}_exit.txt
