"""copy_tree.py -- a scratch copy of the candidate: what a commit of the working tree would hold.

    python copy_tree.py <repo> <dest>

Tracked plus untracked-not-ignored files (git ls-files --cached --others
--exclude-standard), byte for byte, as drift_test.copy_tree does: the
untracked engines.py and engine_specs/ are the plant on GRA-test. No .git.
"""
import os
import shutil
import subprocess
import sys

repo, dest = sys.argv[1], sys.argv[2]
names = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
                       cwd=repo, capture_output=True, check=True).stdout.decode("utf-8").split("\0")
n = 0
for rel in (x for x in names if x):
    src = os.path.join(repo, rel)
    if not os.path.isfile(src):
        continue
    out = os.path.join(dest, rel)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    shutil.copyfile(src, out)
    n += 1
print(f"copied {n} files to {dest}")
