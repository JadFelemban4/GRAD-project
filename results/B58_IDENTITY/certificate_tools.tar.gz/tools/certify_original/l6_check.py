"""l6_check.py -- an L6 dump against what X1's scoring committed.

    python l6_check.py <dump.npz> <tag> [--json out.json]

1. SCORES, FULL PRECISION: every one of the 7 values of every episode against
   results/phase_d_extremes_dt1_raw.json's row for policy
   "runs/extremes_dt1/<tag>", by float equality (json reads back the repr X1's
   scoring wrote, so equality is equality of the doubles).
2. PER STEP: every field of results/agents/extremes_dt1/<tag>/eval_record.npz
   (float32 engine and reward fields, float16 observation, int gear, the seeds
   and float64 weights) against the dump's cast_<field>, by tobytes().
Prints the first difference of each; exit 0 only when everything is equal.
"""
import json
import sys

import numpy as np

REPO = r"C:\Users\badcl\Desktop\GRAD-project"
SCORE_KEYS = ("ret", "damage", "damage_thermal", "fuel", "torque_viol", "peak_turb", "knock")

dump, tag = sys.argv[1], sys.argv[2]
d = np.load(dump, allow_pickle=False)
n_ep = d["score"].shape[0]
raw = json.load(open(f"{REPO}/results/phase_d_extremes_dt1_raw.json", encoding="utf-8"))
want = {r["episode"]: r for r in raw if r["policy"] == f"runs/extremes_dt1/{tag}"}
out = dict(dump=dump, tag=tag, episodes=n_ep)

# 1. scores
n_eq, first = 0, None
for i in range(n_ep):
    for j, k in enumerate(SCORE_KEYS):
        mine, theirs = float(d["score"][i, j]), float(want[i][k])
        if mine == theirs:
            n_eq += 1
        elif first is None:
            first = dict(episode=i, key=k, dump=repr(mine), committed=repr(theirs))
out["scores"] = dict(compared=n_ep * len(SCORE_KEYS), equal=n_eq, first_difference=first)
print(f"scores vs phase_d_extremes_dt1_raw.json: {n_eq} of {n_ep * len(SCORE_KEYS)} equal at full precision"
      + ("" if first is None else f"; FIRST DIFFERENCE {first}"))

# 2. per step
rec = np.load(f"{REPO}/results/agents/extremes_dt1/{tag}/eval_record.npz", allow_pickle=False)
fields, vals, bad = 0, 0, []
for k in rec.files:
    theirs = rec[k][:n_ep]
    mine = d[k] if k in ("episode_seed", "weights") else d.get("cast_" + k)
    if mine is None:
        bad.append(dict(field=k, why="missing from the dump"))
        continue
    fields += 1
    vals += int(theirs.size)
    if mine.dtype != theirs.dtype or mine.shape != theirs.shape:
        bad.append(dict(field=k, why=f"dtype/shape {mine.dtype}{mine.shape} vs {theirs.dtype}{theirs.shape}"))
        continue
    if mine.tobytes() != theirs.tobytes():
        u = np.dtype(f"u{mine.dtype.itemsize}")
        diff = np.ascontiguousarray(mine).view(u) != np.ascontiguousarray(theirs).view(u)
        i = int(np.flatnonzero(diff)[0])
        idx = tuple(int(x) for x in np.unravel_index(i, mine.shape))
        bad.append(dict(field=k, n_differ=int(diff.sum()), first_index=list(idx),
                        dump=repr(mine.reshape(-1)[i].item()), committed=repr(theirs.reshape(-1)[i].item())))
extra = sorted(k[5:] for k in d.files if k.startswith("cast_") and k[5:] not in rec.files)
out["per_step"] = dict(fields=fields, values=vals, differences=bad, dump_fields_not_in_record=extra)
print(f"per step vs eval_record.npz: {fields} fields, {vals} values, "
      + ("all identical (tobytes)" if not bad else f"{len(bad)} fields DIFFERENT"))
for b in bad:
    print(f"   DIFFERENT {b}")
if extra:
    print(f"   (fields the dump has and the committed record does not: {extra})")
ok = first is None and not bad and n_eq == n_ep * len(SCORE_KEYS)
out["identical"] = ok
if "--json" in sys.argv:
    with open(sys.argv[sys.argv.index("--json") + 1], "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)
print("VERDICT:", "EQUAL TO THE COMMITTED FILES" if ok else "NOT EQUAL")
sys.exit(0 if ok else 1)
