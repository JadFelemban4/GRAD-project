"""derived_check.py -- L5: derive_params.py re-run in scratch copies, against the committed file.

    python derived_check.py <committed.json> <derived_cand.json> <derived_ref.json> [--json out.json]

derived_sha is fingerprint.derived_sha's definition (SHA-256 over the values,
keys starting with "_" dropped, json.dumps sort_keys), recomputed here so the
reference and the candidate are hashed by one function. Every key that differs
is listed with its section, and whether it is bookkeeping ("_") or a value.
"""
import hashlib
import json
import sys


def dsha(d):
    vals = {k: v for k, v in d.items() if not k.startswith("_")}
    return hashlib.sha256(json.dumps(vals, sort_keys=True).encode()).hexdigest()[:16]


def walk(a, b, path=""):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            yield from walk(a.get(k, "<absent>"), b.get(k, "<absent>"), f"{path}/{k}")
    elif a != b:
        yield path, a, b


files = sys.argv[1:4]
docs = [json.load(open(f, encoding="utf-8")) for f in files]
out = {"files": files, "derived_sha": [dsha(d) for d in docs], "differences": {}}
names = ("committed", "derived in the candidate copy", "derived in the reference copy")
for n, f, d in zip(names, files, docs):
    print(f"{n:<32} derived_sha {dsha(d)}   ({f})")
for i, j in ((0, 1), (0, 2), (1, 2)):
    diffs = list(walk(docs[i], docs[j]))
    key = f"{names[i]} vs {names[j]}"
    out["differences"][key] = [dict(path=p, a=repr(x)[:120], b=repr(y)[:120],
                                    bookkeeping=p.split("/")[1].startswith("_") or "/_" in p) for p, x, y in diffs]
    vals = [p for p, _, _ in diffs if not (p.split("/")[1].startswith("_") or "/_" in p)]
    print(f"{key}: {len(diffs)} paths differ, {len(vals)} of them values (not '_' bookkeeping)")
    for p, x, y in diffs[:12]:
        print(f"    {p}: {repr(x)[:70]} -> {repr(y)[:70]}")
if "--json" in sys.argv:
    with open(sys.argv[sys.argv.index("--json") + 1], "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)
