"""l7_expect.py -- L7's cross-check: the rows evaluate.py should print for X1's
sighted_seed0, rebuilt from the committed results/phase_d_extremes_dt1_raw.json
with evaluate.py's own formatting (summarise: median, IQR, worst; the peak is the
largest episode peak), then looked for in the two reports.

    python l7_expect.py <report.txt> [<report.txt> ...]
"""
import json
import sys

import numpy as np

REPO = r"C:\Users\badcl\Desktop\GRAD-project"
raw = json.load(open(f"{REPO}/results/phase_d_extremes_dt1_raw.json", encoding="utf-8"))
POL = {"baseline ECU": "baseline ECU", "reactive": "reactive", "current-grade": "current-grade",
       "agent": "runs/extremes_dt1/sighted_seed0"}


def rows_of(label):
    return sorted((r for r in raw if r["policy"] == label), key=lambda r: r["episode"])


def summarise(rows, key):
    v = np.array([r[key] for r in rows], dtype=float)
    q1, med, q3 = np.percentile(v, [25, 50, 75])
    return med, q3 - q1, v.max(), v.min()


expect = {}
for name, label in POL.items():
    rows = rows_of(label)
    dm, di, dw, _ = summarise(rows, "damage")
    fm = summarise(rows, "fuel")[0]
    pk = max(r["peak_turb"] for r in rows)
    expect[name] = f"{dm:>12.1f}{di:>9.1f}{dw:>9.1f}{fm:>10.0f}{pk:>9.0f}"
base = np.median([r["damage"] for r in rows_of("baseline ECU")])
cuts = {n: f"cuts median damage {100 * (1 - np.median([r['damage'] for r in rows_of(l)]) / base):5.1f} %"
        for n, l in POL.items() if n != "baseline ECU"}
ok_all = True
for rep in sys.argv[1:]:
    text = open(rep, encoding="utf-8").read().splitlines()
    print(f"== {rep}")
    for name, tail in expect.items():
        hit = [ln for ln in text if ln.startswith(name) and ln.endswith(tail)]
        ok_all &= bool(hit)
        print(f"  {'ok ' if hit else 'MISSING'} {name:<14} {tail}")
    for name, c in cuts.items():
        hit = [ln for ln in text if ln.strip().startswith(name) and ln.rstrip().endswith(c)]
        ok_all &= bool(hit)
        print(f"  {'ok ' if hit else 'MISSING'} {name:<14} {c}")
print("VERDICT:", "every row equals the committed raw scores" if ok_all else "NOT EQUAL")
sys.exit(0 if ok_all else 1)
