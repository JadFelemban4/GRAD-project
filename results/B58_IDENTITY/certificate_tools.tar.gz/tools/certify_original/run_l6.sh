#!/usr/bin/env bash
# run_l6.sh -- L6: four X1 agents x twenty frozen episodes, in both trees, 8 processes at once
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
SW='C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify'
PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
CAND='C:/Users/badcl/Desktop/GRAD-project'
REF="$SW/ref"
for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
  for t in cand ref; do
    tree=$CAND; [ $t = ref ] && tree=$REF
    ( $PY -I "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
  done
done
wait
echo "L6 done: $(grep -c '^0 ' $S/L6/_status.txt) of $(wc -l < $S/L6/_status.txt) exit 0"
