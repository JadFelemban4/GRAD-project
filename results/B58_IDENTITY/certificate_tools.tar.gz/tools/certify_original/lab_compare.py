"""lab_compare.py -- two lab_dump.py files, value for value. Source-line numbers
(re-resolved by text against files whose lines moved) and the three re-worded
provenance strings are listed apart; every other difference fails."""
import json
import sys

a = json.load(open(sys.argv[1], encoding="utf-8"))
b = json.load(open(sys.argv[2], encoding="utf-8"))


def diff(x, y, path=""):
    out = []
    if type(x) != type(y):
        return [(path, x, y)]
    if isinstance(x, dict):
        for k in sorted(set(x) | set(y)):
            if k not in x or k not in y:
                out.append((path + "/" + k, x.get(k, "<absent>"), y.get(k, "<absent>")))
            else:
                out += diff(x[k], y[k], path + "/" + k)
    elif isinstance(x, list):
        if len(x) != len(y):
            out.append((path, f"len {len(x)}", f"len {len(y)}"))
        for i, (u, v) in enumerate(zip(x, y)):
            out += diff(u, v, f"{path}[{i}]")
    elif x != y:
        out.append((path, x, y))
    return out


def count(x):
    if isinstance(x, dict):
        return sum(count(v) for v in x.values())
    if isinstance(x, list):
        return sum(count(v) for v in x)
    return 1


# the three strings build step 1 re-words: they named a default that no longer exists
WORDED = ("/charge_temp_source", "/scenario_source", "/method")
d = diff(a, b)
lines = [t for t in d if t[0].endswith("/line")]
worded = [t for t in d if t[0].endswith(WORDED)]
rest = [t for t in d if not t[0].endswith("/line") and not t[0].endswith(WORDED)]
print(f"{count(a)} leaf values compared; {len(lines)} source-line numbers moved; "
      f"{len(worded)} re-worded strings; {len(rest)} other differences")
for p, u, v in {t[0].rsplit("/", 1)[1]: t for t in worded}.values():
    print("  re-worded", p)
    print("     ref:", repr(u)[:300])
    print("     new:", repr(v)[:300])
for p, u, v in rest[:40]:
    print(" ", p)
    print("     ref:", repr(u)[:240])
    print("     new:", repr(v)[:240])
print("VERDICT:", "IDENTICAL apart from source-line numbers and the re-worded strings" if not rest
      else "DIFFERENT")
sys.exit(1 if rest else 0)
