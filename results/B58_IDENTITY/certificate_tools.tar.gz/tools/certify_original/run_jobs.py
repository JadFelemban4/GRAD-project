"""run_jobs.py -- every harness job of a list in one tree, N at a time, one dump and one log each.

    python run_jobs.py <tree_dir> <label> <jobs.txt> <parallel> [NAME=VALUE ...]

Each job is `python -I harness.py <tree> <job> out/<label>/<slug>.npz` with
OMP_NUM_THREADS=1; NAME=VALUE pairs are added to the job's environment (the
control's HARNESS_PERTURB). _status.txt gets "<exit> <seconds> <job>" per job.
"""
import os
import re
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PY = r"C:\Users\badcl\Desktop\GRAD-project\.venv\Scripts\python.exe"

tree, label, jobs_file, par = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
extra = dict(kv.split("=", 1) for kv in sys.argv[5:])
outdir = os.path.join(ROOT, "out", label)
os.makedirs(outdir, exist_ok=True)
with open(jobs_file, encoding="utf-8") as fh:
    jobs = [ln.strip() for ln in fh if ln.strip() and not ln.startswith("#")]
env = dict(os.environ, OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", **extra)


def slug(j):
    return re.sub(r"[^A-Za-z0-9.-]+", "_", j).strip("_")


pending, running, done = list(jobs), [], []
t0 = time.time()
while pending or running:
    while pending and len(running) < par:
        j = pending.pop(0)
        log = open(os.path.join(outdir, slug(j) + ".log"), "w", encoding="utf-8")
        p = subprocess.Popen([PY, "-I", os.path.join(HERE, "harness.py"), tree, j,
                              os.path.join(outdir, slug(j) + ".npz")], stdout=log, stderr=subprocess.STDOUT,
                             env=env)
        running.append((p, j, log, time.time()))
    time.sleep(2)
    for item in list(running):
        p, j, log, ts = item
        if p.poll() is not None:
            log.close()
            running.remove(item)
            done.append((p.returncode, time.time() - ts, j))
            with open(os.path.join(outdir, "_status.txt"), "a", encoding="utf-8") as fh:
                fh.write(f"{p.returncode} {time.time() - ts:.0f} {j}\n")
ok = sum(1 for rc, _, _ in done if rc == 0)
print(f"DONE {label}: {ok} of {len(done)} exit 0 in {time.time() - t0:.0f} s")
for rc, s, j in done:
    if rc != 0:
        print(f"  FAILED ({rc}) {j}")
