#!/usr/bin/env bash
# run_roads.sh -- L5: check_roads.py --road extremes, then --road wideair, in both trees at once
S=/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/build1b/certify
for road in extremes wideair; do
  bash $S/tools/run_writer.sh cand roads_$road results/training_roads_$road.json check_roads.py --road $road &
  bash $S/tools/run_writer.sh ref roads_$road results/training_roads_$road.json check_roads.py --road $road &
  wait
done
cd /c/Users/badcl/Desktop/GRAD-project && git status --porcelain results/ && echo "(git status of results/ above; empty means restored)"
