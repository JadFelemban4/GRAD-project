"""drift_control.py -- drift_test's own control, run with the certificate written into the tree.

    python -I drift_control.py <REPO> <out.txt>

drift_test.control() copies the files a commit of REPO's working tree would hold (git
ls-files --cached --others --exclude-standard, with working-tree contents) and runs
verify_docs.py in the copy. While the certificate is untracked, its page, its JSON and its
archive are in that set only if git does not ignore them, so this first checks that they
are; then the control. The last line of <out.txt> is what make_cert.py records.
"""
import os
import subprocess
import sys

repo, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
os.chdir(repo)
sys.path.insert(0, repo)
import drift_test  # noqa: E402

CERT = ("results/B58_IDENTITY.md", "results/B58_IDENTITY.json", "results/B58_IDENTITY/certificate_tools.tar.gz")
listed = set(subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard"], cwd=repo,
                            capture_output=True, text=True, check=True).stdout.splitlines())
present = {rel: os.path.isfile(os.path.join(repo, rel)) for rel in CERT}
in_copy = {rel: rel in listed for rel in CERT}
ok, why = drift_test.control()
lines = [f"{rel}: on disk {present[rel]}, in the copy {in_copy[rel]}" for rel in CERT]
lines.append(f"{'passes' if ok else 'FAILS'} with the certificate's files in the copy: {why}")
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w", encoding="utf-8", newline="\n") as fh:
    fh.write("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(0 if ok and all(in_copy[rel] for rel in CERT if present[rel]) else 1)
