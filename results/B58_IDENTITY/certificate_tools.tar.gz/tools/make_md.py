"""make_md.py -- results/B58_IDENTITY.md from results/B58_IDENTITY.json.

    python -I make_md.py <B58_IDENTITY.json> <B58_IDENTITY.md>

Every number in the page is read from the certificate's JSON, which make_cert.py
read from the runs' own files: none is typed here (mistake 22). The prose says
what each number is.
"""
import json
import sys

src, out = sys.argv[1], sys.argv[2]
c = json.load(open(src, encoding="utf-8"))
V, I, L, CT, SU, RR = c["verdict"], c["identity"], c["levels"], c["controls"], c["suites"], c["review_runs"]
L5 = L["L5_suites_that_write_or_pin"]
APPS = L5["app_and_learning_lab_suites"]["suites"]


def n(x):
    """A count with thin spaces, as the project's documents write them."""
    return f"{x:,}".replace(",", " ") if isinstance(x, int) else str(x)


def esc(x):
    """Text for a table cell: no ANSI colour codes, no bare pipe, one space between words."""
    import re
    t = re.sub(r"\x1b?\[[0-9;]*m", "", str(x))
    return " ".join(t.replace("|", "\\|").split())


def cap(t):
    """A sentence's first letter in capitals, unless its first word is a name from the code."""
    if not t or any(ch in t.split()[0] for ch in "_.()-"):
        return t
    return t[:1].upper() + t[1:]


def one_space(t):
    return " ".join(str(t).split())


def diff_item(z):
    """A line of a unified diff as the page writes it: '-' is cf43fbb's line, '+' the candidate's."""
    t = str(z)
    if t[:1] in "+-" and not t[1:2].isdigit():
        return ("cf43fbb: " if t[0] == "-" else "candidate: ") + one_space(t[1:])
    return one_space(t)


def nodes(d):
    return MISSING_TEXT if not isinstance(d, dict) else (
        f"{d.get('tests')} tests, {d.get('pass')} pass, {d.get('fail')} fail, {d.get('skipped')} skipped")


MISSING_TEXT = "MISSING"


def eq(flag, what):
    """'equals <what>' for True, 'DIFFERS from <what>' for False, MISSING for anything else."""
    return f"equals {what}" if flag is True else f"DIFFERS from {what}" if flag is False else f"{what}: MISSING"


def ut(s):
    if not isinstance(s, dict):
        return str(s)
    return f"{s['ran']} tests, {s['verdict']}"


def failing(s):
    return [] if not isinstance(s, dict) else [f.split(" (")[0] for f in s["failing"]]


vals = V["values_compared_byte_for_byte"]
fam = {k: L["L2_roads"][k]["summary"] for k in ("extremes", "terrain", "random_road", "wideair", "conditions")}
units = L["L1_units"]["rows"][0]
prem = L["L3_premise"]
l6 = L["L6_x1_agents"]["agents"]
l7 = L["L7_evaluate_end_to_end"]
l8 = L["L8_training"]["runs"]
cand = c["candidate"]
first = c["first_certificate"]


def ctl_first(name, job):
    row = next(r for r in CT[name]["jobs"] if r["job"] == job)
    f = row.get("first_different") or {}
    return row["result"], f.get("key"), f.get("first_index"), f.get("first_a"), f.get("first_b")


cm = ctl_first("one_ulp_car_mass", "units")
cc = ctl_first("one_ulp_thermal_c_turb", "units")
ce = ctl_first("one_ulp_thermal_c_turb", "extremes:double:12:random")
l6c = CT["L6_against_the_committed_files"]["runs"]
l8c, l8x = CT["L8_training"]["runs"], CT["L8_training"]["relative_steps"]
lab = CT["learning_lab"]
LAB_ULP = "IDENTICAL" if "IDENTICAL" in lab["one_ulp_verdict"] else "DIFFERENT"
LAB_REL = "DIFFERENT" if "DIFFERENT" in lab["relative_verdict"] else "IDENTICAL"
LIMITS = "three" if LAB_ULP == "IDENTICAL" else "two"      # the lab is a limit only while one ulp does not show
bd = RR["build_dataset without a derived file (finding 2)"]
ter = RR["check_roads.py, the 40 terrain roads (finding 11)"]
rr = RR["check_random_road.py (finding 11)"]
d2 = RR["evaluate.py --protocol d2 (finding 11)"]
labb = RR["the learning lab's build and launcher (finding 11)"]
ARCH = c.get("archive") or {}

lines = []
w = lines.append
MISSING_ROWS = []


def row(label, build):
    """A row built from the JSON, or the row's label with MISSING when its evidence is not there."""
    try:
        w(build())
    except (KeyError, TypeError, IndexError, StopIteration, AttributeError) as exc:
        MISSING_ROWS.append(label)
        w(f"| {label} | MISSING ({type(exc).__name__}) | | |")
w("# The B58 identity certificate: build step 1 against cf43fbb")
w("")
w("**21 October 2026, made again after the review.** Build step 1 of decision 24")
w("(`results/VALIDATION_DECISIONS.md`, section F) threads an Engine record and a Car")
w("record through the plant, the environments and every script, with no default engine")
w("anywhere (mistake 1). Before anything is calibrated or trained on `GRA-test`, the B58")
w("built that way has to be X1's plant, the plant of `cf43fbb`: the same doubles, not the")
w("same figures to a tolerance. It was certified once that night; two reviews then found")
w("21 things (section 6), the fixes changed the plant's code, and every level ran again")
w("on the corrected tree. This file says how that was measured and what came out.")
w("`results/B58_IDENTITY.json` holds every number below, read by `make_cert.py` from the")
w("runs' own output files; the tools and the evidence are archived beside it (section 8).")
w("")
w(f"**Verdict: {V['result']}.** On one interpreter the corrected candidate reproduces the")
w(f"reference byte for byte: {n(vals['harness'])} values from the harness (units, every road family,")
w(f"the premise), {n(vals['l6_agents'])} from four X1 agents on the twenty frozen episodes, the")
w("reward gate's whole output, `evaluate.py`'s report line for line, 600 steps of training to")
w(f"the last weight ({n(vals['l8_tensor_values'])} tensor values), every committed file the scripts rewrite,")
w(f"and, without a derived file, `build_dataset.py` on all eleven drives ({n(vals['build_dataset_columns'])}")
w("values; it could not run that way before the review). No computed value differs. What")
w("does differ is a printed line, a label, a code hash or a fingerprint field that names the")
w("plant, and two committed files that were already stale on `cf43fbb` (section 5). The")
w("checks can fail: one ulp on the housing's heat capacity or on the car's mass comes out")
w(f"DIFFERENT (section 2), with {LIMITS} measured limits stated there.")
w("")
w("## 1. What was compared")
w("")
w("| | reference | candidate |")
w("|---|---|---|")
w(f"| code | `cf43fbb`, `git archive` (tar sha256 `{(c['reference']['archive_sha256'] or '?')[:8]}…{(c['reference']['archive_sha256'] or '?')[-6:]}`), extracted in scratch and checked with `tar --compare` | `GRA-test`'s working tree: build step 1 and the review's fixes uncommitted, on HEAD `{(cand['head'] or '?')[:7]}` (`96884f1` when the runs began: another session committed a document, `results/VALIDATION_DECISIONS.md`, during them), {cand['files']} files (manifest sha256 `{cand['manifest_sha256_start']}` at the first run, `{cand['manifest_sha256_end']}` after the last: section 5 lists what changed between them) |")
w(f"| `plant_sha` | `{I['plant_sha']['reference']}`, the value X1's `meta.json` records | `{I['plant_sha']['candidate']}` (`{I['plant_sha']['first_certificate']}` in the first certificate) |")
w(f"| `derived_sha` | `{I['derived_sha']['reference']}` | `{I['derived_sha']['candidate']}` |")
w(f"| `engine`, `engine_sha`, `backend` | none (fingerprint schema 2) | `{I['engine']}`, `{I['engine_sha']}` (`{I['engine_sha_first_certificate']}` in the first certificate), `{I['backend']}` (schema 3) |")
sf = I["shared_fatal_fields"]
same = all(a == b for a, b in sf.values())
w(f"| gears, final drive, crank step, knees, scenario, `episodes_sha` | {sf['gears'][0]}; {sf['final_drive'][0]}; {sf['dtheta_deg'][0]}°; {sf['turb_protect_k'][0]} K and {sf['oil_protect_k'][0]} K; {sf['scenario'][0]}; `{I['episodes_sha']['reference']}` | {'the same, read from the plant' if same and I['episodes_sha']['candidate'] == I['episodes_sha']['reference'] else 'DIFFERENT: see the JSON'} |")
w("")
w(f"**Why the hashes move although no number does.** {cap(I['why_plant_sha_moves'])} "
  f"{cap(I['why_engine_sha_moves'])}. `derived_sha` does not move: `data/derived_params.json` is the same "
  "file in both trees.")
w("")
env = c["environment"]
pk = env["packages"]
w(f"**One interpreter for both trees**: `.venv\\Scripts\\python.exe`, Python 3.13.2, numpy {pk.get('numpy')},")
w(f"scipy {pk.get('scipy')}, pandas {pk.get('pandas')}, torch {env['torch_build']}, stable-baselines3 {pk.get('stable_baselines3')},")
w(f"gymnasium {pk.get('gymnasium')} (`pip freeze`: {env['pip_freeze']['lines']} packages). Rule 4 asks for 3.12, which this")
w("machine does not have; decision 32 (revised 21 October, open) would amend it to the training")
w("device's pinned versions and re-run this certificate on that device.")
w("Every process is single-threaded (OMP and MKL at 1), so how many ran at once changes the")
w("time, not a number. Each job runs in its own process in its own tree and dumps every")
w("number it produced as float64 (`harness.py`); two dumps are compared array by array with")
w("`tobytes()`, after dtype and shape, and element by element as bits to find the first")
w("difference (`cmp.py`). The reference side is the first certificate's evidence, copied: the")
w("reference tree and the reference-side code of the tools did not change. L8's reference")
w("runs, deleted after the first certificate, were made again.")
w("")
w("## 2. The checks can fail (mistake 12)")
w("")
w("| control | expected | result |")
w("|---|---|---|")
rr_ok = all(r["result"] == "BIT-IDENTICAL" for r in CT["reference_against_reference"]["jobs"])
rvals = sum(r.get("values", 0) for r in CT["reference_against_reference"]["jobs"])
w(f"| the reference against a second run of itself: units, an extremes episode with random actions, the hot thin-air WideAir corner, a conditions rollout at 82 kPa ({n(rvals)} values) | IDENTICAL | **{'IDENTICAL' if rr_ok else 'DIFFERENT'}**, all four |")
ndc = sum(r["result"] == "DIFFERENT" for r in CT["one_ulp_thermal_c_turb"]["jobs"])
ndm = sum(r["result"] == "DIFFERENT" for r in CT["one_ulp_car_mass"]["jobs"])
w(f"| the corrected candidate with one ulp on `thermal.c_turb` (6000.0 → 6000.000000000001), put through the frozen records and into `engines.get`'s cache; the same four jobs | DIFFERENT | **DIFFERENT**, {ndc} of 4. First differences: in units, `{cc[1]}` at {cc[2]}, {cc[3]} against {cc[4]}; in the extremes episode, `{ce[1]}` at {ce[2]}, {ce[3]} against {ce[4]} |")
w(f"| the same with one ulp on `car.mass` (1520.0 → 1520.0000000000002) | DIFFERENT | **DIFFERENT**, {ndm} of 4. First difference in units: `{cm[1]}` at {cm[2]}, {cm[3]} against {cm[4]} |")
m5, t5 = l6c["one_ulp_car_mass_5_episodes"], l6c["one_ulp_thermal_c_turb_5_episodes"]
m9 = l6c["car_mass_x_1e-9_2_episodes"]
w(f"| L6 on a perturbed candidate, `sighted_seed0`, against the committed files | NOT EQUAL | one ulp on the mass: {m5['scores_equal']} scores equal, the first difference {m5['first_score_difference']['key']} of episode {m5['first_score_difference']['episode']}, {m5['first_score_difference']['dump']} against {m5['first_score_difference']['committed']}; one ulp on `c_turb`: {t5['scores_equal']}. **The per-step records do not see one ulp** ({m5['per_step_fields_different']} fields differ): `eval_record.npz` is float32. A relative 1e-9 on the mass: {m9['scores_equal']} scores equal, {m9['per_step_fields_different']} per-step fields differ |")
w(f"| L8 through a wrapper that replaces the plant before `train.main()` runs | the wrapper alone IDENTICAL; perturbed DIFFERENT | the wrapper alone: **{'IDENTICAL' if l8c['wrapper_alone']['identical'] else 'DIFFERENT'}**. One ulp on the mass or on `c_turb`: **{'IDENTICAL' if l8c['one_ulp_car_mass']['identical'] and l8c['one_ulp_thermal_c_turb']['identical'] else 'DIFFERENT'} weights**, although each run's `engine_sha` shows the perturbed plant reached it: the network learns from float32. A relative 1e-9 on the mass: largest weight difference {l8x['car.mass x (1 + 1e-9)']['largest_weight_difference']:.4g}, {l8x['car.mass x (1 + 1e-9)']['tensors_not_identical']} tensors; 1e-6: {l8x['car.mass x (1 + 1e-6)']['largest_weight_difference']:.4g} |")
w(f"| the learning lab's outputs, `lab_dump.py` on a perturbed candidate | DIFFERENT | one ulp on `c_turb`: **{LAB_ULP}**, {lab['one_ulp_thermal_c_turb']}.{' **The lab' + chr(39) + 's 40-step sessions do not show one ulp.**' if LAB_ULP == 'IDENTICAL' else ''} A relative 1e-9: **{LAB_REL}**, {lab['thermal_c_turb_x_(1+1e-9)']} |")
w("")
if LAB_ULP == "IDENTICAL":
    w("So three comparisons are exact only to their own precision: the per-step comparison")
    w("against the committed float32 records, training, and the learning lab's outputs. All")
    w("three sit on top of the full-precision comparisons, L1 to L3 and L6's comparison of the")
    w("two trees' float64 records, which do see one ulp.")
else:
    w("So two comparisons are exact only to their own precision: the per-step comparison")
    w("against the committed float32 records, and training. Both sit on top of the")
    w("full-precision comparisons, L1 to L3 and L6's comparison of the two trees' float64")
    w("records, which do see one ulp.")
w("")
w("## 3. The levels")
w("")
w("| level | what ran, in both trees | compared | result |")
w("|---|---|---|---|")
w(f"| **L1** units | `run_cycle` on 1200 operating points × 16 fields, `predict`, the crank-step pair, the boost ceiling, the charge temperature, the airflow inversion, the thermal network at three housings and its cold reset, the ECU over 400 steps, the gearbox and road load, the damage model, the locked climb at three steps, every terrain family, the deliverable-torque table re-measured (the candidate on the car's own grid and conditions, `Car.table_*`), the load loop | {n(units['values'])} values | **{units['result']}** |")
w(f"| **L2** Extremes | `ExtremesTrainingEnv`, five families, neutral and seeded random actions: {fam['extremes']['jobs']} jobs | {n(fam['extremes']['values'])} | **{fam['extremes']['result']}** |")
w(f"| **L2** Terrain | `TerrainTrainingEnv`, five families | {n(fam['terrain']['values'])} | **{fam['terrain']['result']}** |")
w(f"| **L2** random road | `random_road.climb` at dt 0.2 and the `RandomClimb` wrapper (which since the review refuses a plant whose locked climb is not the Supra's) | {n(fam['random_road']['values'])} | **{fam['random_road']['result']}** |")
w(f"| **L2** WideAir | the four corners of 0–45 C × 80–101.3 kPa, 30 C, a four-episode sequence: the thin-air kickdown table and the closed-throttle floor, measured in the car's own table conditions since the review | {n(fam['wideair']['values'])} | **{fam['wideair']['result']}** |")
w(f"| **L2** conditions | `conditions_test._run`, the four hand-written policies | {n(fam['conditions']['values'])} | **{fam['conditions']['result']}** |")
pj = prem["check_premise"]
w(f"| **L3** premise | `check_premise`'s five rollouts, every step; then `check_premise.py` itself, in a copy of the candidate | {n(prem['harness'][0]['values'])} values; `results/premise.json` | **{prem['harness'][0]['result']}**; the file {eq(pj['premise_json_cand_equals_ref'], 'the reference' + chr(39) + 's')} and {eq(pj['premise_json_equals_committed'], 'the committed one')} |")
t4, t4r = L["L4_test_reward"]["test_reward"], L["L4_test_reward"]["test_reward --road random"]
w(f"| **L4** reward gate | `test_reward.py`, and `--road random` | stdout, byte for byte | **{'identical' if t4['stdout_identical'] is True and t4r['stdout_identical'] is True else 'DIFFERENT'}**: {t4['stdout_bytes_on_disk']} and {t4r['stdout_bytes_on_disk']} bytes, \"{(t4['verdict'] or ['?'])[-1]}\" |")
re_, rw = L5["check_roads --road extremes"], L5["check_roads --road wideair"]
w(f"| **L5** roads | `check_roads.py --road extremes` and `--road wideair`, in a copy of the candidate | the JSON each writes; stdout | **{'identical in both trees' if re_['output_cand_equals_ref'] is True and rw['output_cand_equals_ref'] is True else 'DIFFERENT'}**, {esc((re_['verdict_line'] or ['?'])[0])} (extremes) and {esc((rw['verdict_line'] or ['?'])[0])} (wideair). Wideair's {eq(rw['output_equals_committed'], 'the committed file')}; extremes adds two keys to every road of the committed file, in both trees (section 5) |")
vd = L5["validate.py"]
w(f"| **L5** validation | `validate.py` | stdout | **{'identical' if vd['stdout_identical'] is True else 'DIFFERENT'}**: {(vd['rows'] or ['?'])[0]}; `validation_table.md` untouched |")
dp = L5["derive_params.py"]
w(f"| **L5** derived constants | `derive_params.py` in a scratch copy of each tree | the file each writes | **the same values**, `derived_sha` `{dp['derived_sha']['candidate_copy']}` in both copies and the committed file; they differ in {', '.join(dp['candidate_and_reference_differ_only_in']) or 'nothing'} only, the time each was written |")
g = L5["generality_test.py"]
w(f"| **L5** generality | `generality_test.py`, in a copy of the candidate | `results/generality.json`; stdout | **{'identical' if g['output_cand_equals_ref'] is True else 'DIFFERENT'}**, and it {eq(g['output_equals_committed'], 'the committed file')} |")
labo = L5["learning_lab_outputs"]
w(f"| **L5** app and lab | every `app/test_*.py` suite, the app's node tests, the lab's tests and its outputs | failing tests; the lab's values | **no failure is the candidate's alone** (section 5); the lab: {labo['result']} |")
l6v = next(iter(l6.values()))["cand_vs_ref"]["values"]
l6ok = all(r["cand_vs_ref"]["result"] == "BIT-IDENTICAL" for r in l6.values())
l6s = next(iter(l6.values()))["cand_vs_committed"]
w(f"| **L6** X1 agents | `sighted_seed0`, `sighted_seed4`, `blind_seed2`, `blind_seed6` on the twenty frozen episodes through `evaluate.run_episode` with a record | the two trees: {n(l6v)} values an agent; each tree against `phase_d_extremes_dt1_raw.json` and `eval_record.npz` | **{'BIT-IDENTICAL' if l6ok else 'DIFFERENT'}**, 4 of 4; {l6s['scores']}, {l6s['per_step']}, for every agent, in both trees |")
w(f"| **L7** end to end | `evaluate.py` on `sighted_seed0`: three hand-written policies and the agent, 80 episodes; the candidate scored a scratch copy (the same `final.zip`) whose `meta.json` carries the schema-3 block and an `identity_override`; no force flag | the report, line by line, after removing the fingerprint block and the model's path | **{'identical' if l7['identical'] else 'DIFFERENT'}**, {l7['lines_compared']} lines; {l7['rows_against_the_committed_raw_scores']} |")
w8 = next(iter(l8.values()))
l8ok = all(v["result"] == "IDENTICAL" for v in l8.values())
w(f"| **L8** training | `train.py`, 600 SAC steps, seed 0, CPU: extremes sighted, extremes blinded, wideair sighted, `--out` in scratch (deleted after) | every tensor of `final.zip`; the counters; the 600 recorded steps | **largest weight difference {max(v['largest_weight_difference'] for v in l8.values())}** in all three ({'IDENTICAL' if l8ok else 'DIFFERENT'}): {w8['tensors']} tensors ({n(w8['values'])} values), {w8['train_record']} |")
w(f"| **finding 2** | `build_dataset.read_drive` and `derive` on all eleven drives with `data/derived_params.json` moved aside | every numeric column | **{'BIT-IDENTICAL' if bd['comparison'] else 'DIFFERENT'}**, {n(bd['values'])} values; before the fix the candidate stopped: `FileNotFoundError` |")
w(f"| **finding 11** | `check_roads.py`'s 40 terrain roads in a copy of each tree | the JSON; stdout | **{'identical' if ter['output_cand_equals_ref'] is True and ter['stdout_identical'] is True else 'DIFFERENT'}**, {esc((ter['verdict_line'] or ['?'])[0])}; the committed file is stale on both (finding 13) |")
w(f"| **finding 11** | `check_random_road.py` in each tree | stdout | the candidate {rr['candidate']}, `cf43fbb` {rr['reference']}; {'identical but for road_sha and the run time (section 5)' if len([ln for ln in rr['stdout_difference'] if ln.startswith(('-', '+')) and not ln.startswith(('---', '+++'))]) <= 4 else 'DIFFERENT: section 5'} |")
w(f"| **finding 11** | `evaluate.py --protocol d2`, end to end (no D2 agent is on this machine): the three hand-written policies on the twenty frozen D2 episodes | the report after the fingerprint block | **{'identical' if (d2['report'] or {}).get('identical') else 'DIFFERENT'}**, {(d2['report'] or {}).get('lines_ref')} lines; X1's agent under `--protocol d2` is refused on the FATAL scenario |")
w(f"| **finding 11** | the learning lab: `npm ci`, `npm run build`, `launch.py --no-browser`, `launch.py --check`, in a copy of the candidate | its summary lines and its exit code | " + "; ".join(f"`{cmd}`: {esc(', '.join(labb.get(key) or [MISSING_TEXT]))}" for cmd, key in (("npm ci", "npm_ci"), ("npm run build", "npm_build"), ("launch.py --no-browser", "launch_no_browser"), ("launch.py --check", "launch_check"))) + " |")
w("")
w("## 4. The suites")
w("")
w("| suite | result |")
w("|---|---|")
for label, text in (("cand_test_engine_threading", "`test_engine_threading.py`"), ("cand_test_epa_map", "`test_epa_map.py`"),
                    ("cand_test_epa_map_with_2021_2023", "`test_epa_map.py` with the MY2021 and MY2023 Test Car Lists (finding 18)"),
                    ("cand_test_plant_guards", "`test_plant_guards.py`"), ("cand_test_wide_air", "`test_wide_air.py`")):
    w(f"| {text} | {ut(SU[label]['result'])} |")
w(f"| `test_plant_guards.py` on `cf43fbb` | {ut(SU['ref_test_plant_guards']['result'])} |")
w(f"| `python random_road.py` | {SU['cand_random_road']['output'][-1] if SU['cand_random_road']['output'] else '?'} in both trees |")
w(f"| `verify_docs.py` | {'; '.join(SU['cand_verify_docs']['verdict'] or ['?'])} (cf43fbb: {'; '.join(SU['ref_verify_docs']['verdict'] or ['?'])}) |")
dtt = SU["drift_test"]
dctl = one_space((dtt["control"] or ["?"])[0])
dctl = (dctl[len("control "):] if dctl.startswith("control ") else dctl).replace(" | ", "; ")
w(f"| `drift_test.py` | {esc((dtt['verdict'] or ['?'])[-1])}, run as six parts of three rows at once, each with drift_test's own control first: {esc(dctl)} |")
w(f"| `drift_test.control()` with this page, its JSON and its archive in the copy | {esc(SU['drift_control_with_the_certificate_present'])} |")
w(f"| `app.test_replay --full` | {'; '.join(APPS['test_replay --full']['candidate'] or ['?'])} |")
for k in ("test_simulation", "test_agents", "test_results", "lab_tests"):
    name = "the lab's tests (`Explanatory Simulation/tests`)" if k == "lab_tests" else f"`app.{k}`"
    w(f"| {name} | {ut(APPS[k]['candidate'])}; on `cf43fbb` (a git clone): {ut(APPS[k]['reference_git_clone'])} |")
others = [k for k in APPS if k.startswith("test_") and k not in ("test_simulation", "test_agents", "test_results",
                                                                  "test_replay --full")]
ok_others = sum(1 for k in others if isinstance(APPS[k]["candidate"], dict) and str(APPS[k]["candidate"]["verdict"]).startswith("OK"))
w(f"| the other {len(others)} `app/test_*.py` | {ok_others} OK |")
nd = APPS["node --test static/sim/*.test.mjs"]
w(f"| `node --test static/sim/*.test.mjs` | {nodes(nd['candidate'])} (`cf43fbb`: {nodes(nd['reference_git_clone'])}) |")
w("")
w("## 5. Every difference, with its first differing value")
w("")
for d in c["different"]:
    fd = d.get("first_difference")
    if isinstance(fd, list):
        fd = "; ".join(diff_item(z) for z in fd if z and not str(z).startswith(("---", "+++", "@@")))
    elif isinstance(fd, dict):
        fd = "; ".join(f"{k.replace('_', ' ')}: " + (", ".join(f'"{one_space(z)}"' for z in v) if v else "none")
                       for k, v in fd.items())
    first_text = f" {fd}." if fd else ""
    extra = ""
    if "candidate_only" in d:
        extra = (f" Candidate only: {', '.join(d['candidate_only']) or 'none'}; `cf43fbb` only: "
                 f"{', '.join(d['reference_only']) or 'none'}; both: {', '.join(d['both']) or 'none'}.")
    why = f" {cap(d['why'])}." if d.get("why") else ""
    w(f"- **{d['where']}** ({d['kind']}):{first_text}{why}{extra}")
changed = cand["files_changed_during_the_runs"]
w(f"- **The candidate between its first and its last run**: {len(changed)} files changed: "
  + ", ".join(f"`{z}`" for z in changed) + f". {cap(cand['files_changed_note'])}.")
w("")
w("## 6. The review of 21 October: 21 findings")
w("")
w("Two reviews read build step 1 and its first certificate, one for correctness and one for")
w("the project's rules. Each finding was reproduced on a copy of the tree as it stood; the")
w("evidence of each, before and after, is in the archive (`repro/`, `F2/`, `F11/`).")
w("")
w("| # | finding | verdict | what changed |")
w("|---|---|---|---|")
for r in c["review"]:
    w(f"| {r['n']} | {r['finding']} (`{r['where']}`, {r['severity']}) | **{r['verdict']}** | {r['fix']} |")
w("")
w("## 7. What this does not cover")
w("")
w("- **Python 3.12, and the training device.** Every run is 3.13.2, on this laptop (rule 4).")
w("  Decision 32, revised on 21 October and open, would train on another device and re-run")
w("  this certificate there first.")
w(f"- **The precision of {LIMITS} comparisons**, measured in section 2: the per-step records against")
if LAB_ULP == "IDENTICAL":
    w("  the committed `eval_record.npz` are float32, training sees float32, and the learning lab's")
    w("  40-step sessions do not show one ulp of `c_turb`, so none of the three can tell one ulp of")
    w("  the plant. The plant is certified at full precision by L1–L3 and by L6's comparison of the")
    w("  two trees.")
else:
    w("  the committed `eval_record.npz` are float32, and training sees float32, so neither can tell")
    w("  one ulp of the plant. The plant is certified at full precision by L1–L3 and by L6's")
    w("  comparison of the two trees.")
w("- **The jobs, not every input.** The harness samples operating points, roads, seeds, airs")
w("  and policies; the identity holds for the code paths those jobs run (section 3). No D2")
w("  agent is on this machine, so `--protocol d2` was scored end to end on the hand-written")
w("  policies only.")
w("- **The four frozen drive-C files** (`drive_c_analysis.py`, `drive_c_rule_numbers.py`,")
w("  `drive_c_check.py`, `test_drive_c_analysis.py`) were not run as stages. They cannot run")
w("  on `GRA-test`: `drive_c_analysis.plant_check`, which stages A, B and C call before they")
w("  read anything, stops with an exception before its plant_sha comparison is reached")
w("  (`AttributeError`: `fingerprint.PLANT_FILES` is gone; before the review, `TypeError`:")
w("  `derived_sha()` requires its path). The first certificate said they \"refuse by design\";")
w("  nobody had run it (finding 14). `test_engine_threading.FrozenFiles` checks it. They wait")
w("  for stage C on `main` (decision 25).")
w("- **What this machine lacks**: `pwsh` (one error each in `app.test_agents` and")
w("  `app.test_results`, eight skips in `app.test_launcher`), `runs_c4/` (14 skips in")
w("  `app.test_agents`), any D2 agent, and in the team's data folder the MY2021 and MY2023 Test")
w("  Car Lists (checked here on downloads whose sha256 equals the list's; `python")
w("  fetch_engine_data.py --group epa-test-car-list` adds them).")
w("- **Nothing is committed.** `app.test_results` skips two tests while the plant files are")
w("  uncommitted; run it again after the commit.")
w("- **The certificate is for this tree against `cf43fbb`.** A new drive re-derives the B58")
w("  (`data/derived_params.json`), and stage C may retune it; either one needs a new")
w("  certificate before the B58 of `GRA-test` is called X1's plant again (decision 25).")
w("")
w("## 8. Reproduce")
w("")
if ARCH:
    w(f"Every tool and the small evidence files are in `{ARCH['path']}` ({n(ARCH['bytes'])} bytes,")
    w(f"sha256 `{ARCH['sha256']}`). Unpacked anywhere, that folder is `S`: the tools find it")
    w("from their own location. The reference side is a fresh `git archive` of `cf43fbb` into")
    w("`S/ref`; the dumps themselves (`.npz`) are not archived and are re-made by the commands.")
    w("`make_cert.py`, run from the unpacked folder against this archive, writes this JSON again")
    w("but for two hashes of files the archive leaves out, both re-made by the commands: the")
    w("`cf43fbb` tar (`reference.archive_sha256`) and L7's scratch `final.zip`")
    w("(`levels.L7_evaluate_end_to_end.meta_json_sha256.scratch_final_zip`).")
w("`PY` is the venv's `python.exe`, `REPO` this repository; Git Bash.")
w("")
w("```")
for st in c["reproduce"]["steps"]:
    w(f"# {st['step']} ({st['cwd']})")
    w(st["command"])
w("```")
w("")
w("Every command, with its working directory, is in the JSON under `reproduce`; "
  "`tools/certify_original/` holds the first certificate's tools as they ran.")
open(out, "w", encoding="utf-8", newline="\n").write("\n".join(lines) + "\n")
print("written", out, len(lines), "lines")
