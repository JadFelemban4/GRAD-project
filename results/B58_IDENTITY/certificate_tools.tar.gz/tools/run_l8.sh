#!/usr/bin/env bash
# run_l8.sh -- L8: 600 SAC steps, seed 0, CPU, OMP/MKL threads 1 (train_all.py's setting), --out in scratch.
# An identity test, not an experiment: every OUT below is deleted after l8_compare.py has read it.
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
SW=$(cygpath -m "$S")
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
CAND=${CAND:-/c/Users/badcl/Desktop/GRAD-project}
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1 PYTHONIOENCODING=utf-8
COMMON="--steps 600 --seed 0 --device cpu"
run() {   # run <name> <dir> <command...>
  local name=$1 dir=$2; shift 2
  ( cd "$dir" && s=$(date +%s) && "$@" > $S/L8/$name.log 2>&1; echo "$? $(( $(date +%s) - s )) $name" >> $S/L8/_status.txt ) &
}
rm -f $S/L8/_status.txt
run cand_extremes_sighted $CAND $PY train.py --engine b58 $COMMON --road extremes --out "$SW/L8/cand_extremes"
run ref_extremes_sighted $S/ref $PY train.py $COMMON --road extremes --out "$SW/L8/ref_extremes"
run cand_extremes_blind $CAND $PY train.py --engine b58 $COMMON --road extremes --no-preview --out "$SW/L8/cand_extremes"
run ref_extremes_blind $S/ref $PY train.py $COMMON --road extremes --no-preview --out "$SW/L8/ref_extremes"
wait
run cand_wideair_sighted $CAND $PY train.py --engine b58 $COMMON --road wideair --out "$SW/L8/cand_wideair"
run ref_wideair_sighted $S/ref $PY train.py $COMMON --road wideair --out "$SW/L8/ref_wideair"
run ctl_none $CAND $PY -I "$SW/tools/l8_perturbed.py" "$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")" none --engine b58 $COMMON --road extremes --out "$SW/L8/ctl_none"
run ctl_mass $CAND $PY -I "$SW/tools/l8_perturbed.py" "$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")" car.mass --engine b58 $COMMON --road extremes --out "$SW/L8/ctl_mass"
run ctl_cturb $CAND $PY -I "$SW/tools/l8_perturbed.py" "$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")" thermal.c_turb --engine b58 $COMMON --road extremes --out "$SW/L8/ctl_cturb"
wait
cat $S/L8/_status.txt
