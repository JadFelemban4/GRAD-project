#!/usr/bin/env bash
# run_writer.sh <cand|ref> <label> <output file, relative to the tree> <script> [args...]
# A script that rewrites a committed file. In the candidate (the working tree) the
# committed file is backed up first, the run's output is kept in scratch, and the
# backup is put back, so the working tree ends as it began (sha256 checked).
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
t=$1; label=$2; rel=$3; shift 3
tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refw
cd "$tree" || exit 9
bak=$S/L5/backup/${t}_$(basename "$rel")
cp -p "$rel" "$bak"
before=$(sha256sum < "$rel" | cut -c1-64)
s=$(date +%s)
PYTHONIOENCODING=utf-8 $PY "$@" > $S/L5/${t}_${label}_stdout.txt 2> $S/L5/${t}_${label}_stderr.txt
rc=$?
cp -p "$rel" $S/L5/${t}_${label}_OUT_$(basename "$rel")
after=$(sha256sum < "$rel" | cut -c1-64)
same=$([ "$before" = "$after" ] && echo "UNCHANGED" || echo "CHANGED")
if [ $t = cand ] && [ "$same" = CHANGED ]; then cp -p "$bak" "$rel"; fi
restored=$(sha256sum < "$rel" | cut -c1-64)
echo "exit $rc in $(( $(date +%s) - s )) s; $rel before ${before:0:16} after ${after:0:16} ($same); now ${restored:0:16}" | tee $S/L5/${t}_${label}_exit.txt
