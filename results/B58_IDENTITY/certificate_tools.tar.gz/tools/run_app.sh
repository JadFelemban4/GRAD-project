#!/usr/bin/env bash
# run_app.sh <cand|ref> -- the app suites and the learning lab's tests, one after another, in one tree
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
t=$1; tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
mkdir -p $S/app
export PYTHONIOENCODING=utf-8
one() {   # one <label> <dir> <command...>
  local label=$1 dir=$2; shift 2
  local s=$(date +%s)
  ( cd "$dir" && "$@" ) > $S/app/${t}_$label.txt 2>&1
  echo "$? $(( $(date +%s) - s )) $label" >> $S/app/${t}_status.txt
}
rm -f $S/app/${t}_status.txt
one test_replay_full "$tree" $PY -m app.test_replay --full
one test_simulation "$tree" $PY -m app.test_simulation
one test_agents "$tree" $PY -m app.test_agents
one test_results "$tree" $PY -m app.test_results
one lab_tests "$tree/Explanatory Simulation" $PY -m unittest discover -s tests -v
cat $S/app/${t}_status.txt
