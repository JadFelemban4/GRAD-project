#!/usr/bin/env bash
# cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
# 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
# run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
# launcher record, HA.4). The edited lines have not run.
#
#     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
#
# p_gate.sh's phase cert runs it, beside the roads check and nothing else, after its own G1.0 (two records in
# G1-harness) and G7.3 (one record in G7-suites). It does not repeat G1.0, G7.3 or G7.0 (test_engine_threading,
# p_gate.sh post). The groups run ONE AT A TIME (the orchestrator's decision, 7 November 2026), in the order
# G1 G2 G3 G4 G5 G6 G7; inside a group the steps CERT_PLAN_A.md runs together run together, with fewer processes
# where the plan used 18 or 20 (CERT_PAR_* below), since the check's 14 jobs share the machine.
#
# The contract (P_GATE_PLAN.md 5.2):
#   1. env_P.sh is sourced from CERT_S; the cwd is the clone candg (REPO's role); LIVE_REPO is read for
#      runs/extremes_dt1 only (and the tools that read committed results there, unchanged by P: l6_check.py,
#      l6_agents.py's X1 agents, harness.py's x1 jobs).
#   2. Every entry point, writer and suite runs in the clone or in a copy (S/cand, S/candd, S/candw, S/candt,
#      S/ref, S/refw, CERT_ROOT/preRV), never in the live repository.
#   3. Labels and files are P_<group>_...; the tools that name their own files write cand_* (S holds none of
#      commit A's: cert-prep left them in X). Commit A's candidate evidence that a check compares with is
#      copied from X into S/commitA/ first (sha256 against the archive's own listing).
#   4. Every check is one record (rec), PASS only for an output equal to the expected one. A check that could
#      not run gets no record and a line in S/out/P_driver_report.txt, except G5's npm ci and the lab launcher's
#      free port, which fail closed (a FAIL record that cert-recheck g5 re-checks; review fixes 3: otherwise 3.6.12
#      and B12 read as answered with the lab's build, launcher and node tests never run). Each group starts from
#      none of an earlier run's outputs that its checks count or compare (G1's harness folders, G5's lab dumps,
#      G6's L6/L7/d2 outputs): a CERT_ONLY re-run is judged on its own files (review fixes 3). The driver exits 0 when every record
#      was written, whatever their verdicts (make_cert.py judges them); 3 when cert_record.py refused a record
#      or a precondition of its own failed, 2 when it could not start.
#   5. Expected outcomes are CERT_PLAN_A.md's unless CERT_PLAN_P.md amends them; where P moves one that neither
#      sheet amends (P_GATE_PLAN.md 7.23), the expectation is written here, at the check, before the run, and
#      INTEGRATION.md lists each.
# Nothing here writes to the vehicle, trains an agent or runs engine_thresholds.py. No fit runs.
# No `set -u` and no `set -e`: an unset variable or a failing command must not end the run half-way through
# the check's window (p_gate.sh's records_fresh refuses a second run on this S); every check reads its own
# outputs and records what it found.

# ----------------------------------------------------------------------------- start
[ -n "${CERT_S:-}" ] || { echo "cert_driver_P.sh: CERT_S is unset (p_gate.sh exports it)" >&2; exit 2; }
# shellcheck source=/dev/null
source "$CERT_S/env_P.sh" || { echo "cert_driver_P.sh: env_P.sh refused" >&2; exit 2; }
cd "$REPO" || exit 2
REPORT="$S/out/P_driver_report.txt"
RECLOG="$S/out/P_driver_records.log"
BAD=0
mkdir -p "$S/out" "$S/cmp" "$S/L4" "$S/L5/backup" "$S/L6" "$S/L7" "$S/L9" "$S/F2" "$S/F11" "$S/app" "$S/lab" \
         "$S/suites" "$S/cert_out" "$S/commitA" "$S/prep"
say() { echo "$(date -u +%FT%TZ) $*" | cut -c1-400 | tee -a "$REPORT"; }
# (review fixes 2, 7 November 2026) The decision is one group at a time (decisions/cert_groups.txt): the driver
# runs no other way. CERT_ONLY=<g1..g7> runs that one group again (p_gate.sh cert-recheck): commit A's evidence
# is then checked, not copied again, and CERT_RECHECK_MAP (lines "<what><TAB><group>.json record <n>", written
# by p_gate.sh from the team's decision file) gives each re-run PASS record whose --what is listed the
# --rechecks field that pairs it with that earlier FAIL (make_cert.py's _rechecks; cert_record.py --rechecks):
# one PASS record per line, when several FAILs of the same check are listed (a FAIL a re-run wrote: settle step).
[ "${CERT_GROUPS:-}" = one-at-a-time ] || { say "REFUSED: CERT_GROUPS is '${CERT_GROUPS:-unset}', not one-at-a-time (decisions/cert_groups.txt)"; exit 2; }
case "${CERT_ONLY:-}" in
  "") RUN_GROUPS="g1 g2 g3 g4 g5 g6 g7";;
  g1|g2|g3|g4|g5|g6|g7) RUN_GROUPS=$CERT_ONLY;;
  *) say "REFUSED: CERT_ONLY is '$CERT_ONLY', not one of g1 ... g7"; exit 2;;
esac
if [ -n "${CERT_RECHECK_MAP:-}" ]; then
  [ -n "${CERT_ONLY:-}" ] && [ -f "$CERT_RECHECK_MAP" ] || { say "REFUSED: CERT_RECHECK_MAP needs CERT_ONLY and an existing file"; exit 2; }
fi
R() {   # one record (env_P.sh's rec); a refusal by cert_record.py is the driver's own refusal
  # (settle step, 7 November 2026) a re-run PASS of a listed check is written once per map line of its 'what',
  # each with its own --rechecks: a check that failed on the first run and again on a re-run has two OPEN FAILs,
  # and make_cert.py's _rechecks pairs one PASS record with one FAIL (cert_record.py --rechecks is one string)
  local a prev="" w="" v="" rid rids=()
  if [ -n "${CERT_RECHECK_MAP:-}" ]; then        # a re-run PASS of a listed check names the FAIL(s) it re-checks
    for a in "$@"; do case "$prev" in --what) w=$a;; --verdict) v=$a;; esac; prev=$a; done
    [ "$v" = PASS ] && [ -n "$w" ] && mapfile -t rids < <(W="$w" awk -F'\t' '$1 == ENVIRON["W"] && $2 != "" { print $2 }' "$CERT_RECHECK_MAP")
  fi
  if [ "${#rids[@]}" -gt 0 ]; then
    for rid in "${rids[@]}"; do
      rec "$@" --rechecks "$rid" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; return; }
      say "re-check: '$w' PASS, recorded with --rechecks '$rid'"
    done
  else
    rec "$@" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; }
  fi
}
verdict() { [ -z "$1" ] && echo PASS || echo FAIL; }     # verdict "$bad": PASS when nothing was found wrong
lf() { tr -d '\r' < "$1"; }
ran_of() { lf "$1" 2>/dev/null | grep -aoE '^Ran [0-9]+ tests?' | tail -1 | grep -oE '[0-9]+'; }
ut_ok() { [ -f "$1" ] && lf "$1" | grep -aqE '^OK( |$)' && [ -n "$(ran_of "$1")" ]; }
ut_line() { lf "$1" 2>/dev/null | grep -aE '^(Ran |OK|FAILED)' | tr '\n' ' ' | cut -c1-200; }
exit_of() { lf "$1" 2>/dev/null | grep -aoE '^exit -?[0-9]+' | tail -1 | grep -oE -- '-?[0-9]+$'; }
fpv() { lf "$1" | awk -v k="$2" '$1 == k { sub(/^ *[^ ]+ */, ""); print; exit }'; }
secs_since() { echo $(( $(date +%s) - $1 )); }
same() { cmp -s <(lf "$1") <(lf "$2"); }                 # two text files equal, CR ignored
nz() { [ -n "${1:-}" ] && echo "$1" || echo 0; }         # a number for --seconds, 0 when none was read
secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
  lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
                      return 0 }
    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
    pend { if (res($0)) { pend = 0; next } }
    $0 ~ h { if (!res($0)) pend = 1; next }
    $0 ~ f { bad++ }
    END { exit !(ok > 0 && sk == 0 && bad == 0) }'
}
cls_ok() {    # cls_ok FILE CLASS: the class's tests all ran ok (bracket expressions: awk -v reads backslashes)
  tests_ok "$1" "^test_[A-Za-z0-9_]+ [(]([A-Za-z0-9_]+[.])*$2[.]test_[A-Za-z0-9_]+[)]" \
                "^(FAIL|ERROR): test_[A-Za-z0-9_]+ [(]([A-Za-z0-9_]+[.])*$2[.]"
}

DRIVER_T0=$(date +%s)
say "BEGIN cert_driver_P.sh in $(pwd); P_CAND ${P_CAND:0:12}; S $S"
# preconditions of its own
RV=$(git -C "$REPO" rev-parse HEAD~1 2>/dev/null)
[ "$RV" = "${RV_SHA:-}" ] || { say "REFUSED: the clone's HEAD~1 is ${RV:0:12}, not RV ${RV_SHA:-unset}"; exit 3; }
[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean"; exit 3; }
for f in tools/run_jobs.py tools/compare_all.sh tools/control_verdict.py tools/cert_record.py tools/make_meta.py \
         tools/failing_sets_P.py tools/stated_counts_P.py tools/road_json_diff.py tools/l7_expect.py out/ref/_status.txt \
         out/fp_ref.txt out/P_G1_fp_cand.txt manifest_start_P.txt L7/ref_eval.txt F11/ref_d2.txt lab/lab_ref_A.json; do
  [ -f "$S/$f" ] || { say "REFUSED: S lacks $f"; exit 3; }
done
for d in ref refw pre cand candd candw candt; do [ -d "$S/$d" ] || { say "REFUSED: S lacks the tree $d"; exit 3; }; done
[ -d "$CERT_X" ] || { say "REFUSED: no archive extraction at $CERT_X"; exit 3; }
B58_PLANT=$(fpv "$S/out/P_G1_fp_cand.txt" plant_sha)
B58_ENGINE_SHA=$(fpv "$S/out/P_G1_fp_cand.txt" engine_sha)
A_B11=$(blob HEAD~1:results/B58_IDENTITY.json | grep -oE '"over_build_step_1_keys": *"[0-9a-f]{16}"' \
        | head -1 | grep -oE '[0-9a-f]{16}')
B58_DERIVED=$(fpv "$S/out/P_G1_fp_cand.txt" derived_sha)
say "G1.0's plant_sha $B58_PLANT, engine_sha $B58_ENGINE_SHA; commit A's B11 reading $A_B11 (read, not typed)"
[ -n "$B58_PLANT" ] && [ -n "$B58_ENGINE_SHA" ] && [ -n "$A_B11" ] || { say "REFUSED: G1.0's fields or commit A's B11 value unread"; exit 3; }
# the processes beside the check (numbers do not depend on them: every process is single-threaded)
PAR_L1=${CERT_PAR_L1:-6}            # CERT_PLAN_A.md G1.1: 6
L9_PROCS=${CERT_L9_PROCS:-6}        # CERT_PLAN_A.md G2.4: ecu_shift.run_all(20); commit A ran 16, with 25 of 25

# commit A's candidate evidence a check compares with, copied from X into S/commitA (contract 3)
COPYA=(app/cand_test_replay_full.txt app/cand_test_simulation.txt app/cand_test_agents.txt app/cand_test_results.txt
       app/cand_lab_tests.txt app/A_G5_lab_tests_pinned.txt app/cand_node_tests.txt
       lab/A_G5_lab_node_tests.txt lab/A_G5_ref_lab_node_tests.txt lab/compare_A_cand_ref.txt
       lab/compare_A_ctl_cturb_ulp.txt lab/compare_A_ctl_cturb_1e-9.txt
       L5/cand_premise_stdout.txt F11/cand_random_road_stdout.txt F11/cand_random_road_stderr.txt
       cmp/A_G1_ref_vs_cand.txt suites/cand_random_road.txt)
EXTRA=(test_agent_generations test_agent_sources test_artifact_api test_artifacts test_graphics_revisions
       test_launcher test_records test_results_comparisons test_results_graphics test_results_records test_results_sets)
for m in "${EXTRA[@]}"; do COPYA+=("app/cand_$m.txt"); done
t0=$(date +%s); bad=""
if [ -n "${CERT_ONLY:-}" ]; then
  # a re-run of one group: the copies of the first run, checked, not made again (no second G0-prepare record)
  [ -s "$S/commitA/_sha256.txt" ] && ( cd "$S/commitA" && sha256sum --quiet -c _sha256.txt ) >> "$REPORT" 2>&1 \
    || { say "REFUSED: S/commitA is not the first run's copy (sha256sum -c commitA/_sha256.txt)"; exit 3; }
  say "CERT_ONLY=$CERT_ONLY: S/commitA checked against its _sha256.txt; only $CERT_ONLY runs"
else
for f in "${COPYA[@]}"; do
  if [ ! -f "$CERT_X/$f" ]; then bad="$bad $f(not in the archive)"; continue; fi
  mkdir -p "$S/commitA/$(dirname "$f")"; cp -p "$CERT_X/$f" "$S/commitA/$f"
  want=$(awk -v f="$f" '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); if (p == f) { print $1; exit } }' "$CERT_X/archive_members.txt")
  got=$(sha256sum < "$S/commitA/$f" | cut -c1-64)
  [ "$want" = "$got" ] || bad="$bad $f(sha256)"
  echo "$got  $f" >> "$S/commitA/_sha256.txt"
done
R G0-prepare --level prep --item prep --what "commit A's candidate evidence the driver compares with, copied into S/commitA" \
  --command "cp -p X/<f> S/commitA/<f> for the ${#COPYA[@]} files of cert_driver_P.sh's COPYA; sha256 of each against X/archive_members.txt" \
  --cwd S --expected "every file present in the archive and its sha256 the archive's listing's" \
  --got "$( [ -z "$bad" ] && echo "${#COPYA[@]} files, every sha256 the listing's" || echo "differs:$bad")" \
  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence commitA/_sha256.txt
fi

# ============================================================================= G1-harness
ctl_run() {   # ctl_run LABEL TREE JOBS PAR [NAME=VALUE ...]: run_jobs.py, its print-out in out/LABEL_run.txt
  local label=$1 tree=$2 jobs=$3 par=$4; shift 4
  "$PY" -I -B "$SW/tools/run_jobs.py" "$tree" "$label" "$SW/tools/$jobs" "$par" "$@" > "$S/out/${label}_run.txt" 2>&1
}
ctl_secs() { nz "$(grep -aoE 'exit 0 in [0-9]+ s' "$S/out/$1_run.txt" 2>/dev/null | grep -oE '[0-9]+ s' | grep -oE '[0-9]+' | tail -1)"; }
ctl_judge() { # ctl_judge LABEL A EXPECT JOBS ITEMS WHAT ENVTEXT [ALLOW] -- compare_all.sh, control_verdict.py, one record
  local label=$1 a=$2 expect=$3 jobs=$4 items=$5 what=$6 envt=$7 allow=${8:-} short=${1#P_G1_} st last extra=""
  bash "$S/tools/compare_all.sh" "$a" "$label" > "$S/cmp/P_G1_${a#P_G1_}_vs_${short}.txt" 2>&1
  if [ -n "$allow" ]; then
    "$PY" -I -B "$SW/tools/control_verdict.py" "$a" "$label" "$SW/tools/$jobs" "$expect" --allow-missing "$allow" \
      > "$S/cmp/P_G1_verdict_${short}.txt" 2>&1; st=$?
  else
    "$PY" -I -B "$SW/tools/control_verdict.py" "$a" "$label" "$SW/tools/$jobs" "$expect" > "$S/cmp/P_G1_verdict_${short}.txt" 2>&1; st=$?
  fi
  last=$(lf "$S/cmp/P_G1_verdict_${short}.txt" | grep -a '^CONTROL ' | tail -1)
  CTL_BAD=""; [ "$st" = 0 ] && [[ $last == *": PASS" ]] || CTL_BAD=" control_verdict.py exit $st"
  R G1-harness --level control --item "$items" --what "$what" \
    --command "python -I -B tools/run_jobs.py <tree> $label tools/$jobs <n> $envt; bash tools/compare_all.sh $a $label; python -I -B tools/control_verdict.py $a $label tools/$jobs $expect${allow:+ --allow-missing $allow}" \
    --cwd S --environment "${envt:-none}" --expected "$expect against $a on every job of tools/$jobs${CTL_EXTRA_EXPECT:+; $CTL_EXTRA_EXPECT}" \
    --got "${last:-no CONTROL line}${CTL_EXTRA_GOT:+; $CTL_EXTRA_GOT}" \
    --verdict "$(verdict "$CTL_BAD${CTL_EXTRA_BAD:-}")" --seconds "$(ctl_secs "$label")" \
    --evidence "cmp/P_G1_${a#P_G1_}_vs_${short}.txt" "cmp/P_G1_verdict_${short}.txt" "out/$label/_status.txt"
  CTL_EXTRA_EXPECT=""; CTL_EXTRA_GOT=""; CTL_EXTRA_BAD=""
}
CTL_EXTRA_EXPECT=""; CTL_EXTRA_GOT=""; CTL_EXTRA_BAD=""
SCHED='ecu.cam_on=1;ecu.cam_c0=10;ecu.cam_rpm_lo=800;ecu.cam_rpm_hi=7000;ecu.cam_map_lo=20;ecu.cam_map_hi=260;ecu.cam_lo=-60;ecu.cam_hi=60'
SET_AB0='cycle.form=A+B;cycle.ve_map=0.0'
SET_ABC065='cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65'
SET_ABCD0='cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.ve_cam=0.0;cycle.cam_ref_deg=0.0;ecu.cam_on=1'
SET_D0="cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=0.0;$SCHED"
SET_D1E4="cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=1e-4;$SCHED"
SET_ABVE='cycle.form=A+B;cycle.ve_map=1e-4'
SET_ABCULP='cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001'
SET_C070='cycle.form=A+B+C;cycle.ce_rich_slope=0.7'

g1() {
  local t0 n bad got sum suma lines bi st f d
  say "G1 begins"
  # (review fixes 3, 7 November 2026) every run starts from none of an earlier run's harness outputs: run_jobs.py
  # appends to out/<label>/_status.txt and compare_all.sh prints one line per status line, so on a CERT_ONLY=g1
  # re-run the first run's lines would be counted again (2n lines: L1 and every control FAIL), and a job that
  # crashed would leave the first run's dump to be compared. p_gate.sh cert-recheck has copied the first run's
  # evidence aside before the re-run. G1.0's own files (out/P_G1_*.txt) are files, not these folders.
  for d in "$S"/out/P_G1_*/ "$S"/cmp/ref_vs_P_G1_*/ "$S"/cmp/P_G1_cand_vs_P_G1_*/; do [ -d "$d" ] && rm -rf "${d%/}"; done
  # ---- G1.1 L1-L3: the 34 jobs (CERT_PLAN_A.md G1.1), one wave of PAR_L1
  t0=$(date +%s)
  ctl_run P_G1_cand "$RW" jobs_all.txt "$PAR_L1"
  bash "$S/tools/compare_all.sh" ref P_G1_cand > "$S/cmp/P_G1_ref_vs_cand.txt" 2>&1
  "$PY" -I -B "$SW/tools/control_verdict.py" ref P_G1_cand "$SW/tools/jobs_all.txt" IDENTICAL > "$S/cmp/P_G1_verdict_cand.txt" 2>&1; st=$?
  n=$(grep -vcE '^(#|[[:space:]]*$)' "$S/tools/jobs_all.txt")
  lines=$(grep -ac ' | ' "$S/cmp/P_G1_ref_vs_cand.txt"); bi=$(grep -ac ' | VERDICT: BIT-IDENTICAL (' "$S/cmp/P_G1_ref_vs_cand.txt")
  sum=$(grep -aoE '\([0-9]+ values in' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -oE '[0-9]+' | awk '{ s += $1 } END { print s + 0 }')
  suma=$(grep -aoE '\([0-9]+ values in' "$S/commitA/cmp/A_G1_ref_vs_cand.txt" | grep -oE '[0-9]+' | awk '{ s += $1 } END { print s + 0 }')
  bad=""
  grep -aq "^DONE P_G1_cand: $n of $n exit 0" "$S/out/P_G1_cand_run.txt" || bad="$bad run($(grep -a '^DONE' "$S/out/P_G1_cand_run.txt"))"
  [ "$lines" = "$n" ] && [ "$bi" = "$n" ] || bad="$bad $bi of $lines lines BIT-IDENTICAL, $n jobs"
  [ "$st" = 0 ] || bad="$bad control_verdict.py exit $st"
  [ "$sum" = "$suma" ] || bad="$bad values $sum, commit A's $suma"
  R G1-harness --level L1 --item 3.6.1 --what "L1-L3: the $n harness jobs of jobs_all.txt against cf43fbb's dumps" \
    --command "python -I -B tools/run_jobs.py candg P_G1_cand tools/jobs_all.txt $PAR_L1 > out/P_G1_cand_run.txt; bash tools/compare_all.sh ref P_G1_cand > cmp/P_G1_ref_vs_cand.txt; python -I -B tools/control_verdict.py ref P_G1_cand tools/jobs_all.txt IDENTICAL > cmp/P_G1_verdict_cand.txt" \
    --cwd S --expected "DONE P_G1_cand: $n of $n exit 0; every line VERDICT: BIT-IDENTICAL; control_verdict PASS; the values compared as many as commit A's comparison (cmp/A_G1_ref_vs_cand.txt: $suma), which the reference dumps fix" \
    --got "$( [ -z "$bad" ] && echo "$n of $n exit 0, $bi BIT-IDENTICAL, $sum values; $(lf "$S/cmp/P_G1_verdict_cand.txt" | grep -a '^CONTROL' | tail -1)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" \
    --evidence out/P_G1_cand_run.txt cmp/P_G1_ref_vs_cand.txt cmp/P_G1_verdict_cand.txt out/P_G1_cand/_status.txt
  bad=""
  for f in 'extremes:double:12:random' 'terrain:single:11:neutral'; do
    grep -aqF "$f | VERDICT: BIT-IDENTICAL (" "$S/cmp/P_G1_ref_vs_cand.txt" || bad="$bad $f"
  done
  got=$(grep -aE '^(extremes|terrain|wideair|wideseq|cond):' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -avc 'VERDICT: BIT-IDENTICAL (')
  [ "$got" = 0 ] || bad="$bad $got step-family lines not BIT-IDENTICAL"
  R G1-harness --level L2 --item B3 --what "the harness runs step(): the step jobs among the $n" \
    --command "as the L1 record (cmp/P_G1_ref_vs_cand.txt), the step() jobs read off it" --cwd S \
    --expected "extremes:double:12:random and terrain:single:11:neutral, and every other extremes, terrain, wideair, wideseq and cond job, BIT-IDENTICAL" \
    --got "$( [ -z "$bad" ] && echo "both named jobs and every step-family job BIT-IDENTICAL" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_ref_vs_cand.txt
  bad=""; got=$(grep -ac '^cond:' "$S/cmp/P_G1_ref_vs_cand.txt")
  [ "$got" = 6 ] && [ "$(grep -a '^cond:' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -ac 'VERDICT: BIT-IDENTICAL (')" = 6 ] || bad=" $got cond lines"
  R G1-harness --level L2 --item HA.9 --what "the six cond jobs among the full harness" \
    --command "as the L1 record (cmp/P_G1_ref_vs_cand.txt), the cond: lines" --cwd S \
    --expected "six cond: jobs, each BIT-IDENTICAL" --got "$( [ -z "$bad" ] && echo "six, each BIT-IDENTICAL" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_ref_vs_cand.txt

  # ---- G1.2-G1.6 the controls, in waves of at most six processes (CERT_PLAN_A.md runs them at once)
  ctl_run P_G1_ref2 "$SW/ref" jobs_ctl.txt 2 &
  ctl_run P_G1_ctl_cturb "$RW" jobs_ctl.txt 2 HARNESS_PERTURB=thermal.c_turb &
  ctl_run P_G1_ctl_mass "$RW" jobs_ctl.txt 2 HARNESS_PERTURB=car.mass &
  wait
  ctl_run P_G1_ctl_afr "$RW" jobs_units.txt 1 HARNESS_PERTURB=fuel.afr_st &
  ctl_run P_G1_ctl_lhv "$RW" jobs_units.txt 1 HARNESS_PERTURB=fuel.lhv_j_per_kg &
  ctl_run P_G1_ctl_divergent "$RW" jobs_units.txt 1 HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg &
  ctl_run P_G1_bind "$RW" jobs_quick.txt 3 HARNESS_BIND_COUNT=1 &
  wait
  ctl_run P_G1_ctl_lamf32 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1 &
  ctl_run P_G1_ctl_lamf64 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1 &
  ctl_run P_G1_ctl_ceilf32 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1 &
  ctl_run P_G1_census "$RW" jobs_census_P2.txt 3 HARNESS_BIND_COUNT=1 &
  wait
  ctl_run P_G1_census_rest "$RW" jobs_census_P2_rest.txt 6 HARNESS_BIND_COUNT=1
  ctl_run P_G1_ctl_AB0 "$RW" jobs_ctl_P3.txt 3 "HARNESS_SET=$SET_AB0" &
  ctl_run P_G1_ctl_ABC065 "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_ABC065" &
  wait
  ctl_run P_G1_ctl_ABCD0 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_ABCD0" &
  ctl_run P_G1_ctl_D0 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_D0" &
  wait
  ctl_run P_G1_ctl_D1e4 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_D1E4" &
  ctl_run P_G1_ctl_ABve "$RW" jobs_ctl_P3.txt 3 "HARNESS_SET=$SET_ABVE" &
  wait
  ctl_run P_G1_ctl_ABCulp "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_ABCULP" &
  ctl_run P_G1_ctl_C070 "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_C070" &
  wait
  ctl_run P_G1_refside "$SW/ref" jobs_P7.txt 3

  # G1.2 build step 1's controls
  ctl_judge P_G1_ref2 ref IDENTICAL jobs_ctl.txt 3.6.2 "the reference against a second run of itself" ""
  ctl_judge P_G1_ctl_cturb P_G1_cand DIFFERENT jobs_ctl.txt 3.6.2 "one ulp on thermal.c_turb (build step 1's control)" HARNESS_PERTURB=thermal.c_turb
  ctl_judge P_G1_ctl_mass P_G1_cand DIFFERENT jobs_ctl.txt 3.6.2 "one ulp on car.mass (build step 1's control)" HARNESS_PERTURB=car.mass
  # G1.3 the fuel controls
  ctl_judge P_G1_ctl_afr P_G1_cand DIFFERENT jobs_units.txt 3.6.2 "one ulp on fuel.afr_st (through engines.with_fuel and _TYPED)" HARNESS_PERTURB=fuel.afr_st
  ctl_judge P_G1_ctl_lhv P_G1_cand DIFFERENT jobs_units.txt 3.6.2 "one ulp on fuel.lhv_j_per_kg, both copies (engines.with_fuel)" HARNESS_PERTURB=fuel.lhv_j_per_kg
  # (the thermal_* keys of the lhv control, judged on control_verdict's own line, written as a record of its own)
  bad=""; got=$(lf "$S/cmp/P_G1_verdict_ctl_lhv.txt" | grep -a '^units |' | grep -aoE 'thermal_[A-Za-z0-9_.]+ \(' | wc -l)
  [ "$got" -ge 3 ] || bad=" $got thermal_* keys DIFFERENT"
  R G1-harness --level control --item 3.6.2 --what "the lhv control moves the thermal network's heating value too" \
    --command "control_verdict.py's units line of P_G1_ctl_lhv (cmp/P_G1_verdict_ctl_lhv.txt)" --cwd S \
    --environment HARNESS_PERTURB=fuel.lhv_j_per_kg --expected "at least the three thermal_* keys among the DIFFERENT keys (commit A: thermal_60000.0, thermal_800.0 and thermal_None, 34 of 5403 each)" \
    --got "$( [ -z "$bad" ] && echo "$got thermal_* keys DIFFERENT: $(lf "$S/cmp/P_G1_verdict_ctl_lhv.txt" | grep -a '^units |' | cut -c1-160)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_verdict_ctl_lhv.txt
  bad=""
  grep -aq '^DONE P_G1_ctl_divergent: 0 of 1 exit 0' "$S/out/P_G1_ctl_divergent_run.txt" || bad="$bad run($(grep -a '^DONE' "$S/out/P_G1_ctl_divergent_run.txt"))"
  grep -aq 'the network would burn another fuel than the cycle' "$S/out/P_G1_ctl_divergent/units.log" || bad="$bad no ValueError line"
  R G1-harness --level control --item 3.6.2 --what "one copy of the LHV moved alone is refused" \
    --command "python -I -B tools/run_jobs.py candg P_G1_ctl_divergent tools/jobs_units.txt 1 HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg" \
    --cwd S --environment HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg \
    --expected "DONE P_G1_ctl_divergent: 0 of 1 exit 0; the log ends in Engine's ValueError: the network would burn another fuel than the cycle" \
    --got "$( [ -z "$bad" ] && echo "0 of 1 exit 0; $(lf "$S/out/P_G1_ctl_divergent/units.log" | grep -a 'ValueError' | tail -1 | cut -c1-160)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/out/P_G1_ctl_divergent_run.txt")" \
    --evidence out/P_G1_ctl_divergent_run.txt out/P_G1_ctl_divergent/units.log
  # G1.4 amendment B1
  CTL_EXTRA_EXPECT="its count 'floor 1 [780]' in extremes:double:12:random, ceiling 0, terrain 0 and 0"
  CTL_EXTRA_GOT=$(grep -ah '^BIND COUNT' "$S/out/P_G1_bind/extremes_double_12_random.log" | head -1)
  grep -aqE '^BIND COUNT over [0-9]+ steps: floor 1 \[780\], ceiling 0 \[\]' "$S/out/P_G1_bind/extremes_double_12_random.log" || CTL_EXTRA_BAD=" the bind count"
  ctl_judge P_G1_bind ref IDENTICAL jobs_quick.txt "3.6.2, B1" "amendment B1's pre-check: the bind-count wrapper alone, with the count printed" HARNESS_BIND_COUNT=1
  bash "$S/tools/compare_all.sh" P_G1_cand P_G1_ctl_lamf32 > /dev/null 2>&1     # its JSONs, read before ctl_judge
  "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); print({k['key']: k['first_index'] for k in c['keys'] if k['status']=='DIFFERENT'})" \
    "$SW/cmp/P_G1_cand_vs_P_G1_ctl_lamf32/extremes_double_12_random.json" > "$S/out/P_G1_lamf32_first_rows.txt" 2>&1
  CTL_EXTRA_EXPECT="info, obs, reward and state first differing at row 780, the bind step"; CTL_EXTRA_GOT=$(lf "$S/out/P_G1_lamf32_first_rows.txt" | cut -c1-160)
  for f in info obs reward state; do grep -aq "'$f': \[780" "$S/out/P_G1_lamf32_first_rows.txt" || CTL_EXTRA_BAD="$CTL_EXTRA_BAD $f"; done
  ctl_judge P_G1_ctl_lamf32 P_G1_cand DIFFERENT jobs_ctl_P2.txt "3.6.2, B1" "the lambda floor moved by one float32 step, at the one job where it binds" "HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1"
  ctl_judge P_G1_ctl_lamf64 P_G1_cand IDENTICAL jobs_ctl_P2.txt "3.6.2, B1" "one float64 ulp on the floor is below float32's resolution" "HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1"
  CTL_EXTRA_EXPECT="ceiling count 0"; grep -aqE 'ceiling 0 \[\]' "$S/out/P_G1_ctl_ceilf32/extremes_double_12_random.log" || CTL_EXTRA_BAD=" the ceiling count"
  ctl_judge P_G1_ctl_ceilf32 P_G1_cand IDENTICAL jobs_ctl_P2.txt "3.6.2, B1" "the ceiling moved by one float32 step (no B58 lambda reaches it)" "HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1"
  grep -ah "^BIND" "$S"/out/P_G1_bind/*.log "$S"/out/P_G1_ctl_lamf32/*.log "$S"/out/P_G1_census/*.log "$S"/out/P_G1_census_rest/*.log > "$S/out/P_G1_bind_lines.txt" 2>&1
  CTL_EXTRA_EXPECT="every BIND COUNT line floor 0 [], ceiling 0 []"
  got=$(cat "$S"/out/P_G1_census/*.log | grep -a '^BIND COUNT' | grep -avc 'floor 0 \[\], ceiling 0 \[\]'); [ "$got" = 0 ] || CTL_EXTRA_BAD=" $got counts above 0"
  ctl_judge P_G1_census ref IDENTICAL jobs_census_P2.txt "3.6.2, B1" "amendment B1's census, three random-action jobs: the floor binds nowhere else" HARNESS_BIND_COUNT=1
  CTL_EXTRA_EXPECT="every BIND COUNT line floor 0 [], ceiling 0 []"
  got=$(cat "$S"/out/P_G1_census_rest/*.log | grep -a '^BIND COUNT' | grep -avc 'floor 0 \[\], ceiling 0 \[\]'); [ "$got" = 0 ] || CTL_EXTRA_BAD=" $got counts above 0"
  ctl_judge P_G1_census_rest ref IDENTICAL jobs_census_P2_rest.txt "3.6.2, B1" "the bind census, the other random-action jobs" HARNESS_BIND_COUNT=1
  # G1.5 amendment B2, the form controls
  ctl_judge P_G1_ctl_AB0 ref IDENTICAL jobs_ctl_P3.txt "3.6.2, B2" "form A+B at ve_map 0 gives form A's doubles (inv skipped by design)" "HARNESS_SET=$SET_AB0" inv
  ctl_judge P_G1_ctl_ABC065 ref IDENTICAL jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C at the shared slope 0.65, on a job that runs rich" "HARNESS_SET=$SET_ABC065" inv
  CTL_EXTRA_EXPECT="its log's CAM ON line 0.0 to 0.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_ABCD0/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
  grep -aqE '0\.0 to 0\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
  ctl_judge P_G1_ctl_ABCD0 ref IDENTICAL jobs_ctl_P4.txt "3.6.2, B2" "form A+B+C+D with zeros" "HARNESS_SET=$SET_ABCD0" inv
  CTL_EXTRA_EXPECT="its log's CAM ON line 10.0 to 10.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_D0/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
  grep -aqE '10\.0 to 10\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
  ctl_judge P_G1_ctl_D0 ref IDENTICAL jobs_ctl_P4.txt "3.6.2, B2" "B2's cam schedule (cam 10 deg) at ve_cam 0" "HARNESS_SET=$SET_D0" inv
  CTL_EXTRA_EXPECT="its log's CAM ON line 10.0 to 10.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_D1e4/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
  grep -aqE '10\.0 to 10\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
  ctl_judge P_G1_ctl_D1e4 P_G1_cand DIFFERENT jobs_ctl_P4.txt "3.6.2, B2" "the cam schedule at ve_cam 1e-4 (the cam reaches the cycle)" "HARNESS_SET=$SET_D1E4" inv
  ctl_judge P_G1_ctl_ABve P_G1_cand DIFFERENT jobs_ctl_P3.txt "3.6.2, B2" "form A+B at ve_map 1e-4 (the B term reaches the breathing)" "HARNESS_SET=$SET_ABVE" inv
  ctl_judge P_G1_ctl_ABCulp P_G1_cand DIFFERENT jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C, the slope one ulp above 0.65 (predict at lambda 0.95, the rich episode)" "HARNESS_SET=$SET_ABCULP" inv
  ctl_judge P_G1_ctl_C070 ref DIFFERENT jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C, slope 0.7 (the pre-check: the file has a job the slope reaches)" "HARNESS_SET=$SET_C070" inv
  # G1.6 the reference side of the tools
  ( cd "$S" && sha256sum tools/*.py tools/*.sh tools/*.txt ) > "$S/out/P_G1_tool_hashes.txt" 2>&1
  ctl_judge P_G1_refside ref IDENTICAL jobs_P7.txt "3.6.2, B9" "the reference side of the edited tools (P_G1_refside; out/P_G1_tool_hashes.txt)" ""

  # ---- G1.7 make_cert.py and make_md.py: P's edits leave the reference side and commit A's route as they were
  g1_7
  say "G1 ends"
}

g1_7() {      # B9 (CERT_PLAN_A.md G1.7, carried to P: INTEGRATION.md, "G1.7 at P")
  # (review fixes 2) make_cert.py takes S from its own path, so G1.7 runs the archived tools inside their own
  # fresh extraction: the one exception to "no tool runs from inside an extracted archive" (P_GATE_PLAN.md 11.2).
  # Each extraction is first checked member by member against its own archive_members.txt (as cert-prep checks
  # X); nothing in it runs unless that check passes; every call runs with -I -B (neither the script's folder nor
  # the cwd on sys.path) and with the cwd CERT_ROOT, outside the extraction.
  local T TW t0 bad got st n mb
  T="$CERT_ROOT/g17"; rm -rf "$T"; mkdir -p "$T/bs1" "$T/a"; TW=$(cygpath -m "$T")
  t0=$(date +%s)
  # (a) build step 1's archive (c47907b's), unpacked; its make_cert/make_md and P's, side by side, without --config
  blob c47907b:results/B58_IDENTITY/certificate_tools.tar.gz > "$T/bs1.tar.gz" && tar -xzf "$T/bs1.tar.gz" -C "$T/bs1"
  ( cd "$T/bs1" && awk '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); print $1 "  " p }' archive_members.txt | sha256sum --quiet -c - ) \
    > "$S/out/P_G1_b9_bs1_members.txt" 2>&1; mb=$?
  echo "members of c47907b's archive against its archive_members.txt: exit $mb ($(grep -c . "$T/bs1/archive_members.txt" 2>/dev/null) listed)" >> "$S/out/P_G1_b9_bs1_members.txt"
  cp -p "$S/tools/make_cert.py" "$T/bs1/tools/make_cert_P.py"; cp -p "$S/tools/make_md.py" "$T/bs1/tools/make_md_P.py"
  if [ "$mb" = 0 ]; then
    ( cd "$CERT_ROOT" || exit 9
      "$PY" -I -B "$TW/bs1/tools/make_cert.py" "$TW/orig.json" "$TW/bs1.tar.gz"; echo "make_cert exit $?"
      "$PY" -I -B "$TW/bs1/tools/make_cert_P.py" "$TW/edit.json" "$TW/bs1.tar.gz"; echo "make_cert_P exit $?"
      "$PY" -I -B "$TW/bs1/tools/make_md.py" "$TW/orig.json" "$TW/orig.md"; echo "make_md exit $?"
      "$PY" -I -B "$TW/bs1/tools/make_md_P.py" "$TW/orig.json" "$TW/edit.md"; echo "make_md_P exit $?"
    ) > "$S/out/P_G1_b9_bs1_mode.txt" 2>&1
  else
    echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_bs1_members.txt)" > "$S/out/P_G1_b9_bs1_mode.txt"
  fi
  blob c47907b:results/B58_IDENTITY.md > "$T/committed_bs1.md"
  n=$(diff "$T/orig.md" "$T/committed_bs1.md" 2>/dev/null | grep -c '^[<>]')
  bad=""
  [ "$mb" = 0 ] || bad="$bad the extraction is not its archive_members.txt"
  [ "$(grep -c ' exit 0$' "$S/out/P_G1_b9_bs1_mode.txt")" = 4 ] || bad="$bad an exit"
  cmp -s "$T/orig.json" "$T/edit.json" || bad="$bad the JSONs differ"
  cmp -s "$T/orig.md" "$T/edit.md" || bad="$bad the pages differ"
  echo "orig.json vs edit.json: $(cmp -s "$T/orig.json" "$T/edit.json" && echo identical || echo DIFFERENT); orig.md vs edit.md: $(cmp -s "$T/orig.md" "$T/edit.md" && echo identical || echo DIFFERENT); orig.md against c47907b's committed page: $n lines differ" >> "$S/out/P_G1_b9_bs1_mode.txt"
  R G1-harness --level control --item B9 --what "make_cert.py and make_md.py without --config are build step 1's (P's edits)" \
    --command "T=CERT_ROOT/g17: git show c47907b:results/B58_IDENTITY/certificate_tools.tar.gz unpacked into T/bs1, every member checked against its archive_members.txt (sha256sum -c) before anything in it runs; S/tools/make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py T/orig.json <archive>; make_cert_P.py T/edit.json <archive>; make_md.py T/orig.json T/orig.md; make_md_P.py T/orig.json T/edit.md; cmp; diff T/orig.md against c47907b's results/B58_IDENTITY.md; T removed" \
    --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/bs1, removed afterwards)" \
    --expected "the extraction equal to its own archive_members.txt; four exit 0; the two JSONs byte-identical and the two pages byte-identical; the lines in which the page differs from build step 1's committed page are counted, not judged (commit A found line 30 only, HEAD and the cf43fbb tar's sha256; the repository's committed files have moved since)" \
    --got "$( [ -z "$bad" ] && echo "the extraction is its listing; four exit 0; JSONs and pages byte-identical; $n lines differ from the committed page" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_bs1_mode.txt out/P_G1_b9_bs1_members.txt
  # (b) commit A's archive (RV's), unpacked: commit A's tools and P's on commit A's own config and records
  t0=$(date +%s)
  blob HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz > "$T/a.tar.gz" && tar -xzf "$T/a.tar.gz" -C "$T/a"
  ( cd "$T/a" && awk '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); print $1 "  " p }' archive_members.txt | sha256sum --quiet -c - ) \
    > "$S/out/P_G1_b9_commitA_members.txt" 2>&1; mb=$?
  echo "members of commit A's archive (RV's) against its archive_members.txt: exit $mb ($(grep -c . "$T/a/archive_members.txt" 2>/dev/null) listed)" >> "$S/out/P_G1_b9_commitA_members.txt"
  cp -p "$S/tools/make_cert.py" "$T/a/tools/make_cert_P.py"; cp -p "$S/tools/make_md.py" "$T/a/tools/make_md_P.py"
  if [ "$mb" = 0 ]; then
    ( cd "$CERT_ROOT" || exit 9
      "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
        "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
    ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
  else
    echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
    : > "$S/out/P_G1_b9_ctl_config.txt"
  fi
  bad=""
  [ "$mb" = 0 ] || bad="$bad the extraction is not its archive_members.txt"
  [ "$(grep -c ' exit 0$' "$S/out/P_G1_b9_commitA_mode.txt")" = 5 ] || bad="$bad an exit"
  cmp -s "$T/a_orig.json" "$T/a_edit.json" || bad="$bad the JSONs differ"
  cmp -s "$T/a_orig.md" "$T/a_edit.md" || bad="$bad the pages differ"
  R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
    --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
    --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
    --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
  bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
  cmp -s "$T/a_orig.json" "$T/a_ctl.json" && bad="$bad the JSON did not move"
  [ "$got" = "$P_CAND" ] || bad="$bad candidate.head ${got:0:12}"
  R G1-harness --level control --item B9 --what "the control of the two above: make_cert_P.py asks git in the configured tree" \
    --command "make_cert_P.py T/a_ctl.json --config T/a/cert_A_ctl_tree.json (commit A's config with candidate.tree = the clone candg)" \
    --cwd "CERT_ROOT/g17 (removed afterwards)" --expected "the JSON differs from T/a_orig.json, and its candidate.head is P's candidate $P_CAND" \
    --got "$( [ -z "$bad" ] && echo "differs; candidate.head $got" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_ctl_config.txt
  rm -rf "$T"
}

# ============================================================================= G2-writers
g2() {
  local t0 t1 bad got since rc1 rc2 d
  say "G2 begins"
  t0=$(date +%s)
  # G2.1 and G2.2 at once (two files), G2.4 beside them in its own copy
  ( CAND="$S/candw" bash "$S/tools/run_writer.sh" cand premise results/premise.json check_premise.py > "$S/L5/P_G2_premise_run.txt" 2>&1 ) &
  ( CAND="$S/candw" bash "$S/tools/run_writer.sh" cand generality results/generality.json generality_test.py > "$S/L5/P_G2_generality_run.txt" 2>&1 ) &
  (
    since=$(date +%s); echo "$since" > "$S/L9/P_G2_since.txt"
    s=$(date +%s); ( cd "$S/candt" && "$PY" -B -c "from thresholds import b58_propagation as P; P.run()" ) > "$S/L9/P_G2_b58_propagation.txt" 2>&1
    echo "exit $? in $(( $(date +%s) - s )) s" >> "$S/L9/P_G2_b58_propagation.txt"
    s=$(date +%s); ( cd "$S/candt" && "$PY" -B -c "from thresholds import ecu_shift as U; U.run_all($L9_PROCS)" ) > "$S/L9/P_G2_ecu_shift.txt" 2>&1
    echo "exit $? in $(( $(date +%s) - s )) s" >> "$S/L9/P_G2_ecu_shift.txt"
    "$PY" -I -B "$SW/tools/l9_check.py" "$SW/candt" "$RW/results/ENGINE_THRESHOLDS.json" --since "$since" --json "$SW/L9/P_G2_l9_check.json" > "$S/L9/P_G2_l9_check.txt" 2>&1
    echo "l9_check exit $?" >> "$S/L9/P_G2_l9_check.txt"; echo "$(( $(date +%s) - since ))" > "$S/L9/P_G2_seconds.txt"
  ) &
  wait
  # G2.1 check_premise.py (L3, 3.6.3)
  bad=""
  grep -aqE '^exit 0 in [0-9]+ s; results/premise.json .*\(UNCHANGED\)' "$S/L5/cand_premise_exit.txt" || bad="$bad $(cat "$S/L5/cand_premise_exit.txt" 2>/dev/null | cut -c1-120)"
  cmp -s "$S/L5/cand_premise_OUT_premise.json" "$S/L5/ref_premise_OUT_premise.json" || bad="$bad OUT against cf43fbb's"
  cmp -s "$S/L5/cand_premise_OUT_premise.json" "$REPO/results/premise.json" || bad="$bad OUT against the committed file"
  same "$S/L5/cand_premise_stdout.txt" "$S/commitA/L5/cand_premise_stdout.txt" || bad="$bad stdout against commit A's candidate's"
  [ ! -s "$S/L5/cand_premise_stderr.txt" ] || bad="$bad stderr"
  diff "$S/L5/ref_premise_stdout.txt" "$S/L5/cand_premise_stdout.txt" > "$S/L5/P_G2_premise_stdout_diff.txt" 2>&1
  R G2-writers --level L3 --item 3.6.3 --what "check_premise.py in a copy" \
    --command "CAND=S/candw bash tools/run_writer.sh cand premise results/premise.json check_premise.py; cmp OUT with L5/ref_premise_OUT_premise.json and with candg's results/premise.json; the stdout against commit A's candidate's (commitA/L5/cand_premise_stdout.txt) and diffed with cf43fbb's" \
    --cwd S/candw --expected "exit 0, results/premise.json UNCHANGED; the output byte-identical to cf43fbb's and to the committed file; stdout byte-identical to commit A's candidate's, which differs from cf43fbb's by the one line 'plant: b58b30o1/a90-supra-zf8hp51' (build step 1's difference); stderr empty" \
    --got "$( [ -z "$bad" ] && echo "as expected; the stdout's difference from cf43fbb's: $(lf "$S/L5/P_G2_premise_stdout_diff.txt" | tr '\n' ' ' | cut -c1-120)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/L5/cand_premise_exit.txt")" \
    --difference "check_premise.py's stdout gains the line 'plant: b58b30o1/a90-supra-zf8hp51' (the candidate names its engine), as on commit A; results/premise.json byte-identical" \
    --evidence L5/cand_premise_exit.txt L5/cand_premise_stdout.txt L5/cand_premise_stderr.txt L5/P_G2_premise_stdout_diff.txt
  # G2.2 generality_test.py (L5, 3.6.7)
  bad=""
  grep -aqE '^exit 0 in [0-9]+ s; results/generality.json .*\(UNCHANGED\)' "$S/L5/cand_generality_exit.txt" || bad="$bad $(cat "$S/L5/cand_generality_exit.txt" 2>/dev/null | cut -c1-120)"
  cmp -s "$S/L5/cand_generality_OUT_generality.json" "$S/L5/ref_generality_OUT_generality.json" || bad="$bad OUT against cf43fbb's"
  cmp -s "$S/L5/cand_generality_OUT_generality.json" "$REPO/results/generality.json" || bad="$bad OUT against the committed file"
  same "$S/L5/cand_generality_stdout.txt" "$S/L5/ref_generality_stdout.txt" || bad="$bad stdout"
  R G2-writers --level L5 --item 3.6.7 --what "generality_test.py in a copy" \
    --command "CAND=S/candw bash tools/run_writer.sh cand generality results/generality.json generality_test.py; cmp OUT with L5/ref_generality_OUT_generality.json and candg's results/generality.json; the stdouts compared" \
    --cwd S/candw --expected "exit 0, UNCHANGED; the output byte-identical to cf43fbb's and to the committed file; stdout identical to cf43fbb's" \
    --got "$( [ -z "$bad" ] && echo "as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_in "$S/L5/cand_generality_exit.txt")" \
    --evidence L5/cand_generality_exit.txt L5/cand_generality_stdout.txt L5/cand_generality_stderr.txt
  # G2.4 L9 (3.6.17)
  bad=""
  [ "$(exit_of "$S/L9/P_G2_b58_propagation.txt")" = 0 ] || bad="$bad b58_propagation"
  [ "$(exit_of "$S/L9/P_G2_ecu_shift.txt")" = 0 ] || bad="$bad ecu_shift"
  got=$(lf "$S/L9/P_G2_l9_check.txt" | grep -a '^L9: ' | tail -1)
  [[ $got == *"-> PASS" ]] && grep -aq '^l9_check exit 0' "$S/L9/P_G2_l9_check.txt" || bad="$bad l9_check"
  R G2-writers --level L9 --item 3.6.17 --what "L9: the contract's B58 steps re-made in a copy (never engine_thresholds.py)" \
    --command "cd S/candt: python -B -c 'from thresholds import b58_propagation as P; P.run()'; python -B -c 'from thresholds import ecu_shift as U; U.run_all($L9_PROCS)'; python -I -B tools/l9_check.py S/candt candg/results/ENGINE_THRESHOLDS.json --since <start> --json L9/P_G2_l9_check.json" \
    --cwd S/candt --environment "ecu_shift.run_all($L9_PROCS): CERT_PLAN_A.md's 20 processes lowered beside the roads check; commit A ran 16 with 25 of 25" \
    --expected "both exit 0; 'L9: N of N step outputs equal the contract's generator_inputs_sha256 and were rewritten after <since> -> PASS' (N the contract's own count; commit A: 25)" \
    --got "$( [ -z "$bad" ] && echo "$got" || echo "differs:$bad; ${got:-no L9 line}")" --verdict "$(verdict "$bad")" \
    --seconds "$(nz "$(cat "$S/L9/P_G2_seconds.txt" 2>/dev/null)")" \
    --evidence L9/P_G2_b58_propagation.txt L9/P_G2_ecu_shift.txt L9/P_G2_l9_check.txt L9/P_G2_l9_check.json L9/P_G2_since.txt
  # G2.3 item 16, before (RV) and after (P): CERT_PLAN_A.md's three scripts (INTEGRATION.md, "item 16 at P")
  t1=$(date +%s); d="$CERT_ROOT/preRV"; rm -rf "$d"; mkdir -p "$d"
  git -C "$REPO" archive --format=tar "$RV" | tar -x -C "$d"
  git -C "$REPO" archive --format=tar "$RV" | tar --compare -C "$d" 2>&1 | grep -v -E 'Mode differs|Uid differs|Gid differs|Mod time differs' > "$S/prep/P_G2_preRV_tar_compare.txt"
  bad=""; [ ! -s "$S/prep/P_G2_preRV_tar_compare.txt" ] || bad=" tar --compare"
  R G2-writers --level prep --item prep --what "item 16's 'before' tree: git archive of RV, outside S" \
    --command "git -C candg archive --format=tar HEAD~1 (RV $RV) | tar -x -C CERT_ROOT/preRV; the same | tar --compare (mode, uid, gid, mtime lines dropped)" \
    --cwd CERT_ROOT/preRV --expected "no content or size difference" --got "$( [ -z "$bad" ] && echo none || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence prep/P_G2_preRV_tar_compare.txt
  for t in pre candw; do
    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_mvd" results/model_vs_data.json model_vs_data.py > /dev/null 2>&1
  done
  bad=""
  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_mvd_exit.txt" || bad="$bad $t exit"; done
  cmp -s "$S/L5/cand_P16pre_mvd_OUT_model_vs_data.json" "$S/L5/cand_P16candw_mvd_OUT_model_vs_data.json" || bad="$bad before and after differ"
  got=$(cmp -s "$S/L5/cand_P16candw_mvd_OUT_model_vs_data.json" "$REPO/results/model_vs_data.json" && echo "equal to the committed file" || echo "unlike the committed file (both trees alike: a stale committed file, not P's)")
  R G2-writers --level L5 --item "3.6.16, B12" --what "item 16: model_vs_data.py before (RV) and after (P), in copies" \
    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_mvd results/model_vs_data.json model_vs_data.py; cmp the two outputs; cmp the candidate's with the committed file" \
    --cwd "CERT_ROOT/preRV, S/candw" --expected "both exit 0; results/model_vs_data.json byte-identical before and after; against the committed file: recorded, not judged" \
    --got "$( [ -z "$bad" ] && echo "byte-identical; $got" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence L5/cand_P16pre_mvd_exit.txt L5/cand_P16candw_mvd_exit.txt L5/cand_P16pre_mvd_stdout.txt L5/cand_P16candw_mvd_stdout.txt
  t1=$(date +%s)
  for t in pre candw; do
    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_substep" results/substep_fit_check.json substep_fit_check.py > /dev/null 2>&1
  done
  "$PY" -I -B -c "import json,sys; a,b=(json.load(open(f,encoding='utf-8')) for f in sys.argv[1:3]); [d.pop('seconds',None) for d in (a,b)]; print('EQUAL apart from seconds' if a==b else 'DIFFERENT'); sys.exit(a!=b)" \
    "$SW/L5/cand_P16pre_substep_OUT_substep_fit_check.json" "$SW/L5/cand_P16candw_substep_OUT_substep_fit_check.json" > "$S/L5/P_G2_substep_compare.txt" 2>&1; rc1=$?
  bad=""
  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_substep_exit.txt" || bad="$bad $t exit"; done
  [ "$rc1" = 0 ] || bad="$bad $(head -1 "$S/L5/P_G2_substep_compare.txt")"
  R G2-writers --level L5 --item "3.6.16, B12" --what "item 16: substep_fit_check.py before (RV) and after (P), in copies" \
    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_substep results/substep_fit_check.json substep_fit_check.py; the two JSONs compared with 'seconds' dropped" \
    --cwd "CERT_ROOT/preRV, S/candw" --expected "both exit 0; the two results equal apart from 'seconds'" \
    --got "$( [ -z "$bad" ] && echo "EQUAL apart from seconds" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence L5/P_G2_substep_compare.txt L5/cand_P16pre_substep_stdout.txt L5/cand_P16candw_substep_stdout.txt
  t1=$(date +%s)
  for t in pre candw; do
    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_page" results/page/index.html make_page.py > /dev/null 2>&1
  done
  "$PY" -I -B -c "import difflib,sys; a,b=(open(f,encoding='utf-8').read().splitlines() for f in sys.argv[1:3]); d=[l[:300] for l in difflib.unified_diff(a,b,'RV','P',lineterm='',n=0)]; print(len(d),'diff lines'); print(*d,sep='\n'); sys.exit(1 if d else 0)" \
    "$SW/L5/cand_P16pre_page_OUT_index.html" "$SW/L5/cand_P16candw_page_OUT_index.html" > "$S/L5/P_G2_page_diff.txt" 2>&1; rc2=$?
  bad=""
  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_page_exit.txt" || bad="$bad $t exit"; done
  [ "$rc2" = 0 ] || bad="$bad $(head -1 "$S/L5/P_G2_page_diff.txt")"
  for got in 'engines.DamageCal.turb_knee_k' 'engines.Fuel.afr_st'; do
    grep -aqF "$got" "$S/L5/cand_P16candw_page_OUT_index.html" || bad="$bad no '$got' (HA.7)"
  done
  R G2-writers --level L5 --item "3.6.16, HA.7, B12" --what "item 16: the study page built before (RV) and after (P), in copies" \
    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_page results/page/index.html make_page.py; difflib of the two pages (L5/P_G2_page_diff.txt); grep the candidate's page for commit A's two glossary sources" \
    --cwd "CERT_ROOT/preRV, S/candw" \
    --expected "both exit 0 (make_page.py's _src and glossary() stop a build whose anchored text is gone: B12); the two pages identical line for line (a build date across midnight would read as a difference, to be read); HA.7: the candidate's page carries engines.DamageCal.turb_knee_k and engines.Fuel.afr_st" \
    --got "$( [ -z "$bad" ] && echo "both exit 0; 0 diff lines; both glossary sources present" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_since "$t1")" --evidence L5/P_G2_page_diff.txt L5/cand_P16pre_page_exit.txt L5/cand_P16candw_page_exit.txt
  rm -rf "$d"
  say "G2 ends ($(secs_since "$t0") s)"
}

# ============================================================================= G3-roads
g3() {
  local t0 t1 bad got diffc want
  say "G3 begins"; t0=$(date +%s)
  t1=$(date +%s); bad=""
  ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
  R G3-roads --level identity --item prep --what "S/cand equals the start manifest before G3's writers" \
    --command "cd S/cand && sha256sum -c --quiet manifest_start_P.txt" --cwd S/cand --expected "every file equal" \
    --got "$( [ -z "$bad" ] && echo "every file equal" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence prep/P_G3_cand_before.txt
  # G3.1 test_reward.py in the clone, beside the roads (L4)
  ( bash "$S/tools/run_l4.sh" cand > "$S/L4/P_G3_run_l4.txt" 2>&1 ) &
  ( bash "$S/tools/run_l4.sh" cand --road random > "$S/L4/P_G3_run_l4_random.txt" 2>&1 ) &
  # G3.2 the roads in S/cand, one after another (each up to 18 workers)
  CAND="$S/cand" bash "$S/tools/run_writer.sh" cand roads_extremes results/training_roads_extremes.json check_roads.py --road extremes > /dev/null 2>&1
  CAND="$S/cand" bash "$S/tools/run_writer.sh" cand roads_wideair results/training_roads_wideair.json check_roads.py --road wideair > /dev/null 2>&1
  ( cd "$S/cand" && cp -p results/training_roads.json "$S/F11/cand_training_roads_committed.json" && s=$(date +%s) \
    && "$PY" -B check_roads.py > "$S/F11/cand_roads_terrain_stdout.txt" 2> "$S/F11/cand_roads_terrain_stderr.txt"; \
    echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_roads_terrain_exit.txt"; \
    cp -p results/training_roads.json "$S/F11/cand_roads_terrain_OUT_training_roads.json"; \
    cp -p "$S/F11/cand_training_roads_committed.json" results/training_roads.json )
  ( cd "$S/cand" && s=$(date +%s) && "$PY" -B check_random_road.py > "$S/F11/cand_random_road_stdout.txt" 2> "$S/F11/cand_random_road_stderr.txt"; \
    echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
  wait
  # G3.1's record
  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
  bad=""
  for t in "" _random; do
    case "$t" in
      "")      want="All checks pass. The reward is safe to train against.";;
      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
    esac
    grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
    cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
    [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
  done
  R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
    --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
    --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
    --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
  # G3.2's records
  local r
  for r in extremes wideair; do
    bad=""
    grep -aq '^exit 0 ' "$S/L5/cand_roads_${r}_exit.txt" || bad="$bad exit"
    cmp -s "$S/L5/cand_roads_${r}_OUT_training_roads_${r}.json" "$S/L5/ref_roads_${r}_OUT_training_roads_${r}.json" || bad="$bad OUT"
    cmp -s "$S/L5/cand_roads_${r}_stdout.txt" "$S/L5/ref_roads_${r}_stdout.txt" || bad="$bad stdout"
    "$PY" -I -B "$SW/tools/road_json_diff.py" "$RW/results/training_roads_${r}.json" "$SW/L5/cand_roads_${r}_OUT_training_roads_${r}.json" \
      --json "$SW/L5/P_G3_roads_${r}_vs_committed.json" > "$S/L5/P_G3_roads_${r}_vs_committed.txt" 2>&1
    diffc=$(lf "$S/L5/P_G3_roads_${r}_vs_committed.txt" | tr '\n' ' ' | cut -c1-300)
    R G3-roads --level L5 --item 3.6.5 --what "check_roads.py --road $r, the candidate against cf43fbb" \
      --command "CAND=S/cand bash tools/run_writer.sh cand roads_$r results/training_roads_$r.json check_roads.py --road $r; cmp OUT and stdout with L5/ref_roads_${r}_*; road_json_diff.py candg's committed file against the OUT" \
      --cwd S/cand --expected "exit 0; the output and the stdout byte-identical to cf43fbb's ($( [ $r = extremes ] && echo "baseline past 850 C: 10 of 40 roads" || echo "2 of 40 roads")); the comparison with the committed file recorded as a difference, not judged" \
      --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/L5/cand_roads_${r}_stdout.txt" | grep -a 'baseline past' | tail -1 | cut -c1-80)" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/L5/cand_roads_${r}_exit.txt")" \
      --difference "results/training_roads_$r.json, committed, against the file both trees write: $diffc" \
      --evidence "L5/cand_roads_${r}_exit.txt" "L5/cand_roads_${r}_stdout.txt" "L5/P_G3_roads_${r}_vs_committed.txt"
  done
  bad=""
  grep -aq '^exit 0 ' "$S/F11/cand_roads_terrain_exit.txt" || bad="$bad exit"
  cmp -s "$S/F11/cand_roads_terrain_OUT_training_roads.json" "$S/F11/ref_roads_terrain_OUT_training_roads.json" || bad="$bad OUT"
  cmp -s "$S/F11/cand_roads_terrain_stdout.txt" "$S/F11/ref_roads_terrain_stdout.txt" || bad="$bad stdout"
  cmp -s "$S/F11/cand_training_roads_committed.json" "$S/cand/results/training_roads.json" || bad="$bad the copy's committed file not restored"
  "$PY" -I -B "$SW/tools/road_json_diff.py" "$RW/results/training_roads.json" "$SW/F11/cand_roads_terrain_OUT_training_roads.json" \
    --json "$SW/F11/P_G3_terrain_vs_committed.json" > "$S/F11/P_G3_terrain_vs_committed.txt" 2>&1
  diffc=$(lf "$S/F11/P_G3_terrain_vs_committed.txt" | tr '\n' ' ' | cut -c1-300)
  R G3-roads --level L5 --item 3.6.5 --what "check_roads.py, the 40 terrain roads (finding 11), the candidate against cf43fbb" \
    --command "cd S/cand && python -B check_roads.py (the copy's committed results/training_roads.json kept aside and put back); cmp OUT and stdout with F11/ref_roads_terrain_*; road_json_diff.py candg's committed file against the OUT" \
    --cwd S/cand --expected "exit 0; the output and the stdout byte-identical to cf43fbb's (baseline past 850 C: 14 of 40 roads); the committed file, stale since 75ca65f (build step 1's finding 13, for main), recorded as a difference" \
    --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/F11/cand_roads_terrain_stdout.txt" | grep -a 'baseline past' | tail -1 | cut -c1-80)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/F11/cand_roads_terrain_exit.txt")" \
    --difference "results/training_roads.json, committed, against the file both trees write: $diffc" \
    --evidence F11/cand_roads_terrain_exit.txt F11/cand_roads_terrain_stdout.txt F11/cand_roads_terrain_stderr.txt F11/P_G3_terrain_vs_committed.txt
  bad=""
  grep -aq '^exit 0 ' "$S/F11/cand_random_road_exit.txt" || bad="$bad exit"
  diff <(lf "$S/commitA/F11/cand_random_road_stdout.txt" | grep -avE '^\([0-9.]+ min\)$') <(lf "$S/F11/cand_random_road_stdout.txt" | grep -avE '^\([0-9.]+ min\)$') > "$S/F11/P_G3_random_road_vs_commitA.txt" 2>&1 || bad="$bad stdout against commit A's candidate's"
  same "$S/F11/cand_random_road_stderr.txt" "$S/commitA/F11/cand_random_road_stderr.txt" || bad="$bad stderr"
  diff "$S/F11/ref_random_road_stdout.txt" "$S/F11/cand_random_road_stdout.txt" > "$S/F11/P_G3_random_road_vs_ref.txt" 2>&1
  R G3-roads --level L5 --item 3.6.5 --what "check_random_road.py (finding 11), the candidate against cf43fbb and commit A" \
    --command "cd S/cand && python -B check_random_road.py; diff against commit A's candidate's stdout (commitA/F11/, the run-time line dropped) and against cf43fbb's (F11/ref_random_road_stdout.txt)" \
    --cwd S/cand --expected "exit 0; stdout identical to commit A's candidate's but for the run-time line '(N min)'; stderr as commit A's; against cf43fbb's it differs in road_sha (random_road.py's code hash, be19b3d0bcef435d against e44153fd81eeaa1e) and the run time, as on commit A" \
    --got "$( [ -z "$bad" ] && echo "as expected; $(lf "$S/F11/cand_random_road_stdout.txt" | grep -aoE 'road_sha [0-9a-f]{16}' | head -1)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/F11/cand_random_road_exit.txt")" \
    --difference "check_random_road.py's header prints road_sha, random_road.code_sha(): be19b3d0bcef435d on the candidate (as on commit A and build step 1), e44153fd81eeaa1e on cf43fbb; random_road.py's code changed between cf43fbb and c47907b, not in P" \
    --evidence F11/cand_random_road_exit.txt F11/cand_random_road_stdout.txt F11/P_G3_random_road_vs_commitA.txt F11/P_G3_random_road_vs_ref.txt
  t1=$(date +%s); bad=""
  ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_after.txt" 2>&1 || bad=" a file differs"
  R G3-roads --level identity --item prep --what "S/cand equals the start manifest after G3's writers" \
    --command "cd S/cand && sha256sum -c --quiet manifest_start_P.txt" --cwd S/cand --expected "every file equal" \
    --got "$( [ -z "$bad" ] && echo "every file equal" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence prep/P_G3_cand_after.txt
  say "G3 ends ($(secs_since "$t0") s)"
}

# ============================================================================= G4-data
g4() {
  local t0 t1 bad got before after n csvs pull
  say "G4 begins"; t0=$(date +%s)
  # G4.1 validate.py in the clone (it only prints)
  t1=$(date +%s)
  before=$(sha256sum < "$REPO/validation_table.md" | cut -c1-64)
  ( cd "$REPO" && "$PY" -B validate.py ) > "$S/L5/P_G4_cand_validate.txt" 2>&1; echo "exit $?" > "$S/L5/P_G4_cand_validate_exit.txt"
  after=$(sha256sum < "$REPO/validation_table.md" | cut -c1-64)
  git -C "$REPO" status --porcelain=v1 --untracked-files=all > "$S/L5/P_G4_status_after_validate.txt"
  bad=""
  [ "$(exit_of "$S/L5/P_G4_cand_validate_exit.txt")" = 0 ] || bad="$bad exit"
  cmp -s "$S/L5/P_G4_cand_validate.txt" "$S/L5/ref_validate.txt" || bad="$bad the printout"
  [ "$before" = "$after" ] && [ ! -s "$S/L5/P_G4_status_after_validate.txt" ] || bad="$bad validation_table.md or the clone moved"
  R G4-data --level L5 --item 3.6.6 --what "validate.py, candidate against cf43fbb" \
    --command "cd candg && python -B validate.py > L5/P_G4_cand_validate.txt 2>&1; cmp with L5/ref_validate.txt; sha256 of validation_table.md before and after; git status of the clone" \
    --cwd candg --expected "exit 0; the printout byte-identical to cf43fbb's (2497 bytes, 8 of 11 quantities inside their band); validation_table.md the same bytes and the clone's status empty. A moved printout is a finding: FAIL, and the table is never edited" \
    --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/L5/P_G4_cand_validate.txt" | grep -a 'quantities inside' | tail -1 | cut -c1-80); the table and the clone unchanged" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence L5/P_G4_cand_validate.txt L5/P_G4_cand_validate_exit.txt L5/P_G4_status_after_validate.txt
  # G4.2 build_dataset with no derived file, both trees at once
  t1=$(date +%s)
  csvs=$(cd "$REPO/logs/raw" && ls *.csv); n=$(echo "$csvs" | grep -c .)
  ( "$PY" -I -B "$SW/tools/bd_dump.py" "$SW/candd" "$SW/F2/cand.npz" $csvs > "$S/F2/cand.txt" 2>&1; echo "cand exit $?" >> "$S/F2/cand.txt" ) &
  ( "$PY" -I -B "$SW/tools/bd_dump.py" "$SW/refw" "$SW/F2/ref.npz" $csvs > "$S/F2/ref.txt" 2>&1; echo "ref exit $?" >> "$S/F2/ref.txt" ) &
  wait
  "$PY" -I -B "$SW/tools/cmp.py" "$SW/F2/ref.npz" "$SW/F2/cand.npz" --quiet --json "$SW/F2/cmp.json" > "$S/F2/cmp.txt" 2>&1
  bad=""
  for t in cand ref; do
    [ "$(grep -ac ': derive OK' "$S/F2/$t.txt")" = "$n" ] || bad="$bad $t derive OK lines"
    grep -aq '^derived file restored: True' "$S/F2/$t.txt" || bad="$bad $t restored"
    grep -aq "^$t exit 0" "$S/F2/$t.txt" || bad="$bad $t exit"
  done
  got=$(lf "$S/F2/cmp.txt" | grep -a '^VERDICT' | tail -1)
  [[ $got == "VERDICT: BIT-IDENTICAL ("* ]] || bad="$bad $got"
  R G4-data --level L5 --item 3.6.9 --what "finding 2: build_dataset with no derived file, both trees" \
    --command "CSVS=\$(cd candg/logs/raw && ls *.csv); python -I -B tools/bd_dump.py S/candd F2/cand.npz \$CSVS; the same in S/refw (the two at once); python -I -B tools/cmp.py F2/ref.npz F2/cand.npz --quiet --json F2/cmp.json" \
    --cwd "S (bd_dump.py chdirs into S/candd and S/refw)" --expected "a derive OK line per drive and 'derived file restored: True' in each, both exit 0; VERDICT: BIT-IDENTICAL (commit A: 3617501 values)" \
    --got "$( [ -z "$bad" ] && echo "$n derive OK lines each, restored, $got" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_since "$t1")" --evidence F2/cand.txt F2/ref.txt F2/cmp.txt F2/cmp.json
  # G4.3 new_drive.py on pull01, the derived file aside, in S/candd (after G4.2)
  t1=$(date +%s)
  pull=$(cd "$S/candd" && ls logs/raw/pull01-*.csv 2>/dev/null | head -1)
  ( cd "$S/candd" && mv data/derived_params.json data/derived_params.json.aside \
    && "$PY" -B new_drive.py "$pull" > "$S/F2/new_drive_candd.txt" 2>&1; echo "exit $?" >> "$S/F2/new_drive_candd.txt"; \
    mv data/derived_params.json.aside data/derived_params.json )
  bad=""
  [ -n "$pull" ] || bad="$bad no pull01 drive"
  cmp -s "$S/F2/new_drive_candd.txt" "$S/F2/new_drive_ref.txt" || bad="$bad the output"
  [ -f "$S/candd/data/derived_params.json" ] && [ ! -e "$S/candd/data/derived_params.json.aside" ] || bad="$bad the derived file not back"
  R G4-data --level L5 --item 3.6.9 --what "finding 2: new_drive.py on pull01 with the derived file aside" \
    --command "cd S/candd && mv data/derived_params.json aside && python -B new_drive.py $pull > F2/new_drive_candd.txt 2>&1; echo \"exit \$?\" >> (as build step 1 captured it); the file back; cmp with F2/new_drive_ref.txt" \
    --cwd S/candd --expected "byte-identical to cf43fbb's output (build step 1's F2/new_drive_ref.txt, 2483 bytes with its 'exit 0' line); the derived file back" \
    --got "$( [ -z "$bad" ] && echo "byte-identical; the derived file back" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_since "$t1")" --evidence F2/new_drive_candd.txt
  # G4.4 derive_params.py in S/candd (after G4.3: it rewrites the copy's derived file)
  t1=$(date +%s)
  ( cd "$S/candd" && "$PY" -B derive_params.py ) > "$S/L5/derive_cand.txt" 2>&1; echo "exit $?" >> "$S/L5/derive_cand.txt"
  cp -p "$S/candd/data/derived_params.json" "$S/L5/derived_params_DERIVED_cand.json"
  "$PY" -I -B "$SW/tools/derived_check.py" "$RW/data/derived_params.json" "$SW/L5/derived_params_DERIVED_cand.json" \
    "$SW/L5/derived_params_DERIVED_ref.json" --json "$SW/L5/derived_check.json" > "$S/L5/derived_check.txt" 2>&1; echo "derived_check exit $?" >> "$S/L5/derived_check.txt"
  bad=""
  [ "$(exit_of "$S/L5/derive_cand.txt")" = 0 ] || bad="$bad derive exit"
  grep -aq '^derived_check exit 0' "$S/L5/derived_check.txt" || bad="$bad derived_check exit"
  [ "$(grep -acE "^(committed|derived in the candidate copy|derived in the reference copy) +derived_sha $B58_DERIVED " "$S/L5/derived_check.txt")" = 3 ] \
    || bad="$bad derived_sha not G1.0's $B58_DERIVED on all three"
  grep -aqE ', [1-9][0-9]* of them values' "$S/L5/derived_check.txt" && bad="$bad a value differs"
  R G4-data --level L5 --item 3.6.8 --what "derive_params.py in a copy; derived_sha as committed" \
    --command "cd S/candd && python -B derive_params.py; cp data/derived_params.json L5/derived_params_DERIVED_cand.json; python -I -B tools/derived_check.py candg/data/derived_params.json L5/derived_params_DERIVED_cand.json L5/derived_params_DERIVED_ref.json --json L5/derived_check.json" \
    --cwd "S/candd (derive_params.py); S (derived_check.py)" --expected "exit 0; derived_sha $B58_DERIVED (G1.0's; CERT_PLAN_A.md: 326c0835548975e2) for the committed file, the candidate's and the reference's; every difference '_' bookkeeping (/_generated), 0 values" \
    --got "$( [ -z "$bad" ] && echo "$(lf "$S/L5/derived_check.txt" | grep -a 'of them values' | tr '\n' ' ' | cut -c1-200)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence L5/derive_cand.txt L5/derived_check.txt L5/derived_check.json
  say "G4 ends ($(secs_since "$t0") s)"
}

# ============================================================================= G5-app-lab
fsets() {   # fsets OUTFILE CAND REF...: failing_sets_P.py; 0 when the candidate fails nowhere a reference does not
  local out=$1; shift
  "$PY" -I -B "$SW/tools/failing_sets_P.py" "$@" > "$out" 2>&1
}
g5() {
  local t0 t1 bad got s refs info m L st pin lp i d data_bad st_ref st_cand st_ulp st_1e9
  say "G5 begins"; t0=$(date +%s)
  # (review fixes 3, 7 November 2026) the ignored local data commit A's run in the repository had: p_gate.sh
  # cert-prep copies these three paths from the live repository into the clone (gitignored there, so the clone's
  # status, the manifests and git_dirty do not see them). Without them agent-scene.test.mjs skips its tests and
  # app.test_agents' test_page_assets_ids fails (and cf43fbb's clone failed it too, so the strict judgement would
  # excuse it): G5 would cover less than commit A's run did. Each G5.1 record of the app requires them.
  data_bad=""
  for d in app/node_modules app/static/vendor runs/extremes_dt1/sighted_seed0/meta.json; do
    { [ -e "$REPO/$d" ] && git -C "$REPO" check-ignore -q -- "$d"; } || data_bad="$data_bad $d"
  done
  say "G5: the clone's ignored local data (app/node_modules, app/static/vendor, X1's sighted_seed0 meta.json): $( [ -z "$data_bad" ] && echo "present and ignored" || echo "MISSING or not ignored:$data_bad")"
  # G5.1 the app suites and the lab's Python tests in the clone, then the eleven, then the node tests
  t1=$(date +%s)
  bash "$S/tools/run_app.sh" cand > "$S/app/P_G5_run_app.txt" 2>&1
  bash "$S/tools/run_app_extra.sh" cand > "$S/app/P_G5_run_app_extra.txt" 2>&1
  ( cd "$REPO/app" && "$NODE" --test --test-reporter=spec static/sim/*.test.mjs ) > "$S/app/cand_node_tests.txt" 2>&1
  echo "exit $?" >> "$S/app/cand_node_tests.txt"
  # app.test_replay --full
  bad=""; got=$(lf "$S/app/cand_test_replay_full.txt" | grep -aE '^[0-9]+ of [0-9]+ checks pass' | tail -1)
  [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($1 == $3) }')" = 1 ] || bad=" ${got:-no 'N of M checks pass' line}"
  # (settle step) the three ignored local paths, as every other G5.1 app record (review fixes 3, R1.M2's claim)
  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
  diff "$S/commitA/app/cand_test_replay_full.txt" "$S/app/cand_test_replay_full.txt" > "$S/app/P_G5_test_replay_vs_commitA.txt" 2>&1
  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "app.test_replay --full" \
    --command "bash tools/run_app.sh cand (CAND = candg; its first line: python -B -m app.test_replay --full > app/cand_test_replay_full.txt); diffed with commit A's (commitA/app/)" \
    --cwd candg --expected "'N of N checks pass' (every check passes; commit A: 59 of 59); the clone holds the three ignored local paths commit A's run had (p_gate.sh cert-prep); the diff with commit A's run recorded, not judged" \
    --got "$( [ -z "$bad" ] && echo "$got; $(grep -c '^[<>]' "$S/app/P_G5_test_replay_vs_commitA.txt") lines differ from commit A's" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(nz "$(awk '$3 == "test_replay_full" { print $2 }' "$S/app/cand_status.txt" 2>/dev/null | tail -1)")" \
    --evidence app/cand_test_replay_full.txt app/P_G5_test_replay_vs_commitA.txt app/cand_status.txt
  # (review fixes 2) judged as CERT_PLAN_A.md G5.1 judges, which CERT_PLAN_P.md does not amend: "candidate only:
  # []" against cf43fbb's git clone (app/refgit_*) alone, the eleven against cf43fbb's copy run (app/ref_*) alone,
  # the lab's node tests against cf43fbb's run of them (commit A's A_G5_ref_lab_node_tests) alone. Commit A's
  # candidate runs and RV's base runs excuse nothing: they are compared too, for information only (*_info.txt,
  # named in the record's got), so that a failure RV's ancestors brought in after cf43fbb reads as a FAIL.
  for s in test_simulation test_agents test_results lab_tests; do
    refs=("$S/app/refgit_$s.txt"); info=("$S/app/refgit_$s.txt")
    [ $s = lab_tests ] && info+=("$S/commitA/app/A_G5_lab_tests_pinned.txt") || info+=("$S/commitA/app/cand_$s.txt")
    [ $s != lab_tests ] && [ -f "$P_GATE_OUT/base_app_$s.log" ] && info+=("$P_GATE_OUT/base_app_$s.log")
    fsets "$S/app/P_G5_failing_$s.txt" "$S/app/cand_$s.txt" "${refs[@]}"; st=$?
    fsets "$S/app/P_G5_failing_${s}_info.txt" "$S/app/cand_$s.txt" "${info[@]}"
    bad=""
    [ -n "$(ran_of "$S/app/cand_$s.txt")" ] && lf "$S/app/cand_$s.txt" | grep -aqE '^(OK|FAILED)( |$)' || bad="$bad did not complete"
    [ "$st" = 0 ] || bad="$bad $(lf "$S/app/P_G5_failing_$s.txt" | grep -a '^candidate only:' | cut -c1-200); for information, against cf43fbb's, commit A's and RV's runs together: $(lf "$S/app/P_G5_failing_${s}_info.txt" | grep -a '^candidate only:' | cut -c1-160)"
    [ $s = lab_tests ] || [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
    if [ $s = lab_tests ]; then
      pin=$(grep -aoE '"current_plant_sha"\], "[0-9a-f]{16}"' "$REPO/Explanatory Simulation/tests/test_catalog.py" | grep -oE '[0-9a-f]{16}' | head -1)
      [ "$pin" = "$B58_PLANT" ] || bad="$bad the pin $pin, not G1.0's plant_sha $B58_PLANT"
      tests_ok "$S/app/cand_lab_tests.txt" "^test_results_are_current_and_inconclusive_with_explicit_caveats [(]" \
        "^(FAIL|ERROR): test_results_are_current_and_inconclusive_with_explicit_caveats " || bad="$bad the pin's test not ok"
    fi
    R G5-app-lab --level L5 --item "$( [ $s = lab_tests ] && echo "3.6.12, HA.2, HA.3" || echo "3.6.11, HA.3, HP7.7")" \
      --what "$( [ $s = lab_tests ] && echo "the lab's Python tests, and its plant_sha pin" || echo "app.$s")" \
      --command "bash tools/run_app.sh cand (CAND = candg); python -I -B tools/failing_sets_P.py app/cand_$s.txt app/refgit_$s.txt > app/P_G5_failing_$s.txt (judged); the same against $(printf '%s ' "${info[@]##*/}")> app/P_G5_failing_${s}_info.txt (information only)" \
      --cwd "candg$( [ $s = lab_tests ] && echo '/Explanatory Simulation')" \
      --expected "the run complete (Ran N, OK or FAILED); candidate only: [] against cf43fbb's git clone (app/refgit_$s.txt) alone, as CERT_PLAN_A.md G5.1 (commit A's candidate run$( [ $s != lab_tests ] && echo " and RV's base run") compared for information only, excusing nothing)$( [ $s = lab_tests ] && echo "; test_results_are_current_and_inconclusive_with_explicit_caveats ... ok, and the pin in tests/test_catalog.py is G1.0's plant_sha $B58_PLANT" || echo "; the clone holds the three ignored local paths commit A's run had (app/node_modules, app/static/vendor, runs/extremes_dt1/sighted_seed0/meta.json; p_gate.sh cert-prep)")" \
      --got "$( [ -z "$bad" ] && echo "$(ut_line "$S/app/cand_$s.txt"); candidate only: []" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
      --seconds "$(nz "$(awk -v l="$s" '$3 == l { print $2 }' "$S/app/cand_status.txt" 2>/dev/null | tail -1)")" \
      --evidence "app/cand_$s.txt" "app/P_G5_failing_$s.txt" "app/P_G5_failing_${s}_info.txt"
  done
  bad=""
  for m in "${EXTRA[@]}"; do
    info=("$S/app/ref_$m.txt" "$S/commitA/app/cand_$m.txt")
    [ -f "$P_GATE_OUT/base_app_$m.log" ] && info+=("$P_GATE_OUT/base_app_$m.log")
    fsets "$S/app/P_G5_failing_${m}_info.txt" "$S/app/cand_$m.txt" "${info[@]}"
    fsets "$S/app/P_G5_failing_$m.txt" "$S/app/cand_$m.txt" "$S/app/ref_$m.txt" \
      || bad="$bad $m(candidate only; with commit A's and RV's runs: $(lf "$S/app/P_G5_failing_${m}_info.txt" | grep -a '^candidate only:' | cut -c16-120))"
    [ -n "$(ran_of "$S/app/cand_$m.txt")" ] && lf "$S/app/cand_$m.txt" | grep -aqE '^(OK|FAILED)( |$)' || bad="$bad $m(incomplete)"
  done
  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "the eleven other app suites (run_app_extra.sh)" \
    --command "bash tools/run_app_extra.sh cand (CAND = candg; python -B -m unittest -v app.<m>); python -I -B tools/failing_sets_P.py app/cand_<m>.txt app/ref_<m>.txt for each (judged); with commitA/app/cand_<m>.txt and RV's base log too (information only, app/P_G5_failing_<m>_info.txt)" \
    --cwd candg --expected "each of the eleven complete; for each, candidate only: [] against cf43fbb's copy run (build step 1's app/ref_<m>.txt) alone (pwsh's absence errs on both alike); commit A's and RV's runs excuse nothing; the clone holds the three ignored local paths commit A's run had (p_gate.sh cert-prep)" \
    --got "$( [ -z "$bad" ] && echo "eleven complete; candidate only: [] for each" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(awk '{ s += $2 } END { print s + 0 }' "$S/app/cand_extra_status.txt" 2>/dev/null)" \
    --evidence app/cand_extra_status.txt app/P_G5_run_app_extra.txt
  info=("$S/app/refgit_node_tests.txt" "$S/commitA/app/cand_node_tests.txt")
  [ -f "$P_GATE_OUT/base_app_node.log" ] && info+=("$P_GATE_OUT/base_app_node.log")
  fsets "$S/app/P_G5_failing_node.txt" "$S/app/cand_node_tests.txt" "$S/app/refgit_node_tests.txt"; st=$?
  fsets "$S/app/P_G5_failing_node_info.txt" "$S/app/cand_node_tests.txt" "${info[@]}"
  bad=""; got=$(lf "$S/app/cand_node_tests.txt" | grep -aE '^ℹ (tests|pass|fail|skipped) [0-9]+' | tr '\n' ' ')
  grep -aqE '^ℹ tests [0-9]+' <(lf "$S/app/cand_node_tests.txt") || bad="$bad no 'tests N' line"
  [ "$st" = 0 ] || bad="$bad candidate only (with commit A's and RV's runs: $(lf "$S/app/P_G5_failing_node_info.txt" | grep -a '^candidate only:' | cut -c16-120))"
  # (review fixes 3) no test skipped, as on commit A's run (cf43fbb's clone, without the ignored data, skipped 12)
  grep -aqxE 'ℹ skipped 0' <(lf "$S/app/cand_node_tests.txt") || bad="$bad not 'skipped 0'"
  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "the app's node tests" \
    --command "cd candg/app && node --test --test-reporter=spec static/sim/*.test.mjs > app/cand_node_tests.txt; failing_sets_P.py against cf43fbb's clone's run (judged), and with commit A's and RV's base run too (information only)" \
    --cwd candg/app --expected "the summary printed with 'ℹ skipped 0' (the clone holds app/node_modules, app/static/vendor and X1's sighted_seed0 meta.json, copied by p_gate.sh cert-prep, as commit A's run in the repository had them: commit A 306 tests, 306 pass, 0 skipped; cf43fbb's clone, without them, 294 pass, 12 skipped); candidate only: [] against cf43fbb's git clone alone" \
    --got "$( [ -z "$bad" ] && echo "$got; candidate only: []" || echo "differs:$bad; $got")" --verdict "$(verdict "$bad")" --seconds 0 \
    --evidence app/cand_node_tests.txt app/P_G5_failing_node.txt app/P_G5_failing_node_info.txt
  # G5.2 the lab's build and launcher, in S/cand (network for npm ci)
  L="$S/cand/Explanatory Simulation"
  { "$NODE" --version; "$NPM" --version; } > "$S/lab/P_G5_versions.txt" 2>&1
  t1=$(date +%s)
  ( cd "$L" && "$NPM" ci ) > "$S/lab/P_G5_npm_ci.txt" 2>&1; echo "exit $? in $(secs_since "$t1") s" >> "$S/lab/P_G5_npm_ci.txt"
  # (review fixes 3) npm ci's record is written whatever its outcome: without the network it is a FAIL, which
  # stands until cert-recheck g5 runs G5 again with it, so that the certificate cannot pass without the lab's build,
  # launcher and node tests (3.6.12, B12) having run. Before, a failed npm ci left no record, and 3.6.12 and B12
  # read as answered by the other records.
  bad=""; [ "$(exit_of "$S/lab/P_G5_npm_ci.txt")" = 0 ] && grep -aq '^added ' "$S/lab/P_G5_npm_ci.txt" || bad=" exit $(exit_of "$S/lab/P_G5_npm_ci.txt")"
  R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab: npm ci" --command "cd \"S/cand/Explanatory Simulation\" && npm ci > lab/P_G5_npm_ci.txt" \
    --cwd "S/cand/Explanatory Simulation" --expected "exit 0, 'added ... packages' (a FAIL here, the network absent, means the lab's build, launcher and node tests did not run: cert-recheck g5)" \
    --got "$(lf "$S/lab/P_G5_npm_ci.txt" | grep -aE '^added|^exit' | tr '\n' ' ' | cut -c1-160)$( [ -n "$bad" ] && echo "; the build, the launcher and the lab's node tests not run")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_ci.txt lab/P_G5_versions.txt
  if [ -n "$bad" ]; then
    say "npm ci failed ($bad; the network?): its record is a FAIL; G5.2's build and launcher and G5.3 did not run (lab/P_G5_npm_ci.txt)"
  else
    t1=$(date +%s)
    ( cd "$L" && "$NPM" run build ) > "$S/lab/P_G5_npm_build.txt" 2>&1; echo "exit $? in $(secs_since "$t1") s" >> "$S/lab/P_G5_npm_build.txt"
    bad=""; [ "$(exit_of "$S/lab/P_G5_npm_build.txt")" = 0 ] && grep -aq 'built in' "$S/lab/P_G5_npm_build.txt" || bad=" $(tail -1 "$S/lab/P_G5_npm_build.txt")"
    R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab: npm run build" --command "cd \"S/cand/Explanatory Simulation\" && npm run build > lab/P_G5_npm_build.txt" \
      --cwd "S/cand/Explanatory Simulation" --expected "exit 0, 'built in'" --got "$( [ -z "$bad" ] && echo "exit 0, built" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
    if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
      t1=$(date +%s)
      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
      # which the trigger below would fire before this run's server is up (a false FAIL)
      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
      ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
        echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
      lp=$!
      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
      ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
      wait "$lp"
      # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
      # p_gate.sh post's no_other_python would then refuse: a listener left on 8765 is killed, with its recorded
      # descendants (settle step, below).
      # (review fixes 3) Only the process that listens on 127.0.0.1:8765 (Get-NetTCPConnection's OwningProcess):
      # the port was free when the launcher started (checked above), so the listener is S/cand's server. Before,
      # every python.exe on the machine whose command line named launch.py was killed.
      if ! "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
        lp=$(powershell.exe -NoProfile -NonInteractive -Command "Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique" < /dev/null 2>/dev/null | tr -d '\r' | grep -E '^[0-9]+$' | grep -vx 0)
        # (settle step, 7 November 2026) not taskkill /T, which walks children by ParentProcessId alone: a process
        # whose parent had exited and whose parent's pid the listener reused would be killed too. The listener and
        # its Win32_Process descendants no older than their parent (as p_gate.sh's sv_win_tree) are recorded, and
        # exactly those pids are killed, each without /T.
        for i in $lp; do
          d=$(powershell.exe -NoProfile -NonInteractive -Command "\$all = @(Get-CimInstance Win32_Process); \$ct = @{}; foreach (\$x in \$all) { \$ct[[int]\$x.ProcessId] = \$x.CreationDate }; \$keep = @{}; if (\$ct.ContainsKey($i)) { \$keep[$i] = 1 }; do { \$n = 0; foreach (\$x in \$all) { \$p = [int]\$x.ParentProcessId; if (-not \$keep.ContainsKey([int]\$x.ProcessId) -and \$keep.ContainsKey(\$p) -and \$x.CreationDate -ge \$ct[\$p]) { \$keep[[int]\$x.ProcessId] = 1; \$n++ } } } while (\$n -gt 0); \$all | Where-Object { \$keep.ContainsKey([int]\$_.ProcessId) } | ForEach-Object { 'listener tree of $i: ' + [string]\$_.ProcessId + ' ' + [string]\$_.ParentProcessId + ' ' + \$_.Name + ' ' + \$_.CommandLine }" < /dev/null 2>/dev/null | tr -d '\r' | grep -aE "^listener tree of $i: [0-9]+ ")
          [ -n "$d" ] && printf '%s\n' "$d" >> "$S/lab/P_G5_launch_cleanup.txt"
          for m in $(printf '%s\n' "$d" | awk 'NF >= 5 { print $5 }'); do
            taskkill.exe //F //PID "$m" >> "$S/lab/P_G5_launch_cleanup.txt" 2>&1
          done
        done
        say "the launcher's server still listened on 8765 after the timeout: the listening process and its recorded descendants killed, each by its pid: [${lp:-none found}] (lab/P_G5_launch_cleanup.txt)"
      fi
      bad=""
      grep -aq 'Supra Lab is ready: http://127.0.0.1:8765' "$S/lab/P_G5_launch_no_browser.txt" || bad="$bad not ready"
      grep -aq '^exit 124 ' "$S/lab/P_G5_launch_no_browser.txt" || bad="$bad launcher exit"
      grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
        --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
        --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
    else
      # (review fixes 3) fail closed, as npm ci: a FAIL record, re-checked by cert-recheck g5 once the port is free
      say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
        --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
    fi
    # G5.3 the lab's node tests (after npm ci)
    t1=$(date +%s)
    ( cd "$L" && CATALOG_TEST_PYTHON="$(cygpath -w "$PY")" "$NODE" --test --test-reporter=spec src/model/*.test.mjs ) > "$S/lab/P_G5_lab_node_tests.txt" 2>&1
    echo "exit $?" >> "$S/lab/P_G5_lab_node_tests.txt"
    fsets "$S/lab/P_G5_lab_node_failing_sets_info.txt" "$S/lab/P_G5_lab_node_tests.txt" "$S/commitA/lab/A_G5_ref_lab_node_tests.txt" "$S/commitA/lab/A_G5_lab_node_tests.txt"
    fsets "$S/lab/P_G5_lab_node_failing_sets.txt" "$S/lab/P_G5_lab_node_tests.txt" "$S/commitA/lab/A_G5_ref_lab_node_tests.txt"; st=$?
    bad=""; grep -aqE '^ℹ tests [0-9]+' <(lf "$S/lab/P_G5_lab_node_tests.txt") || bad="$bad no summary"
    [ "$st" = 0 ] || bad="$bad $(lf "$S/lab/P_G5_lab_node_failing_sets.txt" | grep -a '^candidate only' | cut -c1-200); with commit A's candidate run too: $(lf "$S/lab/P_G5_lab_node_failing_sets_info.txt" | grep -a '^candidate only' | cut -c16-120)"
    R G5-app-lab --level L5 --item "3.6.12, B12" --what "the lab's node tests" \
      --command "cd \"S/cand/Explanatory Simulation\" && CATALOG_TEST_PYTHON=<PY> node --test --test-reporter=spec src/model/*.test.mjs; failing_sets_P.py against commit A's run of them on cf43fbb's tree (judged: CERT_PLAN_A.md G5.3 classifies a failure by the same command on S/ref), and with commit A's candidate run too (information only)" \
      --cwd "S/cand/Explanatory Simulation" --expected "the summary printed; candidate only: [] against the cf43fbb run alone (commit A: one failure on both trees, provenance.test.mjs's oil row; command-explanations.test.mjs anchors on engine_env.py's text, which P edits: B12)" \
      --got "$( [ -z "$bad" ] && echo "$(lf "$S/lab/P_G5_lab_node_tests.txt" | grep -aE '^ℹ (tests|fail) [0-9]+' | tr '\n' ' '); candidate only: []" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_lab_node_tests.txt lab/P_G5_lab_node_failing_sets.txt lab/P_G5_lab_node_failing_sets_info.txt
  fi
  # G5.4 the lab's outputs. (review fixes 3) Each dump is removed before lab_dump.py writes it, its exit code is
  # recorded in its log, and every record that reads a dump requires that dump's exit 0 and its file: on a
  # CERT_ONLY=g5 re-run a crashed dump would otherwise leave the first run's JSON to be compared as if it had run.
  t1=$(date +%s)
  rm -f "$S/lab/lab_ref_P.json"
  "$PY" -I -B "$SW/tools/lab_dump.py" "$SW/ref" "$SW/lab/lab_ref_P.json" > "$S/lab/lab_ref_P.log" 2>&1; st_ref=$?
  echo "lab_dump exit $st_ref" >> "$S/lab/lab_ref_P.log"
  bad=""; { [ "$st_ref" = 0 ] && [ -s "$S/lab/lab_ref_P.json" ]; } || bad="$bad lab_dump exit $st_ref"
  cmp -s "$S/lab/lab_ref_P.json" "$S/lab/lab_ref_A.json" || bad="$bad differs from commit A's reference dump"
  R G5-app-lab --level L5 --item "3.6.12, HA.8" --what "the lab: cf43fbb's dump made again" \
    --command "python -I -B tools/lab_dump.py S/ref lab/lab_ref_P.json; cmp lab/lab_ref_P.json lab/lab_ref_A.json (commit A's, from its S)" --cwd S \
    --expected "lab_dump.py exit 0; byte-identical to commit A's reference dump" --got "$( [ -z "$bad" ] && echo "exit 0; byte-identical" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/lab_ref_P.log
  t1=$(date +%s)
  rm -f "$S/lab/lab_cand_P.json"
  "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_cand_P.json" > "$S/lab/lab_cand_P.log" 2>&1; st_cand=$?
  echo "lab_dump exit $st_cand" >> "$S/lab/lab_cand_P.log"
  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_ref_P.json" "$SW/lab/lab_cand_P.json" > "$S/lab/compare_P_cand_ref.txt" 2>&1; st=$?
  echo "exit $st" >> "$S/lab/compare_P_cand_ref.txt"
  bad=""
  { [ "$st_ref" = 0 ] && [ -s "$S/lab/lab_ref_P.json" ]; } || bad="$bad cf43fbb's dump (lab_dump exit $st_ref)"
  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
  [ "$st" = 1 ] && grep -aq '^VERDICT: DIFFERENT' "$S/lab/compare_P_cand_ref.txt" || bad="$bad exit $st"
  cmp -s <(lf "$S/lab/compare_P_cand_ref.txt" | awk '/^VERDICT:/ { exit } f || /^  \// { f = 1; print }') \
         <(lf "$S/commitA/lab/compare_A_cand_ref.txt" | awk '/^VERDICT:/ { exit } f || /^  \// { f = 1; print }') || bad="$bad the other differences are not commit A's four"
  [ "$(lf "$S/lab/compare_P_cand_ref.txt" | head -1 | grep -oE '^[0-9]+ leaf values compared')" = "$(lf "$S/commitA/lab/compare_A_cand_ref.txt" | head -1 | grep -oE '^[0-9]+ leaf values compared')" ] \
    && lf "$S/lab/compare_P_cand_ref.txt" | head -1 | grep -aq '; 4 other differences$' || bad="$bad the summary line"
  R G5-app-lab --level L5 --item "3.6.12, HA.8, B12" --what "the lab's outputs against cf43fbb's" \
    --command "python -I -B tools/lab_dump.py candg lab/lab_cand_P.json; python -I -B -X utf8 tools/lab_compare.py lab/lab_ref_P.json lab/lab_cand_P.json > lab/compare_P_cand_ref.txt" --cwd S \
    --expected "both dumps lab_dump.py exit 0; VERDICT: DIFFERENT, exit 1, which is the expected outcome (HANDOFFS commit A item 8): as many leaf values as commit A's comparison; 4 other differences, exactly commit A's four with their values (/meta_en and /meta_ar concepts[4]/source/match 'm_air' -> 'm_air =', concepts[7]/range); no value differs. The counts of moved source lines and re-worded strings are P's own (P edits engine_env.py) and are not judged" \
    --got "$( [ -z "$bad" ] && echo "$(lf "$S/lab/compare_P_cand_ref.txt" | head -1 | cut -c1-160); the four are commit A's" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/compare_P_cand_ref.txt lab/lab_cand_P.log
  # G5.5 the lab's controls
  t1=$(date +%s)
  rm -f "$S/lab/lab_P_ctl_cturb_ulp.json"
  LAB_PERTURB=thermal.c_turb "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_P_ctl_cturb_ulp.json" > "$S/lab/lab_P_ctl_cturb_ulp.log" 2>&1; st_ulp=$?
  echo "lab_dump exit $st_ulp" >> "$S/lab/lab_P_ctl_cturb_ulp.log"
  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_cand_P.json" "$SW/lab/lab_P_ctl_cturb_ulp.json" > "$S/lab/compare_P_ctl_cturb_ulp.txt" 2>&1; st=$?
  bad=""; [ "$st" = 0 ] && grep -aq '; 0 other differences$' <(lf "$S/lab/compare_P_ctl_cturb_ulp.txt" | head -1) || bad=" exit $st"
  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
  { [ "$st_ulp" = 0 ] && [ -s "$S/lab/lab_P_ctl_cturb_ulp.json" ]; } || bad="$bad the control's dump (lab_dump exit $st_ulp)"
  R G5-app-lab --level control --item 3.6.12 --what "lab one ulp (a measured limit)" --environment LAB_PERTURB=thermal.c_turb \
    --command "LAB_PERTURB=thermal.c_turb python -I -B tools/lab_dump.py candg lab/lab_P_ctl_cturb_ulp.json; lab_compare.py lab/lab_cand_P.json it" --cwd S \
    --expected "both dumps lab_dump.py exit 0 (the candidate's and this one); IDENTICAL, exit 0, 0 other differences: the lab's 40-step sessions round one ulp away (a measured limit, as on commit A)" \
    --got "$(lf "$S/lab/compare_P_ctl_cturb_ulp.txt" | head -1 | cut -c1-160); exit $st; lab_dump exits $st_cand and $st_ulp" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence lab/compare_P_ctl_cturb_ulp.txt lab/lab_P_ctl_cturb_ulp.log
  t1=$(date +%s)
  rm -f "$S/lab/lab_P_ctl_cturb_1e-9.json"
  LAB_PERTURB=thermal.c_turb:1e-9 "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_P_ctl_cturb_1e-9.json" > "$S/lab/lab_P_ctl_cturb_1e-9.log" 2>&1; st_1e9=$?
  echo "lab_dump exit $st_1e9" >> "$S/lab/lab_P_ctl_cturb_1e-9.log"
  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_cand_P.json" "$SW/lab/lab_P_ctl_cturb_1e-9.json" > "$S/lab/compare_P_ctl_cturb_1e-9.txt" 2>&1; st=$?
  bad=""; [ "$st" = 1 ] && grep -aq '^VERDICT: DIFFERENT' "$S/lab/compare_P_ctl_cturb_1e-9.txt" || bad=" exit $st"
  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
  { [ "$st_1e9" = 0 ] && [ -s "$S/lab/lab_P_ctl_cturb_1e-9.json" ]; } || bad="$bad the control's dump (lab_dump exit $st_1e9)"
  R G5-app-lab --level control --item 3.6.12 --what "lab relative 1e-9" --environment LAB_PERTURB=thermal.c_turb:1e-9 \
    --command "LAB_PERTURB=thermal.c_turb:1e-9 python -I -B tools/lab_dump.py candg lab/lab_P_ctl_cturb_1e-9.json; lab_compare.py lab/lab_cand_P.json it" --cwd S \
    --expected "both dumps lab_dump.py exit 0 (the candidate's and this one); VERDICT: DIFFERENT, exit 1 (the control that must come out DIFFERENT; build step 1: 1212 other differences)" \
    --got "$(lf "$S/lab/compare_P_ctl_cturb_1e-9.txt" | head -1 | cut -c1-160); exit $st; lab_dump exits $st_cand and $st_1e9" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
    --evidence lab/compare_P_ctl_cturb_1e-9.txt lab/lab_P_ctl_cturb_1e-9.log
  say "G5 ends ($(secs_since "$t0") s)"
}

# ============================================================================= G6-agents
g6() {
  local t0 t1 bad got tag sec n c st fields
  say "G6 begins"; t0=$(date +%s)
  # (review fixes 3, 7 November 2026) every run starts from none of an earlier run's L6, L7 and d2 outputs (p_gate.sh
  # cert-recheck has copied the first run's evidence aside). run_l6.sh appends each job's exit to L6/_status.txt
  # and counts every line, so a re-run read "L6 done: 16 of 16 exit 0" and FAILed against "8 of 8"; the controls
  # append to L6/P_G6_ctl_status.txt, whose first-run "0 <name>" line passed a re-run control that crashed, with
  # l6_check.py reading the first run's dump; and check_l6.sh would compare the first run's dumps of an
  # l6_agents.py that crashed. The references S/L7/ref_eval.txt and S/F11/ref_d2.txt (build step 1's) stay.
  rm -f "$S/L6/_status.txt" "$S/L6/P_G6_ctl_status.txt" "$S"/L6/cand_*.npz "$S"/L6/ref_*.npz "$S"/L6/P_G6_ctl_*.npz \
        "$S"/cmp/L6_*.json "$S"/cmp/P_G6_L6_ctl_*_committed.json \
        "$S"/L7/cand_*.txt "$S"/L7/ref_eval_blind.txt "$S"/L7/ref_blind_*.txt "$S"/L7/make_meta*.txt "$S"/L7/l7_diff*.txt \
        "$S"/L7/l7_diff*.json "$S"/L7/l7_expect*.txt "$S"/F11/cand_d2*.txt "$S"/F11/d2_diff.*
  rm -rf "$S/L7/cand_model"
  # G6.1 L6 (8 processes) and G6.2's four controls after it
  t1=$(date +%s)
  bash "$S/tools/run_l6.sh" > "$S/L6/P_G6_run_l6.txt" 2>&1
  sec=$(secs_since "$t1")
  bash "$S/tools/check_l6.sh" > "$S/cmp/P_G6_L6_report.txt" 2>&1
  bad=""; got=$(lf "$S/L6/P_G6_run_l6.txt" | grep -a '^L6 done' | tail -1)
  [ "$got" = "L6 done: 8 of 8 exit 0" ] || bad=" ${got:-no L6 done line}"
  R G6-agents --level L6 --item 3.6.13 --what "L6 run: four X1 agents x twenty frozen episodes in both trees" \
    --command "bash tools/run_l6.sh (per tag and tree: python -I -B tools/l6_agents.py <candg|S/ref> <tag> L6/<cand|ref>_<tag>.npz)" --cwd S \
    --expected "L6 done: 8 of 8 exit 0" --got "${got:-none}" --verdict "$(verdict "$bad")" --seconds "$sec" --evidence L6/P_G6_run_l6.txt L6/_status.txt
  for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
    lf "$S/cmp/P_G6_L6_report.txt" | awk -v t="=================== $tag" '$0 == t { f = 1; next } /^===================/ { f = 0 } f' > "$S/cmp/P_G6_L6_$tag.txt"
    bad=""
    grep -aq '^VERDICT: BIT-IDENTICAL (' "$S/cmp/P_G6_L6_$tag.txt" || bad="$bad cand against ref"
    [ "$(grep -ac '^VERDICT: EQUAL TO THE COMMITTED FILES' "$S/cmp/P_G6_L6_$tag.txt")" = 2 ] || bad="$bad against the committed files"
    R G6-agents --level L6 --item 3.6.13 --what "L6 $tag: candidate against reference, and each tree against the committed files" \
      --command "bash tools/check_l6.sh > cmp/P_G6_L6_report.txt (for $tag: cmp.py L6/ref_$tag.npz L6/cand_$tag.npz --json cmp/L6_$tag.json; l6_check.py L6/<cand|ref>_$tag.npz $tag --json cmp/L6_<cand|ref>_${tag}_committed.json)" \
      --cwd S --expected "candidate against reference VERDICT: BIT-IDENTICAL; each tree against the committed files 'VERDICT: EQUAL TO THE COMMITTED FILES' (140 of 140 scores at full precision; 46 fields, all identical)" \
      --got "$( [ -z "$bad" ] && echo "$(grep -a '^VERDICT: BIT-IDENTICAL' "$S/cmp/P_G6_L6_$tag.txt" | head -1); both trees EQUAL TO THE COMMITTED FILES" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds 0 --evidence "cmp/P_G6_L6_$tag.txt" "cmp/L6_$tag.json" "cmp/L6_cand_${tag}_committed.json" "cmp/L6_ref_${tag}_committed.json"
  done
  t1=$(date +%s)
  for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do
    set -- $c
    ( HARNESS_PERTURB=$1 "$PY" -I -B "$SW/tools/l6_agents.py" "$RW" sighted_seed0 "$SW/L6/P_G6_ctl_$3.npz" "$2" > "$S/L6/P_G6_ctl_$3.log" 2>&1; echo "$? $3" >> "$S/L6/P_G6_ctl_status.txt" ) &
  done
  wait
  sec=$(secs_since "$t1")
  for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do
    set -- $c
    "$PY" -I -B "$SW/tools/l6_check.py" "$SW/L6/P_G6_ctl_$3.npz" sighted_seed0 --json "$SW/cmp/P_G6_L6_ctl_$3_committed.json" > "$S/L6/P_G6_ctl_$3_check.txt" 2>&1; st=$?
    bad=""
    grep -aq "^0 $3\$" "$S/L6/P_G6_ctl_status.txt" || bad="$bad the run's exit"
    [ "$st" != 0 ] && grep -aq '^VERDICT: NOT EQUAL' "$S/L6/P_G6_ctl_$3_check.txt" || bad="$bad l6_check exit $st"
    R G6-agents --level control --item 3.6.13 --what "L6 control: $1, sighted_seed0, $2 episodes" --environment "HARNESS_PERTURB=$1" \
      --command "HARNESS_PERTURB=$1 python -I -B tools/l6_agents.py candg sighted_seed0 L6/P_G6_ctl_$3.npz $2; python -I -B tools/l6_check.py L6/P_G6_ctl_$3.npz sighted_seed0 --json cmp/P_G6_L6_ctl_$3_committed.json" \
      --cwd S --expected "VERDICT: NOT EQUAL, l6_check exit 1 (the expected outcome; commit A: one ulp on the mass 23 of 35 scores equal, on c_turb 30 of 35; 1e-9 on the mass 2 of 14)" \
      --got "$( [ -z "$bad" ] && echo "$(lf "$S/L6/P_G6_ctl_$3_check.txt" | grep -aE '^(scores|per step|VERDICT)' | tr '\n' ' ' | cut -c1-220)" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds "$sec" --evidence "L6/P_G6_ctl_$3_check.txt" "L6/P_G6_ctl_$3.log" "cmp/P_G6_L6_ctl_$3_committed.json"
  done
  # G6.3 L7: make_meta for sighted_seed0 and blind_seed0 (CERT_PLAN_P.md G6.3), then four evaluate.py runs at once
  "$PY" -I -B "$SW/tools/make_meta.py" "$RW" "$X1_RUNS/sighted_seed0" "$SW/L7/cand_model/sighted_seed0" > "$S/L7/make_meta.txt" 2>&1; echo "exit $?" >> "$S/L7/make_meta.txt"
  "$PY" -I -B "$SW/tools/make_meta.py" "$RW" "$X1_RUNS/blind_seed0" "$SW/L7/cand_model/blind_seed0" > "$S/L7/make_meta_blind.txt" 2>&1; echo "exit $?" >> "$S/L7/make_meta_blind.txt"
  for f in make_meta make_meta_blind; do
    bad=""
    [ "$(exit_of "$S/L7/$f.txt")" = 0 ] || bad="$bad exit"
    grep -aq '^FATAL disagreements with the live tree: none' "$S/L7/$f.txt" || bad="$bad FATAL disagreements"
    grep -aq '^schema_problem: None' "$S/L7/$f.txt" || bad="$bad schema_problem"
    got=$(lf "$S/L7/$f.txt" | grep -a '^final.zip sha256' | head -1)
    [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($3 == $5) }')" = 1 ] || bad="$bad final.zip"
    R G6-agents --level L7 --item 3.6.14 --what "L7 make_meta.py: the scratch model directory for X1's $( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0)" \
      --command "python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/$( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0) L7/cand_model/$( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0) > L7/$f.txt" \
      --cwd S --expected "final.zip sha256 the same on both sides; 'FATAL disagreements with the live tree: none'; 'schema_problem: None' (the schema-4 block, through FP.for_arm$( [ $f = make_meta_blind ] && echo ": the blinded arm, preview_h_s None, row 117"))" \
      --got "$( [ -z "$bad" ] && echo "as expected; $(echo "$got" | cut -c1-40)..." || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds 0 --evidence "L7/$f.txt"
  done
  t1=$(date +%s)
  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --out "$SW/L7/cand_eval.txt" "$SW/L7/cand_model/sighted_seed0" > "$S/L7/cand_stdout.txt" 2>&1; \
    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/cand_exit.txt" ) &
  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --out "$SW/L7/cand_eval_blind.txt" "$SW/L7/cand_model/blind_seed0" > "$S/L7/cand_blind_stdout.txt" 2>&1; \
    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/cand_blind_exit.txt" ) &
  ( cd "$S/ref" && "$PY" -B evaluate.py --out "$SW/L7/ref_eval_blind.txt" "$X1_RUNS/blind_seed0" > "$S/L7/ref_blind_stdout.txt" 2>&1; \
    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/ref_blind_exit.txt" ) &
  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --protocol d2 --out "$SW/F11/cand_d2.txt" > "$S/F11/cand_d2_stdout.txt" 2>&1; \
    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/F11/cand_d2_exit.txt" ) &
  wait
  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/L7/ref_eval.txt" "$X1_RUNS/sighted_seed0" "$SW/L7/cand_eval.txt" "$SW/L7/cand_model/sighted_seed0" --json "$SW/L7/l7_diff.json" > "$S/L7/l7_diff.txt" 2>&1
  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/L7/ref_eval_blind.txt" "$X1_RUNS/blind_seed0" "$SW/L7/cand_eval_blind.txt" "$SW/L7/cand_model/blind_seed0" --json "$SW/L7/l7_diff_blind.json" > "$S/L7/l7_diff_blind.txt" 2>&1
  "$PY" -I -B "$SW/tools/l7_expect.py" --repo "$RW" "$SW/L7/cand_eval.txt" > "$S/L7/l7_expect.txt" 2>&1
  "$PY" -I -B "$SW/tools/l7_expect.py" --agent blind_seed0 --repo "$RW" "$SW/L7/cand_eval_blind.txt" > "$S/L7/l7_expect_blind.txt" 2>&1
  for tag in sighted_seed0 blind_seed0; do
    local sfx=""; [ $tag = blind_seed0 ] && sfx=_blind
    bad=""
    [ "$(exit_of "$S/L7/cand${sfx}_exit.txt")" = 0 ] || bad="$bad evaluate.py exit"
    grep -aq 'force-plant-mismatch was given' "$S/L7/cand${sfx}_stdout.txt" && bad="$bad a forced mismatch"
    grep -aq '^NO DIFFERENCE' "$S/L7/l7_diff${sfx}.txt" || bad="$bad l7_diff"
    grep -aq '^VERDICT: every row equals the committed raw scores' "$S/L7/l7_expect${sfx}.txt" || bad="$bad l7_expect"
    [ $tag = blind_seed0 ] && { [ "$(exit_of "$S/L7/ref_blind_exit.txt")" = 0 ] || bad="$bad cf43fbb's run exit"; }
    R G6-agents --level L7 --item 3.6.14 --what "L7 evaluate.py end to end: X1's $tag (scratch model) on the twenty frozen Phase D episodes" \
      --command "cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval${sfx}.txt L7/cand_model/$tag$( [ $tag = blind_seed0 ] && echo "; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0 (cf43fbb's own run: build step 1 scored sighted_seed0 only)"); python -I -B tools/l7_diff.py L7/ref_eval${sfx}.txt LIVE_REPO/runs/extremes_dt1/$tag L7/cand_eval${sfx}.txt L7/cand_model/$tag; python -I -B tools/l7_expect.py$( [ $tag = blind_seed0 ] && echo " --agent blind_seed0") --repo candg L7/cand_eval${sfx}.txt" \
      --cwd candg --expected "evaluate.py exit 0 with no --force-plant-mismatch (no --reward-knock: absent reads 'in' on phase-d, row 138 (1)); NO DIFFERENCE after the fingerprint block and the model path, against cf43fbb's report$( [ $tag = sighted_seed0 ] && echo " (build step 1's L7/ref_eval.txt)" || echo " (made here in S/ref)"); VERDICT: every row equals the committed raw scores" \
      --got "$( [ -z "$bad" ] && echo "exit 0; $(lf "$S/L7/l7_diff${sfx}.txt" | grep -a '^compared' | tail -1); NO DIFFERENCE; every row equals the committed raw scores" || echo "differs:$bad")" \
      --verdict "$(verdict "$bad")" --seconds "$(lf "$S/L7/cand${sfx}_exit.txt" | grep -oE '^[0-9]+ s$' | grep -oE '[0-9]+' || echo 0)" \
      --evidence "L7/cand${sfx}_stdout.txt" "L7/cand${sfx}_exit.txt" "L7/l7_diff${sfx}.txt" "L7/l7_expect${sfx}.txt"
  done
  # G6.4 evaluate.py --protocol d2 (finding 11), and X1's agent refused under d2
  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/F11/ref_d2.txt" NONE "$SW/F11/cand_d2.txt" NONE --json "$SW/F11/d2_diff.json" > "$S/F11/d2_diff.txt" 2>&1
  bad=""
  [ "$(exit_of "$S/F11/cand_d2_exit.txt")" = 0 ] || bad="$bad exit"
  grep -aq '^NO DIFFERENCE' "$S/F11/d2_diff.txt" || bad="$bad l7_diff"
  R G6-agents --level L5 --item 3.6.10 --what "finding 11's d2: evaluate.py --protocol d2, the three hand-written policies on the twenty frozen D2 episodes, against cf43fbb's" \
    --command "cd candg && python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; python -I -B tools/l7_diff.py F11/ref_d2.txt NONE F11/cand_d2.txt NONE --json F11/d2_diff.json" \
    --cwd candg --expected "exit 0; NO DIFFERENCE (commit A: 23 lines compared after stripping)" \
    --got "$( [ -z "$bad" ] && echo "exit 0; $(lf "$S/F11/d2_diff.txt" | grep -a '^compared' | tail -1); NO DIFFERENCE" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(lf "$S/F11/cand_d2_exit.txt" | grep -oE '^[0-9]+ s$' | grep -oE '[0-9]+' || echo 0)" \
    --evidence F11/cand_d2_stdout.txt F11/cand_d2_exit.txt F11/d2_diff.txt
  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --protocol d2 --out "$SW/F11/cand_d2_x1.txt" "$SW/L7/cand_model/sighted_seed0" ) > "$S/F11/cand_d2_x1_stdout.txt" 2>&1
  echo "exit $?" >> "$S/F11/cand_d2_x1_stdout.txt"
  fields=$(lf "$S/F11/cand_d2_x1_stdout.txt" | awk '/PLANT MISMATCH/ { f = 1; next } f && /^     [a-z_]+ +model / { print $1; next } f { exit }' | LC_ALL=C sort | tr '\n' ' ' | sed 's/ $//')
  bad=""
  [ "$(exit_of "$S/F11/cand_d2_x1_stdout.txt")" != 0 ] || bad="$bad exit 0"
  grep -aq 'PLANT MISMATCH' "$S/F11/cand_d2_x1_stdout.txt" && grep -aq '^REFUSING to evaluate' "$S/F11/cand_d2_x1_stdout.txt" || bad="$bad no refusal"
  [ "$fields" = "episodes_sha scenario" ] || bad="$bad the fields [$fields]"
  R G6-agents --level L5 --item 3.6.10 --what "finding 11's d2: X1's sighted_seed0 (L7's scratch model, schema 4) under --protocol d2 is refused" \
    --command "cd candg && python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2_x1.txt L7/cand_model/sighted_seed0" \
    --cwd candg --expected "PLANT MISMATCH on exactly scenario and episodes_sha (the protocol's two FATAL fields; the schema-4 block's other FATAL fields agree), REFUSING, a nonzero exit (the refusal is the expected outcome)" \
    --got "$( [ -z "$bad" ] && echo "PLANT MISMATCH on [$fields], REFUSING, exit $(exit_of "$S/F11/cand_d2_x1_stdout.txt")" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence F11/cand_d2_x1_stdout.txt
  say "G6 ends ($(secs_since "$t0") s)"
}

# ============================================================================= G7-suites
one() {   # run_suites.sh's own function (CERT_PLAN_A.md G7): one <label> <dir> <command...>
  local label=$1 dir=$2; shift 2
  local s; s=$(date +%s)
  ( cd "$dir" && "$@" ) > "$S/suites/$label.txt" 2>&1
  echo "$? $(( $(date +%s) - s )) $label" >> "$S/suites/_status.txt"
}
st_of() { awk -v l="$1" '$3 == l { e = $1; s = $2 } END { print e " " s }' "$S/suites/_status.txt"; }
suite_rec() {   # suite_rec LABEL ITEMS WHAT EXTRA_EXPECT EXTRA_BAD EXTRA_GOT [ARGS]: OK with its own Ran N, plus the extras
  local label=$1 items=$2 what=$3 xe=$4 xb=$5 xg=$6 args=${7:--v} e s bad=""
  read -r e s <<< "$(st_of "$label")"
  [ "${e:-x}" = 0 ] || bad="$bad exit ${e:-none}"
  ut_ok "$S/suites/$label.txt" || bad="$bad not OK"
  bad="$bad$xb"
  R G7-suites --level suite --item "$items" --what "$what" \
    --command "one $label candg python -B ${label#cand_}.py${args:+ $args}" --cwd candg \
    --expected "OK, with the run's own 'Ran N tests' (HP7.6: no count typed here)${xe:+; $xe}" \
    --got "$( [ -z "$bad" ] && echo "$(ut_line "$S/suites/$label.txt")${xg:+; $xg}" || echo "differs:$bad; $(ut_line "$S/suites/$label.txt")")" \
    --verdict "$(verdict "$bad")" --seconds "$(nz "$s")" --evidence "suites/$label.txt"
}
g7() {
  local t0 t1 bad got xb xg c TCL e s
  say "G7 begins"; t0=$(date +%s)
  # (review fixes 3) the one G7 output whose record depends on the file's existence: a re-run without the MY2021
  # and MY2023 lists must not record the first run's file (every other label is rewritten, and st_of reads the
  # last suites/_status.txt line of each label, which is this run's)
  rm -f "$S/suites/cand_test_epa_map_with_2021_2023.txt"
  # G7.1 the MY2021 and MY2023 Test Car Lists: commit A's S/tcl (lists and package zips) copied, then the plan's fetch
  t1=$(date +%s)
  [ -d "$COMMIT_A_S/tcl" ] && [ ! -e "$S/tcl" ] && cp -a "$COMMIT_A_S/tcl" "$S/tcl"
  ( cd "$REPO" && "$PY" -B fetch_engine_data.py --target "$SW/tcl" --group epa-test-car-list ) > "$S/suites/P_G7_fetch_tcl.txt" 2>&1
  echo "exit $?" >> "$S/suites/P_G7_fetch_tcl.txt"
  bad=""; [ "$(exit_of "$S/suites/P_G7_fetch_tcl.txt")" = 0 ] && grep -aq '^ALL VERIFIED' "$S/suites/P_G7_fetch_tcl.txt" || bad=" exit $(exit_of "$S/suites/P_G7_fetch_tcl.txt")"
  R G7-suites --level suite --item 3.6.15 --what "G7.1: the MY2021 and MY2023 Test Car Lists, verified in S/tcl" \
    --command "cp -a <commit A's S>/tcl S/tcl (its lists and the seven package zips, commit A's record 30); cd candg && python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list" \
    --cwd candg --expected "exit 0, ALL VERIFIED (every file against logs/epa/D3_AND_EPA_SOURCES.csv's sha256; the script fetches only what is missing and writes only under the target)" \
    --got "$( [ -z "$bad" ] && echo "exit 0, $(lf "$S/suites/P_G7_fetch_tcl.txt" | grep -a '^ALL VERIFIED' | cut -c1-100)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence suites/P_G7_fetch_tcl.txt
  # G7.2 the suites in the clone, in three waves
  one cand_test_wide_air "$REPO" "$PY" -B test_wide_air.py &
  one cand_test_epa_map "$REPO" "$PY" -B test_epa_map.py -v &
  if [ -d "$S/tcl/epa-test-car-list/MY2021" ] && [ -d "$S/tcl/epa-test-car-list/MY2023" ]; then
    TCL=$(cygpath -m "$S/tcl/epa-test-car-list")
    ( export GRAD_EXTRA_DATA="$TCL/MY2021;$TCL/MY2023"; one cand_test_epa_map_with_2021_2023 "$REPO" "$PY" -B test_epa_map.py -v ) &
  fi
  one cand_test_plant_guards "$REPO" "$PY" -B test_plant_guards.py -v &
  one cand_random_road "$REPO" "$PY" -B random_road.py &
  one cand_fingerprint "$REPO" "$PY" -B fingerprint.py --engine b58 &
  wait
  one cand_test_cars "$REPO" "$PY" -B test_cars.py -v &
  one cand_test_trainable "$REPO" "$PY" -B test_trainable.py -v &
  one cand_test_fuel_forms "$REPO" "$PY" -B test_fuel_forms.py -v &
  one cand_test_carried "$REPO" "$PY" -B test_carried.py -v &
  one cand_test_tit_cap "$REPO" "$PY" -B test_tit_cap.py -v &
  one cand_test_epa_plants "$REPO" "$PY" -B test_epa_plants.py -v &
  wait
  one cand_test_preview_horizon "$REPO" "$PY" -B test_preview_horizon.py -v      # 8 worker processes: alone
  suite_rec cand_test_wide_air "3.6.15, HP7.6" "test_wide_air.py" "" "" "" " "
  suite_rec cand_test_epa_map 3.6.15 "test_epa_map.py (the team's data folder)" "" "" ""
  if [ -f "$S/suites/cand_test_epa_map_with_2021_2023.txt" ]; then
    suite_rec cand_test_epa_map_with_2021_2023 3.6.15 "test_epa_map.py again, GRAD_EXTRA_DATA naming the MY2021 and MY2023 Test Car Lists" "" "" "" \
      "-v (GRAD_EXTRA_DATA=S/tcl/epa-test-car-list/MY2021;MY2023)"
  else
    say "NO RECORD: test_epa_map.py with the MY2021 and MY2023 lists: S/tcl lacks them"
  fi
  xb=""; cls_ok "$S/suites/cand_test_plant_guards.txt" GitDirtyPlantFiles || xb=" GitDirtyPlantFiles"
  [ -z "$(fpv "$S/out/P_G1_fp_cand.txt" git_dirty_plant_files)" ] || xb="$xb G1.0's git_dirty_plant_files"
  suite_rec cand_test_plant_guards "3.6.15, HA.10, HP7.6" "test_plant_guards.py" "HA.10: test_plant_guards.GitDirtyPlantFiles ok, and G1.0's git_dirty_plant_files empty" "$xb" "GitDirtyPlantFiles ok"
  read -r e s <<< "$(st_of cand_random_road)"
  bad=""; [ "$e" = 0 ] && grep -aq 'SELF-TEST PASSES' "$S/suites/cand_random_road.txt" || bad="$bad the self-test"
  diff <(lf "$S/suites/ref_random_road.txt" | grep -av road_sha) <(lf "$S/suites/cand_random_road.txt" | grep -av road_sha) > "$S/suites/P_G7_random_road_diff.txt" 2>&1 || bad="$bad a line beside road_sha differs from cf43fbb's"
  R G7-suites --level suite --item 3.6.15 --what "random_road.py self-test" --command "one cand_random_road candg python -B random_road.py; diff with suites/ref_random_road.txt, the road_sha line dropped" \
    --cwd candg --expected "SELF-TEST PASSES; road_sha be19b3d0bcef435d, the only line unlike cf43fbb's (e44153fd81eeaa1e)" \
    --got "$( [ -z "$bad" ] && echo "SELF-TEST PASSES; $(lf "$S/suites/cand_random_road.txt" | grep -aoE 'road_sha *:? *[0-9a-f]{16}' | head -1)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_random_road.txt suites/P_G7_random_road_diff.txt
  read -r e s <<< "$(st_of cand_fingerprint)"
  bad=""; [ "$e" = 0 ] && same "$S/suites/cand_fingerprint.txt" "$S/out/P_G1_fp_cand.txt" || bad=" differs from G1.0's"
  R G7-suites --level suite --item "3.6.15, HA.10" --what "fingerprint.py --engine b58" --command "one cand_fingerprint candg python -B fingerprint.py --engine b58" \
    --cwd candg --expected "exit 0; the block G1.0 printed (out/P_G1_fp_cand.txt), line for line" --got "$( [ -z "$bad" ] && echo "the same block" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_fingerprint.txt
  xb=""; cls_ok "$S/suites/cand_test_fuel_forms.txt" EngineSha || xb=" EngineSha"
  got=$(lf "$S/suites/cand_test_fuel_forms.txt" | grep -aoE 'engine_sha [0-9a-f]{16}; without \[[^]]*\]: [0-9a-f]{16}' | head -1)
  [ "$(echo "$got" | awk '{ print $2 }' | tr -d ';')" = "$B58_ENGINE_SHA" ] || xb="$xb engine_sha"
  [ "$(echo "$got" | awk '{ print $NF }')" = "$A_B11" ] || xb="$xb the build-step-1 key set's hash"
  suite_rec cand_test_fuel_forms "3.6.15, HP7.1, B11, HP7.6" "test_fuel_forms.py (EngineSha: amendment B11)" \
    "B11: EngineSha ok; its line 'engine_sha $B58_ENGINE_SHA; without [...]: $A_B11' (G1.0's engine_sha; commit A's certificate's over_build_step_1_keys, read from RV's results/B58_IDENTITY.json)" "$xb" \
    "$(echo "$got" | sed -E 's/without \[[^]]*\]/without [...]/')"
  suite_rec cand_test_cars "3.6.15, HP7.1, HP7.6" "test_cars.py" "" "" ""
  suite_rec cand_test_carried "3.6.15, HP7.1, HP7.6" "test_carried.py (run_suites.sh quick does not run it)" "" "" ""
  xb=""; for c in Help B58 RecordsAbsent SummaryDrop BackendDrop RealTree; do cls_ok "$S/suites/cand_test_trainable.txt" "$c" || xb="$xb $c"; done
  suite_rec cand_test_trainable "3.6.15, HP7.1, B8, HP7.6" "test_trainable.py (B8: the refusals and their controls, SummaryDrop the literal case)" \
    "B8: Help, B58, RecordsAbsent, SummaryDrop, BackendDrop and RealTree each ok" "$xb" \
    "$(lf "$S/suites/cand_test_trainable.txt" | grep -aE 'engines\.trainable\(\)' | head -1 | cut -c1-120)"
  xb=""; cls_ok "$S/suites/cand_test_preview_horizon.txt" BlindBitForBit || xb=" BlindBitForBit"
  suite_rec cand_test_preview_horizon "R138-4 BlindBitForBit, 3.6.15" "test_preview_horizon.py, whole (BlindBitForBit; row 138 (4))" \
    "BlindBitForBit ok" "$xb" "BlindBitForBit ok"
  suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
  suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
  # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
  ( cd "$REPO" && {
      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
      echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
      echo "== HA.6"; grep -n -i "scipy" requirements.txt
      echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
    } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
  bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
  R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
  bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
  echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
  R G7-suites --level docs --item HA.5 --what "README.md and full_run.py name the four test files" --command "grep -c <t>.py candg/README.md candg/full_run.py, t in test_fuel_forms test_cars test_carried test_trainable" \
    --cwd candg --expected "each of the four named at least once in each document (README states no count for test_trainable.py; CERT_PLAN_P.md G7.4)" \
    --got "$( [ -z "$bad" ] && echo "$(echo "$got" | tr '\n' ';')" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
  bad=""; got=$(awk '/^== HA.6/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
  echo "$got" | grep -qE 'scipy==' || bad=" no pin"; echo "$got" | grep -qi 'imported by nothing' && bad="$bad the old comment"
  R G7-suites --level docs --item HA.6 --what "scipy pinned in requirements.txt" --command "grep -n -i scipy candg/requirements.txt" --cwd candg \
    --expected "a scipy== pin and no 'imported by nothing'" --got "$( [ -z "$bad" ] && echo "$(echo "$got" | grep 'scipy==' | head -1)" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
  bad=""; grep -q '^line 433: 0$' "$S/suites/P_G7_docs_checks.txt" || bad=" a line number cited"; grep -qE '^fuel properties: [1-9]' "$S/suites/P_G7_docs_checks.txt" || bad="$bad no row text"
  R G7-suites --level docs --item HA.11 --what "engine_specs/b58.toml cites REFERENCES.md's row by its text" --command "grep -c 'line 433' and 'fuel properties' candg/engine_specs/b58.toml" \
    --cwd candg --expected "no 'line 433'; the row cited by its text ('fuel properties')" --got "$( [ -z "$bad" ] && echo "as expected" || echo "differs:$bad")" \
    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
  # G7.5 verify_docs.py and drift_test (run_drift.sh) in the clone
  one cand_verify_docs "$REPO" "$PY" -B verify_docs.py
  read -r e s <<< "$(st_of cand_verify_docs)"
  bad=""; got=$(lf "$S/suites/cand_verify_docs.txt" | grep -aE '^All [0-9]+ checks pass' | tail -1); [ "$e" = 0 ] && [ -n "$got" ] || bad=" exit $e"
  R G7-suites --level docs --item 3.6.18 --what "verify_docs.py in the clone (P's candidate, before the sweep's document edits)" \
    --command "one cand_verify_docs candg python -B verify_docs.py" --cwd candg \
    --expected "exit 0, 'All N checks pass (M figure mentions scanned in the documents).' (the run's own numbers; p_gate.sh pre ran it on the same tree first: a failure there is known before this run)" \
    --got "$( [ -z "$bad" ] && echo "$got" || echo "differs:$bad; $(lf "$S/suites/cand_verify_docs.txt" | tail -2 | tr '\n' ' ' | cut -c1-160)")" \
    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_verify_docs.txt
  t1=$(date +%s)
  bash "$S/tools/run_drift.sh" > "$S/suites/P_G7_run_drift.txt" 2>&1
  bad=""; got=$(lf "$S/suites/drift_test.txt" | grep -aE '^[0-9]+ of [0-9]+ drifts CAUGHT \(all parts\)' | tail -1)
  [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($1 == $3 && $1 > 0) }')" = 1 ] || bad=" ${got:-no verdict line}"
  [ "$(grep -h '^exit' "$S"/suites/drift_part*.txt | grep -vc '^exit 0 ')" = 0 ] || bad="$bad a part's exit"
  R G7-suites --level docs --item 3.6.18 --what "run_drift.sh: drift_test.py in six parts, each with drift_test's own control" \
    --command "bash tools/run_drift.sh (CAND = candg)" --cwd candg --expected "every part exit 0 (each runs drift_test's own control first); 'N of N drifts CAUGHT (all parts)' (commit A: 18 of 18)" \
    --got "$( [ -z "$bad" ] && echo "$got; $(cat "$S/suites/drift_test_exit.txt" | cut -c1-120)" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
    --seconds "$(secs_since "$t1")" --evidence suites/drift_test.txt suites/drift_test_exit.txt
  say "G7 ends ($(secs_since "$t0") s)"
}

# ============================================================================= run
for G in $RUN_GROUPS; do      # one group at a time, each to its end (decisions/cert_groups.txt)
  T=$(date +%s); "$G"; say "$G took $(secs_since "$T") s"
done
# the clone and the live repository's runs untouched: the clone clean at P_CAND
if [ "$(git -C "$REPO" rev-parse HEAD)" != "$P_CAND" ] || [ -n "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ]; then
  say "REFUSED: the clone is not clean at P_CAND after the groups"; BAD=1
fi
say "END cert_driver_P.sh after $(secs_since "$DRIVER_T0") s; records: $(cat "$S"/cert_results/*.json | grep -c '"verdict": "PASS"') PASS, $(cat "$S"/cert_results/*.json | grep -c '"verdict": "FAIL"') FAIL; driver refusals: $( [ "$BAD" = 0 ] && echo none || echo "at least one (the REFUSED lines above)")"
[ "$BAD" = 0 ] || exit 3
exit 0
