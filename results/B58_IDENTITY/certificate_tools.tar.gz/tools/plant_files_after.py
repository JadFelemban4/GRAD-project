"""plant_files_after.py -- finding 4 after the fix: each plant's plant_sha hashes its own specs.

    python -I plant_files_after.py <tree COPY>

The reviewer's demonstration (plant_files_demo.py), run where fingerprint.py can read the specs:
two extra plants are registered in this process only, their specs written into the COPY's
engine_specs/ (copies of b58.toml under another id, one with c_turb 9000) and removed after.
Before the fix all three plants had one plant_sha; now the B58's is its own, the two others
differ from it and from each other, and an edit to another engine's spec leaves the B58's alone.
"""
import os
import sys

tree = os.path.abspath(sys.argv[1])
os.chdir(tree)
sys.path.insert(0, tree)
import engines            # noqa: E402
import fingerprint as FP  # noqa: E402

made = []
try:
    with open(os.path.join(engines.SPECS, "b58.toml"), encoding="utf-8") as fh:
        spec = fh.read()
    for tag, text in (("other", spec.replace('id = "b58b30o1"', 'id = "other_engine"')),
                      ("other2", spec.replace('id = "b58b30o1"', 'id = "other_engine2"')
                       .replace("c_turb = { value = 6000.0", "c_turb = { value = 9000.0"))):
        p = os.path.join(engines.SPECS, tag + ".toml")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(text)
        made.append(p)
    engines.PLANTS.update(other=("other", "a90_supra"), other2=("other2", "a90_supra"))
    b58_before = FP.plant_fingerprint(plant=engines.get("b58"), backend=FP.BACKEND_CYCLE)["plant_sha"]
    rows = []
    for name in ("b58", "other", "other2"):
        fp = FP.plant_fingerprint(plant=engines.get(name), backend=FP.BACKEND_CYCLE)
        rows.append((name, fp["engine"], fp["plant_sha"], fp["engine_sha"], FP.plant_files(name)[-2:]))
    for r in rows:
        print(f"  {r[0]:7s} engine {r[1]:34s} plant_sha {r[2]}  engine_sha {r[3]}  specs {r[4]}")
    print("plant_sha equal for all three plants:", len({r[2] for r in rows}) == 1)
    # an edit to another engine's spec value: its plant_sha moves, the B58's does not
    with open(made[0], encoding="utf-8") as fh:
        t = fh.read()
    with open(made[0], "w", encoding="utf-8") as fh:
        fh.write(t.replace("c_turb = { value = 6000.0", "c_turb = { value = 6500.0"))
    engines._BUILT.pop("other", None)
    other_after = FP.plant_fingerprint(plant=engines.get("other"), backend=FP.BACKEND_CYCLE)["plant_sha"]
    b58_after = FP.plant_fingerprint(plant=engines.get("b58"), backend=FP.BACKEND_CYCLE)["plant_sha"]
    print(f"other's spec edited (c_turb 6000 -> 6500): other's plant_sha {rows[1][2]} -> {other_after}; "
          f"the B58's {b58_before} -> {b58_after}")
finally:
    for p in made:
        os.remove(p)
    print("spec copies removed:", not any(os.path.exists(p) for p in made))
