"""spec_hash_form.py -- fingerprint._code_only picks its rule by "does it parse as Python",
not by "is it a spec". The same spec written as TOML tables (which engines.read_spec
accepts) parses as Python, so it is hashed as code: a SOURCE edit then moves plant_sha.

    python spec_hash_form.py <tree>
"""
import os
import sys
import tempfile
import tomllib

tree = sys.argv[1]
sys.path.insert(0, tree)
import engines          # noqa: E402
import fingerprint as FP  # noqa: E402

inline = ('id = "x"\n'
          '[geometry]\n'
          'bore = { value = 0.0820, unit = "m", label = "PUBLISHED", source = "Toyota GTP-009045 p. 1" }\n')
table = ('id = "x"\n'
         '[geometry.bore]\n'
         'value = 0.0820\nunit = "m"\nlabel = "PUBLISHED"\nsource = "Toyota GTP-009045 p. 1"\n')
print("same TOML document:", tomllib.loads(inline) == tomllib.loads(table))
with tempfile.TemporaryDirectory() as tmp:
    for name, text in (("inline", inline), ("table", table)):
        with open(os.path.join(tmp, name + ".toml"), "w", encoding="utf-8") as fh:
            fh.write(text)
    engines.SPECS = tmp                        # this process only
    print("read_spec(inline) ->", engines.read_spec("inline")["geometry"])
    print("read_spec(table)  ->", engines.read_spec("table")["geometry"])
for name, text in (("inline", inline), ("table", table)):
    reworded = text.replace("Toyota GTP-009045 p. 1", "BMW 3 Series 05/2015 p. 7")
    renumbered = text.replace("0.0820", "0.0821")
    print(f"{name:6s}: source edit moves the hash: {FP._code_only(reworded) != FP._code_only(text)};"
          f" value edit moves it: {FP._code_only(renumbered) != FP._code_only(text)};"
          f" hashed as {'values' if FP._code_only(text).startswith('{') else 'Python code'}")
