"""make_archive.py -- the certificate's tools and its small evidence files, as one sha-checked archive.

    python -I make_archive.py <out.tar.gz>

Finding 12 of the review of build step 1 (21 October 2026): the certificate's harness,
its comparison tools and its evidence lived only in a session's scratch folder, so the
certificate could not be reproduced from anything that lasts. This packs S (the folder
above tools/) into one gzip-compressed tar for results/B58_IDENTITY/: every tool, and
every evidence file that is text or small JSON. Left out, and re-made by the commands
in reproduce.json: the dumps (.npz), models and zips, the scratch trees (ref, cand,
candd, before), the downloaded Test Car Lists (tcl/) and the lab's 0.8 MB value dumps.
archive_members.txt, inside the archive, lists every member with its size and sha256.
Deterministic: members sorted, mtimes and owners fixed, so the same files give the
same bytes.
"""
import gzip
import hashlib
import io
import os
import sys
import tarfile

S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.abspath(sys.argv[1])
SKIP_DIRS = {"ref", "cand", "candd", "before", "tcl", "cand_model", "__pycache__", "backup"}
SKIP_EXT = (".npz", ".zip", ".tar", ".gz", ".pth", ".pkl", ".html", ".part")
MAX_BYTES = 400_000
TEXT_EXT = (".py", ".sh", ".txt", ".json", ".log", ".md", ".csv")


def members():
    out = []
    for root, dirs, files in os.walk(S):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        rel_root = os.path.relpath(root, S)
        if rel_root.split(os.sep)[0] in SKIP_DIRS:
            continue
        for f in sorted(files):
            p = os.path.join(root, f)
            rel = os.path.relpath(p, S).replace(os.sep, "/")
            if f.endswith(SKIP_EXT) or not f.endswith(TEXT_EXT):
                continue
            if rel.startswith("lab/lab_") and f.endswith(".json"):
                continue                       # the lab's value dumps: re-made by lab_dump.py
            if rel == "archive_members.txt":
                continue                       # the previous run's listing: this run writes its own below
            if os.path.getsize(p) > MAX_BYTES:
                continue
            out.append((rel, p))
    return sorted(out)


rows, blobs = [], []
for rel, p in members():
    with open(p, "rb") as fh:
        data = fh.read()
    rows.append(f"{hashlib.sha256(data).hexdigest()}  {len(data):>9}  {rel}")
    blobs.append((rel, data))
listing = ("\n".join(rows) + "\n").encode("utf-8")
blobs.append(("archive_members.txt", listing))
with open(os.path.join(S, "archive_members.txt"), "wb") as fh:
    fh.write(listing)

buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode="w", format=tarfile.PAX_FORMAT) as tar:
    for rel, data in sorted(blobs):
        info = tarfile.TarInfo(rel)
        info.size, info.mtime, info.mode = len(data), 1792540800, 0o644      # 21 Oct 2026 00:00 UTC
        info.uid = info.gid = 0
        info.uname = info.gname = ""
        tar.addfile(info, io.BytesIO(data))
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "wb") as fh:
    with gzip.GzipFile(filename="", mode="wb", fileobj=fh, mtime=0, compresslevel=9) as gz:
        gz.write(buf.getvalue())
sha = hashlib.sha256(open(OUT, "rb").read()).hexdigest()
print(f"{len(blobs)} members, {os.path.getsize(OUT):,} bytes, sha256 {sha} -> {OUT}")
