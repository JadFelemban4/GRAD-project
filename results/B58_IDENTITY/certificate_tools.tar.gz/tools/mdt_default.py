"""mdt_default.py -- measure_deliverable_torque(plant=...) with no rpms measures the B58
table's grid (1000-6600 rpm) whatever the plant's own speed range is.

    python mdt_default.py <tree>
"""
import inspect
import os
import sys
from dataclasses import replace

tree = sys.argv[1]
os.chdir(tree)
sys.path.insert(0, tree)
import engine_env as E  # noqa: E402
import engines          # noqa: E402

print("signature:", inspect.signature(E.measure_deliverable_torque))
src = inspect.getsource(E.measure_deliverable_torque)
print("default grid line:", next(l.strip() for l in src.splitlines() if "range(1000" in l))
b = engines.get("b58")
v = replace(b, car=replace(b.car, rpm_min=1200.0, rpm_max=5000.0))      # a car revving to 5000
print("variant car rpm range:", v.car.rpm_min, "-", v.car.rpm_max)
t = E.measure_deliverable_torque(plant=v, settle=4)                    # settle shortened: only the grid is shown
rpms = [r for r, _ in t]
print(f"measured at {len(rpms)} speeds, {rpms[0]}-{rpms[-1]} rpm; above the car's rpm_max: "
      f"{[r for r in rpms if r > v.car.rpm_max][:4]} ...")
print("stored B58 table spans:", b.car.deliverable_torque[0][0], "-", b.car.deliverable_torque[-1][0],
      "rpm; the Supra's rpm_max is", b.car.rpm_max)
