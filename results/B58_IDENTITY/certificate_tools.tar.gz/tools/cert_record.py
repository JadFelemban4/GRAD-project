"""cert_record.py -- append one check to a run group's record file, cert_results/<group>.json.

    python -I cert_record.py <group> --level L1 --item 3.6.1 --command "..." --cwd REPO \
        --expected "..." --got "..." --verdict PASS --seconds 1970 \
        [--evidence <file> ...] [--what "..."] [--environment "..."] [--difference "..."]

Build step 2, commit A (22 October 2026; recorded in TOOL_EDITS.md). Every check of commit A's
certificate run is one record {level, item, command, cwd, expected, got, verdict, seconds,
evidence_files}; what (a short name for the page), environment (a control's variables) and
difference (an expected difference the page lists in its section 5) are optional and carried
through. make_cert.py --config reads every cert_results/*.json. Several items are written
"3.6.11, HA.3". An evidence path is absolute or relative to S.

The verdict must be PASS or FAIL: a check that did not run is not recorded as one (say so in
the group's report instead). The file is rewritten whole through a temporary file and
os.replace, so a reader never sees half a list; one group writes one file, so two groups never
race on a file.

Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): an optional
--rechecks "<group>.json record <n>" is carried into the record as "rechecks", the field
make_cert.py's _rechecks() (commit A's final step) pairs with an earlier FAIL of the same file.
Commit A wrote that field by editing its records afterwards; P's route after a FAIL (a re-check
record, written by hand once the cause is read) writes it here. Without --rechecks a record is
what it was.
"""
import argparse
import json
import os
import sys

S = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ap = argparse.ArgumentParser()
ap.add_argument("group")
for k in ("level", "item", "command", "cwd", "expected", "got"):
    ap.add_argument(f"--{k}", required=True)
ap.add_argument("--verdict", required=True, choices=("PASS", "FAIL"))
ap.add_argument("--seconds", required=True, type=float)
ap.add_argument("--evidence", nargs="*", default=[])
ap.add_argument("--what")
ap.add_argument("--environment")
ap.add_argument("--difference")
ap.add_argument("--rechecks")                  # (commit P) "<group>.json record <n>": the FAIL this record re-checks
a = ap.parse_args()

if not a.group.replace("-", "").replace("_", "").isalnum():
    raise SystemExit(f"group {a.group!r}: letters, digits, '-' and '_' only (it names the file)")
rec = dict(level=a.level, item=a.item, command=a.command, cwd=a.cwd, expected=a.expected, got=a.got,
           verdict=a.verdict, seconds=round(a.seconds, 1),
           evidence_files=[e.replace("\\", "/") for e in a.evidence])
for k in ("what", "environment", "difference", "rechecks"):
    if getattr(a, k):
        rec[k] = getattr(a, k)
missing = [e for e in rec["evidence_files"]
           if not os.path.exists(e if os.path.isabs(e) else os.path.join(S, *e.split("/")))]
path = os.path.join(S, "cert_results", f"{a.group}.json")
os.makedirs(os.path.dirname(path), exist_ok=True)
rows = []
if os.path.exists(path):
    with open(path, encoding="utf-8") as fh:
        rows = json.load(fh)
    if not isinstance(rows, list):
        raise SystemExit(f"{path} is not a list of records")
rows.append(rec)
tmp = path + ".tmp"
with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
    json.dump(rows, fh, indent=1, ensure_ascii=False)
    fh.write("\n")
os.replace(tmp, path)
print(f"{a.group}: record {len(rows)} ({a.level}, {a.item}, {a.verdict}) -> {path}")
if missing:
    print(f"WARNING: evidence not found (make_cert.py will write it as MISSING): {missing}", file=sys.stderr)
