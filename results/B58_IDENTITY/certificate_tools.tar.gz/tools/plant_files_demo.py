"""plant_files_demo.py -- fingerprint.PLANT_FILES names the B58's two spec files, so plant_sha
hashes them whatever plant is passed. A second plant registered in this process only (its spec
a copy of b58.toml under another id, in a temporary folder) gets the B58's plant_sha, and a
value edit to ITS spec moves engine_sha but not plant_sha.

    python plant_files_demo.py <tree copy>
"""
import os
import shutil
import sys
import tempfile

tree = sys.argv[1]
os.chdir(tree)
sys.path.insert(0, tree)
import engines            # noqa: E402
import fingerprint as FP  # noqa: E402

print("PLANT_FILES:", FP.PLANT_FILES)
tmp = tempfile.mkdtemp(prefix="pf_demo_")
try:
    for name in ("b58", "a90_supra"):
        shutil.copy(os.path.join(engines.SPECS, name + ".toml"), os.path.join(tmp, name + ".toml"))
    with open(os.path.join(tmp, "b58.toml"), encoding="utf-8") as fh:
        spec = fh.read()
    for tag, text in (("other", spec.replace('id = "b58b30o1"', 'id = "other_engine"')),
                      ("other2", spec.replace('id = "b58b30o1"', 'id = "other_engine"')
                       .replace("c_turb = { value = 6000.0", "c_turb = { value = 9000.0"))):
        with open(os.path.join(tmp, tag + ".toml"), "w", encoding="utf-8") as fh:
            fh.write(text)
    engines.SPECS = tmp                               # this process only
    engines.PLANTS.update(other=("other", "a90_supra"), other2=("other2", "a90_supra"))
    rows = []
    for name in ("b58", "other", "other2"):
        fp = FP.plant_fingerprint(plant=engines.get(name))
        rows.append((name, fp["engine"], fp["plant_sha"], fp["engine_sha"]))
    for r in rows:
        print(f"  {r[0]:7s} engine {r[1]:32s} plant_sha {r[2]}  engine_sha {r[3]}")
    print("plant_sha equal for all three plants:", len({r[2] for r in rows}) == 1)
finally:
    shutil.rmtree(tmp, ignore_errors=True)
