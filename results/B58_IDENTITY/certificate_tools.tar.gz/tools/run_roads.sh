#!/usr/bin/env bash
# run_roads.sh -- L5: check_roads.py --road extremes, then --road wideair, in both trees at once
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
for road in extremes wideair; do
  bash $S/tools/run_writer.sh cand roads_$road results/training_roads_$road.json check_roads.py --road $road &
  bash $S/tools/run_writer.sh ref roads_$road results/training_roads_$road.json check_roads.py --road $road &
  wait
done
cd "${CAND:-/c/Users/badcl/Desktop/GRAD-project}" && git status --porcelain results/ && echo "(git status of results/ above; empty means restored)"
