"""scan_defaults.py -- every function in the tree that takes a plant record (engine,
plant, cal, car, p, veh, env) and gives some OTHER parameter a literal default.

    python scan_defaults.py <repo>
"""
import ast
import os
import subprocess
import sys

repo = sys.argv[1]
names = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard", "*.py"],
                       cwd=repo, capture_output=True, text=True, check=True).stdout.splitlines()
REC = set(sys.argv[2].split(",")) if len(sys.argv) > 2 else {"engine", "plant", "cal", "car"}
rows = []
for rel in sorted(names):
    p = os.path.join(repo, rel)
    if not os.path.isfile(p):
        continue
    try:
        tree = ast.parse(open(p, encoding="utf-8").read())
    except SyntaxError:
        continue
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        a = node.args
        allp = [x.arg for x in a.posonlyargs + a.args + a.kwonlyargs]
        if not REC & set(allp):
            continue
        pos = a.posonlyargs + a.args
        d = dict(zip([x.arg for x in pos][len(pos) - len(a.defaults):], a.defaults))
        d.update({x.arg: dd for x, dd in zip(a.kwonlyargs, a.kw_defaults) if dd is not None})
        lits = {k: ast.unparse(v) for k, v in d.items()}
        if lits:
            rows.append(f"{rel}:{node.lineno} {node.name}({', '.join(sorted(REC & set(allp)))}) "
                        + "; ".join(f"{k}={v}" for k, v in lits.items()))
print("\n".join(rows))
print(len(rows), "functions")
