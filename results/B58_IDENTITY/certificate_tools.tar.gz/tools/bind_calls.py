"""bind_calls.py -- every call in the tree whose callee resolves to a function or class of a
repository module, bound against that callee's LIVE signature with placeholders.

    python bind_calls.py <repo> [--selftest]

A call that does not bind (too many positional arguments, an unknown keyword such as geo= or
octane=, a missing required argument) is a caller left on an old signature. Calls that forward
*args or **kwargs are skipped (the binding cannot be known). Stronger than an "is the record
keyword present" scan: it checks the whole argument list. Read-only.
"""
import ast
import importlib
import inspect
import os
import subprocess
import sys

repo = sys.argv[1]
os.chdir(repo)
sys.path.insert(0, repo)
sys.path.insert(1, os.path.join(repo, "Explanatory Simulation"))
os.environ.setdefault("OMP_NUM_THREADS", "1")

FROZEN = {"drive_c_analysis.py", "drive_c_rule_numbers.py", "drive_c_check.py", "test_drive_c_analysis.py"}
# never imported: they run work (or write files) at import
SIDE_EFFECTS = {"prove_buffer", "presentation.dump_sweeps", "presentation.dump_traces",
                "app.verification.review-2026-10-09-repro"}

files = [f for f in subprocess.run(["git", "-C", "C:/Users/badcl/Desktop/GRAD-project", "ls-files", "--cached", "--others", "--exclude-standard", "*.py"],
                                   capture_output=True, text=True, check=True).stdout.splitlines()
         if f and f not in FROZEN]
root_mods = {f[:-3] for f in files if "/" not in f}
app_mods = {"app." + f[4:-3] for f in files if f.startswith("app/") and f.count("/") == 1}
lab_mods = {"backend." + os.path.basename(f)[:-3] for f in files if f.startswith("Explanatory Simulation/backend/")}
KNOWN = root_mods | app_mods | lab_mods

_cache = {}


def load(name):
    if name in SIDE_EFFECTS or name not in KNOWN:
        return None
    if name not in _cache:
        try:
            _cache[name] = importlib.import_module(name)
        except BaseException as exc:          # noqa: BLE001 -- a script may SystemExit
            _cache[name] = None
            print(f"  (could not import {name}: {type(exc).__name__}: {exc})")
    return _cache[name]


def module_of(rel):
    if "/" not in rel:
        return rel[:-3]
    if rel.startswith("app/") and rel.count("/") == 1:
        return "app." + rel[4:-3]
    if rel.startswith("Explanatory Simulation/backend/"):
        return "backend." + os.path.basename(rel)[:-3]
    return None


def resolve_from(node, rel):
    """The module an ImportFrom names, relative imports included."""
    if node.level == 0:
        return node.module
    pkg = module_of(rel)
    if pkg is None:
        return None
    parts = pkg.split(".")[:-node.level]
    return ".".join(parts + ([node.module] if node.module else []))


def scan(rel, src):
    tree = ast.parse(src, filename=rel)
    mods, names = {}, {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name in KNOWN:
                    mods[a.asname or a.name] = a.name
                elif a.asname is None and a.name.split(".")[0] in ("app",) and a.name in KNOWN:
                    mods[a.name] = a.name
        elif isinstance(node, ast.ImportFrom):
            m = resolve_from(node, rel)
            if m is None:
                continue
            for a in node.names:
                if a.name == "*":
                    continue
                full = f"{m}.{a.name}"
                if full in KNOWN:                       # from app import estimator
                    mods[a.asname or a.name] = full
                elif m in KNOWN:
                    names[a.asname or a.name] = (m, a.name)
    me = module_of(rel)
    own = {}
    if me in KNOWN and me not in SIDE_EFFECTS:
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                own[node.name] = (me, node.name)
    # names rebound locally (parameters, assignments) are not the imported object
    local_rebinds = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            a = node.args
            for p in a.posonlyargs + a.args + a.kwonlyargs:
                local_rebinds.add(p.arg)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and not isinstance(node.value, ast.Attribute):
                    local_rebinds.add(t.id)
    out = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        f = node.func
        target = None
        if isinstance(f, ast.Name):
            if f.id in names and f.id not in local_rebinds:
                target = names[f.id]
            elif f.id in own:
                target = own[f.id]
        elif isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in mods \
                and f.value.id not in local_rebinds:
            target = (mods[f.value.id], f.attr)
        if target is None:
            continue
        if any(isinstance(a, ast.Starred) for a in node.args) or any(k.arg is None for k in node.keywords):
            continue
        mod = load(target[0])
        if mod is None:
            continue
        obj = getattr(mod, target[1], None)
        if obj is None:
            out.append((rel, node.lineno, f"{target[0]}.{target[1]}", "does not exist"))
            continue
        if not callable(obj):
            continue
        try:
            sig = inspect.signature(obj)
        except (TypeError, ValueError):
            continue
        try:
            sig.bind(*[object()] * len(node.args), **{k.arg: object() for k in node.keywords})
        except TypeError as exc:
            out.append((rel, node.lineno, f"{target[0]}.{target[1]}", str(exc)))
    return out


if "--selftest" in sys.argv:
    bad = ("import plant\nfrom engine_env import SupervisoryTunerEnv, BaselineECU, damage_rate\n"
           "plant.predict(1, 2, 3, 4, 5, 6, geo=None, engine=e)\n"
           "SupervisoryTunerEnv(c, None, 1.0, plant=p)\n"
           "BaselineECU(True, cal=c)\n"
           "damage_rate(1, 2, 3, 4, cal=c)\n"
           "plant.charge_temperature(300.0, engine=e)\n"
           "plant.run_cycle(op, engine=e)\n")              # the last one binds
    hits = scan("selftest_injected.py", bad)
    for h in hits:
        print("  SELFTEST", h)
    assert [h[1] for h in hits] == [3, 4, 5, 6, 7], hits
    print("selftest: 5 of 5 bad calls flagged, the good one not")
    sys.exit(0)

hits = []
for rel in files:
    try:
        src = open(rel, encoding="utf-8").read()
        hits += scan(rel, src)
    except SyntaxError as exc:
        print(f"  (does not parse: {rel}: {exc})")
for h in hits:
    print(f"{h[0]}:{h[1]}  {h[2]}  -> {h[3]}")
print(f"{len(files)} files scanned, {len(hits)} calls do not bind")
