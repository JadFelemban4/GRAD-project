"""ratios_cache.py -- wide_air.thin_air_ratios caches by plant.id, and a dataclasses.replace
variant (the way engines.get's docstring says to make one) keeps that id.

    python ratios_cache.py <tree>
"""
import os
import sys
import time
from dataclasses import replace

tree = sys.argv[1]
os.chdir(tree)
sys.path.insert(0, tree)
import engines          # noqa: E402
import wide_air as W    # noqa: E402

b = engines.get("b58")
eng = b.engine
v = replace(b, engine=replace(eng, geometry=replace(eng.geometry, bore=eng.geometry.bore * 0.9)))
print("variant id == base id:", v.id == b.id, "| engine_sha base", engines.engine_sha(b),
      "variant", engines.engine_sha(v))
t0 = time.time()
r_base = W.thin_air_ratios(b)
print(f"thin_air_ratios(base) measured in {time.time() - t0:.0f} s; 80 kPa @3000 rpm ratio {r_base[80.0][3000]!r}")
t0 = time.time()
r_var = W.thin_air_ratios(v)
print(f"thin_air_ratios(variant) returned in {time.time() - t0:.3f} s; same object as base: {r_var is r_base}")
m = W.deliverable_torque(80.0, [3000], plant=v)[3000]
own = m / dict(v.car.deliverable_torque)[3000]
print(f"the variant's own 80 kPa ratio @3000 rpm, measured: {own!r}  (cached value served: {r_var[80.0][3000]!r})")
