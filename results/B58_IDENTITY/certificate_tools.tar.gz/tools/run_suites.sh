#!/usr/bin/env bash
# run_suites.sh [quick|docs|all] -- the candidate's own suites, as their docstrings say to run them.
#   quick  the unit suites: test_wide_air, test_engine_threading, test_epa_map (and again with the
#          MY2021 and MY2023 Test Car Lists in GRAD_EXTRA_DATA, when S/tcl holds them),
#          test_plant_guards, random_road.py and fingerprint.py --engine b58
#   docs   verify_docs.py, once the documents are final
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
CAND=${CAND:-/c/Users/badcl/Desktop/GRAD-project}
export PYTHONIOENCODING=utf-8
what=${1:-all}
one() {   # one <label> <dir> <command...>
  local label=$1 dir=$2; shift 2
  local s=$(date +%s)
  ( cd "$dir" && "$@" ) > $S/suites/$label.txt 2>&1
  echo "$? $(( $(date +%s) - s )) $label" >> $S/suites/_status.txt
}
mkdir -p $S/suites
if [ $what = quick ] || [ $what = all ]; then
  one cand_test_wide_air $CAND $PY test_wide_air.py &
  one cand_test_engine_threading $CAND $PY test_engine_threading.py -v &
  one cand_test_epa_map $CAND $PY test_epa_map.py -v &
  if [ -d $S/tcl/epa-test-car-list/MY2021 ]; then
    TCL=$(cygpath -m $S/tcl/epa-test-car-list)
    GRAD_EXTRA_DATA="$TCL/MY2021;$TCL/MY2023" one cand_test_epa_map_with_2021_2023 $CAND $PY test_epa_map.py -v &
  fi
  one cand_test_plant_guards $CAND $PY test_plant_guards.py -v &
  one cand_random_road $CAND $PY random_road.py &
  one cand_fingerprint $CAND $PY fingerprint.py --engine b58 &
  wait
  cp $S/suites/cand_fingerprint.txt $S/out/fp_cand.txt
fi
if [ $what = docs ] || [ $what = all ]; then
  one cand_verify_docs $CAND $PY verify_docs.py
fi
cat $S/suites/_status.txt
