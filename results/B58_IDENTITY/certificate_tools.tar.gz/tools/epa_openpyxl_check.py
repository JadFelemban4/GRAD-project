"""epa_openpyxl_check.py -- read EPA's workbooks with openpyxl (an independent reader, not
epa_map.read_xlsx) and compare every cell of every generated table, by spreadsheet row and by
the (name, unit) of rows 4 and 5, with data/engines/<engine>/epa_*.csv.

    <anaconda python> -I epa_openpyxl_check.py <repo>

Prints one line per table and a sample row by hand.
"""
import csv
import math
import os
import sys

import openpyxl

repo = sys.argv[1]
TABLES = {
    "mazda_25t": [("4- 2016 Mazda 2.5L Turbo Skyactiv-G Engine Tier 2 Fuel - Test Data.xlsx",
                   {"Steady State": "epa_steady.csv", "High Load Initial": "epa_highload_initial.csv",
                    "High Load Final": "epa_highload_final.csv"})],
    "honda_l15b7": [("4- 2016 Honda 1.5L L15B7 Engine Tier 2 Fuel - Test Data.xlsx",
                     {"Steady State": "epa_steady.csv", "High Load Initial": "epa_highload_initial.csv",
                      "High Load Final": "epa_highload_final.csv"})],
    "ford_27tt": [("4- 2015 Ford 2.7L EcoBoost V6 Engine Tier 2 Fuel Cell 9 - Test Data.xlsx",
                   {"Steady State": "epa_steady_cell9.csv"}),
                  ("4- 2015 Ford 2.7L EcoBoost V6 Engine Tier 2 Fuel HD1 - Test Data.xlsx",
                   {"Steady State": "epa_steady_hd1.csv", "High Load Initial": "epa_highload_initial_hd1.csv",
                    "High Load Final": "epa_highload_final_hd1.csv"})],
}
# the generated column for an EPA (name, unit), as a reader would name it by hand
sys.path.insert(0, repo)
total_bad = 0
for eng, books in TABLES.items():
    for fname, sheets in books:
        path = os.path.join(repo, "logs", "epa", eng, fname)
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        print(f"{eng}: {fname}: sheets {wb.sheetnames}")
        for sheet, out in sheets.items():
            ws = wb[sheet]
            grid = {i + 1: list(r) for i, r in enumerate(ws.iter_rows(values_only=True))}
            names = grid[4]
            units = grid[5]
            with open(os.path.join(repo, "data", "engines", eng, out), encoding="utf-8", newline="") as fh:
                rows = list(csv.reader(fh))
            head, body = rows[0], rows[1:]
            chan = head[5:]
            # map each generated column to the sheet column by position of (name, unit) pairs
            pairs = [(str(n).strip() if n is not None else "", str(u).strip() if u is not None else "")
                     for n, u in zip(names, units)]
            pairs = [p for p in pairs if p[0]]
            if len(pairs) != len(chan):
                print(f"  {sheet}: {len(pairs)} named columns on the sheet, {len(chan)} in {out}")
            bad = 0
            data_rows = sorted(k for k, v in grid.items() if k >= 6 and any(x is not None for x in v))
            if [int(r[2]) for r in body] != data_rows:
                print(f"  {sheet}: source_row list differs from the sheet's data rows "
                      f"({len(body)} vs {len(data_rows)})")
                bad += 1
            for r in body:
                assert r[1] == sheet and r[0] == fname, (r[:3], sheet, fname)
                n = int(r[2])
                vals = grid[n]
                for j, col in enumerate(chan):
                    sheet_v = vals[j] if j < len(vals) else None
                    got = r[5 + j]
                    if sheet_v is None:
                        if got != "":
                            bad += 1
                            print(f"   row {n} {col}: sheet empty, csv {got!r}")
                        continue
                    if got == "" or float(got) != float(sheet_v):
                        bad += 1
                        if bad < 5:
                            print(f"   row {n} {col}: sheet {sheet_v!r}, csv {got!r}")
            total_bad += bad
            print(f"  {sheet} -> {out}: {len(body)} rows x {len(chan)} channels, {bad} differ; "
                  f"columns: " + ", ".join(f"{p[0]}[{p[1]}]={c}" for p, c in list(zip(pairs, chan))[:6]) + " ...")
        wb.close()
print("TOTAL cells differing:", total_bad)

# one row by hand: Honda Steady State row 7, every named column with its unit
wb = openpyxl.load_workbook(os.path.join(repo, "logs", "epa", "honda_l15b7",
                                         "4- 2016 Honda 1.5L L15B7 Engine Tier 2 Fuel - Test Data.xlsx"),
                            read_only=True, data_only=True)
ws = wb["Steady State"]
g = {i + 1: list(r) for i, r in enumerate(ws.iter_rows(values_only=True))}
print("\nHonda 'Steady State' row 7, by openpyxl:")
for n, u, v in zip(g[4], g[5], g[7]):
    if n is not None:
        print(f"  {str(n):28s} [{u}] = {v!r}")
