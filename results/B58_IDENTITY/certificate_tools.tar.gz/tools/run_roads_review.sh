#!/usr/bin/env bash
# run_roads_review.sh -- the pool-heavy road checks of the review, one after another (each runs up
# to 18 workers): check_roads --road extremes and --road wideair in the candidate copy (L5), then
# finding 11's: check_roads (the 40 terrain roads) and check_random_road.py in the candidate copy and
# in the reference. Every writer runs in a scratch copy (S/cand, S/ref) and its output is kept apart.
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
export PYTHONIOENCODING=utf-8
for road in extremes wideair; do
  CAND=$S/cand bash $S/tools/run_writer.sh cand roads_$road results/training_roads_$road.json check_roads.py --road $road
done
mkdir -p $S/F11
for t in cand ref; do
  ( cd $S/$t && cp -p results/training_roads.json $S/F11/${t}_training_roads_committed.json && s=$(date +%s) \
    && $PY check_roads.py > $S/F11/${t}_roads_terrain_stdout.txt 2> $S/F11/${t}_roads_terrain_stderr.txt; \
    echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/${t}_roads_terrain_exit.txt; \
    cp -p results/training_roads.json $S/F11/${t}_roads_terrain_OUT_training_roads.json; \
    cp -p $S/F11/${t}_training_roads_committed.json results/training_roads.json )
done
for t in cand ref; do
  ( cd $S/$t && s=$(date +%s) && $PY check_random_road.py > $S/F11/${t}_random_road_stdout.txt 2> $S/F11/${t}_random_road_stderr.txt; \
    echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/${t}_random_road_exit.txt )
done
cat $S/L5/cand_roads_*_exit.txt $S/F11/*_exit.txt
