#!/usr/bin/env bash
# check_l6.sh -- L6's three comparisons for each agent: cand vs ref (every value, tobytes),
# each tree vs the committed raw scores (full precision) and eval_record.npz (per step)
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
mkdir -p $S/cmp
for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
  echo "=================== $tag"
  echo "--- candidate against reference"
  $PY -I $S/tools/cmp.py $S/L6/ref_$tag.npz $S/L6/cand_$tag.npz --quiet --json $S/cmp/L6_$tag.json
  for t in cand ref; do
    echo "--- $t against the committed files"
    $PY -I $S/tools/l6_check.py $S/L6/${t}_$tag.npz $tag --json $S/cmp/L6_${t}_${tag}_committed.json
  done
done
