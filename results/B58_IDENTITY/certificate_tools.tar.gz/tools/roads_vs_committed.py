"""roads_vs_committed.py -- a check_roads.py output against the committed one, road by road.

    python -I roads_vs_committed.py <new.json> <committed.json> --json <out.json>

Finding 13 of the review of build step 1: results/training_roads.json (the 40 terrain
roads) was last written before 75ca65f changed the plant. Counts the roads whose every
value is equal, lists the summary figures of both, and the first value that differs.
"""
import json
import sys

new, old = (json.load(open(p, encoding="utf-8")) for p in sys.argv[1:3])
out = dict(new=sys.argv[1], committed=sys.argv[2])
same = [a == b for a, b in zip(new["roads"], old["roads"])]
out["roads"] = dict(compared=len(same), equal=sum(same))
out["summary"] = {k: dict(new=new.get(k), committed=old.get(k))
                  for k in ("n", "binding", "worst_neutral_r", "worst_p95_err", "passed")}
first = None
for a, b in zip(new["roads"], old["roads"]):
    for k in a:
        if a.get(k) != b.get(k) and not isinstance(a.get(k), list):
            first = f"road seed {a['seed']}: {k} {b.get(k)!r} committed, {a.get(k)!r} now"
            break
    if first:
        break
out["first_difference"] = first
print(json.dumps(out, indent=1))
if "--json" in sys.argv:
    json.dump(out, open(sys.argv[sys.argv.index("--json") + 1], "w", encoding="utf-8"), indent=1)
