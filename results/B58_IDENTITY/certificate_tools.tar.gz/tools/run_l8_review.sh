#!/usr/bin/env bash
# run_l8_review.sh -- L8 in full for the second certificate: run_l8.sh (both trees, the wrapper and the
# one-ulp controls), the two relative-step controls, every comparison, each run's identity read from its
# meta.json, then the run directories deleted (an identity test, not an experiment).
S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
SW=$(cygpath -m "$S")
PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
CAND=${CAND:-/c/Users/badcl/Desktop/GRAD-project}
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONUNBUFFERED=1 PYTHONIOENCODING=utf-8
COMMON="--steps 600 --seed 0 --device cpu"
bash $S/tools/run_l8.sh
for rel in 1e-9 1e-6; do
  ( cd $CAND && s=$(date +%s) && $PY -I "$SW/tools/l8_perturbed.py" "$(cygpath -m "$CAND")" car.mass:$rel --engine b58 $COMMON \
      --road extremes --out "$SW/L8/ctl_mass$rel" > $S/L8/ctl_mass$rel.log 2>&1; \
    echo "$? $(( $(date +%s) - s )) ctl_mass$rel" >> $S/L8/_status.txt ) &
done
wait
cmp8() {   # cmp8 <name> <run a> <run b>
  $PY -I $S/tools/l8_compare.py "$SW/L8/$2" "$SW/L8/$3" --json "$SW/cmp/L8_$1.json" > $S/L8/compare_$1.txt 2>&1
  echo "$1: $(tail -n 1 $S/L8/compare_$1.txt)"
}
cmp8 extremes_sighted_seed0 ref_extremes/sighted_seed0 cand_extremes/sighted_seed0
cmp8 extremes_blind_seed0 ref_extremes/blind_seed0 cand_extremes/blind_seed0
cmp8 wideair_sighted_seed0 ref_wideair/sighted_seed0 cand_wideair/sighted_seed0
cmp8 ctl_none cand_extremes/sighted_seed0 ctl_none/sighted_seed0
cmp8 ctl_mass cand_extremes/sighted_seed0 ctl_mass/sighted_seed0
cmp8 ctl_cturb cand_extremes/sighted_seed0 ctl_cturb/sighted_seed0
cmp8 ctl_mass1e-9 cand_extremes/sighted_seed0 ctl_mass1e-9/sighted_seed0
cmp8 ctl_mass1e-6 cand_extremes/sighted_seed0 ctl_mass1e-6/sighted_seed0
$PY - "$SW/L8" << 'EOF'
import glob, hashlib, json, os, sys
root = sys.argv[1]
out = {}
for meta in sorted(glob.glob(os.path.join(root, "*", "*", "meta.json"))):
    run = os.path.relpath(os.path.dirname(meta), root).replace(os.sep, "/")
    m = json.load(open(meta, encoding="utf-8"))
    z = os.path.join(os.path.dirname(meta), "final.zip")
    out[run] = dict(engine_sha=m.get("engine_sha"), plant_sha=m.get("plant_sha"), schema=m.get("schema"),
                    backend=m.get("backend"), train_road=m.get("train_road"),
                    final_zip_sha256=hashlib.sha256(open(z, "rb").read()).hexdigest()[:16] if os.path.exists(z) else None)
json.dump(out, open(os.path.join(root, "run_identities.json"), "w", encoding="utf-8"), indent=1)
print(json.dumps(out, indent=1))
EOF
cat $S/L8/_status.txt
for d in ref_extremes cand_extremes ref_wideair cand_wideair ctl_none ctl_mass ctl_cturb ctl_mass1e-9 ctl_mass1e-6; do
  rm -rf "$S/L8/$d"
done
echo "run directories deleted"
