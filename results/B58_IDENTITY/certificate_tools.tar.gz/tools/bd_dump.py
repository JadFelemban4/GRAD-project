"""bd_dump.py -- build_dataset.read_drive + derive on drives of a tree COPY, with that
copy's data/derived_params.json moved aside (as before a first derivation), every
numeric column dumped as float64 for a byte comparison (cmp.py).

    python -I bd_dump.py <tree copy> <out.npz> <drive.csv> [<drive.csv> ...]

Finding 2 of the review of build step 1 (21 October 2026): on cf43fbb build_dataset.py
ran with no derived file; the candidate refused it (engines.get read every DERIVED
field). The file is put back afterwards, whatever happens.
"""
import os
import shutil
import sys
import traceback

tree, out, drives = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), sys.argv[3:]
os.chdir(tree)
sys.path.insert(0, tree)
src = os.path.join(tree, "data", "derived_params.json")
aside = src + ".aside"
shutil.move(src, aside)
arrays, status = {}, 0
try:
    import numpy as np
    import build_dataset as B
    for name in drives:
        d = B.read_drive(os.path.join(tree, "logs", "raw", name))
        try:
            d = B.derive(d)
        except Exception as exc:                  # noqa: BLE001
            print(f"{name}: derive FAILED: {type(exc).__name__}: {exc}")
            traceback.print_exc(limit=3)
            status = 1
            continue
        keys = sorted(k for k, v in d.items() if np.asarray(v).dtype.kind in "fiub")
        for k in keys:
            arrays[f"{name}:{k}"] = np.asarray(d[k], dtype=np.float64)
        mp = np.asarray(d["map_kpa"])
        print(f"{name}: derive OK, {len(keys)} numeric columns, {len(mp)} rows; "
              f"map_kpa[:3] {mp[np.isfinite(mp)][:3].tolist()}")
finally:
    shutil.move(aside, src)
    print("derived file restored:", os.path.exists(src))
np.savez(out, **arrays)
sys.exit(status)
