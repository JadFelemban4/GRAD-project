#!/usr/bin/env bash
# cert_final_driver_P.sh -- P's B58 identity certificate, F.1 and F.2 (CERT_FINAL_DRIVER of p_gate.sh; P_GATE_PLAN.md
# 5.2, K8). DRAFT of 7 November 2026, NOT RUN. Read INTEGRATION.md first.
#
#     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_final_driver_P.sh
#
# p_gate.sh's phase cert-final runs it, after post (test_engine_threading alone, the certificate's G7.0, recorded
# in G7-suites). It writes, in this order:
#   F.1  the end fingerprint (out/P_end_fp_cand.txt) and the end manifest (manifest_end_P.txt), one record each;
#   HP7.6 every test count README.md and full_run.py state, against the runs (tools/stated_counts_P.py): it
#        needs G7.0's count, so it runs here and not in G7.4;
#   3.6.19's record: the certificate made from every record once (cert_out/P_F2_draft0.*), its print-out read;
#        the only item open then is 3.6.19 itself, which this record answers;
#   F.2  the draft certificate, cert_out/B58_IDENTITY.json and .md, make_cert.py's print-out kept in
#        cert_out/make_cert_stdout.txt (p_gate.sh reads it: every check ok, no PROBLEM, FAIL or MISSING line);
#   a pre-check that is no record: verify_docs.py in a copy of the clone with the draft in results/
#        (cert_out/P_F2_verify_docs_precheck.txt), so that a figure verify_docs.py would refuse in the page is
#        seen before p_gate.sh cert-docs, where the page_markers of cert_P.json can no longer change.
# Exit 0 when it wrote what it should, whatever the verdicts (p_gate.sh judges the draft); 3 on a refusal of
# its own (cert_record.py refused a record, an input is missing, the clone is not clean, or, before any record, a
# FAIL record that no later PASS re-checks: review fixes 3); 2 if it cannot start.
# No `set -u` and no `set -e`, as cert_driver_P.sh.
[ -n "${CERT_S:-}" ] || { echo "cert_final_driver_P.sh: CERT_S is unset (p_gate.sh exports it)" >&2; exit 2; }
# shellcheck source=/dev/null
source "$CERT_S/env_P.sh" || { echo "cert_final_driver_P.sh: env_P.sh refused" >&2; exit 2; }
cd "$REPO" || exit 2
REPORT="$S/out/P_final_driver_report.txt"
RECLOG="$S/out/P_final_driver_records.log"
BAD=0
say() { echo "$(date -u +%FT%TZ) $*" | cut -c1-400 | tee -a "$REPORT"; }
R() { rec "$@" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; }; }
verdict() { [ -z "$1" ] && echo PASS || echo FAIL; }
lf() { tr -d '\r' < "$1"; }
same() { cmp -s <(lf "$1") <(lf "$2"); }
secs_since() { echo $(( $(date +%s) - $1 )); }

say "BEGIN cert_final_driver_P.sh in $(pwd); P_CAND ${P_CAND:0:12}"
[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean"; exit 3; }
for f in out/P_G1_fp_cand.txt manifest_start_P.txt suites/P_test_engine_threading.txt cert_P.json tools/make_cert.py \
         tools/make_md.py tools/manifest.py tools/stated_counts_P.py tools/copy_tree.py; do
  [ -f "$S/$f" ] || { say "REFUSED: S lacks $f (post and cert run first)"; exit 3; }
done
mkdir -p "$S/cert_out"

# ---- (review fixes 3, 7 November 2026) no record while a FAIL record is open. A FAIL that no later PASS record of
# its own file re-checks (make_cert.py's _rechecks rule, which p_gate.sh's cert_fail_list reads alike) would make
# the 3.6.19 record below a FAIL, and no run can re-check a record of this driver (cert-recheck runs g1 ... g7):
# the certificate would be stuck until a new S. So the driver refuses before its first record (exit 3; it writes
# nothing in cert_results): re-check the group (cert-recheck <g>), then post and cert-final again. A FAIL record of
# a group no driver group writes again (G0-prepare, G1.0, G7.3, G7.0, HP7.6, F-certificate) needs a new S.
"$PY" -I -B - "$SW" > "$S/out/P_F0_open_fails.txt" 2>&1 <<'EOF'
import glob, json, os, re, sys
S = sys.argv[1]
out = []
for f in sorted(glob.glob(os.path.join(S, "cert_results", "*.json"))):
    name = os.path.basename(f)
    try:
        with open(f, encoding="utf-8") as fh:
            rows = json.load(fh)
    except Exception as e:                                      # unreadable: nothing can be judged
        out.append(f"{name}: unreadable ({type(e).__name__})")
        continue
    if not isinstance(rows, list):
        out.append(f"{name}: not a list of records")
        continue
    closed = set()
    for i, r in enumerate(rows):                                # a later PASS (or "PASS (<why>)") that names it
        if not isinstance(r, dict) or not r.get("rechecks"):
            continue
        v = r.get("verdict")
        m = re.search(r"([\w-]+\.json) record (\d+)", str(r.get("rechecks")))
        if m and m.group(1) == name and int(m.group(2)) < i + 1 and isinstance(v, str) and re.match(r"^PASS( \(.+\))?$", v):
            closed.add(int(m.group(2)))
    for i, r in enumerate(rows):
        if isinstance(r, dict) and r.get("verdict") == "FAIL" and (i + 1) not in closed:
            out.append(f"{name} record {i + 1}: OPEN FAIL, item {r.get('item')}: {r.get('what')}")
print("\n".join(out) if out else "no open FAIL record")
raise SystemExit(1 if out else 0)
EOF
rc=$?
if [ "$rc" != 0 ]; then
  say "REFUSED: a FAIL record is open, or a record file unreadable ($(grep -c . "$S/out/P_F0_open_fails.txt") lines, out/P_F0_open_fails.txt): no record written; cert-recheck <g> first (a FAIL of G0-prepare, G1.0, G7.3, G7.0, HP7.6 or F-certificate needs a new S)"
  exit 3
fi

# ---- F.1 the end of the run: nothing may have changed in the clone
t0=$(date +%s)
( cd "$REPO" && "$PY" -B fingerprint.py --engine b58 ) > "$S/out/P_end_fp_cand.txt" 2>&1; rc=$?
bad=""; [ "$rc" = 0 ] || bad=" exit $rc"; same "$S/out/P_end_fp_cand.txt" "$S/out/P_G1_fp_cand.txt" || bad="$bad the block differs from G1.0's"
R F-certificate --level identity --item "3.6.1, HA.10" --what "F.1: the candidate's fingerprint at the end of the run" \
  --command "cd candg && python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; compared line for line with out/P_G1_fp_cand.txt" \
  --cwd candg --expected "exit 0; the block G1.0 printed, every field the same (plant_sha $(awk '$1 == "plant_sha" { print $2 }' "$S/out/P_G1_fp_cand.txt"), git_dirty False, git_head P_CAND)" \
  --got "$( [ -z "$bad" ] && echo "the same block" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" \
  --evidence out/P_end_fp_cand.txt out/P_G1_fp_cand.txt
t0=$(date +%s)
"$PY" -I -B "$SW/tools/manifest.py" "$RW" "$SW/manifest_end_P.txt" > "$S/out/P_F1_manifest.txt" 2>&1; rc=$?
git -C "$REPO" status --porcelain=v1 --untracked-files=all > "$S/out/P_F1_git_status_end.txt"
bad=""; [ "$rc" = 0 ] || bad=" exit $rc"; cmp -s "$S/manifest_start_P.txt" "$S/manifest_end_P.txt" || bad="$bad the manifests differ"
[ ! -s "$S/out/P_F1_git_status_end.txt" ] || bad="$bad git status"
R F-certificate --level manifest --item 3.6.1 --what "F.1: the candidate manifest at the end against the start" \
  --command "python -I -B tools/manifest.py candg manifest_end_P.txt; cmp manifest_start_P.txt manifest_end_P.txt; git -C candg status --porcelain --untracked-files=all" \
  --cwd S --expected "the two manifests identical; the clone's status empty (cert_P.json declares no file changed during the run)" \
  --got "$( [ -z "$bad" ] && echo "identical ($(grep -c . "$S/manifest_end_P.txt") files); status empty" || echo "differs:$bad")" \
  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence manifest_end_P.txt out/P_F1_git_status_end.txt

# ---- HP7.6 every stated test count against its run (G7.4's last check, after G7.0)
t0=$(date +%s)
M=()
for t in test_plant_guards test_fuel_forms test_cars test_carried test_trainable test_wide_air test_epa_map \
         test_preview_horizon test_tit_cap test_epa_plants; do
  M+=("$t=$SW/suites/cand_$t.txt")
done
M+=("test_engine_threading=$SW/suites/P_test_engine_threading.txt")
for t in test_agents test_simulation test_results; do M+=("app.$t=$SW/app/cand_$t.txt"); done
"$PY" -I -B "$SW/tools/stated_counts_P.py" "$RW" "${M[@]}" > "$S/suites/P_F_stated_counts.txt" 2>&1; rc=$?
bad=""; [ "$rc" = 0 ] || bad=" exit $rc"
R G7-suites --level docs --item HP7.6 --what "every test count README.md and full_run.py state, against its run (G7.4, after G7.0)" \
  --command "python -I -B tools/stated_counts_P.py candg <suite>=<its output> for the suites G5, G7 and G7.0 ran (suites/P_F_stated_counts.txt)" \
  --cwd S --expected "every statement of '<N> tests' in candg's README.md and full_run.py names a suite this certificate ran, and each count (and stated skip count) equals that run's 'Ran N tests' (and skipped=K); exit 0" \
  --got "$(lf "$S/suites/P_F_stated_counts.txt" | grep -a '^HP7.6:' | tail -1)$( [ -n "$bad" ] && echo "; $(lf "$S/suites/P_F_stated_counts.txt" | grep -avE '^(equal|HP7.6:)' | head -3 | tr '\n' ' ' | cut -c1-240)")" \
  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence suites/P_F_stated_counts.txt

# ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
t0=$(date +%s)
# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
bad=""
[ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
[ "$rc2" = 0 ] || bad="$bad make_md exit $rc2"
# (review fixes 2) While 3.6.19 has no record, make_cert.py prints "  NO  every item of the re-run list answered"
# by construction: that one line is dropped, and the next test keeps 3.6.19 the only item MISSING, so the line is
# 3.6.19's alone (any other unanswered item prints its own "  FAIL item" or "  MISSING item" line). A "  FAIL {...}"
# line is accepted only for a FAIL record that a later PASS re-checks (make_cert.py's dict ends with a non-empty
# 'rechecked_by'), and only with the "ok  every record PASS, or a FAIL that a later PASS record re-checks" line.
lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aE '^  (NO  |PROBLEM |FAIL )' \
  | grep -avxF '  NO  every item of the re-run list answered' \
  | grep -avE "^  FAIL \{.*'rechecked_by': \['[^]]+'\]\}$" | grep -aq . && bad="$bad a check NO, a PROBLEM or a FAIL"
lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aqxF '  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)' \
  || bad="$bad the records' check is not ok"
got=$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aE '^  MISSING ' | grep -avE '^  MISSING item 3\.6\.19:' | wc -l)
[ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
[ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
  --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
  --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt

# ---- F.2 the draft certificate in scratch
"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
[ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }

# ---- the pre-check (no record): verify_docs.py with the draft in a copy of the clone
V="$CERT_ROOT/vdcheck_P"; rm -rf "$V"
if "$PY" -I -B "$SW/tools/copy_tree.py" "$RW" "$(cygpath -m "$V")" > "$S/cert_out/P_F2_verify_docs_copy.txt" 2>&1; then
  cp -p "$S/cert_out/B58_IDENTITY.json" "$V/results/B58_IDENTITY.json"; cp -p "$S/cert_out/B58_IDENTITY.md" "$V/results/B58_IDENTITY.md"
  ( cd "$V" && "$PY" -B verify_docs.py ) > "$S/cert_out/P_F2_verify_docs_precheck.txt" 2>&1
  say "pre-check, no record: verify_docs.py with the draft in a copy of the clone: exit $? ($(lf "$S/cert_out/P_F2_verify_docs_precheck.txt" | grep -aE '^All [0-9]+ checks pass|FAIL' | head -2 | tr '\n' ' ' | cut -c1-200)); cert_out/P_F2_verify_docs_precheck.txt"
else
  say "pre-check not run: copy_tree.py into $V failed"
fi
rm -rf "$V"
[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean at the end"; BAD=1; }
say "END cert_final_driver_P.sh; refusals: $BAD"
[ "$BAD" = 0 ] || exit 3
exit 0
