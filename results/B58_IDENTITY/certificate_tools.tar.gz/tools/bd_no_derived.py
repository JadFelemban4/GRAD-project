"""bd_no_derived.py -- build_dataset.derive on one drive, in a tree copy whose
data/derived_params.json has been moved aside (as on a re-derivation from scratch).

    python bd_no_derived.py <tree>

Run from the tree; restores the file afterwards. Prints the first inverted manifold
pressures, or the exception.
"""
import os
import shutil
import sys
import traceback

tree = sys.argv[1]
os.chdir(tree)
sys.path.insert(0, tree)
src = os.path.join(tree, "data", "derived_params.json")
aside = src + ".aside"
shutil.move(src, aside)
try:
    import numpy as np
    import build_dataset as B
    d = B.read_drive(os.path.join(tree, "logs", "raw", "3aca2ec1-20260907_072817.csv"))
    try:
        d = B.derive(d)
        mp = np.asarray(d["map_kpa"]) if "map_kpa" in d else None
        print("derive OK; map_kpa[:5] =", None if mp is None else mp[np.isfinite(mp)][:5].tolist())
    except Exception as exc:                      # noqa: BLE001
        print(f"derive FAILED: {type(exc).__name__}: {exc}")
        traceback.print_exc(limit=4)
finally:
    shutil.move(aside, src)
    print("restored", os.path.exists(src))
