# Edits to the certificate tools for build step 2 (append only)

Base: the tools of `results/B58_IDENTITY/certificate_tools.tar.gz` (sha256 `a639190b…01503fb`),
unpacked here as `tools/`. Rule: a candidate-side edit lives only inside a tool's NEW branch (a
tree that holds engines.py); the reference side (NEW False) stays byte-identical in behaviour.

## 22 October 2026, WP1 P1 (the fuel is the engine's)

### `tools/harness.py`: a `fuel.<field>` route for `HARNESS_PERTURB`

- **Where:** inside `if NEW:` → `if _pert:`, a new `elif rec_name == "fuel":` between the `car`
  branch and the generic record branch (8 lines, archive line 45).
- **What:** `HARNESS_PERTURB=fuel.afr_st` or `fuel.lhv_j_per_kg` moves that field by one float64 ulp
  through `engines.with_fuel(PLANT.engine, replace(PLANT.engine.fuel, field=nextafter))`, then the
  plant goes into `engines._BUILT["b58"]` as before.
- **Why:** P1 puts a copy of the fuel's LHV in the thermal record (`ThermalParams.fuel_lhv_j_per_kg`)
  and `engines.Engine.__post_init__` refuses the two copies apart. The generic branch
  (`replace(PLANT.engine, fuel=replace(fuel, lhv=...))`) would raise for the LHV, so the plan's §3.5
  control "one ulp on `fuel.lhv_j_per_kg`, through `with_fuel`" needs this route. `afr_st` has one
  copy and takes the same route (the generic branch would give the same plant).
- **Reference side:** untouched. With `HARNESS_PERTURB` unset the candidate side is also unchanged
  (the block is not entered). Checked: the edited file minus the 8 inserted lines equals the
  archive's `tools/harness.py` except three lines found with CRLF endings (archive lines 227-229,
  the `deliverable` comment and call), which were CRLF before this edit (behaviour identical).
- **Used by:** labels `ctl_P1_afr` (`HARNESS_PERTURB=fuel.afr_st`) and `ctl_P1_lhv`
  (`HARNESS_PERTURB=fuel.lhv_j_per_kg`), units job. The generic route was also run once as a
  negative control, `ctl_P1_divergent` (`HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg`): it must
  stop, and stops with Engine's ValueError (exit 1).
- sha256 after the edit: `50c047d5d92662fa0ead4466b6de5bb5ce22bce0c21353ab5ed3040f9d9a61ac`
  (archive copy `8d50e7633be7d3adb1d5a7db12bb2ad6206371b7ea4a26eee7df9c4c38b0cfe2`).

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the archive (`diff -q`).
- Jobs file: the existing `tools/jobs_units.txt` ("units"), unchanged.

### Scratch scripts of P1 (not certificate tools; in `scratchpad/p1/`)

- `keyset.py`: prints the asdict key set of the B58 in a tree (HEAD c47907b's was pinned in
  test_fuel_forms.py's BUILD_STEP_1_KEYS).
- `ulp_probe.py`: how one ulp on afr_st and the LHV reaches run_cycle, measured_fuel_gps, the network.
- `callers_dump.py`: what the three changed callers of measured_fuel_gps compute
  (calibrate_thermal.load_drive, model_vs_data.oil_inputs, car_thermal.thermal_replay), HEAD vs P1;
  `CALLERS_PERTURB=1` is its one-ulp afr_st control (candidate only).

## 22 October 2026, WP1 P2 (the policies' lambda clip is the engine's)

### `tools/harness.py`: a float32-step route and a bind count

- **Where:** two blocks, both candidate-side; nothing else in the file moved.
  1. Inside `if NEW:`, after the `if _pert:` block and before `KW = dict(plant=PLANT)` (15 lines):
     `HARNESS_PERTURB_F32=<record>.<field>` moves an engine-record field to the next float32 above
     float32(field), as a Python float (`float(np.nextafter(np.float32(old), np.float32(np.inf)))`),
     through one `replace` of the Engine (so Engine's checks run on it), then into
     `engines._BUILT["b58"]` as the other routes do. It prints
     `PERTURBED_F32 <field>: <old> (float32 <float32(old)>) -> <new>`.
  2. After `import engine_env as E`, under `if NEW and os.environ.get("HARNESS_BIND_COUNT"):`
     (23 lines): wraps `E.SupervisoryTunerEnv.step`. After each step it compares `info["lam"]` with
     `float(np.float32(bound))` for the plant's `ecu.lam_floor` and `ecu.lam_ceiling`, prints
     `BIND <floor|ceiling> at step <k>` (k counts every env step of the process, so it is the row of
     the dump's per-step arrays, which `run_env` fills one row per step) and, at exit (`atexit`),
     `BIND COUNT over <n> steps: floor <c> [...], ceiling <c> [...]`. The wrapper returns step()'s
     outputs untouched; every subclass (Terrain, Extremes, WideAir, the RandomClimb wrapper's env)
     inherits step(), so the patch reaches every job that steps.
- **Why:** amendment B1. After P2 the policies' clip reads `eng.ecu.lam_floor`, and the clip
  compares in float32 (`lam_b + act[1]` is float32 under NEP 50). The generic `HARNESS_PERTURB`
  moves the floor by one float64 ulp, 0.7 -> 0.7000000000000001, and float32 of both is
  0.699999988079071, so that control could not come out DIFFERENT (the plan's 3.5 expected it to;
  the amendments' wrong claim 2). The float32 step, 0.7 -> 0.7000000476837158, moves the binding
  output. B1 also asks for the bind count first ("1 at HEAD"), so that the control fails for the
  right reason.
- **Reference side:** untouched. Both blocks are entered only when NEW (a tree that holds engines.py)
  and their variable is set; with neither variable set the candidate side is unchanged too.
  Checked: the edited file against the P1 version (sha256 `50c047d5…9d9a61ac`, copied to
  `scratchpad/p2/harness_before_P2.py` before the edit) differs by exactly two insertions (difflib
  opcodes: insert after line 63, 15 lines; insert after line 69, 23 lines). Every other line is byte
  for byte the same; the P1 version is CRLF on every line, and so are the inserted lines.
- **Shown neutral:** `pre_P2_bind` (HARNESS_BIND_COUNT=1, the three quick jobs) is BIT-IDENTICAL to
  `ref` on all three.
- **Used by:** labels `pre_P2_bind` (HARNESS_BIND_COUNT=1, `jobs_quick.txt`), `ctl_P2_lamf32`
  (HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1, `jobs_ctl_P2.txt`), `ctl_P2_lamf64`
  (the generic HARNESS_PERTURB=ecu.lam_floor, one float64 ulp, plus the bind count), `ctl_P2_ceilf32`
  (HARNESS_PERTURB_F32=ecu.lam_ceiling plus the bind count) and `census_P2_bind`
  (HARNESS_BIND_COUNT=1, `jobs_census_P2.txt`).
- sha256 after the edit: `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`.

### New jobs files (`tools/`)

- `jobs_quick.txt`: units, extremes:double:12:random, terrain:single:11:neutral. The quick loop
  from P2 on (amendment B3: the units job never runs step(), which P2 edits). A `#` comment line
  heads it; run_jobs.py skips it.
- `jobs_ctl_P2.txt`: extremes:double:12:random, B1's control job.
- `jobs_census_P2.txt`: rr:120.0:0.16:random, rrwrap:7:3, wideseq:9:4:120, the three random-action
  jobs B1's bind count did not check.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`, the other jobs files.

### Results (out/, compared with `compare_all.sh ref <label>`)

| label | environment | jobs | against `ref` | bind count (`info["lam"]` on float32 of a bound) |
|---|---|---|---|---|
| `cand_P2` | none | units, extremes:double:12:random, terrain:single:11:neutral | BIT-IDENTICAL, all three (115173, 76498, 76498 values) | not asked |
| `pre_P2_bind` | `HARNESS_BIND_COUNT=1` | the same three | BIT-IDENTICAL, all three: the wrapper is neutral | extremes:double:12:random floor **1** of 1099 steps, at step 780 (lam 0.699999988079071), ceiling 0; terrain:single:11:neutral (neutral action) 0 and 0 of 1099; units 0 steps |
| `ctl_P2_lamf32` | `HARNESS_PERTURB_F32=ecu.lam_floor` (0.7, float32 0.699999988079071, -> 0.7000000476837158) and the bind count | extremes:double:12:random | **NOT IDENTICAL**: info, obs, reward, state and summary DIFFERENT, the 12 cycle and seed keys IDENTICAL. `first_diff.py`: the first differing row is **780** in info, obs, reward and state, the bind step; at row 780 lam 0.699999988079071 -> 0.7000000476837158, with egt_c, ki, mdot_exh, mdot_fuel, r_fuel, r_life, r_resp, t_turb and torque; 119 info rows differ (780-898, the rest of the first episode), the second episode none | floor 1, at step 780 (lam 0.7000000476837158), ceiling 0 |
| `ctl_P2_lamf64` | `HARNESS_PERTURB=ecu.lam_floor` (one float64 ulp: 0.7 -> 0.7000000000000001) and the bind count | extremes:double:12:random | BIT-IDENTICAL, as amendment B1 says: float32 of both is 0.699999988079071 | floor 1, at step 780 (lam 0.699999988079071) |
| `ctl_P2_ceilf32` | `HARNESS_PERTURB_F32=ecu.lam_ceiling` (1.25 -> 1.2500001192092896) and the bind count | extremes:double:12:random | BIT-IDENTICAL, by construction: the B58's lambda is at most 1 + ACT_HI[1] = 1.06, so no job can show the ceiling (test_fuel_forms.py shows it with a ceiling of 1) | ceiling 0 |
| `census_P2_bind` | `HARNESS_BIND_COUNT=1` | rr:120.0:0.16:random, rrwrap:7:3, wideseq:9:4:120 | BIT-IDENTICAL, all three (158371, 52215, 44760 values) | floor 0 and ceiling 0 in 2399, 600 and 480 steps |
| `cand_P2_final` | none; the tree after a comment-only edit of engines.py (EcuCal's field comment; plant_sha 67c3f53f188366c5 before and after) | the three quick jobs | BIT-IDENTICAL, all three | not asked |

The reference dump itself (`out/ref/extremes_double_12_random.npz`, cf43fbb) has
`info["lam"] == float32(0.70)` at row 780 only: the bind count is 1 on cf43fbb as on the candidate.
With the census, all 13 random-action jobs of `jobs_all.txt` are counted, the other nine by amendment
B1's lens (`b58_lens/bind_*.txt`, not re-run here): the floor binds in extremes:double:12:random
only, once.

### Scratch scripts of P2 (not certificate tools; in `scratchpad/p2/`)

- `first_diff.py`: per per-step array of a control's dump, the first row that differs from `ref`
  (bit for bit), the info columns that differ there (names from a live step's info_keys), the bind
  steps from the control's log, and the rows where the reference dump's lambda equals
  float32(0.70).
- `mutate.sh`: P2's tests on a minimal copy of the tree with one mutation each (the clip's
  literals back, one bound literal, a float64 bound, no order check, the plan's two conditions
  only, no type check); each must fail.
- `clip_probe.py`: the agent's lambda at the ECU's deepest enrichment, the probe behind
  test_fuel_forms.LambdaClip.test_the_environment_clips_to_the_engines_bounds.

## 22 October 2026, WP1 P2, resumed (the interrupted implementer's work re-read and re-run)

### Tools: not edited

- `harness.py` is the P2 version above, sha256 `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`
  (re-hashed); against `scratchpad/p2/harness_before_P2.py` (P1's, `50c047d5…9d9a61ac`) `diff` shows exactly the
  two candidate-side insertions described above, and every line of both files is CRLF (439 of 439, 401 of 401,
  counted in Python). `run_jobs.py`, `compare_all.sh` and `cmp.py` equal the certificate archive's
  (`results/B58_IDENTITY/certificate_tools.tar.gz`, `cmp`).
- **New jobs file:** `tools/jobs_census_P2_rest.txt`, the nine random-action jobs of `jobs_all.txt` that neither
  `jobs_quick.txt` nor `jobs_census_P2.txt` holds. **Why:** amendment B1 had their bind count from the b58 lens
  only (`b58_lens/bind_*.txt`); with this file every one of the 13 random-action jobs is counted by this harness.

### Results, re-run (labels `*_r2` and `census_P2_rest`; out/, `compare_all.sh ref <label>`)

The tree: the interrupted implementer's edits plus two comment-only rewordings (`engines.EcuCal`'s field comment,
`engine_env.py`'s clip comment); `plant_sha` 67c3f53f188366c5 and `engine_sha` 97b604f96c6d81fe as recorded
above, derived_sha 326c0835548975e2.

| label | environment | jobs | against `ref` | bind count |
|---|---|---|---|---|
| `cand_P2_r2` | none | jobs_quick.txt (3) | BIT-IDENTICAL, all three (115173, 76498, 76498 values) | not asked |
| `bind_P2_r2` | `HARNESS_BIND_COUNT=1` | jobs_quick.txt (3) | BIT-IDENTICAL, all three | extremes:double:12:random floor 1 [780] of 1099, lam 0.699999988079071, ceiling 0; terrain:single:11:neutral 0 and 0 of 1099; units 0 steps |
| `ctl_P2_r2_lamf32` | `HARNESS_PERTURB_F32=ecu.lam_floor` (0.7 -> 0.7000000476837158), bind count | extremes:double:12:random | **NOT IDENTICAL**. `p2/first_diff.py`: first differing row 780 in info, obs, reward and state (the bind step); info 119 rows, obs 16, reward 10, state 119; summary DIFFERENT; the 12 cycle, obs0 and c_turb_scale keys IDENTICAL; at row 780 lam 0.699999988079071 -> 0.7000000476837158 | floor 1 [780] |
| `ctl_P2_r2_lamf64` | `HARNESS_PERTURB=ecu.lam_floor` (0.7 -> 0.7000000000000001), bind count | extremes:double:12:random | BIT-IDENTICAL (amendment B1) | floor 1 [780], lam 0.699999988079071 |
| `ctl_P2_r2_ceilf32` | `HARNESS_PERTURB_F32=ecu.lam_ceiling` (1.25 -> 1.2500001192092896), bind count | extremes:double:12:random | BIT-IDENTICAL: no B58 lambda reaches 1 + ACT_HI[1] = 1.06 | ceiling 0 |
| `census_P2_r2` | `HARNESS_BIND_COUNT=1` | jobs_census_P2.txt (3) | BIT-IDENTICAL, all three | 0 and 0 in 2399, 600, 480 steps |
| `census_P2_rest` | `HARNESS_BIND_COUNT=1` | jobs_census_P2_rest.txt (9) | BIT-IDENTICAL, all nine | 0 and 0 in each (1099 steps; the two wideair jobs 899) |

The reference dump (`out/ref/extremes_double_12_random.npz`, cf43fbb) has `info["lam"] == float32(0.70)` at row 780
only. Over all 13 random-action jobs the floor binds once, at step 780 of extremes:double:12:random, and the
ceiling never: amendment B1's "1 at HEAD", now counted by this harness for every job rather than ten.
`p2/mutate.sh` re-run (`p2/mutate_r2.txt`): the unmutated copy passes; each of the seven mutations fails
LambdaClip.

## 22 October 2026, WP1 P3 (forms B and C)

### `tools/harness.py`: amendment B2's `HARNESS_SET`, and the units job's inversion skipped for forms other than A

- **Before the edit:** the P2 version, sha256 `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`
  (re-hashed; copied to `scratchpad/p3/harness_before_P3.py`). The edit was made by `scratchpad/p3/edit_harness.py`,
  which asserts each anchor occurs once and writes CRLF; every line of the result is CRLF (468 of 468).
- **Where and what (three places, all candidate-side in behaviour):**
  1. Inside `if NEW:`, after the `HARNESS_PERTURB_F32` block and before `KW = dict(plant=PLANT)` (19 lines):
     `HARNESS_SET="cycle.form=A+B;cycle.ve_map=0.0"` sets engine-record fields to the values given, each converted
     to the type the field already has (`type(old)(value)`: str, float or int, so a Python float, amendment B10),
     all records in ONE `replace` of the Engine, then puts the plant into `engines._BUILT["b58"]` as the other
     routes do. It prints `SET <record>.<field>: <old> -> <new>` per field.
  2. The units job's `inv` block: its condition `if m > 0:` became
     `if m > 0 and not (NEW and getattr(eng.cycle, "form", "A") != "A"):` (one line changed). This line is in the
     units job's body, which both trees run: on the reference side `NEW` is False and the condition is `m > 0`, as
     before. `getattr(..., "A")` keeps the tool running on a pre-P3 candidate tree (P1, P2), whose CycleCal has no form.
  3. After that loop, under `if NEW and getattr(eng.cycle, "form", "A") != "A":` (10 lines): calls
     `map_from_airflow` once and requires it to refuse the form (ValueError), printing `INV SKIPPED, form ...`;
     if it accepts, the job stops (`SystemExit`).
- **Why:** amendment B2. P3's `CycleCal.__post_init__` refuses a `ve_map` other than 0 without form B and a
  `ce_rich_slope` other than 0.65 without form C, so the generic per-record `HARNESS_PERTURB` cannot set a form
  and its companion value (and `HARNESS_PERTURB=cycle.ce_rich_slope` raises on the B58, B2 "mine (1)"). P3's
  `map_from_airflow` refuses every form other than A, so under `HARNESS_SET` the units job would stop at the
  `inv` block; B2 has it skip the block, "recorded as by design". The `inv` key is therefore MISSING from those
  dumps, and `cmp.py`'s verdict line reads NOT IDENTICAL for that reason alone: read the per-key report
  (`scratchpad/p3/summarize.py` over `cmp/ref_vs_<label>/*.json`). B2's cam pass-through (`cam_deg` to
  `run_cycle` and `predict`) is P4's and is not in this edit (amendment B4: no cam names in P3).
- **Reference side shown unchanged:** `refside_P3`, the three quick jobs run in the reference tree
  (`$S/ref`, cf43fbb) with the edited harness, is BIT-IDENTICAL to `ref` on all three (115173, 76498, 76498
  values). With `HARNESS_SET` unset the candidate side is unchanged too (`cand_P3` below).
- **Checked:** `diff` against `harness_before_P3.py` (CR stripped) shows exactly the three changes above.
- sha256 after the edit: `b71929393f125b937cd7780af5e94f2b6d82e18bcf1c43e33141743725d64892`.

### New jobs file (`tools/`)

- `jobs_ctl_P3.txt`: units, terrain:single:11:neutral. B2's form controls run "on units plus
  terrain:single:11:neutral, never on wideair".

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the certificate archive's `tools/` copies
  (`cmp`; the archive's `certify_original/compare_all.sh` is an older copy and differs from both). The other
  jobs files.

### Results (out/, `compare_all.sh ref <label>`; the tree: P3 in the working tree on HEAD 0e07423)

| label | environment | jobs | against `ref` |
|---|---|---|---|
| `cand_P3` | none | jobs_quick.txt: units, extremes:double:12:random, terrain:single:11:neutral | BIT-IDENTICAL, all three (115173, 76498, 76498 values) |
| `refside_P3` | none; the REFERENCE tree with the edited harness | jobs_quick.txt | BIT-IDENTICAL, all three |
| `ctl_P3_AB0` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=0.0` | jobs_ctl_P3.txt | **IDENTICAL as B2 expects**: units, 76 of 77 keys IDENTICAL and `inv` MISSING by design (verdict line NOT IDENTICAL for that key alone); terrain BIT-IDENTICAL (17 keys) |
| `ctl_P3_ABC065` | `HARNESS_SET=cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65` | jobs_ctl_P3.txt | **IDENTICAL as B2 expects**: units 76 keys IDENTICAL, `inv` MISSING by design; terrain BIT-IDENTICAL |
| `ctl_P3_ABve` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=1e-4` | jobs_ctl_P3.txt | **DIFFERENT as B2 expects**: units `cycle` 13156 of 19200 values, `cycle_dtheta` 6 of 6, `predict` 249 of 288, `deliverable` 29 of 58, `deliverable_probe` 5 of 10 (71 keys IDENTICAL, `inv` MISSING); terrain `info` 14794 of 19782, `obs` 7184 of 25277, `reward` 1099 of 1099, `state` 14881 of 23079, `summary` 6 of 8 |
| `ctl_P3_ABCulp` | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001` (one ulp above 0.65) | jobs_ctl_P3.txt | **DIFFERENT as B2 expects**: units `predict` (lambda 0.95) 55 of 288 values, and `deliverable` 1 of 58 (row 12, 463.9355123336708 vs 463.93551233367066: the WOT table's enriched lambda), every `cycle` value IDENTICAL (lambda 0.70, 0.85 do not see the ulp; 1.0 and 1.12 take the lean branch); `inv` MISSING by design; terrain (neutral) BIT-IDENTICAL |

Every log of the four controls prints its `SET` lines and, in the units job, `INV SKIPPED, form 'A+B'`
(or `'A+B+C'`): `map_from_airflow inverts form A only ...`.

### Scratch scripts of P3 (not certificate tools; in `scratchpad/p3/`)

- `edit_harness.py`: the harness edit above.
- `summarize.py`: per control and job, the keys by status from `compare_all.sh`'s JSON reports
  (`controls_summary.txt`).
- `mutate.sh` (and `mutate_one.sh`, its form-A mutation re-run alone): P3's tests on a minimal copy of the tree
  with one mutation each; the unmutated copy passes and each of the twelve mutations fails (`mutate.txt`).

## 22 October 2026, WP1 P3, the review's fixes (`P3fix`)

### `tools/harness.py`: the candidate's form read directly (review should-fix 7)

- **Before the edit:** the P3 version, sha256 `b71929393f125b937cd7780af5e94f2b6d82e18bcf1c43e33141743725d64892`
  (copied to `scratchpad/p3fix/harness_before_P3fix.py`). The edit was made by `scratchpad/p3fix/edit_harness.py`,
  which asserts each anchor occurs once and keeps CRLF (468 of 468 lines).
- **What:** the two lines P3 added that read the form, `getattr(eng.cycle, "form", "A")`, now read `eng.cycle.form`:
  the units job's `inv` condition (`if m > 0 and not (NEW and eng.cycle.form != "A"):`) and the refusal check
  (`if NEW and eng.cycle.form != "A":`). Nothing else changed (`diff`, CR stripped: lines 222 and 225 only).
- **Why:** the default "A" was mistake 1's shape in the tool that certifies the plant: a candidate CycleCal
  without `form` would have been run as form A without a word. Every candidate tree from P3 on has the field, so
  the default only served P1/P2 trees, which are not certified again.
- **Reference side:** both lines keep their `NEW and` guard, so with NEW False neither attribute is read.
  Shown: `ctl_P3fix_refside` (the reference tree `$S/ref`, cf43fbb, with this harness, `jobs_quick.txt`) is
  BIT-IDENTICAL to `ref` on all three jobs (115173, 76498, 76498 values).
- sha256 after the edit: `17377d8693c7e19a1b36170f572570f57b7063e8de2e1983034b14b49b05f68f`.

### New tool `tools/control_verdict.py` (review should-fix 3; cmp.py and compare_all.sh not edited)

- `python control_verdict.py <label_a> <label_b> <jobs.txt> IDENTICAL|DIFFERENT [--allow-missing key,...]`:
  reads compare_all.sh's per-job JSON reports (`cmp/<a>_vs_<b>/<slug>.json`) and both labels' `_status.txt`,
  and prints per job IDENTICAL / DIFFERENT / INCOMPLETE, the SET lines and INV SKIPPED lines of b's logs, and
  `CONTROL <b> against <a>: expected X, got Y ...: PASS|FAIL` (exit 0 on PASS).
- Rules: a key named in `--allow-missing` may be absent from b only; any other MISSING key, a job absent from
  either label or not exit 0, or a job without a compare report makes the control INCOMPLETE (FAIL); b's jobs
  must print the same SET lines. The declared list for P3's form controls is `inv`, and only under HARNESS_SET
  forms other than A, where the harness skips `map_from_airflow` by design (amendment B2) and logs INV SKIPPED.
- **Why:** cmp.py's verdict line read NOT IDENTICAL for the IDENTICAL form controls because of that one missing
  key, so the certificate would have rested on a person reading per-key reports.
- **Shown able to fail:** `ref ctl_P3_r1_AB0 jobs_ctl_P3.txt IDENTICAL` without `--allow-missing inv` gives
  INCOMPLETE, FAIL (exit 1); `cand_P3_r1 ctl_P3_r1_ABve ... IDENTICAL --allow-missing inv` gives DIFFERENT, FAIL
  (exit 1); run before compare_all.sh had written its reports, `ctl_P3fix_AB0` gave INCOMPLETE, FAIL.
- sha256: `c57d1db419bc4b178b0816782fd3274d34b8c7cff39e1e1d1aaee52bae611285`.

### New jobs file `tools/jobs_ctl_P3_C.txt` (review should-fix 2)

- units, terrain:single:11:neutral, extremes:double:12:random (CRLF; two `#` lines head it). sha256
  `630b27a4e5111e56028e100feec9aebf46e253eba9d77634324bf56c4d6a9d17`.
- **Why:** the B58's neutral terrain episode never runs rich, so form C's controls could not fail on it: the
  slope-0.70 pre-check reads IDENTICAL there. extremes:double:12:random (random trim; 989 of its 1099 info rows
  at lambda < 1 in the reference dump) is a job the slope reaches. The form C controls (A+B+C at 0.65, and the
  one-ulp slope) run on this file; the form B controls keep `jobs_ctl_P3.txt`.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the certificate archive's `tools/` copies
  (`cmp` against `results/B58_IDENTITY/certificate_tools.tar.gz`). The other jobs files.

### Results (out/; the tree: P3 plus the review's fixes, on HEAD 0e07423; plant_sha 896a79c757b56fcb)

Every verdict below is `control_verdict.py`'s, after `compare_all.sh`; the per-key counts are cmp.py's.

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P3fix` | none | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values) |
| `cand_P3fix_final` | none; the same code after a comment-only edit of engines.py and a docstring edit of test_fuel_forms.py (plant_sha 896a79c757b56fcb before and after) | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values): PASS |
| `ctl_P3fix_refside` | none; the REFERENCE tree with this harness | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three |
| `ctl_P3fix_AB0` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=0.0` | jobs_ctl_P3.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys IDENTICAL (`inv` allowed missing, INV SKIPPED logged); terrain 17 keys |
| `ctl_P3fix_ABC065` | `HARNESS_SET=cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65` | **jobs_ctl_P3_C.txt** | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys (`inv` allowed missing); terrain 17; **extremes:double:12:random 17** |
| `ctl_P3fix_ABve` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=1e-4` | jobs_ctl_P3.txt | `cand_P3fix`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 13156/19200, cycle_dtheta 6/6, deliverable 29/58, deliverable_probe 5/10, predict 249/288; terrain info 14794/19782, obs 7184/25277, reward 1099/1099, state 14881/23079, summary 6/8 |
| `ctl_P3fix_ABCulp` | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001` | **jobs_ctl_P3_C.txt** | `cand_P3fix`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units predict 55/288 and deliverable 1/58, cycle IDENTICAL; terrain IDENTICAL; **extremes:double:12:random info 111/19782, state 105/23079, summary 1/8** (obs, reward IDENTICAL), first at row 778, lambda 0.8557777404785156 (ki, r_resp, torque), max abs difference 1.4e-12 |
| `ctl_P3fix_C070` (pre-check) | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.7` | jobs_ctl_P3_C.txt | `ref`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 5900/19200, deliverable 17/58, deliverable_probe 1/10, predict 191/288; **terrain IDENTICAL** (the neutral episode never runs rich); extremes info 13818/19782, obs 6962/25277, reward 1097/1099, state 11996/23079, summary 6/8 (the review's rvw_P3_C070, re-run) |

Why the one-ulp slope shows in the extremes episode at all: the agent's lambda reaches run_cycle as a Python float
(engine_env.py:1010, `float(np.clip(...))`), so the rich branch is float64 arithmetic, and whether one ulp on the
slope survives `1 - slope (1 - lambda)` depends on the lambda. `scratchpad/p3fix/ulp_lams.py` over the reference
dump: of the 639 distinct rich lambdas, one ulp moves combustion_efficiency at 4 (0.7070471048355103,
0.817680835723877, 0.8557777404785156, 0.8618496656417847); the control's first difference is at the third. Over
20001 float32 lambdas in [0.70, 0.999] it shows at 3645. At 0.70, 0.85 and float32(0.81) it does not, at 0.95 it
does (amendment B2's statement, re-measured). In test_fuel_forms.py's 60 s episode it shows nowhere
(`scratchpad/p3fix/episode_probe.py`), so the in-repository episode check uses finite steps as its controls.

For the certificate's control table (written when WP1 lands): list `ctl_P3fix_ABC065` and `ctl_P3fix_ABCulp` with
`jobs_ctl_P3_C.txt`, `ctl_P3fix_C070` beside them as the pre-check showing that each lists a job the slope
reaches, and every form control's verdict as `control_verdict.py` prints it with `--allow-missing inv`.

### Scratch scripts of the P3 fix (not certificate tools; in `scratchpad/p3fix/`)

- `edit_harness.py`: the harness edit above. `run_waves.sh`: the seven labels above (two waves, 3 jobs at a time).
- `episode_probe.py`: a short random-trim extremes episode under the neutral forms, the slope 0.70, ve_map 1e-4 and
  the one-ulp slope; 60 s: 59 steps, 56 rich, 3.5 s per episode.
- `ulp_lams.py`: the lambdas at which one ulp on the slope moves combustion_efficiency (above).
- `mutate.sh`: the implementer's twelve mutations, the reviewer's four that passed before the fix (ref_literal,
  sign_flip, half_term, clip_then_add) and the new finiteness check removed; the unmutated copy passes and all
  seventeen fail (`mutate.txt`).

## 22 October 2026, WP1 P4 (form D, the intake cam run by the ECU)

### `tools/harness.py`: amendment B2's cam pass-through in the units job

- **Before the edit:** the P3fix version, sha256 `17377d8693c7e19a1b36170f572570f57b7063e8de2e1983034b14b49b05f68f`
  (re-hashed; copied to `scratchpad/p4/harness_before_P4.py`). The edit was made by `scratchpad/p4/edit_harness.py`,
  which asserts each anchor occurs once and keeps CRLF (484 of 484 lines); replayed on the copy it reproduces the
  edited file byte for byte (`cmp`).
- **Where and what (five places, all in the units job, all candidate-side):**
  1. After `eng = PLANT.engine if NEW else None`, under `if NEW:` (12 lines): `_ecu_cam = E.BaselineECU(eng.ecu).cam_deg`
     and a wrapper `_cam(rpm, mp)` that returns it and keeps each value in `_cams`. Not defined on the reference side.
  2. The grid's `run_cycle` (archive line 130): the NEW branch passes `cam_deg=_cam(rpm, mp)`.
  3. `predict` (archive line 139): the NEW branch passes `cam_deg=_cam(rpm, mp)` (the call now spans two lines).
  4. The crank-step `run_cycle` (archive line 146): the NEW branch passes `cam_deg=_cam(kw["rpm"], kw["map_kpa"])`.
  5. After the crank-step loop, under `if NEW and eng.ecu.cam_on:` (3 lines): prints
     `CAM ON: <n> cycles and predicts at the ECU's cam, <min> to <max> deg (<k> distinct), cam_ref_deg <ref>`, the
     pre-check of amendment section 4 item 2 ("a nonzero cam"): a schedule of zeros could not fail.
- **Why:** amendment B2. After P4, `plant.volumetric_efficiency` refuses `cam_deg=None` under form D and a number under
  every other form, and the cam is the ECU's (decision 41). So the units job passes
  `cam_deg=BaselineECU(eng.ecu).cam_deg(rpm, map)` at each cycle's own speed and MAP; under form A (the B58, cam_on 0)
  that is None, run_cycle's and predict's own default, so the A path is the same call. The `map_from_airflow` block is
  still skipped for forms other than A by design (P3's edit, unchanged). The step() jobs need no edit: P4's step()
  schedules the cam itself.
- **Reference side shown unchanged:** every change sits in a `... if NEW else ...` branch the reference never takes, or
  under `if NEW`. `refside_P4`, the three quick jobs run in the reference tree (`$S/ref`, cf43fbb) with the edited
  harness, is BIT-IDENTICAL to `ref` on all three (115173, 76498, 76498 values). With HARNESS_SET unset the candidate
  side passes None and is unchanged too (`cand_P4` below).
- **A P1-P3 candidate tree can no longer run the units job** with this harness (its run_cycle has no `cam_deg`
  keyword, a TypeError). Those trees are not certified again; the P3fix copy is kept as `p4/harness_before_P4.py`.
- sha256 after the edit: `38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`.

### New jobs files (`tools/`, CRLF, `#` lines head them)

- `jobs_ctl_P4.txt` (sha256 `1a8cfee5…ca8d89`): units, terrain:single:11:neutral, extremes:double:12:random. B2's form-D
  controls run "on units plus terrain:single:11:neutral, never on wideair"; the random-trim extremes episode is added
  (the quick loop's third job, P3fix's should-fix 2 pattern).
- `jobs_keyword_P4.txt` (sha256 `c72f6c97…4218d`): wideair:locked:45.0:80.0:11:neutral, wideair:single:0.0:101.3:12:random.
  **Why:** P4 changes `_track_torque`'s and `_evaluate`'s signatures (a keyword-only `cam_deg=None`), and wide_air.py
  calls `_track_torque` with eight positional arguments and no cam (`wide_air.py:149, 182`); the quick loop never
  reaches those calls.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `lab_dump.py`, `lab_compare.py`: equal to the certificate archive's
  `tools/` copies (`cmp` against `results/B58_IDENTITY/certificate_tools.tar.gz`, unpacked in `scratchpad/p4/archive`).
  `control_verdict.py`: P3fix's, sha256 `c57d1db4…611285`, unchanged.

### Results (out/; the tree: P4 in the working tree on HEAD fe0e321; plant_sha 9daef293c84c0557, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

Every verdict is `control_verdict.py`'s, after `compare_all.sh`; the per-key counts are cmp.py's.

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P4` | none | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values): PASS. Its units log prints no CAM line (cam_on 0) |
| `refside_P4` | none; the REFERENCE tree with this harness | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three: PASS |
| `ctl_P4_ABCD0` | `HARNESS_SET=cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.ve_cam=0.0;cycle.cam_ref_deg=0.0;ecu.cam_on=1` (the schedule's twelve fields stay 0.0: "A+B+C+D with zeros") | jobs_ctl_P4.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys (`inv` allowed missing, INV SKIPPED logged); terrain 17; extremes 17. CAM ON: 1220 cycles and predicts at 0.0 to 0.0 deg |
| `ctl_P4_D0` | the same form and terms with `ecu.cam_on=1;ecu.cam_c0=10;ecu.cam_rpm_lo=800;ecu.cam_rpm_hi=7000;ecu.cam_map_lo=20;ecu.cam_map_hi=260;ecu.cam_lo=-60;ecu.cam_hi=60` and `cycle.ve_cam=0.0` (B2's schedule at ve_cam 0) | jobs_ctl_P4.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys; terrain 17; extremes 17. CAM ON: 1220 at 10.0 to 10.0 deg (the cam is off the reference 0, and ve_cam 0 keeps it out of the breathing) |
| `ctl_P4_D1e4` | B2's schedule at `cycle.ve_cam=1e-4` | jobs_ctl_P4.txt | `cand_P4`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 16505/19200, cycle_dtheta 6/6, deliverable 29/58, deliverable_probe 5/10, predict 249/288 (71 keys IDENTICAL); terrain info 14492/19782, obs 6375/25277, reward 1099/1099, state 14074/23079, summary 6/8; extremes info 14635/19782, obs 6946/25277, reward 1099/1099, state 14644/23079, summary 6/8. CAM ON: 1220 at 10.0 deg |
| `cand_P4_kw` | none | jobs_keyword_P4.txt | `ref` | IDENTICAL | BIT-IDENTICAL, both (60331 values each; compare_all.sh) |

Shown able to fail: `cand_P4 ctl_P4_D1e4 jobs_ctl_P4.txt IDENTICAL --allow-missing inv` gives DIFFERENT, FAIL;
`ref ctl_P4_ABCD0 jobs_ctl_P4.txt IDENTICAL` without the allowance gives INCOMPLETE, FAIL.

The learning lab, through its `CapturingEnv` (`_track_torque(*args, **kwargs)`, `args[7] is self.pi_base`):
`tools/lab_dump.py` on `$S/ref` and on the P4 tree (`lab/lab_ref_P4.json`, `lab/lab_cand_P4.json`), compared by
`tools/lab_compare.py` (`lab/compare_cand_P4_ref.txt`): 36325 leaf values, 178 source-line numbers moved, 88 re-worded
strings, 0 other differences, the counts build step 1's comparison listed (`lab/compare_cand_ref.txt`).

### Scratch scripts of P4 (not certificate tools; in `scratchpad/p4/`)

- `edit_harness.py`: the harness edit above.
- `mutate.sh`: P4's tests (test_fuel_forms.FormD, EngineSha) on a minimal copy of the tree with one mutation each
  (`mutate.txt`).
- `mutate.txt`, the result: the unmutated copy passes (exit 0), and so does a spec edit that changes no value (a `unit`
  key added to `cam_on`); each of the 20 mutations fails FormD: the agent's loop without the cam, at its own MAP's cam,
  the cam scheduled on the current MAP, the cam zeroed in `_track_torque`, the D term's sign flipped, its reference
  ignored, no input clamp, no output clamp, MAP scaled by 1000, Engine's cam check removed, EcuCal's cam-off check,
  its lo/hi check, `isinstance` for the int check (a bool passes), CycleCal's ve_cam check, the P4 fields dropped
  from CycleCal's type check, form A taking a cam, the deliverable table without the cam, the table's cam on a fixed
  150 kPa, the surrogate's refusal removed, and run_cycle zeroing the cam.

## 22 October 2026, WP1 P5 (records, constructors, cars, vehicles and guards)

### Tools: not edited

- `harness.py` is the P4 version, sha256 `38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46` (re-hashed).
  **Why no edit:** P5 changes no interface the harness calls. It still builds the B58 with `engines.get("b58")`
  (whose `_build` now reads the specs' top-level `derived_set` and `kind`), the units job still builds
  `E.Vehicle(PLANT.car)` and calls the training-road builders on it (an `engines.Car`, which the new B15 guards
  pass), and the step() jobs build their vehicle through `engine_env.vehicle_for`, which returns `Vehicle(car)`
  for a Car. `HARNESS_PERTURB=car.mass` keeps the record's type (`dataclasses.replace`), so the guards pass it too.
- `run_jobs.py` (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`),
  `control_verdict.py` (P3fix's): unchanged.

### New jobs files (`tools/`, CRLF, `#` lines head them)

- `jobs_P5.txt` (sha256 `0c4e1669dbbd7b21ea459d35aeeac3db6ac97e944b6b335ee07d9be7a89291db`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3), and
  wideair:locked:45.0:80.0:11:neutral, wideair:single:0.0:101.3:12:random. **Why the two wideair jobs:** P5 adds
  the B15 guard to `wide_air.ThinAirVehicle`, `wide_air.grade_floor` and `wide_air.speed_profile`, which the quick
  loop never reaches (P4's `jobs_keyword_P4.txt` pair).
- `jobs_ctl_P5.txt` (sha256 `695593dc653f46ddbcdc270225cd7ea037116ade0ff5330e5dcd9b9aadc9cfa2`):
  terrain:single:11:neutral, the `car.mass` control's job.

### Results (out/; the tree: P5 in the working tree on HEAD 7ea42f5; plant_sha f5c11de53cbe7c9c, plant_text_sha 8a861524a776ff55, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5_r0` | none; the first pass, the plant code final, before the tests were written (two later engines.py edits: two unused tuples dropped, build_candidate's check skips top-level `_` keys) | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 236 s |
| `cand_P5` | none; the final tree | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 254 s |
| `ctl_P5_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL. The car record reaches step() through `vehicle_for` (mistake 25) |

After `cand_P5`, one docstring-only edit of engines.py (the module docstring's DERIVED paragraph names
EPA_DERIVED_FIELDS too): plant_sha f5c11de53cbe7c9c before and after (code-only hash), plant_text_sha
8a861524a776ff55 -> cf10abf3926b2e98. Re-run, as P2's and P3fix's comment-only edits were: `cand_P5_final`
(jobs_P5.txt against `ref`) BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 262 s.

### Scratch scripts of P5 (not certificate tools; in `scratchpad/p5/`)

- `edit_threading.py`: the anchored edit of test_engine_threading.py (CALLS, QUALIFIED, NOT_NONE, the scan
  control, Signatures, the record list, Registry per DERIVED set, the `_record` call).
- `mutate.sh` and its result `mutate.txt`: P5's tests (test_cars.py, test_engine_threading.py Registry and
  Signatures, test_trainable.py) on a minimal copy of the tree (every .py, engine_specs, the derived file) with one
  mutation each; the anchors' line breaks follow the file's own (CRLF or LF). The unmutated copy passes (exit 0) and
  each of the 34 mutations fails: the B15 guard off, or letting an EpaCar through; ThinAirVehicle and
  wide_air.speed_profile unguarded; the kickdown threshold on target_load; the kickdown returning the failing end of
  the bisection; the scan without the bisection; the power-limited branch unflagged; the power fallback at the window's
  top; the launch at rpm_min instead of cvt_rpm_min; the economy speed without the cvt_rpm_min floor; f <= 0 kicking
  down; the CVT's torque without eta; C not scaled by the air density; A + B v without cos(theta); EpaVehicle's torque
  scaled 1.001; the radius from the final drive (4.411) instead of EPA's axle (4.41); LBF_N rounded; the mass a curb
  weight; vehicle_for giving an EpaCar the Supra's Vehicle; the EPA set's form converted as a number; the B58's table
  fallback returning None; build_candidate taking a NumPy value; the freeze check skipped; step_record's CVT branch
  removed; fingerprint's CVT refusal removed; trainable() returning known(); train.py and evaluate.py back on known();
  a spec's top-level key set unchecked; a converted field also typed; EpaCar's type check removed; CvtCar's checks
  removed; calibrated() ignoring the freeze record. The first run found one test gap and one script fault, both
  closed before the final run: `calibrated_ignores_freeze` passed (test_engine_threading gained a
  derived-file-present, freeze-missing case), and four mutations with multi-line anchors were not applied to CRLF
  files (the script now converts the anchors' line breaks). Before that run, `launch_at_rpm_min` could not have
  failed while the fixture's cvt_rpm_min equalled its rpm_min, so test_cars gained a 1200 rpm floor first.

## 22 October 2026, WP1 P5, the review's fixes (`P5fix`)

### `tools/run_suites.sh`: WP1's own suites on the candidate side (review should-fix 11)

- **Where:** the `quick` block, three new lines before its `wait`, and the header comment's `quick` line. The script
  has no reference side (every label is `cand_*`), so nothing of a reference changed.
- **What:** `one cand_test_cars $CAND $PY test_cars.py -v &`, `one cand_test_trainable $CAND $PY test_trainable.py -v &`
  and `one cand_test_fuel_forms $CAND $PY test_fuel_forms.py -v &`.
- **Why:** §3.6 item 15 of the full list runs `run_suites.sh quick`, which ran test_wide_air, test_engine_threading,
  test_epa_map, test_plant_guards, random_road and fingerprint only, so the certificate would have skipped the three
  WP1 suites, amendment B8's `--help` runs and refusals (test_trainable) among them.
- sha256 before `b20a731dcfc7db38dd3be594796692e57eee2ea63cd8033f1c6be6f7a38589cf`, after
  `e1efa910f3bff62eba4ac419152bbf9aaf2598a356bc46b29985de1204f9b82b` (the before copy:
  `scratchpad/p5fix/run_suites_before.sh`; `diff` shows the four lines only).

### Not edited

- `harness.py` (`38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`, the P4 version), `run_jobs.py`
  (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py`
  (`c57d1db4…1285`): re-hashed, unchanged. **Why no harness edit:** the fixes change no interface it calls. The B58
  is still `engines.get("b58")`; `vehicle_for`, the B15 guards and `Vehicle` are as in P5 for an `engines.Car`; the
  new `_ThreeTermRoad.DELIVERABLE_TORQUE`, `is_candidate`, the candidate mark and the published file in
  `spec_files` touch EPA cars, candidates and EPA plants only; `step_record.gear` refuses a CVT only.
- Jobs files: `jobs_P5.txt` and `jobs_ctl_P5.txt`, unchanged (sha256 `0c4e1669…91db`, `695593dc…cfa2`).

### Results (out/; the tree: P5 plus the review's fixes in the working tree on HEAD 7ea42f5; plant_sha 38d8c7e01a515e51, plant_text_sha 7243314e7232673d, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5fix` | none | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 312 s |
| `ctl_P5fix_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5fix` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL (P5's counts) |

plant_sha moved f5c11de53cbe7c9c -> 38d8c7e01a515e51: engines.py's code (`_python_scalars` by annotation,
`spec_files`, `is_candidate`, the candidate mark) and engine_env.py's (`_ThreeTermRoad.DELIVERABLE_TORQUE`, CvtVehicle's
alias dropped). derived_sha and engine_sha did not move.

### Scratch scripts of the P5 fix (not certificate tools; in `scratchpad/p5fix/`)

- `supra_pin.py <tree>`: the Supra's `Vehicle.demand` doubles on test_cars.py's pinned grid, hashed; `Vehicle()` in a
  tree without engines.py. Run on `ref` (cf43fbb) and on the candidate: both
  `d0f458126a512e480e5011d2c758899cc888c27dc4248ae2783e4d258db1cbea` (2208 doubles), the digest test_cars.py pins.
- `edit_threading.py`, `edit_threading_b13.py`, `fix_b13_escapes.py`: the anchored edits of test_engine_threading.py
  (`is_candidate` in QUALIFIED, the scan control and Signatures; amendment B13's comment check). The shell turned two
  escapes of the second into control characters; the third put them back, and a scan of every changed file finds
  no control character.
- `mutate.sh` and its result `mutate.txt`: P5's scheme (a minimal tree copy per mutation, then test_cars,
  test_engine_threading Registry and Signatures, test_trainable). The unmutated copy passes and all 17 mutations
  fail: the review's five survivors (Vehicle.demand's sum regrouped; engine_env.grade_floor's and
  wide_air.grade_floor's own guard off; N_hi unbounded; fingerprint.py's CLI without `refuse_uncalibrated`), each other
  builder's own guard off alone (min_tractive_force, extreme_speed_profile, wide_air.speed_profile), the published file
  left out of `spec_files` or passed through unnormalised, the candidate unmarked or not refused by
  `plant_fingerprint`, the EPA car's empty table naming derive_params.py, `_python_scalars` taking any of float, int
  and str or a float in an int field, a CVT recorded as gear 0, and the Supra's `kind` comment without its label.

After `cand_P5fix` and `ctl_P5fix_mass`, one docstring-only edit of derived.py (a reflowed paragraph): plant_sha
38d8c7e01a515e51 before and after (code-only hash), plant_text_sha 7243314e7232673d -> 3eaed2f2d997da2b. Re-run, as
P5's own docstring edit was: `cand_P5fix_final` (jobs_P5.txt against `ref`) BIT-IDENTICAL, all five (115173, 76498,
76498, 60331, 60331 values), 232 s. The final tree's fingerprint: plant_sha 38d8c7e01a515e51, plant_text_sha
3eaed2f2d997da2b, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2.

## 22 October 2026, WP1 P5, the second review's fixes (`P5fix2`)

### Not edited

- No tool was edited. `harness.py` (`38c9f119…df46`), `run_jobs.py` (`015510b4…bf18`), `compare_all.sh`
  (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py` (`c57d1db4…1285`), `jobs_P5.txt`
  (`0c4e1669…91db`) and `jobs_ctl_P5.txt` (`695593dc…cfa2`) were hashed before the runs
  (`scratchpad/p5fix2/tool_hashes_before.txt`) and again after: unchanged. **Why no harness edit:** the fixes change
  no interface the harness calls. The B58 is still `engines.get("b58")`. The new converters `_epa_table` and
  `_epa_floats` are the EPA set's only (`CONVERT_BY_SET["epa"]`), and the B58's `_table`, `_floats` and `float` are
  untouched. CvtCar's new reserve check runs for a CvtCar only. The rest are tests and two README sentences.

### Results (out/; the tree: P5, the first review's fixes and the second's, in the working tree on HEAD 7ea42f5; plant_sha 1c74d8d02537cb8f, plant_text_sha f111ce8929488ea0, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5fix2` | none | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 290 s |
| `ctl_P5fix2_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5fix2` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL (P5's counts) |

plant_sha moved 38d8c7e01a515e51 -> 1c74d8d02537cb8f because engines.py's code changed (`_epa_table`, `_epa_floats`,
the EPA set's converter map, CvtCar's reserve check). derived_sha and engine_sha did not move.

### Scratch scripts of this fix (not certificate tools; in `scratchpad/p5fix2/`)

- `mutate.sh` and its result `mutate.txt`: the first fix's scheme (`scratchpad/p5fix/mutate.sh`'s `run()`). The
  unmutated copy passes (exit 0), and all 13 mutations fail: the environment back on `Vehicle(plant.car)`;
  `typed_engine` in the B58's set; the CX-9 typed at EPA's axle 4.41 (a test-file mutation standing for P6);
  EpaVehicle's final drive x (1 + 1e-5); the radius from `[final_drive]`; CvtCar's reserve check removed, or made
  `<=`; the EPA table or either envelope back on the B58's converters; a float rpm let into the table; a NaN
  fallback added to `_epa_floats`; `_epa_table`'s None fallback removed.

## 22 October 2026, WP1 P6 (the six EPA specs and the registration)

### Tools: not edited

- `harness.py` (`38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`, the P4 version), `run_jobs.py`
  (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`, P5fix's): re-hashed before the runs, unchanged. **Why no harness
  edit:** P6 adds six spec files and three `engines.PLANTS` entries, refactors `engines.calibrated` into
  `engines._missing_files` and makes `engines.py`'s `__main__` list an uncalibrated plant. The harness builds the B58
  with `engines.get("b58")`, whose `_build` reads `b58.toml` and `a90_supra.toml` only; no job calls `name_of`,
  `calibrated`, `spec_files` or the listing, so no harness path reaches the new specs.

### New jobs file (`tools/`, CRLF, a `#` line heads it)

- `jobs_P6.txt` (sha256 `952010d96f6ffeb4af57f6f6eba1b3049f1fc2bbee8a895d63511a17c296bc39`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3). No wideair job: P6 touches
  nothing `wide_air.py` reads.

### Results (out/; the tree: P6 in the working tree on HEAD 1b0e83f; plant_sha e85d442a4015a86f, plant_text_sha deef1edf338c45e8, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P6` | none; engines.py final, the specs before two wording edits | jobs_P6.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values), 88 s |
| `cand_P6_final` | none; the final tree (the MZ19 citations reworded to PDF pages, one README paragraph) | jobs_P6.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values), 90 s |

plant_sha moved 1c74d8d02537cb8f -> e85d442a4015a86f because engines.py's code changed (PLANTS, `_missing_files`,
`calibrated`, `__main__`); the six new specs are not in the B58's plant_files. derived_sha and engine_sha did not move.

### Scratch scripts of P6 (not certificate tools; in `scratchpad/p6/`)

- `mz19_dl/mz19.pdf`: Mazda USA's 2019 CX-9 specifications (MZ19), fetched 22 October 2026 into its own folder,
  sha256 `aa0c19ad21248f1c17c72be13248ff2179fa8c393ea0ac95e194b36a296c45fb`; `mz19_txt/mz19.txt` its pdftotext text;
  `mz19_pages.py` (run `-I`, outside the download folder) the pages that print the torque: PDF pages 2, 8, 14, 21
  (Sport, Touring, Grand Touring, Signature), each "TORQUE 310 lb-ft @ 2,000 rpm", "BORE X STROKE (MM) 89 x 100",
  "DISPLACEMENT (CC) 2488" (decision 43).
- `compute.py <repo>`: the arithmetic the specs type (the Mazda's stroke, the conrods, the displacements, the scaled
  loop gains, the peak torques); no EPA row read.
- `make_specs.py <repo>`: the Honda's and the Ford's engine specs from the Mazda's text, each differing line replaced
  whole, each anchor asserted once.
- `edit_guards.py <file>`: the anchored CRLF edit of test_plant_guards.py's DerivedFingerprint.
- `mutate.sh` and its result `mutate.txt`: P5's scheme (a minimal tree copy per mutation; then test_carried,
  test_cars RegisteredCars, test_engine_threading Registry and Signatures, test_plant_guards DerivedFingerprint,
  test_trainable). The unmutated copy passes (exit 0) and all 20 mutations fail: one plant left out of PLANTS;
  calibrated() always yes; the listing's skip removed; the listing naming the last missing file; `_missing_files`
  ignoring the freeze record; DerivedFingerprint's skip removed; a carried value moved (the Mazda's c_turb); a carried
  value's marker dropped (the Honda's fres_a); the Honda's floor at 0.70; the Ford on one turbine; the Mazda's stroke
  at MZ19's 100 mm; the CX-9's peak torque rounded to 420.3; its final drive at EPA's 4.41; the Accord's top ratio at
  0.4; the F-150 pointed at the CX-9's published file; the form typed in the Mazda's spec; the Ford's freeze comment
  without its label; the Honda's feed-forward slope left at the B58's.
- `verify_docs.txt`: `verify_docs.py` on the P6 tree (read-only): "All 74 checks pass (959 figure mentions scanned)".

## 22 October 2026, WP1 P7 (the polish: the reviews' should-fix items)

### `tools/harness.py`: the `fuel.<field>` route also reaches `engines._TYPED` (the review of P1, should-fix 3)

- **Where:** inside `if NEW:` -> `if _pert:` -> `elif rec_name == "fuel":`, after the `with_fuel` replace (7 lines:
  a 4-line comment, the assignment, a 2-line print). The candidate side only; nothing else in the file moved.
- **What:** `engines._TYPED["b58"] = replace(engines.typed_engine("b58"), fuel=PLANT.engine.fuel)`, then
  `PERTURBED fuel.<field> also in engines._TYPED['b58']: <value>`, read back through `engines.typed_engine("b58")`.
- **Why:** P1 put the fuel in the TypedEngine too (`calibrate_thermal.load_drive` reads `typed_engine("b58").fuel`),
  and the route set `engines._BUILT["b58"]` only, so a job that reached the typed engine would have read IDENTICAL
  for the wrong reason (mistake 25). None of the 34 jobs reaches it today (the review's finding); the route now
  covers both caches, as P1's scratch `callers_dump.py` did. **Not changed, and why:** the generic, F32 and SET
  routes also leave `_TYPED` as built. They move cycle, ecu, thermal or car fields; the TypedEngine holds geometry,
  cycle, charge and fuel, so a cycle-field control would leave the typed cycle stale. No job reaches
  `typed_engine` (it is read by build_dataset.py, new_drive.py and the thermal fit, none of which a job runs), so
  it is recorded here rather than coded: a future job that does must sync `_TYPED` the same way.
- **Reference side:** untouched. With `HARNESS_PERTURB` unset (or set to a non-fuel field) the block is not
  entered, so every other run is unchanged. Checked: `diff` of the edited file against the P4 version (copied to
  `scratchpad/p7/harness_before_P7.py`, sha256 `38c9f119…df46`, before the edit) is one insertion of 7 lines after
  line 53; every line is CRLF, as the file's are (491 of 491).
- sha256 after the edit: `0e06275cc64e0eba940dbf2d3aa5a240211be92908b98db99ce2e921a6f4a480`.
- **Used by:** `ctl_P7_afr` (below). Its log's first line is `PERTURBED fuel.afr_st also in engines._TYPED['b58']:
  14.700000000000001`.

### New jobs file (`tools/`, CRLF, `#` lines head it)

- `jobs_P7.txt` (sha256 `662df4ad474c61e2f52987b29f4f0272a13601c8a6ab4d0ac43d971f2ea1385a`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3), wideair:single:0.0:101.3:12:random,
  wideair:locked:45.0:80.0:11:neutral (P5's pair) and `cond:baseline ECU:315.0:101.3:0.12:locked`, the cond job the
  review of P5 found missing from `jobs_P5.txt` (should-fix 5: P5 changed `step_record.gear`, which the cond jobs
  record; that review's own run `rvw3_P5_extra` read BIT-IDENTICAL on it and three more).

### Not edited

- `run_jobs.py` (`015510b4…`), `compare_all.sh` (`2220420c…`), `cmp.py` (`3d424f8b…`), `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`), `lab_dump.py` (`7115fabd…`), `lab_compare.py` (`2dfa1b0b…`),
  `jobs_units.txt` (`a8537a4e…`): re-hashed, unchanged. **lab_compare.py not edited, and why:** the review of P4
  suggested comparing the text of each resolved source line, not only its number. P7 makes the one anchor that
  moved deliberate instead (the lab's "air" concept, `match` "m_air =", line 219: the m_air assignment), and the
  comparison below shows it, and the clip's two re-worded texts, as its only differences beyond line numbers and
  build step 1's three strings. A text comparison of every resolved line stays an option for the full list's
  item 12 (docs/build_step_2/HANDOFFS.md, commit A).
- `lab_compare.py` printed through cp1252 and stopped at the first Arabic string: run with `-X utf8` (no edit).

### Results (out/; the tree: P7 in the working tree on HEAD c77640a; plant_sha 04753d8fa99cc2e3, plant_text_sha ec69d3be215d273f, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P7` | none | jobs_P7.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all six (115173, 76498, 76498, 60331, 60331, 53220 values), 280 s |
| `ctl_P7_afr` | `HARNESS_PERTURB=fuel.afr_st` (14.7 -> 14.700000000000001; the edited route) | jobs_units.txt | `cand_P7` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): cycle 3094/19200, cycle_dtheta 3/6, deliverable 12/58, deliverable_probe 2/10, predict 57/288; 72 keys IDENTICAL (P1's `ctl_P1_r1_afr` counts) |

The tree was hashed before and after the runs (`git diff --binary` plus `git status --porcelain`, sha256
`faf82de1…b56e83` both times). plant_sha moved e85d442a4015a86f -> 04753d8fa99cc2e3 because engines.py's code
changed (Fuel's finiteness check, Engine's bit comparison and the floor above 0, `_car_tuples`); thermal.py's edit
is a docstring. derived_sha and engine_sha did not move.

### Lab (read-only; `tools/lab_dump.py` on the repository, `tools/lab_compare.py -X utf8` against `lab/lab_ref_P4.json`, cf43fbb's)

- `scratchpad/p7/lab_cand_P7.json`, `lab_compare_P7.txt`: 36325 leaf values; 178 source-line numbers moved; 88
  re-worded strings (build step 1's three); 4 other differences, each intended: `/meta_en` and `/meta_ar`
  `concepts[4]/source/match` "m_air" -> "m_air =" (the air concept's anchor, the review of P4's should-fix 1), and
  `concepts[7]/range` (the fuel concept: the clip is the engine's, 0.70-1.25 on the B58; the review of P2's
  should-fix 7). Every number the lab computes is IDENTICAL.

### Scratch scripts of P7 (not certificate tools; in `scratchpad/p7/`)

- `mutate.sh` and its result `mutate.txt`: P6's scheme (a minimal tree copy per mutation; the master samples and the
  one logged drive the replay test reads copied in, never edited), each mutation undoing one P7 fix and running only
  the tests that guard it. The unmutated copy passes (77 tests, exit 0) and all 16 mutations fail (run twice; the
  second after the two skip controls were made to expect any plant already calibrated, so they skip, not fail, after WP4): Fuel's
  finiteness check off; Engine's copies compared with == again (-0.0 against 0.0); thermal_replay's LHV check off;
  thermal_replay given afr_st=14.7, or typed_engine("b58")'s; the floor's lower bound off; `_record`'s "is missing"
  reworded (a bare assertRaises would have passed it); `_car_tuples` off in EpaCar, and in CvtCar; `c2_errors`
  without the plan's comparisons (the 4.411 control then fails); the live Supra's sum regrouped; `fingerprint._git`
  back on strip(); the scan's literal rule off; each of the three uncalibrated_or_skip calls removed (its control
  then fails on the Mazda's subtest).
- The scan's literal rule on the live text, read-only: `scan_source` of car_thermal.py as it is gives `[]`; with
  `afr_st=14.7` it flags `measured_fuel_gps` "afr_st (a literal)"; calibrate_thermal.py and model_vs_data.py give `[]`.
- `verify_docs.py` on the final P7 tree (read-only): "All 74 checks pass (959 figure mentions scanned in the
  documents)", in `scratchpad/p7/verify_docs_final.txt`. `docs/build_step_2/HANDOFFS.md` is untracked, so not scanned;
  its first line declares it a dated record once committed.

## 22 October 2026, commit A: the certificate run prepared (amendment B9)

The plan of the run is `CERT_PLAN_A.md` (S), its shell variables `env_A.sh`, its config for
`make_cert.py --config` `cert_A.json`, and its reproduce block `reproduce_A.json`. Nothing of the
repository was edited.

### `tools/make_cert.py`: parametrised (amendment B9)

- **Before the edit:** the archive's, sha256 `a6cd572e5166ecddf551ce835e7bade164a469ae72fbd95b65b613af433e4c7a`
  (equal to `results/B58_IDENTITY/certificate_tools.tar.gz`'s `tools/make_cert.py`, `cmp`; copied to
  `scratchpad/cert2_bs1_snapshot/tools_before_B9/`). LF line ends, kept.
- **What:** three insertions, nothing changed or removed (`diff`: `3a4,8`, `29a35,43`, `137a152,543`):
  1. the docstring names the second usage, `make_cert.py <out.json> [<archive>] --config <cert_A.json>`;
  2. before `OUT = sys.argv[1]`: `--config <file>` is taken out of `sys.argv` when present (when absent,
     `sys.argv` is untouched);
  3. after `lines_matching()`, before build step 1's `cert = {}`: the commit-A block (`commit_a()` and its
     helpers) and `if CONFIG is not None: sys.exit(commit_a(CONFIG))`.
- **What commit_a() writes:** commit A's certificate from what the run wrote, as the config names it:
  the run groups' records (`cert_results/*.json`, each a list of {level, item, command, cwd, expected,
  got, verdict, seconds, evidence_files}; each record checked for those keys and a verdict PASS or
  FAIL; each evidence file hashed, or MISSING), the fingerprints at the start and the end, the
  manifests, compare_all.sh's reports (the harness by family, as build step 1's code groups it, and
  every harness control recomputed by control_verdict.py's rules, with `--allow-missing`), value
  counts from the comparison JSONs, the lines the config's regular expressions read from the runs'
  outputs (the B11 line of test_fuel_forms.EngineSha among them), the previous certificate read from
  git (`c47907b:results/B58_IDENTITY.json`: build step 1's plant_sha, derived_sha, engine_sha), X1's
  `meta.json`, `pip freeze`, `git rev-parse` / `git log` / `git archive` (the reference's full sha and
  tar sha256, the commits on the base), the tools' hashes and the archive. The verdict is the AND of
  ten checks (every record well formed; every record PASS; every required item answered; the harness
  BIT-IDENTICAL; every control as expected; the plant's fingerprint the same at the start and the end;
  derived_sha and the shared FATAL fields as the reference's; engine_sha over build step 1's keys equal
  to build step 1's; the manifests equal; every value count read), with the config's pending items
  (L8) listed beside it. No hash and no count is typed in the code or the config; the prose (what,
  asked_by, notes, not_covered, tools_note, verdict texts) is the config's.
- **Reference side (build step 1's mode) shown unchanged:** run without `--config` against S as it
  stood before this edit (`scratchpad/cert2_b9/bs1_before.json`) and after every edit of this entry
  (`bs1_final.json`): the two JSONs differ in the `tools` block only, in the four entries this entry
  adds or changes (`make_cert.py`, `make_md.py`, `cert_record.py`, `l9_check.py`). And `bs1_before.json`
  against the committed `results/B58_IDENTITY.json`: HEAD, the two hashes the page says the archive
  cannot re-make (`reference.archive_sha256`, L7's `scratch_final_zip`) and the `tools` block (WP1's tool
  edits), nothing else.
- **Shown able to fail:** a dry run on synthetic records (`scratchpad/cert2_b9/cert_dry.json`,
  `fakeS/cert_results/`) reads NOT CERTIFIED with a malformed record, a FAIL record, MISSING items, a
  control without its allowance (INCOMPLETE), a control expected DIFFERENT on two identical labels
  (FAIL) and a control with no compare report (INCOMPLETE), and PASS on P7's real `ctl_P7_afr` and
  P3fix's `ctl_P3fix_AB0`; the real `cert_A.json` before the run, with no record and no run file,
  reads NO on all ten checks (`real_config_after_move.json`).
- sha256 after: `409ed68017e57af6f614795bb49edbd0753a70de35a2f8a23e1e2c1488647806` (1150 lines).

### `tools/make_md.py`: parametrised (amendment B9)

- **Before:** sha256 `1fec2b48b22d2e5c7d2e856b19fd6a1d7819c23930ed4432c854ebc0dc2110d1` (the archive's).
- **What:** two insertions (`diff`: `7a8,11`, `13a18,247`): the docstring's paragraph, and after the JSON
  is loaded, `commit_a_page()` and `if c.get("certificate_format") == 2: sys.exit(commit_a_page(c, out))`.
  make_cert.py's commit-A JSON carries `"certificate_format": 2`; build step 1's JSON has no such key,
  so its page is written by the untouched code below.
- **The page:** the verdict and its ten checks; what was compared (both fingerprints, build step 1's
  hashes from git, X1's meta.json, B11's stripped engine_sha, the shared FATAL fields, the git fields,
  the plant at the start and the end); the environment; the controls (recomputed, then the records of
  level `control`); the harness by family and every record level by level; the re-run list item by
  item with its record count and verdict, pending L8; every difference (the records' `difference`
  fields and the fingerprint fields that differ); what is not covered (pending, the config's list,
  every FAIL and MISSING); reproduce. Every number from the JSON.
- **Reference side shown unchanged:** `make_md.py bs1_before.json` before and after the edit:
  byte-identical pages (257 lines; `cmp`), re-checked after the last edit.
- sha256 after: `86e9c4c3de74b4853fdee1457b966ac661511eb6569972ba7fa0d08f8940123e` (592 lines).

### New tool `tools/cert_record.py`

- `python -I cert_record.py <group> --level --item --command --cwd --expected --got --verdict PASS|FAIL
  --seconds [--evidence ...] [--what] [--environment] [--difference]`: appends one record to
  `S/cert_results/<group>.json` (rewritten whole through a temporary file and os.replace). Refuses a
  verdict other than PASS or FAIL (a check that did not run is not recorded) and a group name that is
  not a plain file name; warns of an evidence file it cannot find. sha256
  `dc4850149ae586bb76496354efc1b905809647ce9fa08e90d2c33b20e4ac76fd`.

### New tool `tools/l9_check.py` (PLAN.md 3.6 item 17)

- `python -I l9_check.py <copy> <ENGINE_THRESHOLDS.json> [--since <unix s>] [--json out]`: the sha_text
  (CRLF read as LF, thresholds/common.py's rule, re-implemented so the copy's code is not imported) of
  `results/ENGINE_THRESHOLDS/b58_propagation.json` and every `ecu/*.json` in the copy against the
  contract's `generator_inputs_sha256`; fails on a missing file, an unlisted file, a differing hash,
  and, with `--since`, a file the run did not rewrite.
- **Shown able to fail:** on REPO's own committed files, 25 of 25 equal without `--since` (exit 0) and
  0 of 25 with `--since` the time of the check (exit 1). sha256
  `413ee19bc3720001cd47fafd0aaa78a980c6b2019788035294b20ca7594b57ba`.

### Not edited

- `harness.py` (`0e06275c…`, P7's), `run_jobs.py`, `compare_all.sh`, `cmp.py`, `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`), `run_writer.sh`, `run_l4.sh`, `run_l6.sh`, `check_l6.sh`,
  `run_app.sh`, `run_app_extra.sh`, `run_drift.sh`, `drift_control.py`, `make_archive.py`, `make_meta.py`,
  `lab_dump.py`, `lab_compare.py`, `l6_agents.py`, `l6_check.py`, `l7_diff.py`, `l7_expect.py`,
  `bd_dump.py`, `derived_check.py`, `copy_tree.py`, `manifest.py`, every jobs file: `cmp` against the
  copies taken before this entry's edits. Three choices made in the plan instead of an edit:
  - `run_suites.sh quick` runs `test_engine_threading.py` beside `fingerprint.py`, and that test creates
    `_scan_probe_*.py` in REPO for a moment, which `fingerprint.py`'s git_dirty counts. The plan runs
    test_engine_threading alone first (G7.0) and the quick list's other lines, written out with the
    script's own `one()`, after it (G7.2), with `test_carried.py` added (the review of P7, item 1).
  - `make_archive.py`'s SKIP_DIRS does not name `refw`, `candw`, `candt` or `pre`: the plan removes those
    trees before the archive is made (F.3), as build step 1's `refw` was.
  - `make_meta.py`'s `identity_override` text still says "build step 1's identity certificate": it is
    written into L7's scratch `meta.json` only, never a result.

### Prepared in S (no tool)

- `cand`, `candd`, `candw`, `candt`: `copy_tree.py` of REPO (1287 files each, all equal to
  `manifest_start_A.txt`: 1287 files, manifest sha256 `b2f45892f0842049`); `refw` = `cp -a ref`; `pre` =
  `git archive c47907b` (both `tar --compare`d: 0 content differences; `ref` likewise).
- `L5/backup` (run_writer.sh needs it; the archive leaves `backup` out), `L9`, `cert_results`, `cert_out`.
- Build step 1's candidate-side evidence (268 files: `L4/cand*`, `L5/cand_*`, `L6/*`, `L7/cand_*`, `L8/*`,
  `F2` but `new_drive_ref.txt`, `F11/cand_*`, `app/cand_*`, build step 1's lab and suites outputs,
  `cmp/L6_*`, `cmp/L8_*`, `out/fp_cand.txt`, `out/ref2`, `out/ctl_*`, `logs`, `repro`, the two manifests)
  moved to `scratchpad/cert2_bs1_snapshot/moved_from_S/`, listed with sha256 in `S/bs1_moved.txt`: this
  run writes the same names, and a step that failed to rewrite one would otherwise be read as fresh
  (the dry run's "every value count read" was ok before the move, on build step 1's `cmp/L6_*.json`).
  They are also in build step 1's archive (`results/B58_IDENTITY/certificate_tools.tar.gz` at c47907b),
  and the whole of S's evidence before this entry is copied to `scratchpad/cert2_bs1_snapshot/`.

### Scratch scripts (not certificate tools; in `scratchpad/cert2_b9/`)

- `move_bs1_candidate_evidence.py`: the move above. `write_reproduce_A.py`: `reproduce_A.json`.
- `bs1_before.json` / `.md`, `bs1_after.json`, `bs1_final.json`, `bs1_before_by_new_md*.md`: the
  build-step-1-mode checks. `fakeS/`, `cert_dry.json`, `dry.json`, `dry.md`, `fp_now.txt`: the dry run.
  `real_config_before_run.json`, `real_config_after_move.json`: the real config before the run.

- **Addendum, the same day (the plan's G1.7):** in a fresh extraction of build step 1's archive, with the
  edited `make_cert.py` and `make_md.py` copied beside the unedited ones (as `make_cert_A.py`,
  `make_md_A.py`, so that both see one tools folder and one tools block), the two write byte-identical
  JSON (`BIT-IDENTICAL at every level`) and byte-identical pages (257 lines); against the committed
  `results/B58_IDENTITY.md` the page differs at line 30 only (HEAD, and the cf43fbb tar's sha256, which
  the archive cannot re-make). The test folder was removed; the plan's G1.7 repeats it.

- **Addendum, last edit of the day:** `make_cert.py`'s commit-A verdict writes the harness value count as
  MISSING, not 0, while the harness rows are MISSING (a page before the run read "harness: 0"); one
  condition added in `commit_a()`, nothing else. sha256 after it:
  `1421fda829c5eba0f15dde6e3ca94b93658208e4fdddfc625711c4cbbe55d467` (1151 lines; it replaces
  `409ed680...` above). The G1.7 check re-run on it: JSON and page byte-identical, the committed page
  differs at line 30 only (`S/prep/b9_build_step_1_mode.txt`).

## 23 October 2026, commit A, the final step (F: the certificate written)

The run's seven groups were done (G3-roads, G4-data and G6-agents resumed after a usage limit, G5's
three FAIL records rechecked by G5-recheck as records 24 to 26 of `cert_results/G5-app-lab.json`).
make_cert.py then refused two things the run held, though the plan had foreseen both: G5's rechecks
(verdicts written "PASS (...)" with a `rechecks` field, appended by `scratchpad/cert2_G5r/append_record.py`,
which cert_record.py cannot write) and the two files G5 changed in the repository during the run
(CERT_PLAN_A.md F.1: "list the files in `cert_A.json`'s `candidate.files_changed_note`, and a plant file
among them voids the run"; the tool's manifest check read only `r0 == r1`). Two edits, inside the
commit-A block only; G5's records are read as written, never edited.

### `tools/make_cert.py`: rechecks and declared changed files (commit-A block only)

- **Before:** sha256 `1421fda829c5eba0f15dde6e3ca94b93658208e4fdddfc625711c4cbbe55d467` (1151 lines, the
  addendum above), copied to `scratchpad/certF/tools_before_F/`.
- **What** (`diff`: `248a249,253`, `260a266,303`, `333a377`, `384a429,438`, `457c511,512`, `458a514,516`,
  `466,467c524,527`, `498c558,559`, `511c572,575`):
  1. `_records()`: every record gets `record_id` ("<group>.json record <n>", n from 1); a verdict
     "PASS (<why>)" is read as PASS **only on a record with a `rechecks` field**, the text kept as
     `verdict_as_written` and `verdict_note`. Any other verdict that is not PASS or FAIL is still a problem.
  2. New `_rechecks()`: a `rechecks` field must name an earlier FAIL of the same file
     ("<group>.json record <n>"), and the recheck must be a PASS; then the FAIL gains `rechecked_by`
     and stays a FAIL, the recheck gains `rechecks_record`, and the pair is listed in
     `records.rechecked`. Any other `rechecks` is a problem (fails "every record well formed").
     New `_closed()`: PASS, or a FAIL a later PASS record rechecks.
  3. The check "every record PASS" became "every record PASS, or a FAIL that a later PASS record
     re-checks (both kept)"; an item of the re-run list is PASS when each of its records is closed,
     and lists `answered_by` (the groups whose records name it) and `rechecked_fails`.
     `records.failed` keeps every FAIL, with its `record` and `rechecked_by`; `records.failed_not_rechecked`
     counts the open ones.
  4. `candidate.files_changed_declared` (config: `[{path, by, why}]`): the check "the repository
     unchanged during the run (manifests)" became "... (manifests), but for the files the config
     declares, none a plant file": it holds if exactly the declared files changed (set equality,
     so an undeclared change and a declared non-change both fail), and, when any did, the end
     fingerprint's `git_dirty_plant_files` is empty on the start's `git_head`. With no declaration it
     is the old `r0 == r1`. The JSON gains `files_changed_declared`, `files_changed_as_declared`,
     `plant_files_dirty_at_the_end`, `git_head_at_the_start_and_the_end`.
- **Build step 1's mode unchanged:** the plan's G1.7, again, on build step 1's archive (HEAD's): JSON and
  page byte-identical (257 lines), the committed page differs at line 30 only
  (`S/prep/A_F_build_step_1_mode.txt`; F-certificate.json record 10).
- **Shown able to fail:** `scratchpad/certF/dry_rechecks.py` runs make_cert on mutated copies of the real
  records and config: the real ones read BIT-IDENTICAL with three pairs (records 9-24, 19-25, 22-26); each
  of ten mutations reads NOT CERTIFIED with its check NO (a "PASS (...)" without `rechecks`; a recheck
  naming a PASS, a later record, no record; a recheck that is a FAIL; an unrechecked FAIL; one changed
  file undeclared; a declared file that did not change; a plant file dirty at the end; no declaration)
  (`S/prep/A_F_make_cert_dry.txt`; F-certificate.json record 11).
- sha256 after: `e862b1a67240c505e17c9a5fc6d87fbe199435451035a33ae223288c466648d6` (1215 lines).

### `tools/make_md.py`: the page shows both records of a recheck, and the declared files (commit-A page only)

- **Before:** sha256 `86e9c4c3de74b4853fdee1457b966ac661511eb6569972ba7fa0d08f8940123e` (592 lines).
- **What** (`diff`: `39a40,53`, `54c68,69`, `137,138c152,153`, `168,169c183,184`, `183c198,201`, `201a220,225`,
  `209a234`, `210a236,241`): `vcell()` (a record's verdict with its note, "re-checks <record>" and
  "re-checked by <record>") and `rid()` (the record's id beside its cwd and seconds) in the level and
  control tables; the verdict line counts the rechecked FAILs; the re-run list shows the answering
  groups and any rechecked FAIL; section 5 lists each declared file with who changed it and why, and
  whether the change is as declared; section 6 writes each rechecked FAIL with its own `got` and its
  recheck's verdict and `got`.
- **Build step 1's page unchanged:** as above (G1.7 again).
- sha256 after the recheck edits: `2393100a51222d4909c9b0a0e7336f7e5ae4957169494d363c0af62d1e6ef359` (623 lines).

### A second edit of both tools: `page_markers` (the drift control asked for it)

The drift control with the draft in the tree read exit 1, and `verify_docs.py` named three lines of the
page, each a record's own words that a figure's pattern reads as that figure (F-certificate.json record 12;
no figure of the plant is wrong, and the page quotes no value this run computed as a live claim). The
records stay verbatim, so the page carries a figure-specific `RETIRED-OK` marker above the three tables
that hold them, as `verify_docs.py`'s own mechanism asks (AUDIT2.md H2-6: a marker excuses only the
figures it names, in that table).

- **`tools/make_cert.py`:** `out["page_markers"] = cfg.get("page_markers") or {}`, and the key in the
  output order. Nothing else; the markers are prose in the config, no hash and no count.
- **`tools/make_md.py`:** above section 2's control table and above each level table, the marker the
  config gives for that key, written as an HTML comment.
- **`cert_A.json`:** `page_markers` for `control` and `L2` (the conditions jobs are named by their ambient
  air in kelvin, which the premise pattern reads as the baseline damage) and for `L5` (G4-data's count of
  build_dataset's derivations, one per log, which the validate pattern reads as the quantities inside
  their band), each with `_what` saying why.
- **F-certificate.json record 12** is reworded to name those two figures in words instead of in the matched
  form, so the docs table needs no exemption; its raw output is in its evidence files
  (`suites/A_F_verify_docs_draft_try1.txt`, `cert_out/B58_IDENTITY_try1.md`). It keeps its FAIL verdict and
  is the only record of this run whose wording was changed after it was written; no other group's record
  was touched.
- The sha256 of both tools after this edit is not typed here: the certificate's own `tools` block carries
  every tool's hash, read by make_cert.py from the file (and `out/A_G1_tool_hashes.txt` holds the hashes as
  they were when G1 ran, before the final step's two edits).

### The config and the reproduce block (`cert_A.json`, `reproduce_A.json`; no tool)

- `cert_A.json`: `date` 2026-10-23; `candidate.head_note` no longer says "clean"; `candidate.files_changed_declared`
  (the two files, by G5-app-lab, with why) and `files_changed_note`; four `not_covered` entries (what did
  not run besides L8; the failures on both trees; where the run left its plan; the last two checks);
  `notes.nothing_computed_moved` (prose, no number).
  Before: `scratchpad/certF/tools_before_F/cert_A.json`.
- `reproduce_A.json`: the REPO convention says the two files changed; a step F.2 (the documents check and
  the draft); F.3 runs make_cert.py and make_md.py with `-X utf8` (`-I` ignores PYTHONIOENCODING, and
  printing a record with a character cp1252 lacks raised UnicodeEncodeError after the JSON was written)
  and names the last verify_docs.py. Before: `scratchpad/certF/tools_before_F/reproduce_A.json`.

### Not edited

- Every other tool, and every group's records (`cert_results/*.json` but `F-certificate.json`, which this
  step writes with cert_record.py). G5's records 24 to 26 are read as G5-recheck wrote them.

### Removed before the archive (CERT_PLAN_A.md F.3)

- `S/refw`, `S/candw`, `S/candt`, `S/pre` (make_archive.py's SKIP_DIRS does not name them).

### Two later edits of the config, and the archive made again

After the first archive, `cert_A.json` gained two things, so the archive was made again and
`make_cert.py` / `make_md.py` run once more, in the order CERT_PLAN_A.md F.3 gives (archive, then the
JSON that records its sha256, then the page):

1. `not_covered`: "a check of this page cannot be inside it" — the drift control on the final files, the
   last `verify_docs.py` and the final step's own last records are in `cert_results/F-certificate.json`
   and in the report of the run, not in the JSON or the archive.
2. `pending` gains item 15's one part that did not run (`test_epa_map.py` a second time, with
   `GRAD_EXTRA_DATA` naming the MY2021 and MY2023 Test Car Lists, which are not on this machine), and
   item 15's `asks` says so. Before this, the re-run list read PASS for item 15 while part of what it
   asks had not run; the not-covered list said so, but the table is what is read first.

3. The `drift_test` extract's pattern now ends at `(all parts)`. `run_drift.sh` concatenates the six
   parts and appends the sum, so `^(\d+ of \d+ drifts CAUGHT.*)$` matched part 1's own line and the
   JSON's extract read "3 of 3" where the run caught 18 of 18 (the record of the run, F-certificate.json
   record 9, always read 18 of 18, and the page prints the record, not the extract). Caught by reading
   the extracts of the finished JSON.

No tool changed for any of the three. Every other member of the archive is the file the JSON names, hash
for hash; what came after the archive is the two final checks and the records of them.

## 23 October 2026, commit A, the certificate's text fixed after its review (F2)

An adversarial review of the files made at 05:18 (archive, JSON, page; its records are
`scratchpad/rev_A/R-review.json`, its evidence beside them) found the B58's identity holding, and the
certificate's own text wrong in two places (must-fix) and five more (should-fix). This step fixes them and
makes the archive, the JSON and the page once more, last.

### Tools: not edited

- Every tool in `tools/` has the sha256 the 05:18 JSON gives it (65 files, `.py`, `.sh`, `.txt`, compared
  before this step's first edit). make_cert.py and make_md.py are the final step's (`page_markers` included).
- G5's three re-check records now carry a plain verdict, so make_cert.py's reading of "PASS (<why>)" beside
  a `rechecks` field (the final step's edit) no longer applies to any record of this run. It is left in the
  tool: `dry_rechecks.py`'s mutations still show it refuses that form without `rechecks`.

### Records

- **`cert_results/G5-app-lab.json` records 24-26 (should-fix 7):** the verdicts "PASS (pre-existing, same on
  cf43fbb)" and "PASS (environmental, recurs no more)" (twice) became "PASS", the words moved into a
  `verdict_note` field beside each (make_md.py shows it in the record's verdict cell). Made by
  `scratchpad/certF2/edit_g5_verdicts.py`, which refuses unless the file re-dumps byte for byte and then
  checks that nothing else changed; the file as G5-recheck wrote it is `prep/A_F2_G5-app-lab.before.json`.
  The only change this run made to another group's record file (F-certificate.json record 21).
- **`cert_results/R-review.json` moved to `scratchpad/rev_A/R-review.json`**, unchanged (sha256
  `e6bf4a3c…`): make_cert.py reads every `cert_results/*.json`, the review's six FAILs are on the text of
  the certificate it reviewed, and one of them (CHECKPOINT.md's body) is the commit step's, so the file
  stays beside the records, not among them (F-certificate.json record 22). Kept outside S so that the
  archive does not carry the hashes of the two earlier archives the review quotes.
- **`cert_results/F-certificate.json`:** records 19-23 appended with cert_record.py (the MY2021/MY2023 fetch,
  test_epa_map.py with them, the G5 verdict edit, the review moved aside, the study page's stamp against the
  tree commit A holds). Record 16 is rewritten for the last make (must-fix 1): it described the first make,
  whose archive no file now holds. Records 17 and 18, which checked the 05:18 files, keep their command, expected
  and got and gain a `difference` field saying so; their labels (`what`), which called them the final certificate's and the
  last checks of the run, now name the 05:18 make; each record's `difference` quotes its first label. The before copy (records 1-23 before these two edits) is
  `scratchpad/certF2/before/F-certificate.after_19-23.json`.

### The config and the reproduce block (no tool)

- `cert_A.json` (before: `scratchpad/certF2/before/cert_A.json`):
  - `required`: item 3.6.11's asks names the committed tree 4461a91 and points to the pending part; item
    3.6.15's asks names the second test_epa_map.py run; a new row for item 3.6.19 (should-fix 1).
  - `pending`: item 3.6.15's part is gone (it ran: F-certificate.json records 19, 20; should-fix 6);
    "3.6.11 (part)", app.test_results again after the commit, on commit A itself, is added (must-fix 2).
    3.6.20 (L8) stays.
  - `asked_by`: item 11's run after the commit named beside item 20; `verdict_text.pass` names both pending
    items (L8 on the training device, app.test_results on commit A itself after the squash).
  - `candidate.files_changed_declared`, the study page: why its stamp names 4461a91, that 4461a91's tree is
    commit A's tree but for the eight files the run and the final step changed, none read by make_page.py,
    and that the page is left as built (should-fix 5).
  - `not_covered`: "What did not run here" (item 11's part pending, item 15 run whole); "Where the run left
    its plan" (G7.1 run by the final step; the reproduce block as run); "A check of this page cannot be
    inside it" rewritten to say which records are in the JSON (F-certificate.json 1-23) and which closing
    checks are not, and that the drift test on the final tree writes under `S/F2drift` (must-fix 1,
    should-fix 3); a new entry for the review kept beside the records.
- `reproduce_A.json` (before: `scratchpad/certF2/before/reproduce_A.json`; written by
  `scratchpad/certF2/write_reproduce.py`): every step as its records ran it, in the copies it ran in (S/cand
  for G2's writers; G5's and G7's own copies outside S for item 16 and L9, with `run_all(16)`; G4.1's
  `A_G2_` file names), the steps that did not run here marked "NOT RUN here" (L8; app.test_results on commit
  A), and the final step's last make and closing checks (should-fix 2).

### The last make (the order CERT_PLAN_A.md F.3 gives, once more)

1. A dry run outside S (`scratchpad/certF2/dry1`): make_archive.py, make_cert.py, make_md.py; the verdict and
   the counts read.
2. Record 16 written from the dry run (its counts; no hash of the archive: the archive holds the record, so
   the record cannot hold the archive's hash, which only section 7 gives).
3. A second dry run on the final records (`scratchpad/certF2/dry2`), verify_docs.py in a copy of REPO holding
   its three files, then the same three commands into REPO; the made files compared with the second dry run's,
   byte for byte.
4. The closing checks, after the make and so outside the JSON: drift_control.py on the final files,
   verify_docs.py, drift_test.py in six parts through `S/F2drift/tools/run_drift.sh` (a byte copy of
   `tools/run_drift.sh`; it derives S from its own folder, so it writes under `S/F2drift/suites` and leaves
   record 9's evidence in `S/suites` as it was), the plant's fingerprint and git status at the end. Their
   records are the last of F-certificate.json.

Nothing in the repository is edited by this step but the certificate's three files and CHECKPOINT.md's header
line for GRA-test (the pending list: L8, and app.test_results on commit A itself).

## 23 October 2026, commit A, the certificate's text fixed after its second review (F3)

A second adversarial review, of the files made at 06:12 (its records: `scratchpad/rev_A2/R2-review.json`; its
evidence: `scratchpad/rev_A2/work/`), found the B58's identity holding and the first review's items fixed, but for
CHECKPOINT.md's body (the commit step's). It found one new must-fix: the archive, unpacked as section 7 says, made
the certificate NOT CERTIFIED. It also found two record verdicts that did not follow the record rule. This step
makes one tool edit, changes records and the config, and makes the archive, the JSON and the page once more, last.

### `tools/make_archive.py`: out/ref archived (the second review's must-fix)

- **Before:** sha256 `5071d5e56612618b81de545473ecc7da96eb3e2fd8af2c8aa9d53f8857157579` (77 lines), copied to
  `scratchpad/certF3/before/make_archive.py`.
- **What** (`diff`: `14a15,20` a docstring paragraph, `25a32` `KEEP_DIRS = {"out/ref"}`, `34c41,42` the folder
  filter): a folder whose name SKIP_DIRS lists is still walked when its path relative to S is in KEEP_DIRS.
- **Why:** SKIP_DIRS names the scratch trees (`ref`, `cand`, `candd`, ...) and was applied at every depth. So
  `out/ref` was dropped along with `S/ref`. That folder is the reference harness run of 21 October: 34 logs,
  `_status.txt` and 34 `.npz`. make_cert.py reads `out/ref/_status.txt` for every control compared against `ref`
  (`_status_of`). In the unpacked folder those ten controls therefore read INCOMPLETE (exit `[None, 0]`), and the
  verdict read NOT CERTIFIED. Build step 1's archive (`a639190b…`) lacks out/ref too.
- **Effect:** the archive gains out/ref's 35 small files (the 34 logs and `_status.txt`). The `.npz` stay out
  (SKIP_EXT), and nothing else is added or dropped by the edit.
- **Shown able to fail** (mistake 12), with `scratchpad/certF3/scripts/repro_check.py` (copy:
  `prep/A_F3_repro_check.py`):
  - F-certificate.json record 34: the 06:12 archive, made by the unedited tool, made again from its unpacked folder,
    reads NOT CERTIFIED, with 228 differences that are not evidence hashes.
  - Record 35: the edited tool's dry archive (`scratchpad/certF3/dry0`) gives the same verdict and checks, and
    every value but the sha256 and bytes of evidence files the archive leaves out.
  - The archive commit A carries gets the same check as a closing record, after the make.
- **Build step 1's mode:** make_archive.py takes no part in make_cert.py and make_md.py's mode without `--config`
  (G1.7), so that mode is not touched.
- sha256 after: `b536855d307597197e0b7cb4bea192a36c30eec2f56b9e150daea1a0bcc3ecd6` (85 lines).

### Not edited

- The other 64 tools in `tools/` have the sha256 the 06:12 JSON's `tools` block gives them. They were compared after
  this edit; make_archive.py was the only one that differed.

### Records (`cert_results/F-certificate.json`; before: `prep/A_F3_F-certificate.before.json`, 29 records)

- **`cert_results/R2-review.json` moved to `scratchpad/rev_A2/R2-review.json`**, unchanged (sha256 `d61278aa…`;
  record 33). It moved for the reason R-review.json did: make_cert.py reads every `cert_results/*.json`.
- **Records 19 and 25 (should-fix 2, minor 3)**, by `scratchpad/certF3/scripts/edit_records_F3.py` (copy:
  `prep/A_F3_edit_records.py`; record 32):
  - Record 19, G7.1's fetch: its expected is CERT_PLAN_A.md G7.1's again ("exit 0, every file verified ..."), so it
    reads FAIL (the run exited 1). The words it was first written with are kept in `expected_as_first_written`,
    `verdict_as_first_written` and `difference_as_first_written`.
  - Record 25, the 06:12 make's closing check: its got is its first run's ("CLOSING CHECK: FAIL (34 of 35 ok)"), so
    it reads FAIL. `got_as_first_written` points to the before copy rather than repeating the 06:12 archive's
    sha256, so the page and the JSON give one archive hash.
  - Records 24-29 checked the 06:12 make's files: each label names that make, and a `difference` says so, as records
    17 and 18 were treated.
- **Records 30-35 appended** by `scratchpad/certF3/scripts/append_records.py` (cert_record.py cannot write
  `rechecks`):
  - 30 re-checks 19: G7.1's command, unchanged, with the seven EPA package zips the exit code also needs copied into
    `S/tcl` from the team's data folder, each checked against the list (`scratchpad/certF3/scripts/place_zips.py`,
    copy `prep/A_F3_place_zips.py`). It printed "ALL VERIFIED: 9 of 9 listed files, 18 of 18 repository copies",
    exit 0, and fetched nothing.
  - 31 re-checks 25: its second run.
  - 32 is the record edit.
  - 33 is the review moved aside.
  - 34 and 35 are the archive's control and pre-check.
- **Record 16 is rewritten for the last make** (`scratchpad/certF3/scripts/rewrite_16_F3.py`). Its counts come from
  the dry run, and it gives no hash of the archive.

### The config and the reproduce block (no tool)

- **`cert_A.json`**, by `scratchpad/certF3/scripts/edit_config_F3.py` and `edit_config_F3b.py` (the second after
  dry0's check listed what the archive leaves out), as string edits, so the file's layout is kept;
  before: `scratchpad/certF3/before/cert_A.json`. Changes to `not_covered`:
  - "Where the run left its plan": G7.1's FAIL and its re-check.
  - "A check of this page cannot be inside it": four makes, records 1 to 35 in the JSON, and the closing checks
    including the archive made again.
  - A new entry for the second review: its three FAILs, and that the commit step runs verify_docs.py,
    drift_control.py and drift_test.py again after its edit of CHECKPOINT.md's body.
  - A new entry, "What the archive makes again, and what it does not".

  Also changed: `tools_note` names make_archive.py's KEEP_DIRS, and item 3.6.19's `asks` names the archive's
  reproduction.
- **`reproduce_A.json`**, by `scratchpad/certF3/scripts/write_reproduce_F3.py`; before:
  `scratchpad/certF3/before/reproduce_A.json`.
  - A step for the reference harness run that makes out/ref, which the review found missing: run_jobs.py on S/ref
    with jobs_all.txt, 21 October, `S/ref_jobs.log`.
  - The S and REF conventions say what the archive holds of it.
  - G7.1 gains its re-check.
  - F2.2 and F2.3 are labelled as the 06:12 make's.
  - New steps F3.1-F3.3: this step, the last make and its closing checks.

### The last make (CERT_PLAN_A.md F.3's order, once more)

1. `scratchpad/certF3/dry0`, with the edited make_archive.py: make_archive.py, make_cert.py and make_md.py, then
   repro_check.py on its archive (record 35).
2. `scratchpad/certF3/dry1`, then record 16 written from its counts. Then `scratchpad/certF3/dry2` on the final
   records, and verify_docs.py in a copy of REPO holding dry2's three files.
3. The same three commands into REPO, each stdout to `scratchpad/certF3/final/`. The made files are compared with
   dry2's, byte for byte.
4. The closing checks, after the make and so outside the JSON:
   - `scratchpad/certF3/scripts/closing_check_F3.py`;
   - repro_check.py on the archive commit A carries;
   - drift_control.py on the final files;
   - verify_docs.py;
   - drift_test.py in six parts through `S/F3drift/tools/run_drift.sh` (a byte copy of `tools/run_drift.sh`);
   - the plant's fingerprint, git status and the manifest at the end.

   Their records are the last of F-certificate.json.

This step edits nothing in the repository but the certificate's three files. CHECKPOINT.md's body is left to the
commit step.
