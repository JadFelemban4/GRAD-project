# Edits to the certificate tools for build step 2 (append only)

Base: the tools of `results/B58_IDENTITY/certificate_tools.tar.gz` (sha256 `a639190b…01503fb`),
unpacked here as `tools/`. Rule: a candidate-side edit lives only inside a tool's NEW branch (a
tree that holds engines.py); the reference side (NEW False) stays byte-identical in behaviour.

## 22 October 2026, WP1 P1 (the fuel is the engine's)

### `tools/harness.py`: a `fuel.<field>` route for `HARNESS_PERTURB`

- **Where:** inside `if NEW:` → `if _pert:`, a new `elif rec_name == "fuel":` between the `car`
  branch and the generic record branch (8 lines, archive line 45).
- **What:** `HARNESS_PERTURB=fuel.afr_st` or `fuel.lhv_j_per_kg` moves that field by one float64 ulp
  through `engines.with_fuel(PLANT.engine, replace(PLANT.engine.fuel, field=nextafter))`, then the
  plant goes into `engines._BUILT["b58"]` as before.
- **Why:** P1 puts a copy of the fuel's LHV in the thermal record (`ThermalParams.fuel_lhv_j_per_kg`)
  and `engines.Engine.__post_init__` refuses the two copies apart. The generic branch
  (`replace(PLANT.engine, fuel=replace(fuel, lhv=...))`) would raise for the LHV, so the plan's §3.5
  control "one ulp on `fuel.lhv_j_per_kg`, through `with_fuel`" needs this route. `afr_st` has one
  copy and takes the same route (the generic branch would give the same plant).
- **Reference side:** untouched. With `HARNESS_PERTURB` unset the candidate side is also unchanged
  (the block is not entered). Checked: the edited file minus the 8 inserted lines equals the
  archive's `tools/harness.py` except three lines found with CRLF endings (archive lines 227-229,
  the `deliverable` comment and call), which were CRLF before this edit (behaviour identical).
- **Used by:** labels `ctl_P1_afr` (`HARNESS_PERTURB=fuel.afr_st`) and `ctl_P1_lhv`
  (`HARNESS_PERTURB=fuel.lhv_j_per_kg`), units job. The generic route was also run once as a
  negative control, `ctl_P1_divergent` (`HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg`): it must
  stop, and stops with Engine's ValueError (exit 1).
- sha256 after the edit: `50c047d5d92662fa0ead4466b6de5bb5ce22bce0c21353ab5ed3040f9d9a61ac`
  (archive copy `8d50e7633be7d3adb1d5a7db12bb2ad6206371b7ea4a26eee7df9c4c38b0cfe2`).

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the archive (`diff -q`).
- Jobs file: the existing `tools/jobs_units.txt` ("units"), unchanged.

### Scratch scripts of P1 (not certificate tools; in `scratchpad/p1/`)

- `keyset.py`: prints the asdict key set of the B58 in a tree (HEAD c47907b's was pinned in
  test_fuel_forms.py's BUILD_STEP_1_KEYS).
- `ulp_probe.py`: how one ulp on afr_st and the LHV reaches run_cycle, measured_fuel_gps, the network.
- `callers_dump.py`: what the three changed callers of measured_fuel_gps compute
  (calibrate_thermal.load_drive, model_vs_data.oil_inputs, car_thermal.thermal_replay), HEAD vs P1;
  `CALLERS_PERTURB=1` is its one-ulp afr_st control (candidate only).

## 22 October 2026, WP1 P2 (the policies' lambda clip is the engine's)

### `tools/harness.py`: a float32-step route and a bind count

- **Where:** two blocks, both candidate-side; nothing else in the file moved.
  1. Inside `if NEW:`, after the `if _pert:` block and before `KW = dict(plant=PLANT)` (15 lines):
     `HARNESS_PERTURB_F32=<record>.<field>` moves an engine-record field to the next float32 above
     float32(field), as a Python float (`float(np.nextafter(np.float32(old), np.float32(np.inf)))`),
     through one `replace` of the Engine (so Engine's checks run on it), then into
     `engines._BUILT["b58"]` as the other routes do. It prints
     `PERTURBED_F32 <field>: <old> (float32 <float32(old)>) -> <new>`.
  2. After `import engine_env as E`, under `if NEW and os.environ.get("HARNESS_BIND_COUNT"):`
     (23 lines): wraps `E.SupervisoryTunerEnv.step`. After each step it compares `info["lam"]` with
     `float(np.float32(bound))` for the plant's `ecu.lam_floor` and `ecu.lam_ceiling`, prints
     `BIND <floor|ceiling> at step <k>` (k counts every env step of the process, so it is the row of
     the dump's per-step arrays, which `run_env` fills one row per step) and, at exit (`atexit`),
     `BIND COUNT over <n> steps: floor <c> [...], ceiling <c> [...]`. The wrapper returns step()'s
     outputs untouched; every subclass (Terrain, Extremes, WideAir, the RandomClimb wrapper's env)
     inherits step(), so the patch reaches every job that steps.
- **Why:** amendment B1. After P2 the policies' clip reads `eng.ecu.lam_floor`, and the clip
  compares in float32 (`lam_b + act[1]` is float32 under NEP 50). The generic `HARNESS_PERTURB`
  moves the floor by one float64 ulp, 0.7 -> 0.7000000000000001, and float32 of both is
  0.699999988079071, so that control could not come out DIFFERENT (the plan's 3.5 expected it to;
  the amendments' wrong claim 2). The float32 step, 0.7 -> 0.7000000476837158, moves the binding
  output. B1 also asks for the bind count first ("1 at HEAD"), so that the control fails for the
  right reason.
- **Reference side:** untouched. Both blocks are entered only when NEW (a tree that holds engines.py)
  and their variable is set; with neither variable set the candidate side is unchanged too.
  Checked: the edited file against the P1 version (sha256 `50c047d5…9d9a61ac`, copied to
  `scratchpad/p2/harness_before_P2.py` before the edit) differs by exactly two insertions (difflib
  opcodes: insert after line 63, 15 lines; insert after line 69, 23 lines). Every other line is byte
  for byte the same; the P1 version is CRLF on every line, and so are the inserted lines.
- **Shown neutral:** `pre_P2_bind` (HARNESS_BIND_COUNT=1, the three quick jobs) is BIT-IDENTICAL to
  `ref` on all three.
- **Used by:** labels `pre_P2_bind` (HARNESS_BIND_COUNT=1, `jobs_quick.txt`), `ctl_P2_lamf32`
  (HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1, `jobs_ctl_P2.txt`), `ctl_P2_lamf64`
  (the generic HARNESS_PERTURB=ecu.lam_floor, one float64 ulp, plus the bind count), `ctl_P2_ceilf32`
  (HARNESS_PERTURB_F32=ecu.lam_ceiling plus the bind count) and `census_P2_bind`
  (HARNESS_BIND_COUNT=1, `jobs_census_P2.txt`).
- sha256 after the edit: `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`.

### New jobs files (`tools/`)

- `jobs_quick.txt`: units, extremes:double:12:random, terrain:single:11:neutral. The quick loop
  from P2 on (amendment B3: the units job never runs step(), which P2 edits). A `#` comment line
  heads it; run_jobs.py skips it.
- `jobs_ctl_P2.txt`: extremes:double:12:random, B1's control job.
- `jobs_census_P2.txt`: rr:120.0:0.16:random, rrwrap:7:3, wideseq:9:4:120, the three random-action
  jobs B1's bind count did not check.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`, the other jobs files.

### Results (out/, compared with `compare_all.sh ref <label>`)

| label | environment | jobs | against `ref` | bind count (`info["lam"]` on float32 of a bound) |
|---|---|---|---|---|
| `cand_P2` | none | units, extremes:double:12:random, terrain:single:11:neutral | BIT-IDENTICAL, all three (115173, 76498, 76498 values) | not asked |
| `pre_P2_bind` | `HARNESS_BIND_COUNT=1` | the same three | BIT-IDENTICAL, all three: the wrapper is neutral | extremes:double:12:random floor **1** of 1099 steps, at step 780 (lam 0.699999988079071), ceiling 0; terrain:single:11:neutral (neutral action) 0 and 0 of 1099; units 0 steps |
| `ctl_P2_lamf32` | `HARNESS_PERTURB_F32=ecu.lam_floor` (0.7, float32 0.699999988079071, -> 0.7000000476837158) and the bind count | extremes:double:12:random | **NOT IDENTICAL**: info, obs, reward, state and summary DIFFERENT, the 12 cycle and seed keys IDENTICAL. `first_diff.py`: the first differing row is **780** in info, obs, reward and state, the bind step; at row 780 lam 0.699999988079071 -> 0.7000000476837158, with egt_c, ki, mdot_exh, mdot_fuel, r_fuel, r_life, r_resp, t_turb and torque; 119 info rows differ (780-898, the rest of the first episode), the second episode none | floor 1, at step 780 (lam 0.7000000476837158), ceiling 0 |
| `ctl_P2_lamf64` | `HARNESS_PERTURB=ecu.lam_floor` (one float64 ulp: 0.7 -> 0.7000000000000001) and the bind count | extremes:double:12:random | BIT-IDENTICAL, as amendment B1 says: float32 of both is 0.699999988079071 | floor 1, at step 780 (lam 0.699999988079071) |
| `ctl_P2_ceilf32` | `HARNESS_PERTURB_F32=ecu.lam_ceiling` (1.25 -> 1.2500001192092896) and the bind count | extremes:double:12:random | BIT-IDENTICAL, by construction: the B58's lambda is at most 1 + ACT_HI[1] = 1.06, so no job can show the ceiling (test_fuel_forms.py shows it with a ceiling of 1) | ceiling 0 |
| `census_P2_bind` | `HARNESS_BIND_COUNT=1` | rr:120.0:0.16:random, rrwrap:7:3, wideseq:9:4:120 | BIT-IDENTICAL, all three (158371, 52215, 44760 values) | floor 0 and ceiling 0 in 2399, 600 and 480 steps |
| `cand_P2_final` | none; the tree after a comment-only edit of engines.py (EcuCal's field comment; plant_sha 67c3f53f188366c5 before and after) | the three quick jobs | BIT-IDENTICAL, all three | not asked |

The reference dump itself (`out/ref/extremes_double_12_random.npz`, cf43fbb) has
`info["lam"] == float32(0.70)` at row 780 only: the bind count is 1 on cf43fbb as on the candidate.
With the census, all 13 random-action jobs of `jobs_all.txt` are counted, the other nine by amendment
B1's lens (`b58_lens/bind_*.txt`, not re-run here): the floor binds in extremes:double:12:random
only, once.

### Scratch scripts of P2 (not certificate tools; in `scratchpad/p2/`)

- `first_diff.py`: per per-step array of a control's dump, the first row that differs from `ref`
  (bit for bit), the info columns that differ there (names from a live step's info_keys), the bind
  steps from the control's log, and the rows where the reference dump's lambda equals
  float32(0.70).
- `mutate.sh`: P2's tests on a minimal copy of the tree with one mutation each (the clip's
  literals back, one bound literal, a float64 bound, no order check, the plan's two conditions
  only, no type check); each must fail.
- `clip_probe.py`: the agent's lambda at the ECU's deepest enrichment, the probe behind
  test_fuel_forms.LambdaClip.test_the_environment_clips_to_the_engines_bounds.

## 22 October 2026, WP1 P2, resumed (the interrupted implementer's work re-read and re-run)

### Tools: not edited

- `harness.py` is the P2 version above, sha256 `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`
  (re-hashed); against `scratchpad/p2/harness_before_P2.py` (P1's, `50c047d5…9d9a61ac`) `diff` shows exactly the
  two candidate-side insertions described above, and every line of both files is CRLF (439 of 439, 401 of 401,
  counted in Python). `run_jobs.py`, `compare_all.sh` and `cmp.py` equal the certificate archive's
  (`results/B58_IDENTITY/certificate_tools.tar.gz`, `cmp`).
- **New jobs file:** `tools/jobs_census_P2_rest.txt`, the nine random-action jobs of `jobs_all.txt` that neither
  `jobs_quick.txt` nor `jobs_census_P2.txt` holds. **Why:** amendment B1 had their bind count from the b58 lens
  only (`b58_lens/bind_*.txt`); with this file every one of the 13 random-action jobs is counted by this harness.

### Results, re-run (labels `*_r2` and `census_P2_rest`; out/, `compare_all.sh ref <label>`)

The tree: the interrupted implementer's edits plus two comment-only rewordings (`engines.EcuCal`'s field comment,
`engine_env.py`'s clip comment); `plant_sha` 67c3f53f188366c5 and `engine_sha` 97b604f96c6d81fe as recorded
above, derived_sha 326c0835548975e2.

| label | environment | jobs | against `ref` | bind count |
|---|---|---|---|---|
| `cand_P2_r2` | none | jobs_quick.txt (3) | BIT-IDENTICAL, all three (115173, 76498, 76498 values) | not asked |
| `bind_P2_r2` | `HARNESS_BIND_COUNT=1` | jobs_quick.txt (3) | BIT-IDENTICAL, all three | extremes:double:12:random floor 1 [780] of 1099, lam 0.699999988079071, ceiling 0; terrain:single:11:neutral 0 and 0 of 1099; units 0 steps |
| `ctl_P2_r2_lamf32` | `HARNESS_PERTURB_F32=ecu.lam_floor` (0.7 -> 0.7000000476837158), bind count | extremes:double:12:random | **NOT IDENTICAL**. `p2/first_diff.py`: first differing row 780 in info, obs, reward and state (the bind step); info 119 rows, obs 16, reward 10, state 119; summary DIFFERENT; the 12 cycle, obs0 and c_turb_scale keys IDENTICAL; at row 780 lam 0.699999988079071 -> 0.7000000476837158 | floor 1 [780] |
| `ctl_P2_r2_lamf64` | `HARNESS_PERTURB=ecu.lam_floor` (0.7 -> 0.7000000000000001), bind count | extremes:double:12:random | BIT-IDENTICAL (amendment B1) | floor 1 [780], lam 0.699999988079071 |
| `ctl_P2_r2_ceilf32` | `HARNESS_PERTURB_F32=ecu.lam_ceiling` (1.25 -> 1.2500001192092896), bind count | extremes:double:12:random | BIT-IDENTICAL: no B58 lambda reaches 1 + ACT_HI[1] = 1.06 | ceiling 0 |
| `census_P2_r2` | `HARNESS_BIND_COUNT=1` | jobs_census_P2.txt (3) | BIT-IDENTICAL, all three | 0 and 0 in 2399, 600, 480 steps |
| `census_P2_rest` | `HARNESS_BIND_COUNT=1` | jobs_census_P2_rest.txt (9) | BIT-IDENTICAL, all nine | 0 and 0 in each (1099 steps; the two wideair jobs 899) |

The reference dump (`out/ref/extremes_double_12_random.npz`, cf43fbb) has `info["lam"] == float32(0.70)` at row 780
only. Over all 13 random-action jobs the floor binds once, at step 780 of extremes:double:12:random, and the
ceiling never: amendment B1's "1 at HEAD", now counted by this harness for every job rather than ten.
`p2/mutate.sh` re-run (`p2/mutate_r2.txt`): the unmutated copy passes; each of the seven mutations fails
LambdaClip.

## 22 October 2026, WP1 P3 (forms B and C)

### `tools/harness.py`: amendment B2's `HARNESS_SET`, and the units job's inversion skipped for forms other than A

- **Before the edit:** the P2 version, sha256 `f06d73e1cc8787401d3ff5a361bd90ad50003696237b1d2803366f583d5a2735`
  (re-hashed; copied to `scratchpad/p3/harness_before_P3.py`). The edit was made by `scratchpad/p3/edit_harness.py`,
  which asserts each anchor occurs once and writes CRLF; every line of the result is CRLF (468 of 468).
- **Where and what (three places, all candidate-side in behaviour):**
  1. Inside `if NEW:`, after the `HARNESS_PERTURB_F32` block and before `KW = dict(plant=PLANT)` (19 lines):
     `HARNESS_SET="cycle.form=A+B;cycle.ve_map=0.0"` sets engine-record fields to the values given, each converted
     to the type the field already has (`type(old)(value)`: str, float or int, so a Python float, amendment B10),
     all records in ONE `replace` of the Engine, then puts the plant into `engines._BUILT["b58"]` as the other
     routes do. It prints `SET <record>.<field>: <old> -> <new>` per field.
  2. The units job's `inv` block: its condition `if m > 0:` became
     `if m > 0 and not (NEW and getattr(eng.cycle, "form", "A") != "A"):` (one line changed). This line is in the
     units job's body, which both trees run: on the reference side `NEW` is False and the condition is `m > 0`, as
     before. `getattr(..., "A")` keeps the tool running on a pre-P3 candidate tree (P1, P2), whose CycleCal has no form.
  3. After that loop, under `if NEW and getattr(eng.cycle, "form", "A") != "A":` (10 lines): calls
     `map_from_airflow` once and requires it to refuse the form (ValueError), printing `INV SKIPPED, form ...`;
     if it accepts, the job stops (`SystemExit`).
- **Why:** amendment B2. P3's `CycleCal.__post_init__` refuses a `ve_map` other than 0 without form B and a
  `ce_rich_slope` other than 0.65 without form C, so the generic per-record `HARNESS_PERTURB` cannot set a form
  and its companion value (and `HARNESS_PERTURB=cycle.ce_rich_slope` raises on the B58, B2 "mine (1)"). P3's
  `map_from_airflow` refuses every form other than A, so under `HARNESS_SET` the units job would stop at the
  `inv` block; B2 has it skip the block, "recorded as by design". The `inv` key is therefore MISSING from those
  dumps, and `cmp.py`'s verdict line reads NOT IDENTICAL for that reason alone: read the per-key report
  (`scratchpad/p3/summarize.py` over `cmp/ref_vs_<label>/*.json`). B2's cam pass-through (`cam_deg` to
  `run_cycle` and `predict`) is P4's and is not in this edit (amendment B4: no cam names in P3).
- **Reference side shown unchanged:** `refside_P3`, the three quick jobs run in the reference tree
  (`$S/ref`, cf43fbb) with the edited harness, is BIT-IDENTICAL to `ref` on all three (115173, 76498, 76498
  values). With `HARNESS_SET` unset the candidate side is unchanged too (`cand_P3` below).
- **Checked:** `diff` against `harness_before_P3.py` (CR stripped) shows exactly the three changes above.
- sha256 after the edit: `b71929393f125b937cd7780af5e94f2b6d82e18bcf1c43e33141743725d64892`.

### New jobs file (`tools/`)

- `jobs_ctl_P3.txt`: units, terrain:single:11:neutral. B2's form controls run "on units plus
  terrain:single:11:neutral, never on wideair".

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the certificate archive's `tools/` copies
  (`cmp`; the archive's `certify_original/compare_all.sh` is an older copy and differs from both). The other
  jobs files.

### Results (out/, `compare_all.sh ref <label>`; the tree: P3 in the working tree on HEAD 0e07423)

| label | environment | jobs | against `ref` |
|---|---|---|---|
| `cand_P3` | none | jobs_quick.txt: units, extremes:double:12:random, terrain:single:11:neutral | BIT-IDENTICAL, all three (115173, 76498, 76498 values) |
| `refside_P3` | none; the REFERENCE tree with the edited harness | jobs_quick.txt | BIT-IDENTICAL, all three |
| `ctl_P3_AB0` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=0.0` | jobs_ctl_P3.txt | **IDENTICAL as B2 expects**: units, 76 of 77 keys IDENTICAL and `inv` MISSING by design (verdict line NOT IDENTICAL for that key alone); terrain BIT-IDENTICAL (17 keys) |
| `ctl_P3_ABC065` | `HARNESS_SET=cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65` | jobs_ctl_P3.txt | **IDENTICAL as B2 expects**: units 76 keys IDENTICAL, `inv` MISSING by design; terrain BIT-IDENTICAL |
| `ctl_P3_ABve` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=1e-4` | jobs_ctl_P3.txt | **DIFFERENT as B2 expects**: units `cycle` 13156 of 19200 values, `cycle_dtheta` 6 of 6, `predict` 249 of 288, `deliverable` 29 of 58, `deliverable_probe` 5 of 10 (71 keys IDENTICAL, `inv` MISSING); terrain `info` 14794 of 19782, `obs` 7184 of 25277, `reward` 1099 of 1099, `state` 14881 of 23079, `summary` 6 of 8 |
| `ctl_P3_ABCulp` | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001` (one ulp above 0.65) | jobs_ctl_P3.txt | **DIFFERENT as B2 expects**: units `predict` (lambda 0.95) 55 of 288 values, and `deliverable` 1 of 58 (row 12, 463.9355123336708 vs 463.93551233367066: the WOT table's enriched lambda), every `cycle` value IDENTICAL (lambda 0.70, 0.85 do not see the ulp; 1.0 and 1.12 take the lean branch); `inv` MISSING by design; terrain (neutral) BIT-IDENTICAL |

Every log of the four controls prints its `SET` lines and, in the units job, `INV SKIPPED, form 'A+B'`
(or `'A+B+C'`): `map_from_airflow inverts form A only ...`.

### Scratch scripts of P3 (not certificate tools; in `scratchpad/p3/`)

- `edit_harness.py`: the harness edit above.
- `summarize.py`: per control and job, the keys by status from `compare_all.sh`'s JSON reports
  (`controls_summary.txt`).
- `mutate.sh` (and `mutate_one.sh`, its form-A mutation re-run alone): P3's tests on a minimal copy of the tree
  with one mutation each; the unmutated copy passes and each of the twelve mutations fails (`mutate.txt`).

## 22 October 2026, WP1 P3, the review's fixes (`P3fix`)

### `tools/harness.py`: the candidate's form read directly (review should-fix 7)

- **Before the edit:** the P3 version, sha256 `b71929393f125b937cd7780af5e94f2b6d82e18bcf1c43e33141743725d64892`
  (copied to `scratchpad/p3fix/harness_before_P3fix.py`). The edit was made by `scratchpad/p3fix/edit_harness.py`,
  which asserts each anchor occurs once and keeps CRLF (468 of 468 lines).
- **What:** the two lines P3 added that read the form, `getattr(eng.cycle, "form", "A")`, now read `eng.cycle.form`:
  the units job's `inv` condition (`if m > 0 and not (NEW and eng.cycle.form != "A"):`) and the refusal check
  (`if NEW and eng.cycle.form != "A":`). Nothing else changed (`diff`, CR stripped: lines 222 and 225 only).
- **Why:** the default "A" was mistake 1's shape in the tool that certifies the plant: a candidate CycleCal
  without `form` would have been run as form A without a word. Every candidate tree from P3 on has the field, so
  the default only served P1/P2 trees, which are not certified again.
- **Reference side:** both lines keep their `NEW and` guard, so with NEW False neither attribute is read.
  Shown: `ctl_P3fix_refside` (the reference tree `$S/ref`, cf43fbb, with this harness, `jobs_quick.txt`) is
  BIT-IDENTICAL to `ref` on all three jobs (115173, 76498, 76498 values).
- sha256 after the edit: `17377d8693c7e19a1b36170f572570f57b7063e8de2e1983034b14b49b05f68f`.

### New tool `tools/control_verdict.py` (review should-fix 3; cmp.py and compare_all.sh not edited)

- `python control_verdict.py <label_a> <label_b> <jobs.txt> IDENTICAL|DIFFERENT [--allow-missing key,...]`:
  reads compare_all.sh's per-job JSON reports (`cmp/<a>_vs_<b>/<slug>.json`) and both labels' `_status.txt`,
  and prints per job IDENTICAL / DIFFERENT / INCOMPLETE, the SET lines and INV SKIPPED lines of b's logs, and
  `CONTROL <b> against <a>: expected X, got Y ...: PASS|FAIL` (exit 0 on PASS).
- Rules: a key named in `--allow-missing` may be absent from b only; any other MISSING key, a job absent from
  either label or not exit 0, or a job without a compare report makes the control INCOMPLETE (FAIL); b's jobs
  must print the same SET lines. The declared list for P3's form controls is `inv`, and only under HARNESS_SET
  forms other than A, where the harness skips `map_from_airflow` by design (amendment B2) and logs INV SKIPPED.
- **Why:** cmp.py's verdict line read NOT IDENTICAL for the IDENTICAL form controls because of that one missing
  key, so the certificate would have rested on a person reading per-key reports.
- **Shown able to fail:** `ref ctl_P3_r1_AB0 jobs_ctl_P3.txt IDENTICAL` without `--allow-missing inv` gives
  INCOMPLETE, FAIL (exit 1); `cand_P3_r1 ctl_P3_r1_ABve ... IDENTICAL --allow-missing inv` gives DIFFERENT, FAIL
  (exit 1); run before compare_all.sh had written its reports, `ctl_P3fix_AB0` gave INCOMPLETE, FAIL.
- sha256: `c57d1db419bc4b178b0816782fd3274d34b8c7cff39e1e1d1aaee52bae611285`.

### New jobs file `tools/jobs_ctl_P3_C.txt` (review should-fix 2)

- units, terrain:single:11:neutral, extremes:double:12:random (CRLF; two `#` lines head it). sha256
  `630b27a4e5111e56028e100feec9aebf46e253eba9d77634324bf56c4d6a9d17`.
- **Why:** the B58's neutral terrain episode never runs rich, so form C's controls could not fail on it: the
  slope-0.70 pre-check reads IDENTICAL there. extremes:double:12:random (random trim; 989 of its 1099 info rows
  at lambda < 1 in the reference dump) is a job the slope reaches. The form C controls (A+B+C at 0.65, and the
  one-ulp slope) run on this file; the form B controls keep `jobs_ctl_P3.txt`.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `copy_tree.py`: equal to the certificate archive's `tools/` copies
  (`cmp` against `results/B58_IDENTITY/certificate_tools.tar.gz`). The other jobs files.

### Results (out/; the tree: P3 plus the review's fixes, on HEAD 0e07423; plant_sha 896a79c757b56fcb)

Every verdict below is `control_verdict.py`'s, after `compare_all.sh`; the per-key counts are cmp.py's.

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P3fix` | none | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values) |
| `cand_P3fix_final` | none; the same code after a comment-only edit of engines.py and a docstring edit of test_fuel_forms.py (plant_sha 896a79c757b56fcb before and after) | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values): PASS |
| `ctl_P3fix_refside` | none; the REFERENCE tree with this harness | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three |
| `ctl_P3fix_AB0` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=0.0` | jobs_ctl_P3.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys IDENTICAL (`inv` allowed missing, INV SKIPPED logged); terrain 17 keys |
| `ctl_P3fix_ABC065` | `HARNESS_SET=cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65` | **jobs_ctl_P3_C.txt** | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys (`inv` allowed missing); terrain 17; **extremes:double:12:random 17** |
| `ctl_P3fix_ABve` | `HARNESS_SET=cycle.form=A+B;cycle.ve_map=1e-4` | jobs_ctl_P3.txt | `cand_P3fix`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 13156/19200, cycle_dtheta 6/6, deliverable 29/58, deliverable_probe 5/10, predict 249/288; terrain info 14794/19782, obs 7184/25277, reward 1099/1099, state 14881/23079, summary 6/8 |
| `ctl_P3fix_ABCulp` | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001` | **jobs_ctl_P3_C.txt** | `cand_P3fix`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units predict 55/288 and deliverable 1/58, cycle IDENTICAL; terrain IDENTICAL; **extremes:double:12:random info 111/19782, state 105/23079, summary 1/8** (obs, reward IDENTICAL), first at row 778, lambda 0.8557777404785156 (ki, r_resp, torque), max abs difference 1.4e-12 |
| `ctl_P3fix_C070` (pre-check) | `HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.7` | jobs_ctl_P3_C.txt | `ref`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 5900/19200, deliverable 17/58, deliverable_probe 1/10, predict 191/288; **terrain IDENTICAL** (the neutral episode never runs rich); extremes info 13818/19782, obs 6962/25277, reward 1097/1099, state 11996/23079, summary 6/8 (the review's rvw_P3_C070, re-run) |

Why the one-ulp slope shows in the extremes episode at all: the agent's lambda reaches run_cycle as a Python float
(engine_env.py:1010, `float(np.clip(...))`), so the rich branch is float64 arithmetic, and whether one ulp on the
slope survives `1 - slope (1 - lambda)` depends on the lambda. `scratchpad/p3fix/ulp_lams.py` over the reference
dump: of the 639 distinct rich lambdas, one ulp moves combustion_efficiency at 4 (0.7070471048355103,
0.817680835723877, 0.8557777404785156, 0.8618496656417847); the control's first difference is at the third. Over
20001 float32 lambdas in [0.70, 0.999] it shows at 3645. At 0.70, 0.85 and float32(0.81) it does not, at 0.95 it
does (amendment B2's statement, re-measured). In test_fuel_forms.py's 60 s episode it shows nowhere
(`scratchpad/p3fix/episode_probe.py`), so the in-repository episode check uses finite steps as its controls.

For the certificate's control table (written when WP1 lands): list `ctl_P3fix_ABC065` and `ctl_P3fix_ABCulp` with
`jobs_ctl_P3_C.txt`, `ctl_P3fix_C070` beside them as the pre-check showing that each lists a job the slope
reaches, and every form control's verdict as `control_verdict.py` prints it with `--allow-missing inv`.

### Scratch scripts of the P3 fix (not certificate tools; in `scratchpad/p3fix/`)

- `edit_harness.py`: the harness edit above. `run_waves.sh`: the seven labels above (two waves, 3 jobs at a time).
- `episode_probe.py`: a short random-trim extremes episode under the neutral forms, the slope 0.70, ve_map 1e-4 and
  the one-ulp slope; 60 s: 59 steps, 56 rich, 3.5 s per episode.
- `ulp_lams.py`: the lambdas at which one ulp on the slope moves combustion_efficiency (above).
- `mutate.sh`: the implementer's twelve mutations, the reviewer's four that passed before the fix (ref_literal,
  sign_flip, half_term, clip_then_add) and the new finiteness check removed; the unmutated copy passes and all
  seventeen fail (`mutate.txt`).

## 22 October 2026, WP1 P4 (form D, the intake cam run by the ECU)

### `tools/harness.py`: amendment B2's cam pass-through in the units job

- **Before the edit:** the P3fix version, sha256 `17377d8693c7e19a1b36170f572570f57b7063e8de2e1983034b14b49b05f68f`
  (re-hashed; copied to `scratchpad/p4/harness_before_P4.py`). The edit was made by `scratchpad/p4/edit_harness.py`,
  which asserts each anchor occurs once and keeps CRLF (484 of 484 lines); replayed on the copy it reproduces the
  edited file byte for byte (`cmp`).
- **Where and what (five places, all in the units job, all candidate-side):**
  1. After `eng = PLANT.engine if NEW else None`, under `if NEW:` (12 lines): `_ecu_cam = E.BaselineECU(eng.ecu).cam_deg`
     and a wrapper `_cam(rpm, mp)` that returns it and keeps each value in `_cams`. Not defined on the reference side.
  2. The grid's `run_cycle` (archive line 130): the NEW branch passes `cam_deg=_cam(rpm, mp)`.
  3. `predict` (archive line 139): the NEW branch passes `cam_deg=_cam(rpm, mp)` (the call now spans two lines).
  4. The crank-step `run_cycle` (archive line 146): the NEW branch passes `cam_deg=_cam(kw["rpm"], kw["map_kpa"])`.
  5. After the crank-step loop, under `if NEW and eng.ecu.cam_on:` (3 lines): prints
     `CAM ON: <n> cycles and predicts at the ECU's cam, <min> to <max> deg (<k> distinct), cam_ref_deg <ref>`, the
     pre-check of amendment section 4 item 2 ("a nonzero cam"): a schedule of zeros could not fail.
- **Why:** amendment B2. After P4, `plant.volumetric_efficiency` refuses `cam_deg=None` under form D and a number under
  every other form, and the cam is the ECU's (decision 41). So the units job passes
  `cam_deg=BaselineECU(eng.ecu).cam_deg(rpm, map)` at each cycle's own speed and MAP; under form A (the B58, cam_on 0)
  that is None, run_cycle's and predict's own default, so the A path is the same call. The `map_from_airflow` block is
  still skipped for forms other than A by design (P3's edit, unchanged). The step() jobs need no edit: P4's step()
  schedules the cam itself.
- **Reference side shown unchanged:** every change sits in a `... if NEW else ...` branch the reference never takes, or
  under `if NEW`. `refside_P4`, the three quick jobs run in the reference tree (`$S/ref`, cf43fbb) with the edited
  harness, is BIT-IDENTICAL to `ref` on all three (115173, 76498, 76498 values). With HARNESS_SET unset the candidate
  side passes None and is unchanged too (`cand_P4` below).
- **A P1-P3 candidate tree can no longer run the units job** with this harness (its run_cycle has no `cam_deg`
  keyword, a TypeError). Those trees are not certified again; the P3fix copy is kept as `p4/harness_before_P4.py`.
- sha256 after the edit: `38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`.

### New jobs files (`tools/`, CRLF, `#` lines head them)

- `jobs_ctl_P4.txt` (sha256 `1a8cfee5…ca8d89`): units, terrain:single:11:neutral, extremes:double:12:random. B2's form-D
  controls run "on units plus terrain:single:11:neutral, never on wideair"; the random-trim extremes episode is added
  (the quick loop's third job, P3fix's should-fix 2 pattern).
- `jobs_keyword_P4.txt` (sha256 `c72f6c97…4218d`): wideair:locked:45.0:80.0:11:neutral, wideair:single:0.0:101.3:12:random.
  **Why:** P4 changes `_track_torque`'s and `_evaluate`'s signatures (a keyword-only `cam_deg=None`), and wide_air.py
  calls `_track_torque` with eight positional arguments and no cam (`wide_air.py:149, 182`); the quick loop never
  reaches those calls.

### Not edited

- `run_jobs.py`, `compare_all.sh`, `cmp.py`, `lab_dump.py`, `lab_compare.py`: equal to the certificate archive's
  `tools/` copies (`cmp` against `results/B58_IDENTITY/certificate_tools.tar.gz`, unpacked in `scratchpad/p4/archive`).
  `control_verdict.py`: P3fix's, sha256 `c57d1db4…611285`, unchanged.

### Results (out/; the tree: P4 in the working tree on HEAD fe0e321; plant_sha 9daef293c84c0557, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

Every verdict is `control_verdict.py`'s, after `compare_all.sh`; the per-key counts are cmp.py's.

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P4` | none | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values): PASS. Its units log prints no CAM line (cam_on 0) |
| `refside_P4` | none; the REFERENCE tree with this harness | jobs_quick.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three: PASS |
| `ctl_P4_ABCD0` | `HARNESS_SET=cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.ve_cam=0.0;cycle.cam_ref_deg=0.0;ecu.cam_on=1` (the schedule's twelve fields stay 0.0: "A+B+C+D with zeros") | jobs_ctl_P4.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys (`inv` allowed missing, INV SKIPPED logged); terrain 17; extremes 17. CAM ON: 1220 cycles and predicts at 0.0 to 0.0 deg |
| `ctl_P4_D0` | the same form and terms with `ecu.cam_on=1;ecu.cam_c0=10;ecu.cam_rpm_lo=800;ecu.cam_rpm_hi=7000;ecu.cam_map_lo=20;ecu.cam_map_hi=260;ecu.cam_lo=-60;ecu.cam_hi=60` and `cycle.ve_cam=0.0` (B2's schedule at ve_cam 0) | jobs_ctl_P4.txt | `ref`, `--allow-missing inv` | IDENTICAL | IDENTICAL, PASS: units 76 keys; terrain 17; extremes 17. CAM ON: 1220 at 10.0 to 10.0 deg (the cam is off the reference 0, and ve_cam 0 keeps it out of the breathing) |
| `ctl_P4_D1e4` | B2's schedule at `cycle.ve_cam=1e-4` | jobs_ctl_P4.txt | `cand_P4`, `--allow-missing inv` | DIFFERENT | DIFFERENT, PASS: units cycle 16505/19200, cycle_dtheta 6/6, deliverable 29/58, deliverable_probe 5/10, predict 249/288 (71 keys IDENTICAL); terrain info 14492/19782, obs 6375/25277, reward 1099/1099, state 14074/23079, summary 6/8; extremes info 14635/19782, obs 6946/25277, reward 1099/1099, state 14644/23079, summary 6/8. CAM ON: 1220 at 10.0 deg |
| `cand_P4_kw` | none | jobs_keyword_P4.txt | `ref` | IDENTICAL | BIT-IDENTICAL, both (60331 values each; compare_all.sh) |

Shown able to fail: `cand_P4 ctl_P4_D1e4 jobs_ctl_P4.txt IDENTICAL --allow-missing inv` gives DIFFERENT, FAIL;
`ref ctl_P4_ABCD0 jobs_ctl_P4.txt IDENTICAL` without the allowance gives INCOMPLETE, FAIL.

The learning lab, through its `CapturingEnv` (`_track_torque(*args, **kwargs)`, `args[7] is self.pi_base`):
`tools/lab_dump.py` on `$S/ref` and on the P4 tree (`lab/lab_ref_P4.json`, `lab/lab_cand_P4.json`), compared by
`tools/lab_compare.py` (`lab/compare_cand_P4_ref.txt`): 36325 leaf values, 178 source-line numbers moved, 88 re-worded
strings, 0 other differences, the counts build step 1's comparison listed (`lab/compare_cand_ref.txt`).

### Scratch scripts of P4 (not certificate tools; in `scratchpad/p4/`)

- `edit_harness.py`: the harness edit above.
- `mutate.sh`: P4's tests (test_fuel_forms.FormD, EngineSha) on a minimal copy of the tree with one mutation each
  (`mutate.txt`).
- `mutate.txt`, the result: the unmutated copy passes (exit 0), and so does a spec edit that changes no value (a `unit`
  key added to `cam_on`); each of the 20 mutations fails FormD: the agent's loop without the cam, at its own MAP's cam,
  the cam scheduled on the current MAP, the cam zeroed in `_track_torque`, the D term's sign flipped, its reference
  ignored, no input clamp, no output clamp, MAP scaled by 1000, Engine's cam check removed, EcuCal's cam-off check,
  its lo/hi check, `isinstance` for the int check (a bool passes), CycleCal's ve_cam check, the P4 fields dropped
  from CycleCal's type check, form A taking a cam, the deliverable table without the cam, the table's cam on a fixed
  150 kPa, the surrogate's refusal removed, and run_cycle zeroing the cam.

## 22 October 2026, WP1 P5 (records, constructors, cars, vehicles and guards)

### Tools: not edited

- `harness.py` is the P4 version, sha256 `38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46` (re-hashed).
  **Why no edit:** P5 changes no interface the harness calls. It still builds the B58 with `engines.get("b58")`
  (whose `_build` now reads the specs' top-level `derived_set` and `kind`), the units job still builds
  `E.Vehicle(PLANT.car)` and calls the training-road builders on it (an `engines.Car`, which the new B15 guards
  pass), and the step() jobs build their vehicle through `engine_env.vehicle_for`, which returns `Vehicle(car)`
  for a Car. `HARNESS_PERTURB=car.mass` keeps the record's type (`dataclasses.replace`), so the guards pass it too.
- `run_jobs.py` (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`),
  `control_verdict.py` (P3fix's): unchanged.

### New jobs files (`tools/`, CRLF, `#` lines head them)

- `jobs_P5.txt` (sha256 `0c4e1669dbbd7b21ea459d35aeeac3db6ac97e944b6b335ee07d9be7a89291db`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3), and
  wideair:locked:45.0:80.0:11:neutral, wideair:single:0.0:101.3:12:random. **Why the two wideair jobs:** P5 adds
  the B15 guard to `wide_air.ThinAirVehicle`, `wide_air.grade_floor` and `wide_air.speed_profile`, which the quick
  loop never reaches (P4's `jobs_keyword_P4.txt` pair).
- `jobs_ctl_P5.txt` (sha256 `695593dc653f46ddbcdc270225cd7ea037116ade0ff5330e5dcd9b9aadc9cfa2`):
  terrain:single:11:neutral, the `car.mass` control's job.

### Results (out/; the tree: P5 in the working tree on HEAD 7ea42f5; plant_sha f5c11de53cbe7c9c, plant_text_sha 8a861524a776ff55, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5_r0` | none; the first pass, the plant code final, before the tests were written (two later engines.py edits: two unused tuples dropped, build_candidate's check skips top-level `_` keys) | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 236 s |
| `cand_P5` | none; the final tree | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 254 s |
| `ctl_P5_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL. The car record reaches step() through `vehicle_for` (mistake 25) |

After `cand_P5`, one docstring-only edit of engines.py (the module docstring's DERIVED paragraph names
EPA_DERIVED_FIELDS too): plant_sha f5c11de53cbe7c9c before and after (code-only hash), plant_text_sha
8a861524a776ff55 -> cf10abf3926b2e98. Re-run, as P2's and P3fix's comment-only edits were: `cand_P5_final`
(jobs_P5.txt against `ref`) BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 262 s.

### Scratch scripts of P5 (not certificate tools; in `scratchpad/p5/`)

- `edit_threading.py`: the anchored edit of test_engine_threading.py (CALLS, QUALIFIED, NOT_NONE, the scan
  control, Signatures, the record list, Registry per DERIVED set, the `_record` call).
- `mutate.sh` and its result `mutate.txt`: P5's tests (test_cars.py, test_engine_threading.py Registry and
  Signatures, test_trainable.py) on a minimal copy of the tree (every .py, engine_specs, the derived file) with one
  mutation each; the anchors' line breaks follow the file's own (CRLF or LF). The unmutated copy passes (exit 0) and
  each of the 34 mutations fails: the B15 guard off, or letting an EpaCar through; ThinAirVehicle and
  wide_air.speed_profile unguarded; the kickdown threshold on target_load; the kickdown returning the failing end of
  the bisection; the scan without the bisection; the power-limited branch unflagged; the power fallback at the window's
  top; the launch at rpm_min instead of cvt_rpm_min; the economy speed without the cvt_rpm_min floor; f <= 0 kicking
  down; the CVT's torque without eta; C not scaled by the air density; A + B v without cos(theta); EpaVehicle's torque
  scaled 1.001; the radius from the final drive (4.411) instead of EPA's axle (4.41); LBF_N rounded; the mass a curb
  weight; vehicle_for giving an EpaCar the Supra's Vehicle; the EPA set's form converted as a number; the B58's table
  fallback returning None; build_candidate taking a NumPy value; the freeze check skipped; step_record's CVT branch
  removed; fingerprint's CVT refusal removed; trainable() returning known(); train.py and evaluate.py back on known();
  a spec's top-level key set unchecked; a converted field also typed; EpaCar's type check removed; CvtCar's checks
  removed; calibrated() ignoring the freeze record. The first run found one test gap and one script fault, both
  closed before the final run: `calibrated_ignores_freeze` passed (test_engine_threading gained a
  derived-file-present, freeze-missing case), and four mutations with multi-line anchors were not applied to CRLF
  files (the script now converts the anchors' line breaks). Before that run, `launch_at_rpm_min` could not have
  failed while the fixture's cvt_rpm_min equalled its rpm_min, so test_cars gained a 1200 rpm floor first.

## 22 October 2026, WP1 P5, the review's fixes (`P5fix`)

### `tools/run_suites.sh`: WP1's own suites on the candidate side (review should-fix 11)

- **Where:** the `quick` block, three new lines before its `wait`, and the header comment's `quick` line. The script
  has no reference side (every label is `cand_*`), so nothing of a reference changed.
- **What:** `one cand_test_cars $CAND $PY test_cars.py -v &`, `one cand_test_trainable $CAND $PY test_trainable.py -v &`
  and `one cand_test_fuel_forms $CAND $PY test_fuel_forms.py -v &`.
- **Why:** §3.6 item 15 of the full list runs `run_suites.sh quick`, which ran test_wide_air, test_engine_threading,
  test_epa_map, test_plant_guards, random_road and fingerprint only, so the certificate would have skipped the three
  WP1 suites, amendment B8's `--help` runs and refusals (test_trainable) among them.
- sha256 before `b20a731dcfc7db38dd3be594796692e57eee2ea63cd8033f1c6be6f7a38589cf`, after
  `e1efa910f3bff62eba4ac419152bbf9aaf2598a356bc46b29985de1204f9b82b` (the before copy:
  `scratchpad/p5fix/run_suites_before.sh`; `diff` shows the four lines only).

### Not edited

- `harness.py` (`38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`, the P4 version), `run_jobs.py`
  (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py`
  (`c57d1db4…1285`): re-hashed, unchanged. **Why no harness edit:** the fixes change no interface it calls. The B58
  is still `engines.get("b58")`; `vehicle_for`, the B15 guards and `Vehicle` are as in P5 for an `engines.Car`; the
  new `_ThreeTermRoad.DELIVERABLE_TORQUE`, `is_candidate`, the candidate mark and the published file in
  `spec_files` touch EPA cars, candidates and EPA plants only; `step_record.gear` refuses a CVT only.
- Jobs files: `jobs_P5.txt` and `jobs_ctl_P5.txt`, unchanged (sha256 `0c4e1669…91db`, `695593dc…cfa2`).

### Results (out/; the tree: P5 plus the review's fixes in the working tree on HEAD 7ea42f5; plant_sha 38d8c7e01a515e51, plant_text_sha 7243314e7232673d, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5fix` | none | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 312 s |
| `ctl_P5fix_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5fix` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL (P5's counts) |

plant_sha moved f5c11de53cbe7c9c -> 38d8c7e01a515e51: engines.py's code (`_python_scalars` by annotation,
`spec_files`, `is_candidate`, the candidate mark) and engine_env.py's (`_ThreeTermRoad.DELIVERABLE_TORQUE`, CvtVehicle's
alias dropped). derived_sha and engine_sha did not move.

### Scratch scripts of the P5 fix (not certificate tools; in `scratchpad/p5fix/`)

- `supra_pin.py <tree>`: the Supra's `Vehicle.demand` doubles on test_cars.py's pinned grid, hashed; `Vehicle()` in a
  tree without engines.py. Run on `ref` (cf43fbb) and on the candidate: both
  `d0f458126a512e480e5011d2c758899cc888c27dc4248ae2783e4d258db1cbea` (2208 doubles), the digest test_cars.py pins.
- `edit_threading.py`, `edit_threading_b13.py`, `fix_b13_escapes.py`: the anchored edits of test_engine_threading.py
  (`is_candidate` in QUALIFIED, the scan control and Signatures; amendment B13's comment check). The shell turned two
  escapes of the second into control characters; the third put them back, and a scan of every changed file finds
  no control character.
- `mutate.sh` and its result `mutate.txt`: P5's scheme (a minimal tree copy per mutation, then test_cars,
  test_engine_threading Registry and Signatures, test_trainable). The unmutated copy passes and all 17 mutations
  fail: the review's five survivors (Vehicle.demand's sum regrouped; engine_env.grade_floor's and
  wide_air.grade_floor's own guard off; N_hi unbounded; fingerprint.py's CLI without `refuse_uncalibrated`), each other
  builder's own guard off alone (min_tractive_force, extreme_speed_profile, wide_air.speed_profile), the published file
  left out of `spec_files` or passed through unnormalised, the candidate unmarked or not refused by
  `plant_fingerprint`, the EPA car's empty table naming derive_params.py, `_python_scalars` taking any of float, int
  and str or a float in an int field, a CVT recorded as gear 0, and the Supra's `kind` comment without its label.

After `cand_P5fix` and `ctl_P5fix_mass`, one docstring-only edit of derived.py (a reflowed paragraph): plant_sha
38d8c7e01a515e51 before and after (code-only hash), plant_text_sha 7243314e7232673d -> 3eaed2f2d997da2b. Re-run, as
P5's own docstring edit was: `cand_P5fix_final` (jobs_P5.txt against `ref`) BIT-IDENTICAL, all five (115173, 76498,
76498, 60331, 60331 values), 232 s. The final tree's fingerprint: plant_sha 38d8c7e01a515e51, plant_text_sha
3eaed2f2d997da2b, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2.

## 22 October 2026, WP1 P5, the second review's fixes (`P5fix2`)

### Not edited

- No tool was edited. `harness.py` (`38c9f119…df46`), `run_jobs.py` (`015510b4…bf18`), `compare_all.sh`
  (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py` (`c57d1db4…1285`), `jobs_P5.txt`
  (`0c4e1669…91db`) and `jobs_ctl_P5.txt` (`695593dc…cfa2`) were hashed before the runs
  (`scratchpad/p5fix2/tool_hashes_before.txt`) and again after: unchanged. **Why no harness edit:** the fixes change
  no interface the harness calls. The B58 is still `engines.get("b58")`. The new converters `_epa_table` and
  `_epa_floats` are the EPA set's only (`CONVERT_BY_SET["epa"]`), and the B58's `_table`, `_floats` and `float` are
  untouched. CvtCar's new reserve check runs for a CvtCar only. The rest are tests and two README sentences.

### Results (out/; the tree: P5, the first review's fixes and the second's, in the working tree on HEAD 7ea42f5; plant_sha 1c74d8d02537cb8f, plant_text_sha f111ce8929488ea0, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P5fix2` | none | jobs_P5.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all five (115173, 76498, 76498, 60331, 60331 values), 290 s |
| `ctl_P5fix2_mass` | `HARNESS_PERTURB=car.mass` (1520.0 -> 1520.0000000000002) | jobs_ctl_P5.txt | `cand_P5fix2` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): info 6303/19782, state 6979/23079, summary 5/8; 14 keys IDENTICAL (P5's counts) |

plant_sha moved 38d8c7e01a515e51 -> 1c74d8d02537cb8f because engines.py's code changed (`_epa_table`, `_epa_floats`,
the EPA set's converter map, CvtCar's reserve check). derived_sha and engine_sha did not move.

### Scratch scripts of this fix (not certificate tools; in `scratchpad/p5fix2/`)

- `mutate.sh` and its result `mutate.txt`: the first fix's scheme (`scratchpad/p5fix/mutate.sh`'s `run()`). The
  unmutated copy passes (exit 0), and all 13 mutations fail: the environment back on `Vehicle(plant.car)`;
  `typed_engine` in the B58's set; the CX-9 typed at EPA's axle 4.41 (a test-file mutation standing for P6);
  EpaVehicle's final drive x (1 + 1e-5); the radius from `[final_drive]`; CvtCar's reserve check removed, or made
  `<=`; the EPA table or either envelope back on the B58's converters; a float rpm let into the table; a NaN
  fallback added to `_epa_floats`; `_epa_table`'s None fallback removed.

## 22 October 2026, WP1 P6 (the six EPA specs and the registration)

### Tools: not edited

- `harness.py` (`38c9f11946b9d17c950cfbce4abd5154f831318c701858b9926d1a9b3937df46`, the P4 version), `run_jobs.py`
  (`015510b4…bf18`), `compare_all.sh` (`2220420c…3c5c`), `cmp.py` (`3d424f8b…bc43`), `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`, P5fix's): re-hashed before the runs, unchanged. **Why no harness
  edit:** P6 adds six spec files and three `engines.PLANTS` entries, refactors `engines.calibrated` into
  `engines._missing_files` and makes `engines.py`'s `__main__` list an uncalibrated plant. The harness builds the B58
  with `engines.get("b58")`, whose `_build` reads `b58.toml` and `a90_supra.toml` only; no job calls `name_of`,
  `calibrated`, `spec_files` or the listing, so no harness path reaches the new specs.

### New jobs file (`tools/`, CRLF, a `#` line heads it)

- `jobs_P6.txt` (sha256 `952010d96f6ffeb4af57f6f6eba1b3049f1fc2bbee8a895d63511a17c296bc39`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3). No wideair job: P6 touches
  nothing `wide_air.py` reads.

### Results (out/; the tree: P6 in the working tree on HEAD 1b0e83f; plant_sha e85d442a4015a86f, plant_text_sha deef1edf338c45e8, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P6` | none; engines.py final, the specs before two wording edits | jobs_P6.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values), 88 s |
| `cand_P6_final` | none; the final tree (the MZ19 citations reworded to PDF pages, one README paragraph) | jobs_P6.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all three (115173, 76498, 76498 values), 90 s |

plant_sha moved 1c74d8d02537cb8f -> e85d442a4015a86f because engines.py's code changed (PLANTS, `_missing_files`,
`calibrated`, `__main__`); the six new specs are not in the B58's plant_files. derived_sha and engine_sha did not move.

### Scratch scripts of P6 (not certificate tools; in `scratchpad/p6/`)

- `mz19_dl/mz19.pdf`: Mazda USA's 2019 CX-9 specifications (MZ19), fetched 22 October 2026 into its own folder,
  sha256 `aa0c19ad21248f1c17c72be13248ff2179fa8c393ea0ac95e194b36a296c45fb`; `mz19_txt/mz19.txt` its pdftotext text;
  `mz19_pages.py` (run `-I`, outside the download folder) the pages that print the torque: PDF pages 2, 8, 14, 21
  (Sport, Touring, Grand Touring, Signature), each "TORQUE 310 lb-ft @ 2,000 rpm", "BORE X STROKE (MM) 89 x 100",
  "DISPLACEMENT (CC) 2488" (decision 43).
- `compute.py <repo>`: the arithmetic the specs type (the Mazda's stroke, the conrods, the displacements, the scaled
  loop gains, the peak torques); no EPA row read.
- `make_specs.py <repo>`: the Honda's and the Ford's engine specs from the Mazda's text, each differing line replaced
  whole, each anchor asserted once.
- `edit_guards.py <file>`: the anchored CRLF edit of test_plant_guards.py's DerivedFingerprint.
- `mutate.sh` and its result `mutate.txt`: P5's scheme (a minimal tree copy per mutation; then test_carried,
  test_cars RegisteredCars, test_engine_threading Registry and Signatures, test_plant_guards DerivedFingerprint,
  test_trainable). The unmutated copy passes (exit 0) and all 20 mutations fail: one plant left out of PLANTS;
  calibrated() always yes; the listing's skip removed; the listing naming the last missing file; `_missing_files`
  ignoring the freeze record; DerivedFingerprint's skip removed; a carried value moved (the Mazda's c_turb); a carried
  value's marker dropped (the Honda's fres_a); the Honda's floor at 0.70; the Ford on one turbine; the Mazda's stroke
  at MZ19's 100 mm; the CX-9's peak torque rounded to 420.3; its final drive at EPA's 4.41; the Accord's top ratio at
  0.4; the F-150 pointed at the CX-9's published file; the form typed in the Mazda's spec; the Ford's freeze comment
  without its label; the Honda's feed-forward slope left at the B58's.
- `verify_docs.txt`: `verify_docs.py` on the P6 tree (read-only): "All 74 checks pass (959 figure mentions scanned)".

## 22 October 2026, WP1 P7 (the polish: the reviews' should-fix items)

### `tools/harness.py`: the `fuel.<field>` route also reaches `engines._TYPED` (the review of P1, should-fix 3)

- **Where:** inside `if NEW:` -> `if _pert:` -> `elif rec_name == "fuel":`, after the `with_fuel` replace (7 lines:
  a 4-line comment, the assignment, a 2-line print). The candidate side only; nothing else in the file moved.
- **What:** `engines._TYPED["b58"] = replace(engines.typed_engine("b58"), fuel=PLANT.engine.fuel)`, then
  `PERTURBED fuel.<field> also in engines._TYPED['b58']: <value>`, read back through `engines.typed_engine("b58")`.
- **Why:** P1 put the fuel in the TypedEngine too (`calibrate_thermal.load_drive` reads `typed_engine("b58").fuel`),
  and the route set `engines._BUILT["b58"]` only, so a job that reached the typed engine would have read IDENTICAL
  for the wrong reason (mistake 25). None of the 34 jobs reaches it today (the review's finding); the route now
  covers both caches, as P1's scratch `callers_dump.py` did. **Not changed, and why:** the generic, F32 and SET
  routes also leave `_TYPED` as built. They move cycle, ecu, thermal or car fields; the TypedEngine holds geometry,
  cycle, charge and fuel, so a cycle-field control would leave the typed cycle stale. No job reaches
  `typed_engine` (it is read by build_dataset.py, new_drive.py and the thermal fit, none of which a job runs), so
  it is recorded here rather than coded: a future job that does must sync `_TYPED` the same way.
- **Reference side:** untouched. With `HARNESS_PERTURB` unset (or set to a non-fuel field) the block is not
  entered, so every other run is unchanged. Checked: `diff` of the edited file against the P4 version (copied to
  `scratchpad/p7/harness_before_P7.py`, sha256 `38c9f119…df46`, before the edit) is one insertion of 7 lines after
  line 53; every line is CRLF, as the file's are (491 of 491).
- sha256 after the edit: `0e06275cc64e0eba940dbf2d3aa5a240211be92908b98db99ce2e921a6f4a480`.
- **Used by:** `ctl_P7_afr` (below). Its log's first line is `PERTURBED fuel.afr_st also in engines._TYPED['b58']:
  14.700000000000001`.

### New jobs file (`tools/`, CRLF, `#` lines head it)

- `jobs_P7.txt` (sha256 `662df4ad474c61e2f52987b29f4f0272a13601c8a6ab4d0ac43d971f2ea1385a`): units,
  extremes:double:12:random, terrain:single:11:neutral (the quick loop, amendment B3), wideair:single:0.0:101.3:12:random,
  wideair:locked:45.0:80.0:11:neutral (P5's pair) and `cond:baseline ECU:315.0:101.3:0.12:locked`, the cond job the
  review of P5 found missing from `jobs_P5.txt` (should-fix 5: P5 changed `step_record.gear`, which the cond jobs
  record; that review's own run `rvw3_P5_extra` read BIT-IDENTICAL on it and three more).

### Not edited

- `run_jobs.py` (`015510b4…`), `compare_all.sh` (`2220420c…`), `cmp.py` (`3d424f8b…`), `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`), `lab_dump.py` (`7115fabd…`), `lab_compare.py` (`2dfa1b0b…`),
  `jobs_units.txt` (`a8537a4e…`): re-hashed, unchanged. **lab_compare.py not edited, and why:** the review of P4
  suggested comparing the text of each resolved source line, not only its number. P7 makes the one anchor that
  moved deliberate instead (the lab's "air" concept, `match` "m_air =", line 219: the m_air assignment), and the
  comparison below shows it, and the clip's two re-worded texts, as its only differences beyond line numbers and
  build step 1's three strings. A text comparison of every resolved line stays an option for the full list's
  item 12 (docs/build_step_2/HANDOFFS.md, commit A).
- `lab_compare.py` printed through cp1252 and stopped at the first Arabic string: run with `-X utf8` (no edit).

### Results (out/; the tree: P7 in the working tree on HEAD c77640a; plant_sha 04753d8fa99cc2e3, plant_text_sha ec69d3be215d273f, engine_sha 023f5589215ee68e, derived_sha 326c0835548975e2)

| label | environment | jobs | against | expected | got |
|---|---|---|---|---|---|
| `cand_P7` | none | jobs_P7.txt | `ref` | IDENTICAL | BIT-IDENTICAL, all six (115173, 76498, 76498, 60331, 60331, 53220 values), 280 s |
| `ctl_P7_afr` | `HARNESS_PERTURB=fuel.afr_st` (14.7 -> 14.700000000000001; the edited route) | jobs_units.txt | `cand_P7` | DIFFERENT | DIFFERENT, PASS (`control_verdict.py`): cycle 3094/19200, cycle_dtheta 3/6, deliverable 12/58, deliverable_probe 2/10, predict 57/288; 72 keys IDENTICAL (P1's `ctl_P1_r1_afr` counts) |

The tree was hashed before and after the runs (`git diff --binary` plus `git status --porcelain`, sha256
`faf82de1…b56e83` both times). plant_sha moved e85d442a4015a86f -> 04753d8fa99cc2e3 because engines.py's code
changed (Fuel's finiteness check, Engine's bit comparison and the floor above 0, `_car_tuples`); thermal.py's edit
is a docstring. derived_sha and engine_sha did not move.

### Lab (read-only; `tools/lab_dump.py` on the repository, `tools/lab_compare.py -X utf8` against `lab/lab_ref_P4.json`, cf43fbb's)

- `scratchpad/p7/lab_cand_P7.json`, `lab_compare_P7.txt`: 36325 leaf values; 178 source-line numbers moved; 88
  re-worded strings (build step 1's three); 4 other differences, each intended: `/meta_en` and `/meta_ar`
  `concepts[4]/source/match` "m_air" -> "m_air =" (the air concept's anchor, the review of P4's should-fix 1), and
  `concepts[7]/range` (the fuel concept: the clip is the engine's, 0.70-1.25 on the B58; the review of P2's
  should-fix 7). Every number the lab computes is IDENTICAL.

### Scratch scripts of P7 (not certificate tools; in `scratchpad/p7/`)

- `mutate.sh` and its result `mutate.txt`: P6's scheme (a minimal tree copy per mutation; the master samples and the
  one logged drive the replay test reads copied in, never edited), each mutation undoing one P7 fix and running only
  the tests that guard it. The unmutated copy passes (77 tests, exit 0) and all 16 mutations fail (run twice; the
  second after the two skip controls were made to expect any plant already calibrated, so they skip, not fail, after WP4): Fuel's
  finiteness check off; Engine's copies compared with == again (-0.0 against 0.0); thermal_replay's LHV check off;
  thermal_replay given afr_st=14.7, or typed_engine("b58")'s; the floor's lower bound off; `_record`'s "is missing"
  reworded (a bare assertRaises would have passed it); `_car_tuples` off in EpaCar, and in CvtCar; `c2_errors`
  without the plan's comparisons (the 4.411 control then fails); the live Supra's sum regrouped; `fingerprint._git`
  back on strip(); the scan's literal rule off; each of the three uncalibrated_or_skip calls removed (its control
  then fails on the Mazda's subtest).
- The scan's literal rule on the live text, read-only: `scan_source` of car_thermal.py as it is gives `[]`; with
  `afr_st=14.7` it flags `measured_fuel_gps` "afr_st (a literal)"; calibrate_thermal.py and model_vs_data.py give `[]`.
- `verify_docs.py` on the final P7 tree (read-only): "All 74 checks pass (959 figure mentions scanned in the
  documents)", in `scratchpad/p7/verify_docs_final.txt`. `docs/build_step_2/HANDOFFS.md` is untracked, so not scanned;
  its first line declares it a dated record once committed.

## 22 October 2026, commit A: the certificate run prepared (amendment B9)

The plan of the run is `CERT_PLAN_A.md` (S), its shell variables `env_A.sh`, its config for
`make_cert.py --config` `cert_A.json`, and its reproduce block `reproduce_A.json`. Nothing of the
repository was edited.

### `tools/make_cert.py`: parametrised (amendment B9)

- **Before the edit:** the archive's, sha256 `a6cd572e5166ecddf551ce835e7bade164a469ae72fbd95b65b613af433e4c7a`
  (equal to `results/B58_IDENTITY/certificate_tools.tar.gz`'s `tools/make_cert.py`, `cmp`; copied to
  `scratchpad/cert2_bs1_snapshot/tools_before_B9/`). LF line ends, kept.
- **What:** three insertions, nothing changed or removed (`diff`: `3a4,8`, `29a35,43`, `137a152,543`):
  1. the docstring names the second usage, `make_cert.py <out.json> [<archive>] --config <cert_A.json>`;
  2. before `OUT = sys.argv[1]`: `--config <file>` is taken out of `sys.argv` when present (when absent,
     `sys.argv` is untouched);
  3. after `lines_matching()`, before build step 1's `cert = {}`: the commit-A block (`commit_a()` and its
     helpers) and `if CONFIG is not None: sys.exit(commit_a(CONFIG))`.
- **What commit_a() writes:** commit A's certificate from what the run wrote, as the config names it:
  the run groups' records (`cert_results/*.json`, each a list of {level, item, command, cwd, expected,
  got, verdict, seconds, evidence_files}; each record checked for those keys and a verdict PASS or
  FAIL; each evidence file hashed, or MISSING), the fingerprints at the start and the end, the
  manifests, compare_all.sh's reports (the harness by family, as build step 1's code groups it, and
  every harness control recomputed by control_verdict.py's rules, with `--allow-missing`), value
  counts from the comparison JSONs, the lines the config's regular expressions read from the runs'
  outputs (the B11 line of test_fuel_forms.EngineSha among them), the previous certificate read from
  git (`c47907b:results/B58_IDENTITY.json`: build step 1's plant_sha, derived_sha, engine_sha), X1's
  `meta.json`, `pip freeze`, `git rev-parse` / `git log` / `git archive` (the reference's full sha and
  tar sha256, the commits on the base), the tools' hashes and the archive. The verdict is the AND of
  ten checks (every record well formed; every record PASS; every required item answered; the harness
  BIT-IDENTICAL; every control as expected; the plant's fingerprint the same at the start and the end;
  derived_sha and the shared FATAL fields as the reference's; engine_sha over build step 1's keys equal
  to build step 1's; the manifests equal; every value count read), with the config's pending items
  (L8) listed beside it. No hash and no count is typed in the code or the config; the prose (what,
  asked_by, notes, not_covered, tools_note, verdict texts) is the config's.
- **Reference side (build step 1's mode) shown unchanged:** run without `--config` against S as it
  stood before this edit (`scratchpad/cert2_b9/bs1_before.json`) and after every edit of this entry
  (`bs1_final.json`): the two JSONs differ in the `tools` block only, in the four entries this entry
  adds or changes (`make_cert.py`, `make_md.py`, `cert_record.py`, `l9_check.py`). And `bs1_before.json`
  against the committed `results/B58_IDENTITY.json`: HEAD, the two hashes the page says the archive
  cannot re-make (`reference.archive_sha256`, L7's `scratch_final_zip`) and the `tools` block (WP1's tool
  edits), nothing else.
- **Shown able to fail:** a dry run on synthetic records (`scratchpad/cert2_b9/cert_dry.json`,
  `fakeS/cert_results/`) reads NOT CERTIFIED with a malformed record, a FAIL record, MISSING items, a
  control without its allowance (INCOMPLETE), a control expected DIFFERENT on two identical labels
  (FAIL) and a control with no compare report (INCOMPLETE), and PASS on P7's real `ctl_P7_afr` and
  P3fix's `ctl_P3fix_AB0`; the real `cert_A.json` before the run, with no record and no run file,
  reads NO on all ten checks (`real_config_after_move.json`).
- sha256 after: `409ed68017e57af6f614795bb49edbd0753a70de35a2f8a23e1e2c1488647806` (1150 lines).

### `tools/make_md.py`: parametrised (amendment B9)

- **Before:** sha256 `1fec2b48b22d2e5c7d2e856b19fd6a1d7819c23930ed4432c854ebc0dc2110d1` (the archive's).
- **What:** two insertions (`diff`: `7a8,11`, `13a18,247`): the docstring's paragraph, and after the JSON
  is loaded, `commit_a_page()` and `if c.get("certificate_format") == 2: sys.exit(commit_a_page(c, out))`.
  make_cert.py's commit-A JSON carries `"certificate_format": 2`; build step 1's JSON has no such key,
  so its page is written by the untouched code below.
- **The page:** the verdict and its ten checks; what was compared (both fingerprints, build step 1's
  hashes from git, X1's meta.json, B11's stripped engine_sha, the shared FATAL fields, the git fields,
  the plant at the start and the end); the environment; the controls (recomputed, then the records of
  level `control`); the harness by family and every record level by level; the re-run list item by
  item with its record count and verdict, pending L8; every difference (the records' `difference`
  fields and the fingerprint fields that differ); what is not covered (pending, the config's list,
  every FAIL and MISSING); reproduce. Every number from the JSON.
- **Reference side shown unchanged:** `make_md.py bs1_before.json` before and after the edit:
  byte-identical pages (257 lines; `cmp`), re-checked after the last edit.
- sha256 after: `86e9c4c3de74b4853fdee1457b966ac661511eb6569972ba7fa0d08f8940123e` (592 lines).

### New tool `tools/cert_record.py`

- `python -I cert_record.py <group> --level --item --command --cwd --expected --got --verdict PASS|FAIL
  --seconds [--evidence ...] [--what] [--environment] [--difference]`: appends one record to
  `S/cert_results/<group>.json` (rewritten whole through a temporary file and os.replace). Refuses a
  verdict other than PASS or FAIL (a check that did not run is not recorded) and a group name that is
  not a plain file name; warns of an evidence file it cannot find. sha256
  `dc4850149ae586bb76496354efc1b905809647ce9fa08e90d2c33b20e4ac76fd`.

### New tool `tools/l9_check.py` (PLAN.md 3.6 item 17)

- `python -I l9_check.py <copy> <ENGINE_THRESHOLDS.json> [--since <unix s>] [--json out]`: the sha_text
  (CRLF read as LF, thresholds/common.py's rule, re-implemented so the copy's code is not imported) of
  `results/ENGINE_THRESHOLDS/b58_propagation.json` and every `ecu/*.json` in the copy against the
  contract's `generator_inputs_sha256`; fails on a missing file, an unlisted file, a differing hash,
  and, with `--since`, a file the run did not rewrite.
- **Shown able to fail:** on REPO's own committed files, 25 of 25 equal without `--since` (exit 0) and
  0 of 25 with `--since` the time of the check (exit 1). sha256
  `413ee19bc3720001cd47fafd0aaa78a980c6b2019788035294b20ca7594b57ba`.

### Not edited

- `harness.py` (`0e06275c…`, P7's), `run_jobs.py`, `compare_all.sh`, `cmp.py`, `control_verdict.py`
  (`c57d1db4…`), `run_suites.sh` (`e1efa910…`), `run_writer.sh`, `run_l4.sh`, `run_l6.sh`, `check_l6.sh`,
  `run_app.sh`, `run_app_extra.sh`, `run_drift.sh`, `drift_control.py`, `make_archive.py`, `make_meta.py`,
  `lab_dump.py`, `lab_compare.py`, `l6_agents.py`, `l6_check.py`, `l7_diff.py`, `l7_expect.py`,
  `bd_dump.py`, `derived_check.py`, `copy_tree.py`, `manifest.py`, every jobs file: `cmp` against the
  copies taken before this entry's edits. Three choices made in the plan instead of an edit:
  - `run_suites.sh quick` runs `test_engine_threading.py` beside `fingerprint.py`, and that test creates
    `_scan_probe_*.py` in REPO for a moment, which `fingerprint.py`'s git_dirty counts. The plan runs
    test_engine_threading alone first (G7.0) and the quick list's other lines, written out with the
    script's own `one()`, after it (G7.2), with `test_carried.py` added (the review of P7, item 1).
  - `make_archive.py`'s SKIP_DIRS does not name `refw`, `candw`, `candt` or `pre`: the plan removes those
    trees before the archive is made (F.3), as build step 1's `refw` was.
  - `make_meta.py`'s `identity_override` text still says "build step 1's identity certificate": it is
    written into L7's scratch `meta.json` only, never a result.

### Prepared in S (no tool)

- `cand`, `candd`, `candw`, `candt`: `copy_tree.py` of REPO (1287 files each, all equal to
  `manifest_start_A.txt`: 1287 files, manifest sha256 `b2f45892f0842049`); `refw` = `cp -a ref`; `pre` =
  `git archive c47907b` (both `tar --compare`d: 0 content differences; `ref` likewise).
- `L5/backup` (run_writer.sh needs it; the archive leaves `backup` out), `L9`, `cert_results`, `cert_out`.
- Build step 1's candidate-side evidence (268 files: `L4/cand*`, `L5/cand_*`, `L6/*`, `L7/cand_*`, `L8/*`,
  `F2` but `new_drive_ref.txt`, `F11/cand_*`, `app/cand_*`, build step 1's lab and suites outputs,
  `cmp/L6_*`, `cmp/L8_*`, `out/fp_cand.txt`, `out/ref2`, `out/ctl_*`, `logs`, `repro`, the two manifests)
  moved to `scratchpad/cert2_bs1_snapshot/moved_from_S/`, listed with sha256 in `S/bs1_moved.txt`: this
  run writes the same names, and a step that failed to rewrite one would otherwise be read as fresh
  (the dry run's "every value count read" was ok before the move, on build step 1's `cmp/L6_*.json`).
  They are also in build step 1's archive (`results/B58_IDENTITY/certificate_tools.tar.gz` at c47907b),
  and the whole of S's evidence before this entry is copied to `scratchpad/cert2_bs1_snapshot/`.

### Scratch scripts (not certificate tools; in `scratchpad/cert2_b9/`)

- `move_bs1_candidate_evidence.py`: the move above. `write_reproduce_A.py`: `reproduce_A.json`.
- `bs1_before.json` / `.md`, `bs1_after.json`, `bs1_final.json`, `bs1_before_by_new_md*.md`: the
  build-step-1-mode checks. `fakeS/`, `cert_dry.json`, `dry.json`, `dry.md`, `fp_now.txt`: the dry run.
  `real_config_before_run.json`, `real_config_after_move.json`: the real config before the run.

- **Addendum, the same day (the plan's G1.7):** in a fresh extraction of build step 1's archive, with the
  edited `make_cert.py` and `make_md.py` copied beside the unedited ones (as `make_cert_A.py`,
  `make_md_A.py`, so that both see one tools folder and one tools block), the two write byte-identical
  JSON (`BIT-IDENTICAL at every level`) and byte-identical pages (257 lines); against the committed
  `results/B58_IDENTITY.md` the page differs at line 30 only (HEAD, and the cf43fbb tar's sha256, which
  the archive cannot re-make). The test folder was removed; the plan's G1.7 repeats it.

- **Addendum, last edit of the day:** `make_cert.py`'s commit-A verdict writes the harness value count as
  MISSING, not 0, while the harness rows are MISSING (a page before the run read "harness: 0"); one
  condition added in `commit_a()`, nothing else. sha256 after it:
  `1421fda829c5eba0f15dde6e3ca94b93658208e4fdddfc625711c4cbbe55d467` (1151 lines; it replaces
  `409ed680...` above). The G1.7 check re-run on it: JSON and page byte-identical, the committed page
  differs at line 30 only (`S/prep/b9_build_step_1_mode.txt`).

## 23 October 2026, commit A, the final step (F: the certificate written)

The run's seven groups were done (G3-roads, G4-data and G6-agents resumed after a usage limit, G5's
three FAIL records rechecked by G5-recheck as records 24 to 26 of `cert_results/G5-app-lab.json`).
make_cert.py then refused two things the run held, though the plan had foreseen both: G5's rechecks
(verdicts written "PASS (...)" with a `rechecks` field, appended by `scratchpad/cert2_G5r/append_record.py`,
which cert_record.py cannot write) and the two files G5 changed in the repository during the run
(CERT_PLAN_A.md F.1: "list the files in `cert_A.json`'s `candidate.files_changed_note`, and a plant file
among them voids the run"; the tool's manifest check read only `r0 == r1`). Two edits, inside the
commit-A block only; G5's records are read as written, never edited.

### `tools/make_cert.py`: rechecks and declared changed files (commit-A block only)

- **Before:** sha256 `1421fda829c5eba0f15dde6e3ca94b93658208e4fdddfc625711c4cbbe55d467` (1151 lines, the
  addendum above), copied to `scratchpad/certF/tools_before_F/`.
- **What** (`diff`: `248a249,253`, `260a266,303`, `333a377`, `384a429,438`, `457c511,512`, `458a514,516`,
  `466,467c524,527`, `498c558,559`, `511c572,575`):
  1. `_records()`: every record gets `record_id` ("<group>.json record <n>", n from 1); a verdict
     "PASS (<why>)" is read as PASS **only on a record with a `rechecks` field**, the text kept as
     `verdict_as_written` and `verdict_note`. Any other verdict that is not PASS or FAIL is still a problem.
  2. New `_rechecks()`: a `rechecks` field must name an earlier FAIL of the same file
     ("<group>.json record <n>"), and the recheck must be a PASS; then the FAIL gains `rechecked_by`
     and stays a FAIL, the recheck gains `rechecks_record`, and the pair is listed in
     `records.rechecked`. Any other `rechecks` is a problem (fails "every record well formed").
     New `_closed()`: PASS, or a FAIL a later PASS record rechecks.
  3. The check "every record PASS" became "every record PASS, or a FAIL that a later PASS record
     re-checks (both kept)"; an item of the re-run list is PASS when each of its records is closed,
     and lists `answered_by` (the groups whose records name it) and `rechecked_fails`.
     `records.failed` keeps every FAIL, with its `record` and `rechecked_by`; `records.failed_not_rechecked`
     counts the open ones.
  4. `candidate.files_changed_declared` (config: `[{path, by, why}]`): the check "the repository
     unchanged during the run (manifests)" became "... (manifests), but for the files the config
     declares, none a plant file": it holds if exactly the declared files changed (set equality,
     so an undeclared change and a declared non-change both fail), and, when any did, the end
     fingerprint's `git_dirty_plant_files` is empty on the start's `git_head`. With no declaration it
     is the old `r0 == r1`. The JSON gains `files_changed_declared`, `files_changed_as_declared`,
     `plant_files_dirty_at_the_end`, `git_head_at_the_start_and_the_end`.
- **Build step 1's mode unchanged:** the plan's G1.7, again, on build step 1's archive (HEAD's): JSON and
  page byte-identical (257 lines), the committed page differs at line 30 only
  (`S/prep/A_F_build_step_1_mode.txt`; F-certificate.json record 10).
- **Shown able to fail:** `scratchpad/certF/dry_rechecks.py` runs make_cert on mutated copies of the real
  records and config: the real ones read BIT-IDENTICAL with three pairs (records 9-24, 19-25, 22-26); each
  of ten mutations reads NOT CERTIFIED with its check NO (a "PASS (...)" without `rechecks`; a recheck
  naming a PASS, a later record, no record; a recheck that is a FAIL; an unrechecked FAIL; one changed
  file undeclared; a declared file that did not change; a plant file dirty at the end; no declaration)
  (`S/prep/A_F_make_cert_dry.txt`; F-certificate.json record 11).
- sha256 after: `e862b1a67240c505e17c9a5fc6d87fbe199435451035a33ae223288c466648d6` (1215 lines).

### `tools/make_md.py`: the page shows both records of a recheck, and the declared files (commit-A page only)

- **Before:** sha256 `86e9c4c3de74b4853fdee1457b966ac661511eb6569972ba7fa0d08f8940123e` (592 lines).
- **What** (`diff`: `39a40,53`, `54c68,69`, `137,138c152,153`, `168,169c183,184`, `183c198,201`, `201a220,225`,
  `209a234`, `210a236,241`): `vcell()` (a record's verdict with its note, "re-checks <record>" and
  "re-checked by <record>") and `rid()` (the record's id beside its cwd and seconds) in the level and
  control tables; the verdict line counts the rechecked FAILs; the re-run list shows the answering
  groups and any rechecked FAIL; section 5 lists each declared file with who changed it and why, and
  whether the change is as declared; section 6 writes each rechecked FAIL with its own `got` and its
  recheck's verdict and `got`.
- **Build step 1's page unchanged:** as above (G1.7 again).
- sha256 after the recheck edits: `2393100a51222d4909c9b0a0e7336f7e5ae4957169494d363c0af62d1e6ef359` (623 lines).

### A second edit of both tools: `page_markers` (the drift control asked for it)

The drift control with the draft in the tree read exit 1, and `verify_docs.py` named three lines of the
page, each a record's own words that a figure's pattern reads as that figure (F-certificate.json record 12;
no figure of the plant is wrong, and the page quotes no value this run computed as a live claim). The
records stay verbatim, so the page carries a figure-specific `RETIRED-OK` marker above the three tables
that hold them, as `verify_docs.py`'s own mechanism asks (AUDIT2.md H2-6: a marker excuses only the
figures it names, in that table).

- **`tools/make_cert.py`:** `out["page_markers"] = cfg.get("page_markers") or {}`, and the key in the
  output order. Nothing else; the markers are prose in the config, no hash and no count.
- **`tools/make_md.py`:** above section 2's control table and above each level table, the marker the
  config gives for that key, written as an HTML comment.
- **`cert_A.json`:** `page_markers` for `control` and `L2` (the conditions jobs are named by their ambient
  air in kelvin, which the premise pattern reads as the baseline damage) and for `L5` (G4-data's count of
  build_dataset's derivations, one per log, which the validate pattern reads as the quantities inside
  their band), each with `_what` saying why.
- **F-certificate.json record 12** is reworded to name those two figures in words instead of in the matched
  form, so the docs table needs no exemption; its raw output is in its evidence files
  (`suites/A_F_verify_docs_draft_try1.txt`, `cert_out/B58_IDENTITY_try1.md`). It keeps its FAIL verdict and
  is the only record of this run whose wording was changed after it was written; no other group's record
  was touched.
- The sha256 of both tools after this edit is not typed here: the certificate's own `tools` block carries
  every tool's hash, read by make_cert.py from the file (and `out/A_G1_tool_hashes.txt` holds the hashes as
  they were when G1 ran, before the final step's two edits).

### The config and the reproduce block (`cert_A.json`, `reproduce_A.json`; no tool)

- `cert_A.json`: `date` 2026-10-23; `candidate.head_note` no longer says "clean"; `candidate.files_changed_declared`
  (the two files, by G5-app-lab, with why) and `files_changed_note`; four `not_covered` entries (what did
  not run besides L8; the failures on both trees; where the run left its plan; the last two checks);
  `notes.nothing_computed_moved` (prose, no number).
  Before: `scratchpad/certF/tools_before_F/cert_A.json`.
- `reproduce_A.json`: the REPO convention says the two files changed; a step F.2 (the documents check and
  the draft); F.3 runs make_cert.py and make_md.py with `-X utf8` (`-I` ignores PYTHONIOENCODING, and
  printing a record with a character cp1252 lacks raised UnicodeEncodeError after the JSON was written)
  and names the last verify_docs.py. Before: `scratchpad/certF/tools_before_F/reproduce_A.json`.

### Not edited

- Every other tool, and every group's records (`cert_results/*.json` but `F-certificate.json`, which this
  step writes with cert_record.py). G5's records 24 to 26 are read as G5-recheck wrote them.

### Removed before the archive (CERT_PLAN_A.md F.3)

- `S/refw`, `S/candw`, `S/candt`, `S/pre` (make_archive.py's SKIP_DIRS does not name them).

### Two later edits of the config, and the archive made again

After the first archive, `cert_A.json` gained two things, so the archive was made again and
`make_cert.py` / `make_md.py` run once more, in the order CERT_PLAN_A.md F.3 gives (archive, then the
JSON that records its sha256, then the page):

1. `not_covered`: "a check of this page cannot be inside it" — the drift control on the final files, the
   last `verify_docs.py` and the final step's own last records are in `cert_results/F-certificate.json`
   and in the report of the run, not in the JSON or the archive.
2. `pending` gains item 15's one part that did not run (`test_epa_map.py` a second time, with
   `GRAD_EXTRA_DATA` naming the MY2021 and MY2023 Test Car Lists, which are not on this machine), and
   item 15's `asks` says so. Before this, the re-run list read PASS for item 15 while part of what it
   asks had not run; the not-covered list said so, but the table is what is read first.

3. The `drift_test` extract's pattern now ends at `(all parts)`. `run_drift.sh` concatenates the six
   parts and appends the sum, so `^(\d+ of \d+ drifts CAUGHT.*)$` matched part 1's own line and the
   JSON's extract read "3 of 3" where the run caught 18 of 18 (the record of the run, F-certificate.json
   record 9, always read 18 of 18, and the page prints the record, not the extract). Caught by reading
   the extracts of the finished JSON.

No tool changed for any of the three. Every other member of the archive is the file the JSON names, hash
for hash; what came after the archive is the two final checks and the records of them.

## 23 October 2026, commit A, the certificate's text fixed after its review (F2)

An adversarial review of the files made at 05:18 (archive, JSON, page; its records are
`scratchpad/rev_A/R-review.json`, its evidence beside them) found the B58's identity holding, and the
certificate's own text wrong in two places (must-fix) and five more (should-fix). This step fixes them and
makes the archive, the JSON and the page once more, last.

### Tools: not edited

- Every tool in `tools/` has the sha256 the 05:18 JSON gives it (65 files, `.py`, `.sh`, `.txt`, compared
  before this step's first edit). make_cert.py and make_md.py are the final step's (`page_markers` included).
- G5's three re-check records now carry a plain verdict, so make_cert.py's reading of "PASS (<why>)" beside
  a `rechecks` field (the final step's edit) no longer applies to any record of this run. It is left in the
  tool: `dry_rechecks.py`'s mutations still show it refuses that form without `rechecks`.

### Records

- **`cert_results/G5-app-lab.json` records 24-26 (should-fix 7):** the verdicts "PASS (pre-existing, same on
  cf43fbb)" and "PASS (environmental, recurs no more)" (twice) became "PASS", the words moved into a
  `verdict_note` field beside each (make_md.py shows it in the record's verdict cell). Made by
  `scratchpad/certF2/edit_g5_verdicts.py`, which refuses unless the file re-dumps byte for byte and then
  checks that nothing else changed; the file as G5-recheck wrote it is `prep/A_F2_G5-app-lab.before.json`.
  The only change this run made to another group's record file (F-certificate.json record 21).
- **`cert_results/R-review.json` moved to `scratchpad/rev_A/R-review.json`**, unchanged (sha256
  `e6bf4a3c…`): make_cert.py reads every `cert_results/*.json`, the review's six FAILs are on the text of
  the certificate it reviewed, and one of them (CHECKPOINT.md's body) is the commit step's, so the file
  stays beside the records, not among them (F-certificate.json record 22). Kept outside S so that the
  archive does not carry the hashes of the two earlier archives the review quotes.
- **`cert_results/F-certificate.json`:** records 19-23 appended with cert_record.py (the MY2021/MY2023 fetch,
  test_epa_map.py with them, the G5 verdict edit, the review moved aside, the study page's stamp against the
  tree commit A holds). Record 16 is rewritten for the last make (must-fix 1): it described the first make,
  whose archive no file now holds. Records 17 and 18, which checked the 05:18 files, keep their command, expected
  and got and gain a `difference` field saying so; their labels (`what`), which called them the final certificate's and the
  last checks of the run, now name the 05:18 make; each record's `difference` quotes its first label. The before copy (records 1-23 before these two edits) is
  `scratchpad/certF2/before/F-certificate.after_19-23.json`.

### The config and the reproduce block (no tool)

- `cert_A.json` (before: `scratchpad/certF2/before/cert_A.json`):
  - `required`: item 3.6.11's asks names the committed tree 4461a91 and points to the pending part; item
    3.6.15's asks names the second test_epa_map.py run; a new row for item 3.6.19 (should-fix 1).
  - `pending`: item 3.6.15's part is gone (it ran: F-certificate.json records 19, 20; should-fix 6);
    "3.6.11 (part)", app.test_results again after the commit, on commit A itself, is added (must-fix 2).
    3.6.20 (L8) stays.
  - `asked_by`: item 11's run after the commit named beside item 20; `verdict_text.pass` names both pending
    items (L8 on the training device, app.test_results on commit A itself after the squash).
  - `candidate.files_changed_declared`, the study page: why its stamp names 4461a91, that 4461a91's tree is
    commit A's tree but for the eight files the run and the final step changed, none read by make_page.py,
    and that the page is left as built (should-fix 5).
  - `not_covered`: "What did not run here" (item 11's part pending, item 15 run whole); "Where the run left
    its plan" (G7.1 run by the final step; the reproduce block as run); "A check of this page cannot be
    inside it" rewritten to say which records are in the JSON (F-certificate.json 1-23) and which closing
    checks are not, and that the drift test on the final tree writes under `S/F2drift` (must-fix 1,
    should-fix 3); a new entry for the review kept beside the records.
- `reproduce_A.json` (before: `scratchpad/certF2/before/reproduce_A.json`; written by
  `scratchpad/certF2/write_reproduce.py`): every step as its records ran it, in the copies it ran in (S/cand
  for G2's writers; G5's and G7's own copies outside S for item 16 and L9, with `run_all(16)`; G4.1's
  `A_G2_` file names), the steps that did not run here marked "NOT RUN here" (L8; app.test_results on commit
  A), and the final step's last make and closing checks (should-fix 2).

### The last make (the order CERT_PLAN_A.md F.3 gives, once more)

1. A dry run outside S (`scratchpad/certF2/dry1`): make_archive.py, make_cert.py, make_md.py; the verdict and
   the counts read.
2. Record 16 written from the dry run (its counts; no hash of the archive: the archive holds the record, so
   the record cannot hold the archive's hash, which only section 7 gives).
3. A second dry run on the final records (`scratchpad/certF2/dry2`), verify_docs.py in a copy of REPO holding
   its three files, then the same three commands into REPO; the made files compared with the second dry run's,
   byte for byte.
4. The closing checks, after the make and so outside the JSON: drift_control.py on the final files,
   verify_docs.py, drift_test.py in six parts through `S/F2drift/tools/run_drift.sh` (a byte copy of
   `tools/run_drift.sh`; it derives S from its own folder, so it writes under `S/F2drift/suites` and leaves
   record 9's evidence in `S/suites` as it was), the plant's fingerprint and git status at the end. Their
   records are the last of F-certificate.json.

Nothing in the repository is edited by this step but the certificate's three files and CHECKPOINT.md's header
line for GRA-test (the pending list: L8, and app.test_results on commit A itself).

## 23 October 2026, commit A, the certificate's text fixed after its second review (F3)

A second adversarial review, of the files made at 06:12 (its records: `scratchpad/rev_A2/R2-review.json`; its
evidence: `scratchpad/rev_A2/work/`), found the B58's identity holding and the first review's items fixed, but for
CHECKPOINT.md's body (the commit step's). It found one new must-fix: the archive, unpacked as section 7 says, made
the certificate NOT CERTIFIED. It also found two record verdicts that did not follow the record rule. This step
makes one tool edit, changes records and the config, and makes the archive, the JSON and the page once more, last.

### `tools/make_archive.py`: out/ref archived (the second review's must-fix)

- **Before:** sha256 `5071d5e56612618b81de545473ecc7da96eb3e2fd8af2c8aa9d53f8857157579` (77 lines), copied to
  `scratchpad/certF3/before/make_archive.py`.
- **What** (`diff`: `14a15,20` a docstring paragraph, `25a32` `KEEP_DIRS = {"out/ref"}`, `34c41,42` the folder
  filter): a folder whose name SKIP_DIRS lists is still walked when its path relative to S is in KEEP_DIRS.
- **Why:** SKIP_DIRS names the scratch trees (`ref`, `cand`, `candd`, ...) and was applied at every depth. So
  `out/ref` was dropped along with `S/ref`. That folder is the reference harness run of 21 October: 34 logs,
  `_status.txt` and 34 `.npz`. make_cert.py reads `out/ref/_status.txt` for every control compared against `ref`
  (`_status_of`). In the unpacked folder those ten controls therefore read INCOMPLETE (exit `[None, 0]`), and the
  verdict read NOT CERTIFIED. Build step 1's archive (`a639190b…`) lacks out/ref too.
- **Effect:** the archive gains out/ref's 35 small files (the 34 logs and `_status.txt`). The `.npz` stay out
  (SKIP_EXT), and nothing else is added or dropped by the edit.
- **Shown able to fail** (mistake 12), with `scratchpad/certF3/scripts/repro_check.py` (copy:
  `prep/A_F3_repro_check.py`):
  - F-certificate.json record 34: the 06:12 archive, made by the unedited tool, made again from its unpacked folder,
    reads NOT CERTIFIED, with 228 differences that are not evidence hashes.
  - Record 35: the edited tool's dry archive (`scratchpad/certF3/dry0`) gives the same verdict and checks, and
    every value but the sha256 and bytes of evidence files the archive leaves out.
  - The archive commit A carries gets the same check as a closing record, after the make.
- **Build step 1's mode:** make_archive.py takes no part in make_cert.py and make_md.py's mode without `--config`
  (G1.7), so that mode is not touched.
- sha256 after: `b536855d307597197e0b7cb4bea192a36c30eec2f56b9e150daea1a0bcc3ecd6` (85 lines).

### Not edited

- The other 64 tools in `tools/` have the sha256 the 06:12 JSON's `tools` block gives them. They were compared after
  this edit; make_archive.py was the only one that differed.

### Records (`cert_results/F-certificate.json`; before: `prep/A_F3_F-certificate.before.json`, 29 records)

- **`cert_results/R2-review.json` moved to `scratchpad/rev_A2/R2-review.json`**, unchanged (sha256 `d61278aa…`;
  record 33). It moved for the reason R-review.json did: make_cert.py reads every `cert_results/*.json`.
- **Records 19 and 25 (should-fix 2, minor 3)**, by `scratchpad/certF3/scripts/edit_records_F3.py` (copy:
  `prep/A_F3_edit_records.py`; record 32):
  - Record 19, G7.1's fetch: its expected is CERT_PLAN_A.md G7.1's again ("exit 0, every file verified ..."), so it
    reads FAIL (the run exited 1). The words it was first written with are kept in `expected_as_first_written`,
    `verdict_as_first_written` and `difference_as_first_written`.
  - Record 25, the 06:12 make's closing check: its got is its first run's ("CLOSING CHECK: FAIL (34 of 35 ok)"), so
    it reads FAIL. `got_as_first_written` points to the before copy rather than repeating the 06:12 archive's
    sha256, so the page and the JSON give one archive hash.
  - Records 24-29 checked the 06:12 make's files: each label names that make, and a `difference` says so, as records
    17 and 18 were treated.
- **Records 30-35 appended** by `scratchpad/certF3/scripts/append_records.py` (cert_record.py cannot write
  `rechecks`):
  - 30 re-checks 19: G7.1's command, unchanged, with the seven EPA package zips the exit code also needs copied into
    `S/tcl` from the team's data folder, each checked against the list (`scratchpad/certF3/scripts/place_zips.py`,
    copy `prep/A_F3_place_zips.py`). It printed "ALL VERIFIED: 9 of 9 listed files, 18 of 18 repository copies",
    exit 0, and fetched nothing.
  - 31 re-checks 25: its second run.
  - 32 is the record edit.
  - 33 is the review moved aside.
  - 34 and 35 are the archive's control and pre-check.
- **Record 16 is rewritten for the last make** (`scratchpad/certF3/scripts/rewrite_16_F3.py`). Its counts come from
  the dry run, and it gives no hash of the archive.

### The config and the reproduce block (no tool)

- **`cert_A.json`**, by `scratchpad/certF3/scripts/edit_config_F3.py` and `edit_config_F3b.py` (the second after
  dry0's check listed what the archive leaves out), as string edits, so the file's layout is kept;
  before: `scratchpad/certF3/before/cert_A.json`. Changes to `not_covered`:
  - "Where the run left its plan": G7.1's FAIL and its re-check.
  - "A check of this page cannot be inside it": four makes, records 1 to 35 in the JSON, and the closing checks
    including the archive made again.
  - A new entry for the second review: its three FAILs, and that the commit step runs verify_docs.py,
    drift_control.py and drift_test.py again after its edit of CHECKPOINT.md's body.
  - A new entry, "What the archive makes again, and what it does not".

  Also changed: `tools_note` names make_archive.py's KEEP_DIRS, and item 3.6.19's `asks` names the archive's
  reproduction.
- **`reproduce_A.json`**, by `scratchpad/certF3/scripts/write_reproduce_F3.py`; before:
  `scratchpad/certF3/before/reproduce_A.json`.
  - A step for the reference harness run that makes out/ref, which the review found missing: run_jobs.py on S/ref
    with jobs_all.txt, 21 October, `S/ref_jobs.log`.
  - The S and REF conventions say what the archive holds of it.
  - G7.1 gains its re-check.
  - F2.2 and F2.3 are labelled as the 06:12 make's.
  - New steps F3.1-F3.3: this step, the last make and its closing checks.

### The last make (CERT_PLAN_A.md F.3's order, once more)

1. `scratchpad/certF3/dry0`, with the edited make_archive.py: make_archive.py, make_cert.py and make_md.py, then
   repro_check.py on its archive (record 35).
2. `scratchpad/certF3/dry1`, then record 16 written from its counts. Then `scratchpad/certF3/dry2` on the final
   records, and verify_docs.py in a copy of REPO holding dry2's three files.
3. The same three commands into REPO, each stdout to `scratchpad/certF3/final/`. The made files are compared with
   dry2's, byte for byte.
4. The closing checks, after the make and so outside the JSON:
   - `scratchpad/certF3/scripts/closing_check_F3.py`;
   - repro_check.py on the archive commit A carries;
   - drift_control.py on the final files;
   - verify_docs.py;
   - drift_test.py in six parts through `S/F3drift/tools/run_drift.sh` (a byte copy of `tools/run_drift.sh`);
   - the plant's fingerprint, git status and the manifest at the end.

   Their records are the last of F-certificate.json.

This step edits nothing in the repository but the certificate's three files. CHECKPOINT.md's body is left to the
commit step.

## commit P (build step 2, ORDER step 14): the tools as P's certificate runs them

Installed by p_gate.sh cert-kit on 2026-11-08 from the kit cert_kit/, reviewed (its
sha256 list: decisions/cert_kit_reviewed.txt). Each file below: commit A's sha256 (the archive's), P's, and the diff.

P's certificate (CERT_PLAN_P.md; the interface sheet 6.8; row 138 (4)) runs commit A's tools as commit A left them, but for the files listed below, each with its diff against the archive's copy. The kit was written before the run, reviewed, and its sha256 list recorded (decisions/cert_kit_reviewed.txt); nothing here changed during the run. Drafted 7 November 2026; nothing in it has run: `bash -n` parsed the shell files, and no Python file was executed.

Commit A's copy of every edited tool is the archive's (results/B58_IDENTITY/certificate_tools.tar.gz at RV), read out of it; commit A's own S (scratchpad cert2) holds the same bytes. p_gate.sh cert-kit appends, below this section, each kit file's two sha256 and its diff again, computed at install time against X: the two must agree.

Second edit, 8 November 2026 (after the first run's five FAIL records): the section "commit P, second edit" at the end names each FAIL and its fix, gives the sha256 of each file it changed before and after, and its diff against the first run's copy (S's installed one). The table of the new files below gives each sha256 as the file now stands.

### Why each file changed

- `tools/make_meta.py` (CERT_PLAN_P G6.3 and G6.4; the interface sheet 6.8). Schema 3's `plant_fingerprint(plant=, protocol="phase-d", backend=)` cannot be called at P: schema 4's takes every FATAL input by keyword, with no default (rule 1.7, mistake 19). The live block is now `FP.plant_fingerprint(protocol="phase-d", plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE, score_backend=FP.BACKEND_CYCLE, preview_h_s=engine_env.PREVIEW_H_S, reward_knock=engine_env.REWARD_KNOCK_DEFAULT)`, then `FP.for_arm(live, sighted="blind" not in os.path.basename(src))`, evaluate.py's arm rule, so that `blind_seed0` is stamped with the blinded arm's block (preview_h_s None, row 117) and `sighted_seed0` with the sighted one. The `identity_override` reason names P's certificate and this tree's schema-4 block, and records the arm. (Review fixes 3, P_GATE_PLAN.md section 12: the reason says that both agents are diffed against cf43fbb's evaluate.py, sighted_seed0 against build step 1's report and blind_seed0 against cf43fbb's run made in S/ref, as the driver does; before, it named sighted_seed0 alone.)
- `tools/make_cert.py` (P_GATE_PLAN.md D21 and 5.2, K5; and two findings of the kit's drafting). Four changes, inside the --config route only: (1) the candidate's git questions go to the config's `candidate.tree` (the clone at P's candidate) instead of REPO, whose HEAD is RV while P is uncommitted there, and `candidate.branch` may name the detached clone's branch; x1_meta is still read in REPO (runs/ is in no clone); (2) **schema 4 folds gears and final_drive into `transmission`, and `backend` into `train_backend`, `score_backend` and `backend_contract`**: unchanged, the check "derived_sha and the shared FATAL fields equal the reference's" would compare cf43fbb's gears with None and fail on P whatever the runs gave; the shared fields now read gears and final_drive out of `transmission` when a block has no field of either name, the fields stable through the run add schema 4's, and the identity gains `backends`; (3) **the previous certificate is now commit A's, of certificate_format 2, whose `identity.engine_sha` is a dict**: unchanged, amendment B11's check would compare build step 1's key-set hash with that dict and fail; it now compares with commit A's own `over_build_step_1_keys`, and one check is added for a format-2 previous certificate, engine_sha equal to its candidate's (row 94); (4) the config's `page_text` is carried into the JSON. With commit A's config (no candidate.tree, branch or page_text; a schema-3 candidate; build step 1's previous certificate) the JSON is byte for byte what it was, and without --config the build-step-1 code is untouched: G1.7 checks both, and its control checks the tree is used.
- `tools/make_md.py`: commit_a_page() wrote "build step 1's certificate", `CERT_PLAN_A.md` and "HANDOFFS.md's items for commit A" as its own words; a JSON with `page_text` gives them (P: "commit A's certificate", CERT_PLAN_P.md amending CERT_PLAN_A.md, the interface sheet 6.8's list, the base RV), and a schema-4 candidate's `backends` are written where schema 3's one backend was. Without page_text and backends the page is byte for byte what it was (G1.7).
- `tools/run_jobs.py`: each job starts `[PY, "-I", "-B", harness.py, ...]` (D20, K4: -I ignores PYTHONDONTWRITEBYTECODE, so harness.py wrote `__pycache__` beside what it imported, in the clone and in S/ref).
- `tools/compare_all.sh`, `tools/check_l6.sh`: `$PY -I -B` for cmp.py and l6_check.py (K4).
- `tools/run_writer.sh`, `tools/run_l4.sh`, `tools/run_l6.sh`, `tools/run_app.sh`, `tools/run_app_extra.sh`, `tools/run_drift.sh`: every Python they start passes -B (K4); and `CAND` has no default (`${CAND:?...}`): each fell back to the live repository's path, which holds P uncommitted while the roads check runs there (P_GATE_PLAN.md 5.2, item 2), so an unset CAND now stops the tool before it runs anything; but for run_l6.sh, whose `${CAND:?...}` sits inside `$(cygpath -m ...)`, where it ends only that subshell: an unset CAND leaves CAND empty there and l6_agents.py takes its working directory (its header says so since review fixes 3; the line itself is unchanged, so that the smoke step's text check still holds). env_P.sh sets CAND to the clone. drift_test.py's own children (verify_docs.py, started with sys.executable and no flag) inherit PYTHONDONTWRITEBYTECODE=1 from env_P.sh and write no bytecode.
- (Revised 7 November 2026 after the kit's review, P_GATE_PLAN.md section 11.) The first draft of these eight lost a space where `-B` went in, in four of them breaking every call (`cmp.py$S/out/...`, `l6_check.py$S/L6/...`, `"l6_agents.py""$tree"`, `test_reward.py"$@"`) and in two more only the layout (`$rows>`, `};[`, `>$S`). Each is now the archive's but for the `-B` tokens, the `CAND` default and its header lines: p_gate.sh cert-kit's smoke step checks it by text (comments dropped, the two intended edits applied to the archive's: 0 lines apart) and by running both versions with PY=echo on the same arguments (only `-B` apart), and replays compare_all.sh and check_l6.sh on commit A's own dumps against commit A's reports.
- `tools/l7_expect.py`: `--agent <tag>` (default sighted_seed0) and `--repo <tree>` (default the repository): L7 at P scores blind_seed0 beside sighted_seed0 (CERT_PLAN_P G6.3), and the committed raw scores are read in the clone. Without the options it is unchanged.
- `tools/cert_record.py`: an optional `--rechecks "<group>.json record <n>"`, carried into the record as `rechecks`, the field make_cert.py's `_rechecks()` already pairs with an earlier FAIL (commit A wrote it by editing records afterwards). Without it a record is unchanged.
- `tools/road_json_diff.py` (new in tools/): commit A's `g3/road_json_diff.py`, byte for byte, moved into tools/ so that G3's difference texts are made by an archived tool of S/tools.
- `tools/failing_sets_P.py` (new): CERT_PLAN_A G5.1's failing-set snippet as a tool, against every reference run given, reading unittest's and node --test's spec layouts; a fixture's error (`ERROR: setUpClass (<module>.<Class>)`) is named `<Class>.setUpClass` in both invocations. The driver judges with cf43fbb's runs alone, as CERT_PLAN_A G5.1 does, and gives commit A's candidate runs and RV's base runs for information only.
- `tools/stated_counts_P.py` (new): amendment HP7.6 (every test count README.md and full_run.py state, against its run) as a check that can fail by itself.
- `tools/cert_driver_P.sh`, `tools/cert_final_driver_P.sh` (new): the drivers (K7, K8), CERT_PLAN_A.md's blocks as CERT_PLAN_P.md amends them; their headers state the contract with p_gate.sh. Revised after the kit's review: the main driver refuses any CERT_GROUPS but one-at-a-time, runs one group again with CERT_ONLY (p_gate.sh cert-recheck) and gives a re-run PASS record the `--rechecks` of the FAIL it re-checks (CERT_RECHECK_MAP), checks G1.7's two extractions against their own archive_members.txt before anything in them runs (and runs them with the cwd CERT_ROOT), judges G5 against cf43fbb's runs alone, and kills a launcher server left on port 8765; the final driver's 3.6.19 record drops make_cert.py's "NO every item of the re-run list answered" line (by construction while 3.6.19 has no record) and accepts a re-checked FAIL record's line. Revised again after the two re-reviews (review fixes 3, P_GATE_PLAN.md section 12): G1, G5, G6 and G7 each start from none of an earlier run's outputs that their checks count or compare, so that a CERT_ONLY re-run is judged on its own files (G6's re-run read "L6 done: 16 of 16" and always FAILed; a re-run control that crashed passed on the first run's status line and dump); every lab_dump.py's exit is recorded and required; G5's app records require the three ignored local paths p_gate.sh cert-prep copies into the clone, and the node tests `ℹ skipped 0`; npm ci's and the launcher's records fail closed (a FAIL that cert-recheck g5 re-checks) instead of leaving no record; a launcher server left on 8765 is found by the port it listens on (Get-NetTCPConnection), not by any python.exe naming launch.py; the END line says "none" or "at least one" refusal. The final driver refuses before its first record (exit 3, nothing written) while a FAIL record is open, so that its 3.6.19 record can never be a FAIL that nothing re-checks. Settled after the independent read of those fixes (the settle step, 7 November 2026, P_GATE_PLAN.md section 13): a re-run PASS of a check whose `what` CERT_RECHECK_MAP lists more than once (the check failed on the first run and on a re-run) is written once per line, each with its own `--rechecks`; the launcher cleanup records the 8765 listener and its Win32_Process descendants no older than their parent and kills exactly those pids, each without taskkill /T (which walks children by ParentProcessId alone); app.test_replay's record requires the three ignored local paths, as the other G5.1 app records do.
- `env_P.sh` (new): commit A's `env_A.sh` with REPO's role taken by the git clone at P's candidate (`candg`, committed and clean; row 139 (2)), the live repository named LIVE_REPO and read only for `runs/extremes_dt1` (gitignored, so not in the clone), `CAND` the clone, CERT_ROOT, CERT_X, COMMIT_A_S, P_GATE_OUT, NODE and NPM exported, and `rec` calling `cert_record.py` with `-B`; it refuses unless the clone's HEAD is P_CAND.
- `cert_P.json`, `reproduce_P.json` (new): P's config (amendment B9's schema, cert_A.json's fields) and the reproduce block. (Review fixes 3: not_covered's "Where the runs ran" names the three gitignored paths the clone holds, copied from the repository by p_gate.sh cert-prep.)

Not edited, though they start Python, because neither driver nor p_gate.sh runs them in P's certificate: `run_suites.sh`, `run_controls.sh`, `run_roads.sh`, `run_roads_review.sh`, `run_l8.sh`, `run_l8_review.sh` (L8 is ORDER step 18's, and test_device_gate.RunL8 reads `l8_compare.py` and `l8_perturbed.py` byte for byte from the archive: neither is touched), `import_all.py`, `bind_calls.py` (the last two also name the live repository). `harness.py`, `l6_agents.py`, `l6_check.py`, `lab_dump.py` start no Python; `l6_agents.py`, `l6_check.py` and `harness.py`'s x1 jobs read X1's agents and the committed raw scores in the live repository, which P does not change.

### The diffs (commit A's copy, the archive's, against the kit's)

#### tools/make_meta.py

commit A (the archive's tools/make_meta.py): sha256 `27afe1f07be4cba57d7ea8151274e19f9a1eb1d0e0954d61ed344592d289728a`; commit P (the kit's): sha256 `c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b`.

```diff
--- commit A: tools/make_meta.py
+++ commit P: tools/make_meta.py
@@ -1,17 +1,26 @@
-"""make_meta.py -- L7's candidate model directory: X1's sighted_seed0, its meta.json
-re-stamped with this tree's schema-3 fingerprint for the identity test only.
+"""make_meta.py -- L7's candidate model directory: an X1 agent (sighted_seed0, and blind_seed0 beside it),
+its meta.json re-stamped with this tree's schema-4 fingerprint for the identity test only.
 
-    python -I make_meta.py <candidate_tree> <src_run_dir> <dest_run_dir>
+    python -I -B make_meta.py <candidate_tree> <src_run_dir> <dest_run_dir>
 
 final.zip is copied byte for byte (sha256 printed for both). meta.json keeps
 every ADVISORY field of the original (train_dt, steps_requested, seed, tag, ...)
-and takes the FATAL fields and the schema from the live candidate fingerprint
-(fingerprint.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d",
-backend=fingerprint.BACKEND_CYCLE); backend required since the review of 21 October),
-so evaluate.py's check passes without --force-plant-mismatch. The re-stamp is
-declared inside the file, in "identity_override": the original schema and
-plant_sha, the original meta.json's sha256, and why. This is not a result
+and takes the FATAL fields and the schema from the live candidate fingerprint,
+built as evaluate.py builds its live side at P, with every FATAL input passed
+(rule 1.7, mistake 19): fingerprint.plant_fingerprint(protocol="phase-d",
+plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE, score_backend=FP.BACKEND_CYCLE,
+preview_h_s=engine_env.PREVIEW_H_S, reward_knock=engine_env.REWARD_KNOCK_DEFAULT),
+then fingerprint.for_arm(..., sighted=...), the arm read from the source directory's
+name as evaluate.py reads it ("blind" in it: the blinded arm, whose preview_h_s is
+None, row 117), so evaluate.py's check passes without --force-plant-mismatch. The
+re-stamp is declared inside the file, in "identity_override": the arm, the original
+schema and plant_sha, the original meta.json's sha256, and why. This is not a result
 directory; it lives in scratch and nothing under runs/ is touched.
+
+Build step 2, commit P (ORDER step 14; CERT_PLAN_P.md G6.3 and the interface sheet 6.8; recorded in
+TOOL_EDITS.md, section "commit P"): schema 3's plant_fingerprint(plant=, protocol=, backend=) is schema 4's
+call above, the blinded arm goes through for_arm, and the reason names P's certificate and this tree's
+schema-4 block instead of build step 1's and schema 3. Nothing else changed.
 """
 import hashlib
 import json
@@ -22,6 +31,7 @@
 tree, src, dest = (os.path.abspath(p) for p in sys.argv[1:4])
 os.chdir(tree)
 sys.path.insert(0, tree)
+import engine_env as E  # noqa: E402
 import engines  # noqa: E402
 import fingerprint as FP  # noqa: E402
 
@@ -34,17 +44,25 @@
 os.makedirs(dest, exist_ok=True)
 shutil.copyfile(os.path.join(src, "final.zip"), os.path.join(dest, "final.zip"))
 orig = FP.read(os.path.join(src, "meta.json"))
-live = FP.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d", backend=FP.BACKEND_CYCLE)
+live = FP.plant_fingerprint(protocol="phase-d", plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE,
+                            score_backend=FP.BACKEND_CYCLE, preview_h_s=E.PREVIEW_H_S,
+                            reward_knock=E.REWARD_KNOCK_DEFAULT)
+sighted = "blind" not in os.path.basename(src)
+live = FP.for_arm(live, sighted=sighted)    # evaluate.py's arm rule
 meta = {k: v for k, v in orig.items() if k not in FP.FATAL}
 meta.update({k: live[k] for k in FP.FATAL})
 meta["schema"] = live["schema"]
 meta["identity_override"] = dict(
-    reason=("build step 1's identity certificate (results/B58_IDENTITY.md, level L7): X1's "
-            "sighted_seed0 scored end to end by this tree's evaluate.py and diffed against "
-            "cf43fbb's evaluate.py on the original directory. Its FATAL fields are this tree's "
-            "schema-3 block, stamped by make_meta.py so that no --force-plant-mismatch is "
-            "needed; whether the plant behind them is cf43fbb's is what the certificate's "
-            "levels measure. Not a result directory"),
+    reason=("P's identity certificate (build step 2, ORDER step 14; results/B58_IDENTITY.md, level L7; "
+            "CERT_PLAN_P.md G6.3): X1's " + os.path.basename(src) + " scored end to end by this tree's "
+            "evaluate.py and compared with the committed raw scores, and diffed against cf43fbb's "
+            "evaluate.py on the original directory (sighted_seed0 against build step 1's report, blind_seed0 "
+            "against cf43fbb's run made in the certificate's S/ref). Its FATAL fields are this tree's "
+            "schema-4 block (" + ("sighted" if sighted else "blinded: preview_h_s None") + ", "
+            "fingerprint.for_arm), stamped by make_meta.py so that no --force-plant-mismatch is needed; "
+            "whether the plant behind them is cf43fbb's is what the certificate's levels measure. Not a "
+            "result directory"),
+    arm="sighted" if sighted else "blind",
     original_schema=orig.get("schema"), original_plant_sha=orig.get("plant_sha"),
     original_derived_sha=orig.get("derived_sha"),
     original_meta_sha256=sha(os.path.join(src, "meta.json")),
```

#### tools/make_cert.py

commit A (the archive's tools/make_cert.py): sha256 `583a69d36ff1716370331cefd3789905d14da637d0dfdd9fdcf67f94c9ccafa8`; commit P (the kit's): sha256 `28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea`.

```diff
--- commit A: tools/make_cert.py
+++ commit P: tools/make_cert.py
@@ -7,6 +7,28 @@
 of build step 2 is written by commit_a() from the run groups' records and the run's own
 files, as the config names them; without it, build step 1's certificate, as before.
 
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"; P_GATE_PLAN.md D21
+and 5.2 K5). Four changes, all inside the --config route; without --config nothing changed:
+  1. The candidate's git questions (HEAD, the branch, base..HEAD, the base, the previous
+     certificate's blob, cf43fbb's archive) are asked in the config's candidate.tree, when it
+     names one (P's certificate: the clone at P's candidate, committed and clean), and in REPO
+     otherwise, as before. x1_meta is still read in REPO (runs/ is gitignored, in no clone).
+     candidate.branch, when the config gives it, is written instead of git's answer (a
+     detached HEAD answers "HEAD").
+  2. Fingerprint schema 4 prints gears and final_drive inside one field, transmission, and
+     backend as train_backend, score_backend and backend_contract. The shared FATAL fields read
+     gears and final_drive out of the candidate's transmission field when its block has no field
+     of either name; the plant's fields through the run add the schema-4 fields; the identity
+     gains backends. A schema-3 block (commit A's) is read as before.
+  3. A previous certificate of certificate_format 2 (commit A's) holds engine_sha as a dict: its
+     candidate's value is the previous engine_sha, and its own reading over build step 1's key
+     set is what amendment B11's check compares with. With such a certificate one check is added:
+     engine_sha is the previous certificate's candidate's (row 94: P moves plant_sha, not
+     engine_sha). Build step 1's certificate (format 1, one value) is read as before.
+  4. The config's page_text, when it has one, is carried into the JSON for make_md.py.
+With commit A's config (no candidate.tree, no candidate.branch, no page_text, a schema-3
+candidate and build step 1's previous certificate) the JSON is byte for byte what it was.
+
 Every value below is READ from a file the certification wrote (the dumps'
 comparisons, the suites' outputs, the manifests, review.json); nothing is typed
 except the descriptions. A level whose evidence file is missing is written as
@@ -179,14 +201,33 @@
     return (a if r.startswith("..") else r).replace("\\", "/")
 
 
+_GIT_TREE = REPO        # (commit P) where the candidate's git questions are asked: commit_a() sets it
+
+
 def _git_out(*args, binary=False):
-    """git's stdout in REPO, or None."""
-    r = __import__("subprocess").run(["git", *args], cwd=REPO, capture_output=True)
+    """git's stdout in the candidate's tree (REPO, or since commit P the config's candidate.tree), or None."""
+    r = __import__("subprocess").run(["git", *args], cwd=_GIT_TREE, capture_output=True)
     if r.returncode != 0:
         return None
     return r.stdout if binary else r.stdout.decode("utf-8", errors="replace")
 
 
+def _with_transmission(f):
+    """(commit P, 7 November 2026; TOOL_EDITS.md, "commit P") A fingerprint's fields, with gears and final_drive
+    read out of schema 4's transmission field ("final_drive=3.15 gears=5.25 ... kind=stepped") when the block
+    has no field of either name; any other block (schema 3, commit A's) is returned as it is. The values are
+    the block's own text: nothing is typed."""
+    t = f.get("transmission") if isinstance(f, dict) else None
+    if not t or "gears" in f or "final_drive" in f:
+        return f
+    m = re.match(r"^final_drive=(\S+) gears=(.+?) kind=(\S+)$", t)
+    return f if m is None else dict(f, final_drive=m.group(1), gears=m.group(2))
+
+
+SCHEMA4_STABLE = ("train_backend", "score_backend", "backend_contract", "transmission", "preview_h_s",
+                  "reward_knock", "preview_samples_s")      # (commit P) schema 4's FATAL fields beyond schema 3's
+
+
 def _text(path):
     try:
         with open(_cfg_path(path), encoding="utf-8", errors="replace") as fh:
@@ -371,8 +412,11 @@
 
 def commit_a(config_path):
     import datetime
+    global _GIT_TREE
     with open(config_path, encoding="utf-8") as fh:
         cfg = json.load(fh)
+    # (commit P) the candidate's own git tree, when the config names one; REPO otherwise, as before
+    _GIT_TREE = (cfg.get("candidate") or {}).get("tree") or REPO
     files, records, problems = _records(cfg.get("results", "cert_results/*.json"))
     rechecked = _rechecks(records, problems)                         # (F, 23 Oct)
     fpc = cfg["fingerprints"]
@@ -413,7 +457,8 @@
     base = cc.get("base")
     log = _git_out("log", "--format=%h %s", f"{base}..HEAD") if base else None
     out["candidate"] = dict(
-        tree=REPO, branch=(_git_out("rev-parse", "--abbrev-ref", "HEAD") or "").strip() or None, head=head,
+        tree=cc.get("tree") or REPO,                                   # (commit P) the configured tree
+        branch=cc.get("branch") or (_git_out("rev-parse", "--abbrev-ref", "HEAD") or "").strip() or None, head=head,
         base=base, base_commit=(_git_out("rev-parse", base) or "").strip() or None if base else None,
         commits_on_base=None if log is None else log.strip().splitlines()[::-1],
         head_note=cc.get("head_note"),
@@ -440,8 +485,16 @@
     # the identity
     shared = ("gears", "final_drive", "dtheta_deg", "turb_protect_k", "oil_protect_k", "scenario", "episodes_sha",
               "eval_dt", "eval_duration", "n_episodes")
-    stable = {k: (f_cand.get(k) == f_end.get(k)) if f_end else MISSING
-              for k in ("plant_sha", "plant_text_sha", "derived_sha", "engine", "engine_sha", "backend")}
+    fcv = _with_transmission(f_cand)               # (commit P) schema 4: gears and final_drive in transmission
+    st_keys = ("plant_sha", "plant_text_sha", "derived_sha", "engine", "engine_sha", "backend")
+    if "train_backend" in f_cand:                  # (commit P) schema 4: backend is two fields and a contract
+        st_keys = st_keys[:-1] + SCHEMA4_STABLE
+    stable = {k: (f_cand.get(k) == f_end.get(k)) if f_end else MISSING for k in st_keys}
+    pe = prev_id.get("engine_sha")
+    if isinstance(pe, dict):       # (commit P) certificate_format 2 (commit A's): its candidate's, and its B11 reading
+        prev_es, prev_b11 = pe.get("candidate"), pe.get("over_build_step_1_keys")
+    else:                          # build step 1's certificate: one value, over build step 1's key set
+        prev_es, prev_b11 = pe, pe
     ex11 = extracts.get("engine_sha_over_build_step_1_keys", {}).get("groups")
     out["identity"] = dict(
         plant_sha=dict(reference=f_ref.get("plant_sha"), candidate=f_cand.get("plant_sha"),
@@ -452,10 +505,10 @@
                          x1_meta_json=(x1 or {}).get("derived_sha"),
                          previous_certificate=(prev_id.get("derived_sha") or {}).get("candidate")),
         engine=f_cand.get("engine"), backend=f_cand.get("backend"),
-        engine_sha=dict(candidate=f_cand.get("engine_sha"), previous_certificate=prev_id.get("engine_sha"),
+        engine_sha=dict(candidate=f_cand.get("engine_sha"), previous_certificate=prev_es,
                         over_build_step_1_keys=ex11[1] if isinstance(ex11, list) and len(ex11) > 1 else MISSING,
                         printed_by=extracts.get("engine_sha_over_build_step_1_keys", {}).get("file")),
-        shared_fatal_fields={k: [f_ref.get(k), f_cand.get(k)] for k in shared},
+        shared_fatal_fields={k: [f_ref.get(k), fcv.get(k)] for k in shared},
         fields_only_in_the_candidate=sorted(set(f_cand) - set(f_ref)),
         git=dict(git_head=f_cand.get("git_head"), git_dirty=f_cand.get("git_dirty"),
                  git_dirty_plant_files=f_cand.get("git_dirty_plant_files")),
@@ -466,6 +519,16 @@
                                   archive_sha256=(prev.get("archive") or {}).get("sha256")),
         read_from_runs=extracts,
         notes=cfg.get("notes") or {})
+    # (commit P) schema 4: what computes the engine in training and in scoring, and the contract; the shared
+    # fields read out of transmission; commit A's B11 reading of build step 1's key set. Each key is added only
+    # when it applies, so a schema-3 candidate against build step 1's certificate writes the JSON as before.
+    if "train_backend" in f_cand:
+        out["identity"]["backends"] = dict(train=f_cand.get("train_backend"), score=f_cand.get("score_backend"),
+                                           contract=f_cand.get("backend_contract"))
+    if fcv is not f_cand:
+        out["identity"]["shared_read_from_transmission"] = ["gears", "final_drive"]
+    if isinstance(pe, dict):
+        out["identity"]["engine_sha"]["over_build_step_1_keys_in_previous_certificate"] = prev_b11
 
     # the environment
     freeze = _text(cfg["pip_freeze"]) if cfg.get("pip_freeze") else None
@@ -568,14 +631,18 @@
         f_ref.get("derived_sha") == f_cand.get("derived_sha"),
         "engine_sha over build step 1's keys is build step 1's (B11)": (
             out["identity"]["engine_sha"]["over_build_step_1_keys"] not in (MISSING, None)
-            and out["identity"]["engine_sha"]["over_build_step_1_keys"]
-            == out["identity"]["engine_sha"]["previous_certificate"]),
+            and out["identity"]["engine_sha"]["over_build_step_1_keys"] == prev_b11),    # (commit P) prev_b11
         "the repository unchanged during the run (manifests), but for the files the config declares, none a plant "
         "file": (m0 is not None and m1 is not None and out["candidate"]["files_changed_as_declared"] and (
             r0 == r1 or (f_end.get("git_dirty_plant_files") == "" and bool(f_cand.get("git_head"))
                          and f_cand.get("git_head") == f_end.get("git_head")))),
         "every value count read": all(v["values"] != MISSING for v in counts.values()),
     }
+    if isinstance(pe, dict):       # (commit P) against a format-2 certificate: the plant as built has not moved
+        checks["engine_sha is the previous certificate's candidate's (row 94: plant_sha moves, engine_sha does "
+               "not)"] = prev_es not in (MISSING, None) and f_cand.get("engine_sha") == prev_es
+    if cfg.get("page_text"):       # (commit P) the page's words for this certificate, read by make_md.py
+        out["page_text"] = cfg["page_text"]
     vt = cfg.get("verdict_text") or {}
     out["verdict"] = dict(
         result=vt.get("pass", "CERTIFIED") if all(checks.values()) else vt.get("fail", "NOT CERTIFIED: see checks"),
@@ -586,8 +653,8 @@
             **{k: v["values"] for k, v in counts.items()}))
     order = ["certificate_format", "title", "what", "date", "asked_by", "verdict", "reference", "candidate",
              "identity", "environment", "harness", "controls", "values_compared", "records", "levels", "required",
-             "pending", "different", "not_covered", "page_markers", "tools", "tool_edits", "tools_note", "archive",
-             "reproduce",
+             "pending", "different", "not_covered", "page_markers", "page_text", "tools", "tool_edits", "tools_note",
+             "archive", "reproduce",
              "config"]
     out = {k: out[k] for k in order if k in out}
     with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
```

#### tools/make_md.py

commit A (the archive's tools/make_md.py): sha256 `dd6ebaf5ef49c91cb514ce904775250b0c399dbeeb6ce4aca17c1cb961ae9301`; commit P (the kit's): sha256 `44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98`.

```diff
--- commit A: tools/make_md.py
+++ commit P: tools/make_md.py
@@ -9,6 +9,14 @@
 A JSON written by make_cert.py --config (build step 2, commit A; "certificate_format": 2;
 22 October 2026, amendment B9, TOOL_EDITS.md) is written by commit_a_page(); any other
 JSON is build step 1's, and its page is written by the code below as before.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): commit_a_page()
+named the previous certificate "build step 1's certificate", the plan CERT_PLAN_A.md and the
+re-run list commit A's, in its own words. A JSON that carries page_text (make_cert.py copies
+the config's) gives those words: previous_certificate, plan, plan_short, rerun_list and
+candidate_base; a schema-4 candidate's backends (train, score and the contract) are written
+where schema 3 had one backend. Without page_text and backends the page is byte for byte what
+it was. Build step 1's page (the code after commit_a_page) is unchanged.
 """
 import json
 import sys
@@ -52,6 +60,8 @@
         return f"; {esc(r['record_id'])}" if r.get("record_id") else ""
 
     V, I, ID = c["verdict"], c["identity"], c["identity"]
+    PT = c.get("page_text") or {}                  # (commit P) the certificate's own words, when it gives them
+    PREV = PT.get("previous_certificate", "build step 1's certificate")
     lines = []
     w = lines.append
     w(f"# {c['title']}")
@@ -83,7 +93,7 @@
     w("| | reference | candidate |")
     w("|---|---|---|")
     commits = cand.get("commits_on_base") or []
-    ctext = (f"{len(commits)} commits on `{(cand.get('base') or '?')}`" + (f" ({esc(commits[0].split()[0])} to "
+    ctext = (f"{len(commits)} commits on `{(PT.get('candidate_base') or cand.get('base') or '?')}`" + (f" ({esc(commits[0].split()[0])} to "
              f"{esc(commits[-1].split()[0])})" if commits else ""))
     w(f"| code | `{ref['rev']}` (`{(ref.get('commit') or '?')[:12]}`), `git archive` (tar sha256 "
       f"{short(ref.get('archive_sha256'))}), extracted in `S/{ref.get('tree') or 'ref'}` | `{cand.get('branch')}` at "
@@ -92,16 +102,20 @@
       "the last |")
     ps, ds, es = ID["plant_sha"], ID["derived_sha"], ID["engine_sha"]
     w(f"| `plant_sha` | {code(ps.get('reference'))} (X1's `meta.json`: {code(ps.get('x1_meta_json'))}) | "
-      f"{code(ps.get('candidate'))} (build step 1's certificate: {code(ps.get('previous_certificate'))}); at the end "
+      f"{code(ps.get('candidate'))} ({PREV}: {code(ps.get('previous_certificate'))}); at the end "
       f"of the run {code(ps.get('candidate_at_the_end'))} |")
     w(f"| `plant_text_sha` | {code(ID['plant_text_sha'].get('reference'))} | "
       f"{code(ID['plant_text_sha'].get('candidate'))} |")
-    w(f"| `derived_sha` | {code(ds.get('reference'))} | {code(ds.get('candidate'))} (build step 1's certificate: "
+    w(f"| `derived_sha` | {code(ds.get('reference'))} | {code(ds.get('candidate'))} ({PREV}: "
       f"{code(ds.get('previous_certificate'))}) |")
-    w(f"| `engine`, `engine_sha`, `backend` | none | {code(ID.get('engine'))}, {code(es.get('candidate'))} (build step "
-      f"1's certificate: {code(es.get('previous_certificate'))}; over build step 1's key set, amendment B11: "
+    bk = ID.get("backends")                        # (commit P) schema 4: train_backend, score_backend, the contract
+    bname = "`train_backend`, `score_backend`" if bk and ID.get("backend") is None else "`backend`"
+    btext = (f"train {code(bk.get('train'))}, score {code(bk.get('score'))} (backend_contract "
+             f"{code(bk.get('contract'))})" if bk and ID.get("backend") is None else code(ID.get('backend')))
+    w(f"| `engine`, `engine_sha`, {bname} | none | {code(ID.get('engine'))}, {code(es.get('candidate'))} ("
+      f"{PREV}: {code(es.get('previous_certificate'))}; over build step 1's key set, amendment B11: "
       f"{code(es.get('over_build_step_1_keys'))}, printed by {code(es.get('printed_by'))}), "
-      f"{code(ID.get('backend'))} |")
+      f"{btext} |")
     sf = ID["shared_fatal_fields"]
     same = all(a == b for a, b in sf.values())
     w("| " + ", ".join(f"`{k}`" for k in sf) + " | " + "; ".join(esc(v[0]) for v in sf.values()) + " | "
@@ -155,7 +169,8 @@
         w(f"| {esc(r.get('what') or r.get('command'))} ({esc(r.get('record_id'))}) | {code(r.get('environment'))} | "
           f"{esc(r.get('item'))} | {esc(r.get('expected'))} | {esc(r.get('got'))} | {vcell(r)} |")
     w("")
-    w("Why each control can fail is in the JSON (`controls[].why_it_can_fail`) and in `S/CERT_PLAN_A.md`.")
+    w("Why each control can fail is in the JSON (`controls[].why_it_can_fail`) and in "
+      f"`{PT.get('plan', 'S/CERT_PLAN_A.md')}`.")
     w("")
 
     w("## 3. The levels")
@@ -195,8 +210,8 @@
 
     w("## 4. The re-run list")
     w("")
-    w("`docs/build_step_2/PLAN.md` section 3.6 as `AMENDMENTS.md` amends it, and `HANDOFFS.md`'s items for "
-      "commit A; each answered by the records that name it.")
+    w(PT.get("rerun_list", "`docs/build_step_2/PLAN.md` section 3.6 as `AMENDMENTS.md` amends it, and "
+             "`HANDOFFS.md`'s items for commit A; each answered by the records that name it."))
     w("")
     w("| item | asks | records | verdict |")
     w("|---|---|---|---|")
@@ -255,7 +270,8 @@
     w("")
     a = c.get("archive") or {}
     if a:
-        w(f"Every tool, `TOOL_EDITS.md`, this run's plan (`CERT_PLAN_A.md`), its records (`cert_results/`) and the "
+        w(f"Every tool, `TOOL_EDITS.md`, this run's plan (`{PT.get('plan_short', 'CERT_PLAN_A.md')}`), its records "
+          "(`cert_results/`) and the "
           f"small evidence files are in `{a['path']}` ({n(a['bytes'])} bytes, sha256 `{a['sha256']}`, "
           f"{n(a['members'])} members). Unpacked anywhere, that folder is `S`: the tools find it from their own "
           "location. The dumps (`.npz`), the scratch trees and the models are not archived; the commands re-make them.")
```

#### tools/run_jobs.py

commit A (the archive's tools/run_jobs.py): sha256 `015510b4b81193155b078791d8f6dc9f42d2073ae6a2f0181563977ae962bf18`; commit P (the kit's): sha256 `24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26`.

```diff
--- commit A: tools/run_jobs.py
+++ commit P: tools/run_jobs.py
@@ -2,9 +2,14 @@
 
     python run_jobs.py <tree_dir> <label> <jobs.txt> <parallel> [NAME=VALUE ...]
 
-Each job is `python -I harness.py <tree> <job> out/<label>/<slug>.npz` with
+Each job is `python -I -B harness.py <tree> <job> out/<label>/<slug>.npz` with
 OMP_NUM_THREADS=1; NAME=VALUE pairs are added to the job's environment (the
 control's HARNESS_PERTURB). _status.txt gets "<exit> <seconds> <job>" per job.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): each job starts
+with -B beside -I. -I makes Python ignore PYTHONDONTWRITEBYTECODE, so harness.py wrote
+__pycache__ beside every module it imported, in the candidate and in S/ref; -B writes none.
+-B changes no number a job computes. Nothing else changed.
 """
 import os
 import re
@@ -35,7 +40,7 @@
     while pending and len(running) < par:
         j = pending.pop(0)
         log = open(os.path.join(outdir, slug(j) + ".log"), "w", encoding="utf-8")
-        p = subprocess.Popen([PY, "-I", os.path.join(HERE, "harness.py"), tree, j,
+        p = subprocess.Popen([PY, "-I", "-B", os.path.join(HERE, "harness.py"), tree, j,
                               os.path.join(outdir, slug(j) + ".npz")], stdout=log, stderr=subprocess.STDOUT,
                              env=env)
         running.append((p, j, log, time.time()))
```

#### tools/cert_record.py

commit A (the archive's tools/cert_record.py): sha256 `dc4850149ae586bb76496354efc1b905809647ce9fa08e90d2c33b20e4ac76fd`; commit P (the kit's): sha256 `c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3`.

```diff
--- commit A: tools/cert_record.py
+++ commit P: tools/cert_record.py
@@ -15,6 +15,13 @@
 the group's report instead). The file is rewritten whole through a temporary file and
 os.replace, so a reader never sees half a list; one group writes one file, so two groups never
 race on a file.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): an optional
+--rechecks "<group>.json record <n>" is carried into the record as "rechecks", the field
+make_cert.py's _rechecks() (commit A's final step) pairs with an earlier FAIL of the same file.
+Commit A wrote that field by editing its records afterwards; P's route after a FAIL (a re-check
+record, written by hand once the cause is read) writes it here. Without --rechecks a record is
+what it was.
 """
 import argparse
 import json
@@ -33,6 +40,7 @@
 ap.add_argument("--what")
 ap.add_argument("--environment")
 ap.add_argument("--difference")
+ap.add_argument("--rechecks")                  # (commit P) "<group>.json record <n>": the FAIL this record re-checks
 a = ap.parse_args()
 
 if not a.group.replace("-", "").replace("_", "").isalnum():
@@ -40,7 +48,7 @@
 rec = dict(level=a.level, item=a.item, command=a.command, cwd=a.cwd, expected=a.expected, got=a.got,
            verdict=a.verdict, seconds=round(a.seconds, 1),
            evidence_files=[e.replace("\\", "/") for e in a.evidence])
-for k in ("what", "environment", "difference"):
+for k in ("what", "environment", "difference", "rechecks"):
     if getattr(a, k):
         rec[k] = getattr(a, k)
 missing = [e for e in rec["evidence_files"]
```

#### tools/l7_expect.py

commit A (the archive's tools/l7_expect.py): sha256 `955fb2e4b526ed139f808d719903e1ad60bfe9e34e630595eab79197cad1be55`; commit P (the kit's): sha256 `72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164`.

```diff
--- commit A: tools/l7_expect.py
+++ commit P: tools/l7_expect.py
@@ -4,6 +4,14 @@
 largest episode peak), then looked for in the two reports.
 
     python l7_expect.py <report.txt> [<report.txt> ...]
+    python l7_expect.py --agent blind_seed0 --repo <tree> <report.txt> ...      (build step 2, commit P)
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"; CERT_PLAN_P.md G6.3: L7 scores
+blind_seed0 beside sighted_seed0): --agent <tag> names X1's agent whose rows are rebuilt (default
+sighted_seed0, as before), and --repo <tree> the tree whose committed raw scores are read (default
+the repository, as before). evaluate.py labels the blinded agent's rows "agent (blind) <path>", which
+start with "agent" as the sighted agent's do, so the rows are found as before. Without the two
+options the tool is unchanged.
 """
 import json
 import sys
@@ -11,9 +19,24 @@
 import numpy as np
 
 REPO = r"C:\Users\badcl\Desktop\GRAD-project"
+ARGS = sys.argv[1:]
+
+
+def _opt(name, default):
+    """(commit P) one '--name value' pair taken out of the arguments, or the default."""
+    if name in ARGS:
+        i = ARGS.index(name)
+        value = ARGS[i + 1]
+        del ARGS[i:i + 2]
+        return value
+    return default
+
+
+AGENT = _opt("--agent", "sighted_seed0")
+REPO = _opt("--repo", REPO)
 raw = json.load(open(f"{REPO}/results/phase_d_extremes_dt1_raw.json", encoding="utf-8"))
 POL = {"baseline ECU": "baseline ECU", "reactive": "reactive", "current-grade": "current-grade",
-       "agent": "runs/extremes_dt1/sighted_seed0"}
+       "agent": f"runs/extremes_dt1/{AGENT}"}
 
 
 def rows_of(label):
@@ -37,7 +60,7 @@
 cuts = {n: f"cuts median damage {100 * (1 - np.median([r['damage'] for r in rows_of(l)]) / base):5.1f} %"
         for n, l in POL.items() if n != "baseline ECU"}
 ok_all = True
-for rep in sys.argv[1:]:
+for rep in ARGS:
     text = open(rep, encoding="utf-8").read().splitlines()
     print(f"== {rep}")
     for name, tail in expect.items():
```

#### tools/compare_all.sh

commit A (the archive's tools/compare_all.sh): sha256 `2220420c6c97787868fd5b35ecaf73f1fb144683f3d2a33068d7a06c64ca3c5c`; commit P (the kit's): sha256 `2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5`.

```diff
--- commit A: tools/compare_all.sh
+++ commit P: tools/compare_all.sh
@@ -1,5 +1,7 @@
 #!/usr/bin/env bash
 # compare_all.sh <label_a> <label_b> -- every harness job finished in both, compared (cmp.py), one line each
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): cmp.py starts with -I -B (-I ignores
+# PYTHONDONTWRITEBYTECODE). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 A=$1; B=$2; mkdir -p $S/cmp/${A}_vs_$B
@@ -7,6 +9,6 @@
 tr -d '\r' < $S/out/$A/_status.txt | while read -r rc secs job; do
   f=$(echo "$job" | sed -E 's/[^A-Za-z0-9.-]+/_/g; s/^_+|_+$//g')
   grep -q " $job\$" $S/cmp/${A}_vs_$B/_b_status.txt || continue
-  line=$($PY -I $S/tools/cmp.py $S/out/$A/$f.npz $S/out/$B/$f.npz --quiet --json $S/cmp/${A}_vs_$B/$f.json | tail -1)
+  line=$($PY -I -B $S/tools/cmp.py $S/out/$A/$f.npz $S/out/$B/$f.npz --quiet --json $S/cmp/${A}_vs_$B/$f.json | tail -1)
   echo "$job | $line"
 done
```

#### tools/check_l6.sh

commit A (the archive's tools/check_l6.sh): sha256 `06be554f8fab326ba159c939e38a3cd92eb199043f1181a0a341173dab302501`; commit P (the kit's): sha256 `6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b`.

```diff
--- commit A: tools/check_l6.sh
+++ commit P: tools/check_l6.sh
@@ -1,15 +1,17 @@
 #!/usr/bin/env bash
 # check_l6.sh -- L6's three comparisons for each agent: cand vs ref (every value, tobytes),
 # each tree vs the committed raw scores (full precision) and eval_record.npz (per step)
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): cmp.py and l6_check.py start with
+# -I -B. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 mkdir -p $S/cmp
 for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
   echo "=================== $tag"
   echo "--- candidate against reference"
-  $PY -I $S/tools/cmp.py $S/L6/ref_$tag.npz $S/L6/cand_$tag.npz --quiet --json $S/cmp/L6_$tag.json
+  $PY -I -B $S/tools/cmp.py $S/L6/ref_$tag.npz $S/L6/cand_$tag.npz --quiet --json $S/cmp/L6_$tag.json
   for t in cand ref; do
     echo "--- $t against the committed files"
-    $PY -I $S/tools/l6_check.py $S/L6/${t}_$tag.npz $tag --json $S/cmp/L6_${t}_${tag}_committed.json
+    $PY -I -B $S/tools/l6_check.py $S/L6/${t}_$tag.npz $tag --json $S/cmp/L6_${t}_${tag}_committed.json
   done
 done
```

#### tools/run_writer.sh

commit A (the archive's tools/run_writer.sh): sha256 `f2dd6109b29dd65f88971766b7b2ce97a9392c9a4357282040becc47dd03057b`; commit P (the kit's): sha256 `28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382`.

```diff
--- commit A: tools/run_writer.sh
+++ commit P: tools/run_writer.sh
@@ -3,16 +3,19 @@
 # A script that rewrites a committed file. In the candidate (the working tree) the
 # committed file is backed up first, the run's output is kept in scratch, and the
 # backup is put back, so the working tree ends as it began (sha256 checked).
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): the script starts with -B, and CAND
+# has no default (it was the live repository, which holds P uncommitted while the roads check runs there):
+# an unset CAND stops the tool before it runs anything. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 t=$1; label=$2; rel=$3; shift 3
-tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refw
+tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refw
 cd "$tree" || exit 9
 bak=$S/L5/backup/${t}_$(basename "$rel")
 cp -p "$rel" "$bak"
 before=$(sha256sum < "$rel" | cut -c1-64)
 s=$(date +%s)
-PYTHONIOENCODING=utf-8 $PY "$@" > $S/L5/${t}_${label}_stdout.txt 2> $S/L5/${t}_${label}_stderr.txt
+PYTHONIOENCODING=utf-8 $PY -B "$@" > $S/L5/${t}_${label}_stdout.txt 2> $S/L5/${t}_${label}_stderr.txt
 rc=$?
 cp -p "$rel" $S/L5/${t}_${label}_OUT_$(basename "$rel")
 after=$(sha256sum < "$rel" | cut -c1-64)
```

#### tools/run_l4.sh

commit A (the archive's tools/run_l4.sh): sha256 `4640165e0723464e27d342beea609be576112d29cd844d5d4eaf577870a71507`; commit P (the kit's): sha256 `6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c`.

```diff
--- commit A: tools/run_l4.sh
+++ commit P: tools/run_l4.sh
@@ -1,12 +1,14 @@
 #!/usr/bin/env bash
 # run_l4.sh <cand|ref> [extra test_reward args] -- L4: test_reward.py in one tree, stdout and stderr kept apart
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): -B, and CAND has no default (an unset
+# CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 t=$1; shift; tag=""; [ "$1" = "--road" ] && tag="_$2"
-tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/ref
+tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/ref
 cd $tree || exit 9
 s=$(date +%s)
-PYTHONIOENCODING=utf-8 $PY test_reward.py "$@" > $S/L4/${t}${tag}_stdout.txt 2> $S/L4/${t}${tag}_stderr.txt
+PYTHONIOENCODING=utf-8 $PY -B test_reward.py "$@" > $S/L4/${t}${tag}_stdout.txt 2> $S/L4/${t}${tag}_stderr.txt
 rc=$?
 echo "exit $rc in $(( $(date +%s) - s )) s" > $S/L4/${t}${tag}_exit.txt
 cat $S/L4/${t}${tag}_exit.txt
```

#### tools/run_l6.sh

commit A (the archive's tools/run_l6.sh): sha256 `5ffd5ab8ed97fc450a72516638728a3681c1b3c7b9f2a380bf345cd1e66849bb`; commit P (the kit's): sha256 `d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7`.

```diff
--- commit A: tools/run_l6.sh
+++ commit P: tools/run_l6.sh
@@ -1,14 +1,20 @@
 #!/usr/bin/env bash
 # run_l6.sh -- L6: four X1 agents x twenty frozen episodes, in both trees, 8 processes at once
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): l6_agents.py starts with -I -B, and
+# CAND has no default. Here (unlike the other five tools) the `${CAND:?...}` sits inside `$(...)`, so an unset CAND
+# ends only that subshell and does NOT stop the tool: CAND is then empty, and l6_agents.py takes the empty path as
+# its working directory (os.path.abspath(""), archive tools/l6_agents.py:28), so the candidate side runs in the
+# folder run_l6.sh was started from. env_P.sh always exports CAND (the clone), and cert_driver_P.sh starts this tool
+# from the clone. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 SW=$(cygpath -m "$S")
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-CAND=$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")
+CAND=$(cygpath -m "${CAND:?CAND is unset: the certificate names every tree, env_P.sh}")
 REF="$SW/ref"
 for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
   for t in cand ref; do
     tree=$CAND; [ $t = ref ] && tree=$REF
-    ( $PY -I "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
+    ( $PY -I -B "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
   done
 done
 wait
```

#### tools/run_app.sh

commit A (the archive's tools/run_app.sh): sha256 `45a596885d918478dff00a5a524b684429bb788669a1a163b3a7a2a86fd2c452`; commit P (the kit's): sha256 `5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91`.

```diff
--- commit A: tools/run_app.sh
+++ commit P: tools/run_app.sh
@@ -1,8 +1,10 @@
 #!/usr/bin/env bash
 # run_app.sh <cand|ref> -- the app suites and the learning lab's tests, one after another, in one tree
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): every suite starts with -B, and CAND
+# has no default (an unset CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-t=$1; tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
+t=$1; tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
 mkdir -p $S/app
 export PYTHONIOENCODING=utf-8
 one() {   # one <label> <dir> <command...>
@@ -12,9 +14,9 @@
   echo "$? $(( $(date +%s) - s )) $label" >> $S/app/${t}_status.txt
 }
 rm -f $S/app/${t}_status.txt
-one test_replay_full "$tree" $PY -m app.test_replay --full
-one test_simulation "$tree" $PY -m app.test_simulation
-one test_agents "$tree" $PY -m app.test_agents
-one test_results "$tree" $PY -m app.test_results
-one lab_tests "$tree/Explanatory Simulation" $PY -m unittest discover -s tests -v
+one test_replay_full "$tree" $PY -B -m app.test_replay --full
+one test_simulation "$tree" $PY -B -m app.test_simulation
+one test_agents "$tree" $PY -B -m app.test_agents
+one test_results "$tree" $PY -B -m app.test_results
+one lab_tests "$tree/Explanatory Simulation" $PY -B -m unittest discover -s tests -v
 cat $S/app/${t}_status.txt
```

#### tools/run_app_extra.sh

commit A (the archive's tools/run_app_extra.sh): sha256 `ac998584317787175c5dc912d2b62559e78eb0753a898d9e1fc88781b965d395`; commit P (the kit's): sha256 `b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777`.

```diff
--- commit A: tools/run_app_extra.sh
+++ commit P: tools/run_app_extra.sh
@@ -1,15 +1,17 @@
 #!/usr/bin/env bash
 # run_app_extra.sh <cand|ref> -- the other eleven app/test_*.py suites (mistake 25: every suite that
 # may read the plant), each with python -m unittest -v, in one tree
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): every suite starts with -B, and CAND
+# has no default (an unset CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-t=$1; tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
+t=$1; tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
 export PYTHONIOENCODING=utf-8
 rm -f $S/app/${t}_extra_status.txt
 for m in test_agent_generations test_agent_sources test_artifact_api test_artifacts test_graphics_revisions \
          test_launcher test_records test_results_comparisons test_results_graphics test_results_records test_results_sets; do
   s=$(date +%s)
-  ( cd "$tree" && $PY -m unittest -v app.$m ) > $S/app/${t}_$m.txt 2>&1
+  ( cd "$tree" && $PY -B -m unittest -v app.$m ) > $S/app/${t}_$m.txt 2>&1
   echo "$? $(( $(date +%s) - s )) $m" >> $S/app/${t}_extra_status.txt
 done
 cat $S/app/${t}_extra_status.txt
```

#### tools/run_drift.sh

commit A (the archive's tools/run_drift.sh): sha256 `80695caef6b7506a82e1bd01889a208640e04222ad3b03cc0b4c008aaf38a61e`; commit P (the kit's): sha256 `98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f`.

```diff
--- commit A: tools/run_drift.sh
+++ commit P: tools/run_drift.sh
@@ -3,9 +3,12 @@
 # joined on 21 October 2026). Each part runs drift_test's own control on an undrifted copy first,
 # then its rows, each on a fresh copy; the rows are independent, so the six parts are the one
 # command split for time. The verdict line sums the parts.
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): drift_test.py starts with -B, and
+# CAND has no default (an unset CAND stops the tool). drift_test's own children (verify_docs.py in each
+# copy, sys.executable without flags) inherit PYTHONDONTWRITEBYTECODE=1 from env_P.sh. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-cd "${CAND:-/c/Users/badcl/Desktop/GRAD-project}" || exit 9
+cd "${CAND:?CAND is unset: the certificate names every tree, env_P.sh}" || exit 9
 export PYTHONIOENCODING=utf-8
 mkdir -p $S/suites
 rm -f $S/suites/drift_part*.txt
@@ -13,7 +16,7 @@
 i=0
 for rows in "1 2 3" "4 5 6" "7 8 9" "10 11 12" "13 14 15" "16 17 18"; do
   i=$((i+1))
-  ( $PY drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
+  ( $PY -B drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
 done
 wait
 { for j in $(seq 1 $i); do echo "### part $j"; cat $S/suites/drift_part$j.txt; done; } > $S/suites/drift_test.txt
```

#### env_P.sh (new; against commit A's env_A.sh, the file it is made from)

env_A.sh (the archive's): sha256 `6eb7cc80f7ae180a8a28034b255571028480b00d444bb30d1dc2f86a9aa3cc0b`; env_P.sh: sha256 `bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0`.

```diff
--- commit A: env_A.sh
+++ commit P: env_P.sh
@@ -1,14 +1,45 @@
 #!/usr/bin/env bash
-# env_A.sh -- the variables every command of CERT_PLAN_A.md uses (commit A's certificate run,
-# build step 2, 22 October 2026). Git Bash: `source <S>/env_A.sh` at the top of every block
-# (shell state does not persist between calls). S is this file's own folder, so the plan's
-# commands also run from the unpacked certificate archive.
+# env_P.sh -- the variables every command of P's certificate uses (CERT_PLAN_P.md; commit A's env_A.sh as P
+# amends it; build step 2, ORDER step 14). DRAFT of 7 November 2026, not run. Git Bash: `source <S>/env_P.sh`
+# at the top of every block (shell state does not persist between calls). S is this file's own folder.
+#
+# REPO's role -- the candidate every entry point, writer and suite runs in -- is taken by the git clone at P's
+# candidate, CERT_TREE (committed and clean; row 139 (2): every entry-point command in REPO or a git clone),
+# which p_gate.sh exports. The live repository is LIVE_REPO: read for runs/extremes_dt1 (gitignored, so not in
+# the clone: L6 and L7 read X1's agents there by absolute path, as l6_agents.py already does) and never
+# written by the certificate's runs; only F.3 (p_gate.sh cert-docs) writes the certificate's three files there.
+# CAND is the clone. Every archived tool fell back to the live repository's path when CAND was unset; the
+# tools the drivers run (TOOL_EDITS.md, commit P) now stop instead, and a writer still names its copy per call
+# (CAND=$S/candw ...).
+#
+# Exported for the drivers (P_GATE_PLAN.md 5.2, item 1): S and SW; PY; REPO and RW (the clone); LIVE_REPO and
+# LRW; X1_RUNS; CAND; CERT_ROOT (the folder above S: candg, X, and the drivers' scratch outside S); CERT_X (the
+# archive extracted whole, read only); COMMIT_A_S (commit A's own S: its tcl/ lists); P_GATE_OUT (p_gate.sh's
+# out/: RV's base logs, read only); NODE and NPM; the thread and bytecode variables; and rec.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
 export S
 export SW=$(cygpath -m "$S")                                  # S for Python arguments
 export PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
-export REPO=/c/Users/badcl/Desktop/GRAD-project                # the candidate (bash paths)
-export RW=C:/Users/badcl/Desktop/GRAD-project                  # the same, for Python arguments
-export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONIOENCODING=utf-8
-unset CAND                                                     # each writer sets CAND itself
-rec() { "$PY" -I "$SW/tools/cert_record.py" "$@"; }            # rec <group> --level ... (cert_record.py)
+[ -n "${CERT_TREE:-}" ] || { echo "env_P.sh: CERT_TREE is unset (p_gate.sh exports the clone at the candidate)" >&2; return 2 2>/dev/null || exit 2; }
+if [ -n "${CERT_S:-}" ] && [ "$(cd "$CERT_S" 2>/dev/null && pwd)" != "$S" ]; then
+  echo "env_P.sh: sourced from $S, and p_gate.sh's CERT_S is $CERT_S" >&2; return 2 2>/dev/null || exit 2
+fi
+export REPO="$CERT_TREE"                                       # the candidate, the clone (bash paths)
+export RW=$(cygpath -m "$CERT_TREE")                           # the same, for Python arguments
+export LIVE_REPO=/c/Users/badcl/Desktop/GRAD-project           # the live repository: runs/ read, nothing written
+export LRW=C:/Users/badcl/Desktop/GRAD-project
+export X1_RUNS="$LRW/runs/extremes_dt1"                        # X1's agents (L6, L7), by absolute path
+export CAND="$CERT_TREE"                                       # the tools' tree: the clone, never the live one
+export CERT_ROOT=$(dirname "$S")                               # p_gate.sh's GD/cert: S, X and candg live here
+export CERT_X="$CERT_ROOT/X"                                   # the archive extracted whole: read, never run, never packed
+export COMMIT_A_S="${COMMIT_A_S:-/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2}"
+export P_GATE_OUT="${P_GATE_OUT:-$(dirname "$CERT_ROOT")/out}" # p_gate.sh's G: RV's base logs (base_app_*.log)
+export NODE="${NODE:-$(command -v node 2>/dev/null || echo '/c/Program Files/nodejs/node.exe')}"
+export NPM="${NPM:-$(command -v npm 2>/dev/null || echo '/c/Program Files/nodejs/npm')}"
+export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONIOENCODING=utf-8 PYTHONDONTWRITEBYTECODE=1
+export PIP_DISABLE_PIP_VERSION_CHECK=1
+# -I ignores PYTHONDONTWRITEBYTECODE: every `$PY -I` call of the plan is written `$PY -I -B` (the task's rule:
+# every python call with -B), and every tool that starts python itself passes -B (TOOL_EDITS.md, commit P)
+rec() { "$PY" -I -B "$SW/tools/cert_record.py" "$@"; }        # rec <group> --level ... (cert_record.py)
+[ "$(git -C "$CERT_TREE" rev-parse HEAD 2>/dev/null)" = "${P_CAND:-}" ] \
+  || { echo "env_P.sh: CERT_TREE's HEAD is not P_CAND (${P_CAND:-unset})" >&2; return 2 2>/dev/null || exit 2; }
```

#### tools/road_json_diff.py (new in tools/: commit A's g3/road_json_diff.py, unchanged)

the archive's g3/road_json_diff.py: sha256 `dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7`; the kit's tools/road_json_diff.py: sha256 `dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7` (the same bytes; no diff).

#### The new files (each is its own diff: the whole file, which p_gate.sh cert-kit appends again against /dev/null)

| file | sha256 |
|---|---|
| `tools/failing_sets_P.py` | `56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc` |
| `tools/stated_counts_P.py` | `7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7` |
| `tools/cert_driver_P.sh` | `17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21` |
| `tools/cert_final_driver_P.sh` | `f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1` |
| `cert_P.json` | `ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193` |
| `reproduce_P.json` | `b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517` |
| `INTEGRATION.md` | `e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3` |

(The sha256 of the five files the second edit changed are the edited files'. The first run's, as cert-kit installed them on S on 7 November, are in the section below.)

### commit P, second edit (after the first run's five FAILs, 8 November 2026)

The first run of P's certificate (p_gate.sh cert, 16:08Z on 7 November to 03:00Z on 8 November 2026, 39139 s beside the roads check) wrote 106 records: 101 PASS, 5 FAIL (`out/cert_fail_records.txt`, all five OPEN). Each FAIL was read in its evidence (`hand/cert_fails_plan.md`, sections 1 and 2). All five are defects of the kit's driver, `tools/cert_driver_P.sh`; none is in P's code: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and the exits were lost to a cp1252 print, in commit A's tool as in P's. In G5.2 the launcher met its expectation, and `--check` ran only as the server stopped. The route is the orchestrator's decision (Ghassan's standing instruction): the re-check on the same S, as commit A re-checked its FAILs (its records name the re-checked FAILs, and its TOOL_EDITS.md records its edits), not a new S. The edited kit is installed on the started S through one new, explicit, recorded route of p_gate.sh, applied after the roads check ends; then g1, g3, g5 and g7 are re-run there with `p_gate.sh cert-recheck <g>`, each re-run PASS naming the FAIL it re-checks, and the five FAIL records stay in the certificate beside the re-check records that name them (`rechecks`; make_cert.py adds `rechecked_by`). The kit was edited after the cert phase had ended, while the roads check still ran (no running phase reads the kit again); none of the edited lines has run, and no Python ran for this edit.

#### The five FAIL records, each with its fix

- **E1: G1-harness.json record 29** (control, B9, "commit A's certificate route (--config) is unchanged by P's edits"; got `differs: an exit`, 2 of the 5 `exit 0` lines). G1.7(b) ran commit A's make_cert.py, P's make_cert_P.py and the control under `-I -B` without `-X utf8`. `-I` ignores env_P.sh's PYTHONIOENCODING, so stdout, redirected to a file, was cp1252; commit A's cert_A.json carries commit A's re-checked FAIL records, and printing G5-app-lab record 22's got (Arabic text, launch.py's title) raised UnicodeEncodeError after the JSON had been written, in commit A's unedited make_cert.py and in P's alike (the same characters, positions 464-468). Both JSONs and both pages were byte-identical, which is what B9 asks. Fix: `-X utf8` on (b)'s five calls (`cert_driver_P.sh` g1_7 part (b)); the json snippet before them is unchanged. Commit A had met it: its TOOL_EDITS.md, "commit A, the final step": "F.3 runs make_cert.py and make_md.py with `-X utf8` (`-I` ignores PYTHONIOENCODING, and printing a record with a character cp1252 lacks raised UnicodeEncodeError after the JSON was written)"; reproduce_A.json runs every make with `-I -X utf8`.
- **E2: G3-roads.json record 2** (L4, 3.6.4, "test_reward.py and --road random, the candidate's stdouts against cf43fbb's"; got `differs:_random last line`). The driver asked the `--road random` run for the default run's last line. `test_reward.py --road random` ends, on cf43fbb as on the candidate, with "All checks pass on every D2 road. The reward is safe to train against on the randomised climb."; both stdouts were byte-identical to cf43fbb's, exit 0 twice (2701 s and 2255 s), stderr empty. Fix: each run's own expected last line (`want`, declared local in g3); `--expected` names both lines. CERT_PLAN_A G3.1 types the default line once for both runs; its byte-identity clause, and commit A's records of the same stdout (commit A's candidate's random stdout is the same bytes), fix the D2 line.
- **E3: G5-app-lab.json record 10** (L5, "3.6.12, HA.3", "the lab launcher and launch.py --check"; got `differs: --check`). The driver waited for `is ready`, which launch.py prints to block-buffered stdout: the line reached the file only at the launcher's exit, at the 300 s timeout, so `--check` ran as the server stopped and printed "Local app is not running with its built frontend", exit 1. The launcher itself logged `GET /api/meta` 200 and `GET /` 200, then "Supra Lab is ready", then exit 124; launch.py is byte-identical in the candidate, cf43fbb and commit A's candidate. Fix: the trigger is the server's own access line `"GET / HTTP/1.1" 200` for the launcher's request, which uvicorn's logging writes record by record. Commit A had met it: its first-cycle launcher record ("printed to block-buffered stdout, so it reached the file only at exit: the plan's wait for it cannot fire early"), and its second cycle, which passed with the trigger "when the launcher's own GET / was served". Rejected: `-u` on the launcher (it changes how the program under test runs) and PYTHONUNBUFFERED (it changes all fifteen G5 runs, and no record would declare it). Before the launcher starts, the driver now also removes an earlier run's launcher log and `--check` output (added after the reviews: see "Revised after the second edit's two reviews" below).
- **E4: G7-suites.json record 12** (suite, "3.6.15, HP7.1, B8, HP7.6", "test_trainable.py (B8: the refusals and their controls, SummaryDrop the literal case)"; got `differs: RealTree; Ran 23 tests ... OK`). `tests_ok` read a test's result only on its header line or the next one. RealTree.test_the_real_records_decide writes its expectation to stderr in the middle of the test, by design (its docstring, CERT_PLAN_P G7.3 and section 4, P_GATE_PLAN H6a), so unittest's `ok` stands alone two lines after the header, and RealTree counted no test ok. 23 tests ran, OK, exit 0, and RealTree's own line reads `('b58',)` against `('b58',)`. pre's log (`out/pre_test_trainable.log`) already had the same layout before the window. Fix: a result is pending until the next test header, and a bare `ok`, `FAIL`, `ERROR` or `skipped ...` line counts while it is pending. Otherwise the rule is as before, but that a test header now ends a pending result, so that the next test's own result line is never counted for the pending one.
- **E5: G7-suites.json record 16** (docs, HA.4, "CLAUDE.md's re-run rule names engines.py and engine_specs/"; got `differs: no line`). The driver ran CERT_PLAN_A G7.4's one-line grep (CERT_PLAN_A.md:604, verbatim) as a check of at least one line; the rule wraps (CLAUDE.md:137-138), so no single line holds both names. Fix: `grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, the rule's line and its continuation, both kept as evidence; `--expected` says so; the judgement (at least one line) is unchanged. Commit A had met it: its F-certificate HA.4 record, a PASS: "the plan's one-line grep ... prints nothing, because the rule wraps: CLAUDE.md:137-138 ...; both names present in the one rule".
- **E6 (hardening; no FAIL record).** `tools/cert_final_driver_P.sh` runs its four makes (3.6.19's draft0, F.2's draft) with `-X utf8`, and says so in the 3.6.19 record's `--command` (a record no run has written yet) and in reproduce_P.json's F.1/F.2 step. Only G5's two node records can carry a got with a character cp1252 lacks (the node runner's info sign); if one FAILed, a later make would print it and stop. cert-docs' makes (p_gate.sh) still run with `-I -B`: p_gate.sh is not edited here.

#### The texts kept, and what the re-run runs

- Every record of the edited checks keeps its `--what` as the first run wrote it: CERT_RECHECK_MAP pairs a re-run PASS with its FAIL by the `what` (the driver's `R`), and each of the five `what`s names one record of its file.
- Every record keeps its `--command` too (cert_fails_plan.md section 4, the re-check route): p_gate.sh's recheck_prep treats the records of one `what` as one check only when level, item and command agree, so a changed command would make a second re-check of the same check refuse ("another check", P_GATE_PLAN 13.5). The commands of G1-harness record 29 ("... python -I -B: ..."), G5-app-lab record 10 ("once it printed 'is ready'") and G7-suites record 16 ("grep -n engines.py candg/CLAUDE.md | grep engine_specs") therefore name what the first run ran, in the first run's records and in every re-run record of those checks alike; what the re-run runs is above (E1, E3, E5), in INTEGRATION.md section 7, in cert_P.json's `notes.first_run`, which the page prints, and in each of those records' `--expected`.
- `--expected` changes for G3-roads record 2 (both last lines) and G7-suites record 16 (the grep that runs, and the two lines), and, so that each says what runs, for G1-harness record 29 (the five makes with `-X utf8`) and G5-app-lab record 10 (the trigger; both of the check's R calls, the launcher's and the port-taken one); no record's level or item changes. `cert_driver_P.sh` lines that carry `--what` or `--command`: none changed (diff below).

#### Replayed by text (bash and awk on the first run's own files, read-only; no Python)

The functions and the loop were taken from the edited driver's own text (and, for contrast, from S's installed copy, the first run's), and run on the first run's outputs in S.

- **E2** (G3.1's judgement): the first run's `S/L4` files: before, `bad=[_random last line]`, FAIL; after, `bad=[]`, PASS. Negative control (a scratch copy whose `--road random` stdout ends with the default line, its reference copy alike): before PASS; after `bad=[_random last line]`, FAIL. The files: `cand` ends "All checks pass. The reward is safe to train against.", `cand_random` "All checks pass on every D2 road. The reward is safe to train against on the randomised climb."; both cmp-equal to `ref*`, exit 0 in 2701 s and 2255 s, stderr 0 bytes.
- **E4** (`tests_ok` and `cls_ok`): `S/suites/cand_test_trainable.txt`, before: Help, B58, RecordsAbsent, SummaryDrop, BackendDrop ok, RealTree FAIL; after: all six ok. `out/pre_test_trainable.log`: the same, before and after. Negative control (a scratch copy with RealTree's bare `ok` changed to `FAIL`, one line): after, RealTree FAIL and the other five ok. Unchanged verdicts, before and after: EngineSha (`cand_test_fuel_forms.txt`) ok, BlindBitForBit (`cand_test_preview_horizon.txt`) ok, GitDirtyPlantFiles (`cand_test_plant_guards.txt`) ok, and G5's lab pin test (`app/cand_lab_tests.txt`, the other caller of `tests_ok`) ok.
- **E5** (HA.4, in candg at P's candidate, clean): before, 0 lines, FAIL (" no line"), as the first run's `suites/P_G7_docs_checks.txt` holds; after, 2 lines (`137:- After changing ... engines.py ...` and `138-  engine_specs/ ...`), PASS. Negative control (a scratch copy of candg's CLAUDE.md, CRLF kept, with `engine_specs/` removed, one line changed): 0 lines, FAIL.
- **E1 and E3** cannot be replayed without Python. E1 rests on commit A's F.3 makes, which exited 0 with `-X utf8` on the same records; E3 on commit A's second cycle, which passed with the same trigger. By text only: the first run's launcher log holds the line `"GET / HTTP/1.1" 200`, on which the new trigger fires; when it would have fired cannot be replayed. The removal of an earlier run's log before the launcher starts (below) has not run either.
- `bash -n` parses every kit shell file (the two drivers, env_P.sh and the eight tools).

#### Revised after the second edit's two reviews (8 November 2026)

Two independent, read-only reviews of the second edit and of the p_gate.sh patch for the second install found no blocking item and five material ones: four in the kit (two of them one item, the wording below, found by both) and one in the text the patch writes into S/TOOL_EDITS.md for the second install. The kit's are fixed here, by a fixer who wrote neither the edit nor the patch; the patch's is fixed in the patch.

- **The commands kept, what runs named.** The B9 record (G1-harness record 29's check), G5.2's launcher record (both of its R calls) and HA.4 keep their `--command` text, so that recheck_prep reads every run of each as one check (its key: level, item, command; make_cert.py pairs records only by `rechecks`, so `--expected` is free). Each now says in its `--expected` what runs, so that no re-run record states a command and contradicts it (before, HA.4's re-run would have read: command, the one-line grep; expected, "the one-line grep prints nothing"; got, 2 lines).
- **G5.2: the first run's launcher log removed before the launcher starts.** `cert-recheck g5` never removed `lab/P_G5_launch_no_browser.txt`: recheck_prep copies a record's evidence aside and leaves the original, and the launcher's own truncation of the file happens in the background subshell, unordered against the trigger's first grep. The first run's log already holds `"GET / HTTP/1.1" 200`, so the trigger could fire on it before the new server was up: a false FAIL, never a false PASS. The driver now runs `rm -f` on that log and on `lab/P_G5_launch_check.txt` in the foreground, before the launcher starts. The first run's copies are by then under `recheck/G5-app-lab_<stamp>/`, and record 10's evidence_files name them. No `--what` or `--command` changed.
- **The texts that ship worded as measured facts, whatever the re-checks find.** cert_P.json's `notes.first_run` and this section said that in each of the five FAILs the output under test met the expectation, and they and INTEGRATION.md 7 said that G1, G3, G5 and G7 were re-run, or re-checked, once each. In G1.7(b) three makes exited 1 (the JSONs and pages were byte-identical), and in G5.2 `--check` exited 1 (it ran as the server stopped); and a second re-check of one check is a planned fallback. Each text now says what the evidence shows of each FAIL, and that the four groups are re-run with cert-recheck, the re-check records saying what each re-run found.
- None of these lines has run; `bash -n` parses the driver.

#### The files the second edit changed (sha256)

| file | the first run's (S's installed copy, 7 November) | after the second edit |
|---|---|---|
| `tools/cert_driver_P.sh` | `bfec15faca167a16bfd8faa4cedf4f5002cf14959a2a919545bdcc6515a11a59` | `17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21` |
| `tools/cert_final_driver_P.sh` | `ab46791e31bba212e0c9356a9551f5c4c2bd5707efecc21d0f99d76fbd2d822d` | `f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1` |
| `cert_P.json` | `c0f3dc95cf26a32dfc5efa4fa074e6dd1a29492fcaa4c98545510804b8c70202` | `ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193` |
| `reproduce_P.json` | `bd1c99a0755558cc0e4d7bcb7c0e7445c5ee34a503f59098ef43377fc83a3888` | `b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517` |
| `INTEGRATION.md` | `cf8f49b56cc75c1fa50990a1bc67849c57a7bb2d0170a1f087a5a444a2c74e18` | `e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3` |

Every other kit file is unchanged: cmp-equal to the copy cert-kit installed on S for the first run (`env_P.sh` and `tools/` `cert_record.py`, `check_l6.sh`, `compare_all.sh`, `failing_sets_P.py`, `l7_expect.py`, `make_cert.py`, `make_md.py`, `make_meta.py`, `road_json_diff.py`, `run_app.sh`, `run_app_extra.sh`, `run_drift.sh`, `run_jobs.py`, `run_l4.sh`, `run_l6.sh`, `run_writer.sh`, `stated_counts_P.py`); this file is the twenty-fourth.

#### The diffs of the second edit (the first run's copy, S's installed one, against the kit's)

##### tools/cert_driver_P.sh

```diff
--- commit P, the first run: tools/cert_driver_P.sh
+++ commit P, second edit: tools/cert_driver_P.sh
@@ -2,6 +2,13 @@
 # cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
 # 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
 # run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
+# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
+# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
+# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
+# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
+# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
+# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
+# launcher record, HA.4). The edited lines have not run.
 #
 #     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
 #
@@ -93,11 +100,16 @@
 secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
 blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
 tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
-              # unittest -v prints a test's result on its own line, or on the next one when the test has a docstring.
+              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
+              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
+              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
   lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
-    function res(l) { if (l ~ /\.\.\. ok$/) { ok++; return 1 } if (l ~ /\.\.\. skipped/) { sk++; return 1 }
-                      if (l ~ /\.\.\. (FAIL|ERROR)$/) { bad++; return 1 } return 0 }
-    pend { pend = 0; if (res($0)) next }
+    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
+                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
+                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
+                      return 0 }
+    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
+    pend { if (res($0)) { pend = 0; next } }
     $0 ~ h { if (!res($0)) pend = 1; next }
     $0 ~ f { bad++ }
     END { exit !(ok > 0 && sk == 0 && bad == 0) }'
@@ -396,11 +408,14 @@
     ( cd "$CERT_ROOT" || exit 9
       "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
         "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
-      "$PY" -I -B "$TW/a/tools/make_cert.py" "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
-      "$PY" -I -B "$TW/a/tools/make_md.py" "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
-      "$PY" -I -B "$TW/a/tools/make_md_P.py" "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
+      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
+      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
+      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
     ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
   else
     echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
@@ -414,7 +429,7 @@
   R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
     --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
     --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
-    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's)" \
+    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
     --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
     --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
   bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
@@ -548,7 +563,7 @@
 
 # ============================================================================= G3-roads
 g3() {
-  local t0 t1 bad got diffc
+  local t0 t1 bad got diffc want
   say "G3 begins"; t0=$(date +%s)
   t1=$(date +%s); bad=""
   ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
@@ -571,16 +586,22 @@
     echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
   wait
   # G3.1's record
+  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
+  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
   bad=""
   for t in "" _random; do
+    case "$t" in
+      "")      want="All checks pass. The reward is safe to train against.";;
+      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
+    esac
     grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
     cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
     [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
-    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "All checks pass. The reward is safe to train against." ] || bad="$bad${t:- default} last line"
+    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
   done
   R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
     --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
-    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last line 'All checks pass. The reward is safe to train against.' (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
+    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
     --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
     --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
     --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
@@ -834,10 +855,19 @@
       --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
     if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
       t1=$(date +%s)
+      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
+      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
+      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
+      # which the trigger below would fire before this run's server is up (a false FAIL)
+      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
       ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
         echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
       lp=$!
-      for i in $(seq 1 280); do grep -aq 'is ready' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
+      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
+      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
+      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
+      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
+      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
       ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
       wait "$lp"
       # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
@@ -867,7 +897,7 @@
       grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
         --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
         --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
     else
@@ -875,7 +905,7 @@
       say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
         --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
     fi
     # G5.3 the lab's node tests (after npm ci)
@@ -1178,15 +1208,17 @@
   suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
   suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
   # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
+  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
+  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
   ( cd "$REPO" && {
-      echo "== HA.4"; grep -n "engines.py" CLAUDE.md | grep -n "engine_specs"
+      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
       echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
       echo "== HA.6"; grep -n -i "scipy" requirements.txt
       echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
     } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
   bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
   R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
-    --cwd candg --expected "at least one line" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
+    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
     --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
   bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
   echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
```

##### tools/cert_final_driver_P.sh

```diff
--- commit P, the first run: tools/cert_final_driver_P.sh
+++ commit P, second edit: tools/cert_final_driver_P.sh
@@ -122,8 +122,11 @@
 
 # ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
 t0=$(date +%s)
-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
+# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
+# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
+# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
 head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
 bad=""
 [ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
@@ -142,14 +145,14 @@
 [ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
 [ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
 R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
-  --command "python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
+  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
   --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
   --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
   --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt
 
 # ---- F.2 the draft certificate in scratch
-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
 say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
 [ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }
 
```

##### cert_P.json

```diff
--- commit P, the first run: cert_P.json
+++ commit P, second edit: cert_P.json
@@ -120,7 +120,8 @@
   "nothing_computed_moved": "Every value the harness, L6 and build_dataset compared is meant to be the same double in both trees (the counts are in the verdict line), and every writer's output and every report to equal cf43fbb's; the differences section 5 lists are labels, code hashes, run times and committed files older than the code on both trees.",
   "why_plant_sha_moves": "plant_sha hashes the code of fingerprint.plant_files('b58') -- plant.py, thermal.py, engine_env.py, derived.py and engines.py -- and the values of the B58's two spec files. P edits engine_env.py (H a parameter, the reward's knock option) and engines.py (trainable() read from the committed records), so plant_sha moves although no computed value is meant to; it names P's plant, which every later step of build step 2 is compared against. fingerprint.py, which P also edits, is not in PLANT_CODE.",
   "why_engine_sha_does_not_move": "engine_sha hashes every value of the plant as built (engines.engine_sha), and P adds and changes no field of the B58's records: engine_sha is commit A's (a check of section 1), and over build step 1's key set it is still build step 1's (amendment B11).",
-  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2)."
+  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2).",
+  "first_run": "The first run of this certificate's groups (7-8 November 2026, 16:08Z to 03:00Z, 39139 s beside the roads check) wrote 101 PASS and 5 FAIL records: G1-harness record 29, G3-roads record 2, G5-app-lab record 10, G7-suites records 12 and 16. All five were defects of the kit's driver (tools/cert_driver_P.sh), not of P: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and three of the five makes exited 1, each only when printing, after writing its JSON: the driver ran them without -X utf8, and commit A's make_cert.py and P's alike stopped printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic text) to a cp1252 stdout. In G5.2 the launcher met its expectation ('is ready', exit 124), and --check ran only as its server stopped: the driver waited for a line launch.py prints to block-buffered stdout, which reaches the file only at the launcher's exit. G3.1 asked the --road random run for the default run's last line; G7.2's parser missed RealTree's ok, printed on a line of its own after RealTree's stderr line; G7.4 grepped one line for a rule that wraps (CLAUDE.md:137-138). The driver was corrected (TOOL_EDITS.md, section 'commit P', its part 'commit P, second edit'), reviewed again, installed on the same S after the roads check ended (TOOL_EDITS.md, section 'commit P, second install'), and G1, G3, G5 and G7 re-run there with cert-recheck: the re-check records say what each re-run found. The five FAIL records stay in this certificate; a re-run PASS record that re-checks one names it (rechecks), and the FAIL gains rechecked_by. The edited checks keep the first run's what and command texts, so that every run of one check is the same check: the re-run records of the checks of G1-harness record 29, G5-app-lab record 10 and G7-suites record 16 therefore carry the first run's command text (python -I -B; once it printed 'is ready'; the one-line grep), and each says in its expected what ran (-X utf8 on the five makes; --check once the server had logged the launcher's GET / with status 200; the rule's line and its continuation), as INTEGRATION.md section 7 does."
  },
  "environment": {
   "interpreter": "C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe, for every run in both trees",
```

##### reproduce_P.json

```diff
--- commit P, the first run: reproduce_P.json
+++ commit P, second edit: reproduce_P.json
@@ -21,7 +21,7 @@
   {"step": "G6 L6, L7 and d2 (cert_driver_P.sh g6)", "cwd": "S, candg, S/ref", "command": "bash tools/run_l6.sh; bash tools/check_l6.sh; HARNESS_PERTURB=<car.mass, thermal.c_turb, car.mass:1e-9, car.mass:1e-6> python -I -B tools/l6_agents.py candg sighted_seed0 ...; l6_check.py; python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/<sighted_seed0|blind_seed0> L7/cand_model/<tag>; cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval[_blind].txt L7/cand_model/<tag>; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0; python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; l7_diff.py and l7_expect.py (--agent blind_seed0); the scratch sighted_seed0 under d2: refused"},
   {"step": "G7 the suites and the documents (cert_driver_P.sh g7)", "cwd": "candg", "command": "commit A's S/tcl copied, then python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list; one <label> candg python -B <suite>.py -v for test_wide_air, test_epa_map (twice, the second with GRAD_EXTRA_DATA), test_plant_guards, random_road.py, fingerprint.py --engine b58, test_cars, test_trainable, test_fuel_forms, test_carried, test_tit_cap, test_epa_plants, test_preview_horizon; the HA.4, HA.5, HA.6 and HA.11 greps; python -B verify_docs.py; bash tools/run_drift.sh"},
   {"step": "G7.0 test_engine_threading, alone (p_gate.sh post)", "cwd": "the live repository, P's candidate applied uncommitted on RV", "command": "python -B test_engine_threading.py -v > S/suites/P_test_engine_threading.txt, after the roads check and every run above; git status unchanged after it"},
-  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md"},
+  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md (every make with -X utf8, as commit A's F.3: -I ignores PYTHONIOENCODING, and a FAIL record's got may carry a character cp1252 lacks)"},
   {"step": "F.3 into the repository (p_gate.sh cert-docs)", "cwd": "the live repository", "command": "the draft copied to results/B58_IDENTITY.json and .md; S/refw, candw, candt and pre removed; python -I -B tools/drift_control.py <repo> suites/P_drift_control_with_certificate.txt (a record); python -I -B tools/make_archive.py results/B58_IDENTITY/certificate_tools.tar.gz; python -I -B tools/make_cert.py results/B58_IDENTITY.json <archive> --config cert_P.json; python -I -B tools/make_md.py results/B58_IDENTITY.json results/B58_IDENTITY.md; drift_control.py again; python -B verify_docs.py"},
   {"step": "not run here", "cwd": "-", "command": "L8 (item 20) on the training device at ORDER step 18; app.test_results on P's own commit (p_gate.sh commit)"}
  ]
```

##### INTEGRATION.md

```diff
--- commit P, the first run: INTEGRATION.md
+++ commit P, second edit: INTEGRATION.md
@@ -125,7 +125,8 @@
 
 A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
 (review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
-before its lab_dump.py; G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
+before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
+(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
 `cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
 `suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
 first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
@@ -311,7 +312,11 @@
 - **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
   takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
   runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
-  P_GATE_PLAN.md 11.2.) (a) In a fresh extraction of build step 1's archive (`c47907b`'s), build step 1's
+  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
+  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
+  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
+  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
+  extraction of build step 1's archive (`c47907b`'s), build step 1's
   make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
   committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
   since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
@@ -324,6 +329,11 @@
 - **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
 - **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
   cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
+- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
+  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
+  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
+  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
+  road. The reward is safe to train against on the randomised climb.' (`--road random`).
 - **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
   each committed file (road_json_diff.py) is a `--difference` text, not judged.
 - **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
@@ -339,6 +349,17 @@
   skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
   configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
   second time, so that a failure RV already has reads as such.
+- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
+  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
+  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
+  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
+  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
+  cycle, which passed, used this trigger. The record's
+  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
+  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
+  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
+  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
+  original), and the trigger would fire on it before the new server is up.
 - **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
   block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
   strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
@@ -350,14 +371,27 @@
 - **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
   `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
   SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
-  ran ok and none was skipped or failed.
+  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
+  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
+  result pending until the next test header.
+- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
+  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
+  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
+  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
+  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
+  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
+  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
+  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
+  runs.
 - **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
 - **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
   record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
   list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
   (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
   no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
-  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it).
+  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
+  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
+  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
 - **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
   eight processes as run_l6.sh starts them; four evaluate.py at once in G6.
 
```

### INTEGRATION.md

commit A: no such file (new in P)
commit P: sha256 e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3

```diff
--- commit A: INTEGRATION.md
+++ commit P: INTEGRATION.md
@@ -0,0 +1,441 @@
+# P's B58 certificate kit: how p_gate.sh uses it
+
+Drafted 7 November 2026 for P_GATE_PLAN.md section 5.2 (K1-K8) and section 8 (R1.B3, R2.B2). **Nothing in the kit
+has run.** The only command run on it was `bash -n` on the shell files (all parse). No Python file of the kit was
+executed, and no JSON file was parsed by a JSON reader. The authorities were CERT_PLAN_P.md (at 4dd0c09 in
+build/clone_p), the interface sheet 6.8, CERT_PLAN_A.md and the tools in results/B58_IDENTITY/certificate_tools.tar.gz
+(read with `tar -xO`, never extracted), and commit A's own S (scratchpad/cert2: its tools are the archive's byte for
+byte, checked member by member; its records give what really ran and how long it took).
+
+`{{NAME}}` is a value only a run can give. "ASSUMED" marks a duration or a behaviour not measured.
+
+**Revised 7 November 2026 after the kit's review (P_GATE_PLAN.md section 11, "Review fixes 2").** What changed in
+the kit: the six shell tools whose `-B` edit had lost a space (compare_all.sh, check_l6.sh, run_l6.sh, run_l4.sh,
+and the cosmetic run_writer.sh and run_drift.sh) restored, each now the archive's but for the `-B` tokens, the
+`CAND` default and its header lines; cert_final_driver_P.sh's 3.6.19 record no longer FAIL by construction, and a
+FAIL record that a later PASS re-checks accepted there as make_cert.py accepts it; cert_driver_P.sh refuses any
+CERT_GROUPS but one-at-a-time, runs one group again with CERT_ONLY (and pairs re-run PASS records with the FAIL
+records they re-check, CERT_RECHECK_MAP), checks G1.7's two extractions against their own archive_members.txt
+before anything in them runs, judges G5 against cf43fbb's runs alone (commit A's and RV's for information), and
+kills a launcher server left on port 8765 (since the settle step of 7 November 2026: the listener and its recorded
+descendants, each by its pid, without taskkill /T); failing_sets_P.py names a setUpClass error alike in both invocations.
+Sections 2-8 below are updated; the items p_gate.sh now does (section 8) are marked done.
+
+**Revised again 7 November 2026 after the two re-reviews of that revision (P_GATE_PLAN.md section 12, "Review fixes
+3").** What changed in the kit: every group of cert_driver_P.sh that counts or compares files an earlier run of it
+leaves (G1's harness folders, G5's lab dumps, G6's L6, L7 and d2 outputs, G7's second test_epa_map output) starts
+from none of them, so that a `CERT_ONLY` re-run (cert-recheck) is judged on its own files (G6's re-run always read
+"L6 done: 16 of 16" and FAILed; G1's would have counted every job twice); every lab_dump.py exit is recorded and
+required; G5 requires the three ignored local paths p_gate.sh cert-prep now copies into the clone and the node tests'
+`ℹ skipped 0`; npm ci and the launcher's port fail closed (a FAIL record that cert-recheck g5 re-checks); the
+launcher's left-over server is found by the port it listens on, not by its command line; cert_final_driver_P.sh
+refuses (exit 3, no record written) while a FAIL record is open; run_l6.sh's and make_meta.py's comments corrected;
+cert_P.json's not_covered says where the clone's ignored data came from.
+
+The orchestrator's decisions of 7 November 2026, as the kit implements them:
+- The certificate runs in the clean clone `GD/cert/candg` at P's candidate (git_dirty False). The kit gives the clone
+  REPO's role everywhere (env_P.sh), and make_cert.py asks git there (cert_P.json's `candidate.tree`), so the
+  certificate names P_CAND. The check that P's final commit differs from P_CAND only by documents and reverify.json
+  is p_gate.sh's (phase commit).
+- The certificate's groups run one at a time beside the roads check: the driver runs G1, G2, ..., G7 in order, and
+  refuses to start unless CERT_GROUPS is one-at-a-time. Inside a group, what CERT_PLAN_A.md runs together runs
+  together: up to six processes in most steps, eight in L6 (run_l6.sh), and up to 18 in check_roads.py's own pool
+  plus two test_reward.py runs in G3, so that G3 puts about 20 processes beside the check's 14 jobs on the laptop's
+  20 threads (numbers do not change: every process is single-threaded; the check's time grows; section 5).
+- test_epa_tightenings MODE ok and the commit-failure route are p_gate.sh's and P's; the kit does not touch them.
+- The kit owns `cert_kit/` only; it does not write P_GATE_PLAN.md, `decisions/` or p_gate.sh. Section 8 lists what
+  the kit asks of them.
+
+## 1. The files
+
+p_gate.sh's phase `cert-kit` installs every file under `cert_kit/` at the same relative path under S (over the
+archive's copy), and appends `TOOL_EDITS_commit_P.md` and a diff of every other file to S/TOOL_EDITS.md.
+
+| kit file | installed as | what it is | new or edited |
+|---|---|---|---|
+| `env_P.sh` | S/env_P.sh | the variables (K3), sourced by both drivers | new (from env_A.sh) |
+| `cert_P.json` | S/cert_P.json | make_cert.py's config (K6); `date` empty (D19) | new (from cert_A.json) |
+| `reproduce_P.json` | S/reproduce_P.json | the reproduce block cert_P.json names | new |
+| `TOOL_EDITS_commit_P.md` | appended to S/TOOL_EDITS.md | why each file changed, and each diff against the archive (K2) | rewritten |
+| `INTEGRATION.md` | S/INTEGRATION.md | this page (archived with the rest; section 8, item 1) | new |
+| `tools/cert_driver_P.sh` | S/tools/ | CERT_DRIVER: G1-G7 (K7) | new |
+| `tools/cert_final_driver_P.sh` | S/tools/ | CERT_FINAL_DRIVER: F.1, HP7.6, the 3.6.19 record, F.2 (K8) | new |
+| `tools/make_meta.py` | S/tools/ | schema-4 live block, for_arm (K1) | edited |
+| `tools/make_cert.py` | S/tools/ | the candidate's tree; schema 4; a format-2 previous certificate; page_text (K5 and more) | edited |
+| `tools/make_md.py` | S/tools/ | the page's own words from page_text; schema 4's backends | edited |
+| `tools/run_jobs.py` | S/tools/ | `-I -B` for every harness job (K4) | edited |
+| `tools/compare_all.sh`, `tools/check_l6.sh` | S/tools/ | `-I -B` (K4) | edited |
+| `tools/run_writer.sh`, `run_l4.sh`, `run_l6.sh`, `run_app.sh`, `run_app_extra.sh`, `run_drift.sh` | S/tools/ | `-B` (K4); CAND has no default (contract item 2) | edited |
+| `tools/l7_expect.py` | S/tools/ | `--agent`, `--repo` (L7's blind_seed0) | edited |
+| `tools/cert_record.py` | S/tools/ | optional `--rechecks` (a FAIL's re-check route) | edited |
+| `tools/road_json_diff.py` | S/tools/ | commit A's g3/road_json_diff.py, unchanged, moved into tools/ | new in tools/ |
+| `tools/failing_sets_P.py` | S/tools/ | G5's failing sets against several reference runs | new |
+| `tools/stated_counts_P.py` | S/tools/ | HP7.6 as a check that can fail | new |
+
+## 2. What p_gate.sh calls
+
+### 2.1 Phase `cert` (beside the check)
+
+p_gate.sh already does, in this order: `cert_ready`, `records_fresh`, `cert_tree_clean`, G1.0 (`g1_identity`: two
+G1-harness records; `out/P_G1_fp_cand.txt`, `pip_freeze_P.txt`), G7.3 (`g7_help`: one G7-suites record), then
+
+```bash
+export CERT_S CERT_TREE P_CAND RV_SHA; export LIVE_REPO=$REPO
+in_dir "$CERT_TREE" bash "$CERT_DRIVER"          # CERT_DRIVER=$CERT_S/tools/cert_driver_P.sh
+```
+
+That is the whole contract: no argument. The driver sources `$CERT_S/env_P.sh`, which refuses unless CERT_TREE's
+HEAD is P_CAND and CERT_S is the folder env_P.sh lies in. Optional environment (defaults in brackets):
+
+| variable | default | what |
+|---|---|---|
+| `CERT_PAR_L1` | 6 | run_jobs.py's parallel jobs for G1.1 (CERT_PLAN_A: 6) |
+| `CERT_L9_PROCS` | 6 | `ecu_shift.run_all(N)` (CERT_PLAN_A: 20; commit A ran 16 with 25 of 25) |
+| `COMMIT_A_S` | `scratchpad/cert2` | commit A's S: its `tcl/` (G7.1's lists and package zips) |
+| `P_GATE_OUT` | `GD/out` (CERT_ROOT's sibling `out`) | p_gate.sh's G: RV's base app logs, read as references in G5 |
+| `NODE`, `NPM` | `command -v node`/`npm`, else `/c/Program Files/nodejs/` | G5 |
+| `CERT_GROUPS` | (none: required) | must be `one-at-a-time` (decisions/cert_groups.txt); any other value: exit 2 |
+| `CERT_ONLY` | (unset: all seven) | `g1` ... `g7`: that group alone (p_gate.sh cert-recheck); S/commitA is then checked against its `_sha256.txt`, not copied again |
+| `CERT_RECHECK_MAP` | (unset) | with CERT_ONLY: lines `<what><TAB><group>.json record <n>`; a re-run PASS record whose `--what` is listed gets `--rechecks "<group>.json record <n>"` (make_cert.py's `_rechecks` pairs it with that earlier FAIL); when several lines share the `what` (the same check failed on the first run and on a re-run: settle step, 7 November 2026), the PASS is written once per line, each with its own `--rechecks` |
+
+Exit: 0 when every record was written (whatever their verdicts); 3 when cert_record.py refused a record, a
+precondition of its own failed (the clone's HEAD~1 is not RV_SHA, the clone is not clean, an input is missing),
+or the clone is not clean at P_CAND at the end; 2 when it cannot start. p_gate.sh stops on any non-zero exit
+("the certificate's driver, exit N") but one: exit 3 whose report (this run's lines) holds no `REFUSED` line but
+`REFUSED by cert_record.py (group <G>)` lines. Then cert passes, the groups that lost a record are listed in
+`GD/out/cert_recheck_needed.txt`, and post refuses until `cert-recheck <g>` has run each of them again. p_gate.sh
+then checks the clone clean and REPO's status unchanged, and lists every FAIL record (`GD/out/cert_fail_records.txt`).
+
+Inputs the driver refuses without (from cert-prep, cert-kit and G1.0): `S/tools/{run_jobs.py, compare_all.sh,
+control_verdict.py, cert_record.py, make_meta.py, failing_sets_P.py, stated_counts_P.py, road_json_diff.py,
+l7_expect.py}`, `S/out/ref/_status.txt`, `S/out/fp_ref.txt`, `S/out/P_G1_fp_cand.txt`, `S/manifest_start_P.txt`,
+`S/L7/ref_eval.txt`, `S/F11/ref_d2.txt`, `S/lab/lab_ref_A.json`, the trees `S/{ref,refw,pre,cand,candd,candw,candt}`,
+and `CERT_ROOT/X` (the archive extracted whole). It reads, never writes: X (commit A's candidate evidence, copied
+into `S/commitA/` with sha256 against `X/archive_members.txt`), P_GATE_OUT, and in the live repository (LIVE_REPO;
+P changes none of these files): `runs/extremes_dt1` (L6, L7), the committed raw scores and agent files
+`l6_check.py` reads (`results/phase_d_extremes_dt1_raw.json`, `results/agents/...`; archive tools/l6_check.py:19,
+25, 43), and `git rev-parse HEAD` there (make_cert.py:68, every make). (review fixes 3) Also read there, read-only:
+every make reads cert_P.json's `x1_meta` (make_cert.py:431-433, relative to REPO, the live repository: of runs/ the clone holds only the copy of X1's sighted_seed0 meta.json cert-prep makes, and make_cert.py does not read it there; make_cert.py:15's "runs/ is in no clone" predates that copy); and G1.7(b)'s
+two makes on commit A's own cert_A.json, which names no `candidate.tree`, ask git in the live repository for HEAD,
+the branch, `log c47907b..HEAD`, `show c47907b:results/B58_IDENTITY.json` and `archive cf43fbb`
+(make_cert.py:208-210, 449-458). G1.7 reads committed blobs through the clone (`git cat-file`). The clone itself holds,
+from p_gate.sh cert-prep, three gitignored paths copied from the live repository (`app/node_modules`,
+`app/static/vendor`, `runs/extremes_dt1/sighted_seed0/meta.json`: a G0-prepare record), as commit A's run in the
+repository had them; G5 checks they are there and ignored.
+
+A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
+(review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
+before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
+(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
+`cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
+`suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
+first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
+`S/F11/ref_d2.txt`, `S/lab/lab_ref_A.json`, `out/ref/`) are never removed.
+
+### 2.1b Phase `cert-recheck <g>` (only when a FAIL record, or a lost record, needs it)
+
+The team writes `decisions/cert_recheck_<g>.txt`: `MODE recheck`, `REASON <the cause, read in the FAIL's
+evidence>`, and one `FAIL <group>.json record <n>` line per FAIL record the re-run re-checks (none when the group only
+lost records). p_gate.sh checks each named record is a FAIL, not re-checked yet, and has a `what` that names only
+records of the same check in its file (the same level, item and command), and that the decision names every OPEN
+FAIL of that check; copies every earlier record's evidence of that file to `S/recheck/<group>_<stamp>/` and points
+those records at the copies (the re-run writes the same paths; a FAIL record keeps the first run's evidence); writes
+CERT_RECHECK_MAP; runs the driver with CERT_ONLY=<g>; then requires a PASS record naming each FAIL in `rechecks`. It
+runs beside the check or after it, before cert-docs (cert-docs removes S's extra trees, which the driver needs), and
+clears post and every phase after it, so that G7.0 runs again after it.
+
+(settle step, 7 November 2026) A group can be re-checked more than once. After one re-run every check of the group
+has two records with the same `what` (the first run's and the re-run's): that is one check run twice, so the rule is
+"the same check", not "one record of the file" (round 3's rule, under which a FAIL a re-run wrote, or a second FAIL
+of a check re-run once, could never be re-checked: npm ci without the network twice, for one). When a check failed
+on the first run and again on the re-run, both FAILs are OPEN: the next decision names both, and the next re-run's
+PASS of that check is written once per FAIL, each with its own `rechecks` (make_cert.py pairs one PASS with one FAIL).
+The re-run deletes the group's raw outputs that no record names as evidence (G1's `out/P_G1_*/` dumps, G6's
+`L6/*.npz`): recheck_prep copies only `evidence_files` aside, so whoever needs the first run's raw dumps to read a
+FAIL's cause reads them, or copies them aside by hand, before cert-recheck.
+
+(review fixes 3) Only the driver's groups g1 ... g7 can be re-run, and a FAIL is re-checked only by a re-run PASS of
+the same check (the same `what`). So a FAIL of a record no driver group writes again needs a new S (move GD/cert
+aside, cert-prep, cert-kit, cert, post): G0-prepare's, G1.0's (cert stops on it anyway), G7.3's, G7.0's (written by
+post), HP7.6's (G7-suites, written by the final driver) and every F-certificate record (the final driver's F.1 and
+3.6.19; cert-docs' drift control). post refuses while any FAIL record is open (it lists them again from S first,
+`GD/out/cert_fail_records.txt`), and the final driver refuses before its first record (2.2), so that an open FAIL
+never turns into a 3.6.19 FAIL that nothing can re-check.
+
+### 2.2 Phase `cert-final`
+
+```bash
+export CERT_S CERT_TREE P_CAND RV_SHA; export LIVE_REPO=$REPO
+in_dir "$CERT_TREE" bash "$CERT_FINAL_DRIVER"    # $CERT_S/tools/cert_final_driver_P.sh
+```
+
+It needs post's `S/suites/P_test_engine_threading.txt` (G7.0's record). Same exit codes; (review fixes 3) before its
+first record it reads every `S/cert_results/*.json` (`$PY -I -B`, make_cert.py's pairing rule: a FAIL is closed only
+by a later PASS of the same file naming it in `rechecks`) and exits 3, writing no record, if a FAIL is open or a
+file does not parse (`S/out/P_F0_open_fails.txt`). Then p_gate.sh checks
+`S/cert_out/B58_IDENTITY.json` and `.md`, `make_cert_ok S/cert_out/make_cert_stdout.txt`, and that the JSON names
+P_CAND: the driver writes all three for exactly those checks. make_cert_ok (and the driver's own 3.6.19 test)
+accepts a `  FAIL {...}` line only when its dict ends with a non-empty `'rechecked_by': [...]` (a FAIL record a later
+PASS re-checks) and the line `  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)` is
+printed; any other `  NO  `, `  PROBLEM `, `  FAIL ` or `  MISSING ` line refuses.
+
+### 2.3 Phase `cert-docs` (no driver)
+
+p_gate.sh's own F.3 calls the kit's tools with unchanged interfaces: `tools/drift_control.py`, `make_archive.py`,
+`make_cert.py <json> <archive> --config S/cert_P.json`, `make_md.py`. make_cert.py now asks git in cert_P.json's
+`candidate.tree` = `GD/cert/candg`: the clone must still exist at cert-docs (H8 deletes it only after the push).
+
+## 3. What each driver writes, and where
+
+Every record goes to `S/cert_results/<group>.json` through `rec` (cert_record.py, `-I -B`). Own reports:
+`S/out/P_driver_report.txt` (every group's start, end and seconds; every "NO RECORD" line; refusals),
+`S/out/P_driver_records.log` (cert_record.py's lines), and `S/out/P_final_driver_report.txt`,
+`S/out/P_final_driver_records.log`.
+
+| group | records (driver) | evidence, under S | scratch outside S (removed by the driver) |
+|---|---|---|---|
+| G0-prepare | 1: commit A's evidence copied into `commitA/` (none on a CERT_ONLY run); p_gate.sh adds 1 per cert-recheck | `commitA/**`, `commitA/_sha256.txt`; `recheck/<group>_<stamp>/**`, `recheck/<group>_<stamp>_{sha256,decision}.txt` | |
+| G1-harness | 3 (L1, B3, HA.9) + 20 controls + the lhv keys + divergent + 3 for G1.7 = 28 | `out/P_G1_*/` (dumps, logs, `_status.txt`), `out/P_G1_*_run.txt`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`, `cmp/P_G1_*.txt`, `out/P_G1_lamf32_first_rows.txt`, `out/P_G1_bind_lines.txt`, `out/P_G1_tool_hashes.txt`, `out/P_G1_b9_*.txt` (with `out/P_G1_b9_{bs1,commitA}_members.txt`: each extraction against its own archive_members.txt) | `CERT_ROOT/g17` |
+| G2-writers | 7: check_premise, generality_test, L9, item 16's tree, model_vs_data, substep_fit_check, make_page | `L5/cand_premise_*`, `L5/cand_generality_*`, `L5/cand_P16{pre,candw}_{mvd,substep,page}_*`, `L5/P_G2_*`, `L9/P_G2_*`, `prep/P_G2_preRV_tar_compare.txt` | `CERT_ROOT/preRV` |
+| G3-roads | 7: S/cand before, test_reward (both), extremes, wideair, terrain, check_random_road, S/cand after | `L4/cand{,_random}_*`, `L5/cand_roads_*`, `L5/P_G3_*`, `F11/cand_roads_terrain_*`, `F11/cand_random_road_*`, `F11/P_G3_*`, `prep/P_G3_*` | |
+| G4-data | 4: validate, build_dataset, new_drive, derive_params | `L5/P_G4_*`, `F2/{cand,ref}.txt`, `F2/{cand,ref}.npz`, `F2/cmp.*`, `F2/new_drive_candd.txt`, `L5/derive_cand.txt`, `L5/derived_*` | |
+| G5-app-lab | 15 with the network (12 without: npm ci's record a FAIL, and the build, the launcher and the lab's node tests get none; with the port 8765 taken, 15 with the launcher's a FAIL: review fixes 3) | `app/cand_*`, `app/P_G5_*` (`app/P_G5_failing_*_info.txt`: the information-only comparisons), `lab/P_G5_*`, `lab/lab_{ref,cand}_P.*`, `lab/lab_P_ctl_*`, `lab/compare_P_*` | |
+| G6-agents | 15: L6 run, 4 agents, 4 controls, 2 make_meta, 2 L7, d2, d2's refusal | `L6/{cand,ref}_*`, `L6/P_G6_*`, `cmp/L6_*`, `cmp/P_G6_*`, `L7/cand_model/*`, `L7/{make_meta*,cand_*,ref_eval_blind.txt,ref_blind_*,l7_*}`, `F11/cand_d2*`, `F11/d2_diff.*` | |
+| G7-suites | 19: G7.1, 12 suites, HA.4, HA.5, HA.6, HA.11, verify_docs, run_drift (+1 when the second test_epa_map runs) | `suites/cand_*.txt`, `suites/_status.txt`, `suites/P_G7_*`, `suites/drift_*`, `tcl/` (not archived: SKIP_DIRS) | |
+| F-certificate (K8) | 3: F.1 fingerprint, F.1 manifest, 3.6.19 (draft0) | `out/P_end_fp_cand.txt`, `manifest_end_P.txt`, `out/P_F1_*`, `cert_out/P_F2_draft0*` | `CERT_ROOT/vdcheck_P` |
+| G7-suites (K8) | 1: HP7.6 | `suites/P_F_stated_counts.txt` | |
+| (K8, no record) | the draft | `cert_out/B58_IDENTITY.json`, `.md`, `make_cert_stdout.txt`, `make_md_stdout.txt`, `P_F2_verify_docs_precheck.txt` | |
+
+With the gate's own records (G0-prepare 6, the sixth the ignored data copied into the clone: review fixes 3; G1.0 2,
+G7.3 1, G7.0 1), the draft holds about {{N_RECORDS}} records
+(about 110 by the counts above; the second test_epa_map run and the network move it). cert-docs adds one (the drift
+control with the certificate, F-certificate, item 3.6.18) before the final make.
+
+Names: harness labels `P_G1_*`; the driver's own files `P_<group>_*`; the tools that name their own files write
+`cand_*` (S holds none from commit A: cert-prep left them in X); commit A's files a check compares with are in
+`S/commitA/` under their archive paths.
+
+## 4. Expected outputs
+
+The driver's report ends with `END cert_driver_P.sh after {{CERT_SECONDS}} s; records: {{N_PASS}} PASS,
+{{N_FAIL}} FAIL; driver refusals: none` (review fixes 3: "none" or "at least one", not the 0/1 flag it printed).
+p_gate.sh's cert phase notes the same two counts.
+
+make_cert.py's print-out at F.2 (`S/cert_out/make_cert_stdout.txt`), as p_gate.sh's `make_cert_ok` needs it:
+
+```
+written C:/.../p_gate/cert/S/cert_out/B58_IDENTITY.json | BIT-IDENTICAL at every level run on this machine (pending: L8 on the training device at ORDER step 18, and app.test_results on P itself after the commit)
+  ok  every record well formed
+  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)
+  ok  every item of the re-run list answered
+  ok  harness jobs BIT-IDENTICAL (compare_all.sh's reports)
+  ok  every control as expected (compare_all.sh's reports)
+  ok  the plant's fingerprint the same at the start and the end
+  ok  derived_sha and the shared FATAL fields equal the reference's
+  ok  engine_sha over build step 1's keys is build step 1's (B11)
+  ok  the repository unchanged during the run (manifests), but for the files the config declares, none a plant file
+  ok  every value count read
+  ok  engine_sha is the previous certificate's candidate's (row 94: plant_sha moves, engine_sha does not)
+```
+
+and no `  PROBLEM`, `  FAIL` or `  MISSING item` line. The JSON: `candidate.head` = {{P_CAND_SHA}}, `candidate.base_commit`
+= {{RV_SHA}}, `candidate.commits_on_base` = one line, P_CAND's; `identity.plant_sha.candidate` =
+{{PLANT_SHA_B58_P}} (the port printed 36655cab94800e30), `.previous_certificate` 865f8e7b7e5c2dbe (commit A's),
+`.reference` 3c48890dd15bc116; `derived_sha` 326c0835548975e2 on all sides; `engine_sha.candidate` 023f5589215ee68e
+= `.previous_certificate`; `over_build_step_1_keys` = `over_build_step_1_keys_in_previous_certificate` =
+99d2a9658b1258a7 (commit A's reading, read at run time from RV's results/B58_IDENTITY.json); `backends` train cycle,
+score cycle, contract {{BACKEND_CONTRACT}}; `shared_read_from_transmission` [gears, final_drive];
+`values_compared_byte_for_byte` harness {{N_HARNESS_VALUES}} (= commit A's comparison's sum, 2 685 037, if every
+job is BIT-IDENTICAL), l6_agents {{N_L6_VALUES}}, build_dataset_columns {{N_BD_VALUES}} (commit A: 3 617 501).
+`different.fingerprint` will list `gears`, `final_drive` and `backend` (a value against none: schema 4 moved them,
+cert_P.json's note says so) and the schema-4 fields, as provenance.
+
+## 5. Durations
+
+Commit A's records give wall times under a load it states as 100 to 180 Python processes at 100 % CPU; P's groups
+run one at a time beside the check's 14 jobs (with up to about six of their own, eight in L6, up to 18 in
+check_roads.py's pool). "P, ASSUMED" is CERT_PLAN_A.md's unloaded time times about 1.3, plus what P adds.
+
+| group | CERT_PLAN_A.md (all groups at once) | commit A's records, s (loaded) | P, ASSUMED |
+|---|---|---|---|
+| G1 | about 1 h | L1 8258 (plan: about 1970 at 6 jobs); ref2 3108, cturb 2455, mass 2075, afr 1812, lhv 953, divergent 32, bind 473, lamf32 304, lamf64 474, ceilf32 473, census 853, census_rest 1829, form controls 384-867 each, refside 962; G1.7 117 | 2-2.5 h (L1 about 45 min, ten waves of controls, G1.7 a few minutes) |
+| G2 | about 2.5 h | premise 4006, generality 9203, L9 7778 (16 processes), item 16: model_vs_data 2518, substep 4311, page 403 | about 2 h (generality about 55 min beside premise and L9 at 6 processes, then item 16 twice each) |
+| G3 | about 2.5 h | test_reward 6528 and 5952 (random), extremes 3754, wideair 2931, terrain 1527, check_random_road 3372 | about 1.6-2 h (the roads one after another: about 996 + 1296 + 608 + 2777 s unloaded) |
+| G4 | about 15 min | validate 1282, bd_dump 160, new_drive 118, derive_params 1121 | about 20 min |
+| G5 | about 1 h | test_replay --full 4625, test_simulation 78, test_agents 1228, test_results 690, lab tests 151, the eleven 386, node 15, npm ci 633, build 632, launcher 300, lab node 191, lab dumps 507-640 each | about 1.3 h (network for npm ci) |
+| G6 | about 2.6 h | L6 3194, check_l6 86, controls 300-735, L7 11991, d2 13460, refusal 2 | about 3.5-4 h (L6 about 1 h; four evaluate.py at once: sighted, blind, cf43fbb's blind, d2) |
+| G7 | about 45 min | test_wide_air 5077, test_fuel_forms 2736, test_trainable 379, test_plant_guards 142, test_epa_map 131, test_cars 100, fingerprint 66, random_road 49, test_carried 26, verify_docs 221-399, run_drift 839-1404 | about 1.3 h (test_preview_horizon alone after the waves: 611-767 s) |
+| K8 | about 30 min with F.3 | F records 2-60 s; make_cert seconds | about 10-15 min (two makes, a copy of the clone and verify_docs in it) |
+
+Sum for P: about 12-14 h (ASSUMED), inside the check's 17.7 h (ASSUMED). If the check ends first, the certificate
+goes on alone; post needs both.
+
+## 6. To settle before `check` (the certificate's window is the check's)
+
+1. **HP7.6 fails at 4dd0c09, by reading.** README.md:830 and full_run.py:86 state test_plant_guards "19 tests (9 skip
+   until the EPA plants are calibrated)"; the port ran it `Ran 47 tests ... OK`, no skip (port_p/out). README.md:827
+   and full_run.py:130 state app.test_agents "135 tests OK, 14 skipped"; P edits app/test_agents.py, so that count is
+   {{N_TEST_AGENTS}}. stated_counts_P.py would print `DIFFERENT` on those lines, the HP7.6 record would FAIL, the draft
+   would print a FAIL line, and p_gate.sh's cert-final would stop. full_run.py is a .py: after apply, docs_only refuses
+   its edit. **Settled (review fixes 2):** the counts go into P's re-made candidate at H-S (P_GATE_PLAN.md 5.3),
+   from the survey's applied-stage runs, which run stated_counts_P.py (`stated_counts` in GD/survey/summary.txt); and
+   p_gate.sh pre runs the same check on its own runs (`stated_counts_pre`, step 8b) and stops on a DIFFERENT line or
+   on any statement but test_wide_air.py's without a run (pre does not run test_wide_air.py; P does not edit it; G7
+   does), before the window opens.
+2. **verify_docs.py on P's candidate tree** (G7.5, item 3.6.18) is a record. **Settled:** p_gate.sh pre now runs it
+   as a gate (step 8c) on the same documents and stops on a failure; the survey's run shows it before H-S.
+3. **The kit's Python was never executed** (make_cert.py, make_md.py, l7_expect.py, cert_record.py, run_jobs.py,
+   failing_sets_P.py, stated_counts_P.py, make_meta.py) and its JSON (cert_P.json, reproduce_P.json) was parsed by no
+   JSON reader. **Settled as far as can be before the window:** cert_ready ast-parses every kit .py and json-loads
+   both JSON files; cert-kit's smoke step (p_gate.sh `kit_smoke`) checks the edited shell tools by text and by an
+   argv run with PY=echo against the archive's, and replays compare_all.sh and check_l6.sh on commit A's own dumps
+   against commit A's reports; the survey runs stated_counts_P.py and failing_sets_P.py on real logs. make_cert.py,
+   make_md.py, make_meta.py, l7_expect.py, run_jobs.py and the drivers still run first inside the window.
+4. `decisions/cert_kit_reviewed.txt` lists every file under cert_kit/, INTEGRATION.md and TOOL_EDITS_commit_P.md
+   among them (cert_ready requires each): 24 files. TOOL_EDITS_commit_P.md's sha256 table was written last; any later
+   kit edit means regenerating its diffs. (review fixes 3) Written 7 November 2026 by the fixer and signer of the two
+   re-reviews of review fixes 2, after their fixes (P_GATE_PLAN.md section 12): its `#` lines name the re-reviews and
+   the date (sha256sum -c skips them), and its other lines are `sha256sum` over the 24 files as they stand then. Any
+   later kit edit voids it: cert_ready then refuses (review-sha256), and the reviewers write it again.
+5. G5 needs the network (npm ci) and a free port 8765. (review fixes 3) Without the network npm ci's record is a
+   FAIL (the build, the launcher and the lab's node tests then get no record); with the port taken the launcher's
+   record is a FAIL; either stands until cert-recheck g5 runs G5 again, so the certificate cannot pass without the
+   lab's runs (before, a missing record let 3.6.12 and B12 read as answered). G5 also needs the three ignored local
+   paths p_gate.sh cert-prep copies into the clone (2.1). G7.1 needs `COMMIT_A_S/tcl` (present in scratchpad
+   cert2: commit A's lists and package zips) or the network.
+6. Nothing else may use the venv's python during `cert` but the check (no_other_python is skipped for cert).
+
+## 7. Expectations the kit writes down (P_GATE_PLAN.md 7.23, and where P moves an expectation no sheet amends)
+
+- **G1.1, values**: the sum of the comparison lines equals commit A's comparison's sum (read from the archive), not a
+  typed 2 685 037.
+- **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
+  takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
+  runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
+  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
+  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
+  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
+  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
+  extraction of build step 1's archive (`c47907b`'s), build step 1's
+  make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
+  committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
+  since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
+  cert_A.json: byte-identical JSON and page. (c) The control: P's make_cert.py on cert_A.json with `candidate.tree` =
+  the clone writes another JSON whose candidate.head is P_CAND.
+- **G2.3, item 16 at P**: before = a git archive of RV (outside S, `CERT_ROOT/preRV`), after = S/candw, for
+  CERT_PLAN_A.md's three scripts (model_vs_data.py, substep_fit_check.py, make_page.py): byte-identical,
+  equal apart from `seconds`, identical pages. c47907b (commit A's "before") would compare WP1's edits, not P's.
+  S/pre (c47907b) is left unused. HA.7: the candidate's page still carries commit A's two glossary sources.
+- **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
+- **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
+  cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
+- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
+  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
+  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
+  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
+  road. The reward is safe to train against on the randomised climb.' (`--road random`).
+- **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
+  each committed file (road_json_diff.py) is a `--difference` text, not judged.
+- **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
+  only be failures that cf43fbb's git clone (app/refgit_*) also has (`failing_sets_P.py`: candidate only []). The
+  eleven: against build step 1's cf43fbb copy run (app/ref_*) alone. The node tests: against cf43fbb's clone's run
+  alone; the lab's node tests (G5.3): against commit A's run of them on cf43fbb's tree alone. Commit A's candidate
+  runs and RV's base runs (P_GATE_OUT/base_app_*.log) are compared too, for information only (`*_info.txt`, named in
+  the record's got): a failure RV's ancestors brought in after cf43fbb is a FAIL, not excused. The survey predicts
+  this verdict before the window (`g5_predict_*` in GD/survey/summary.txt). The lab's pin: the value in
+  tests/test_catalog.py equals G1.0's plant_sha, and its test passes. (review fixes 3) The clone holds the three
+  ignored local paths commit A's run in the repository had (cert-prep), so G5 runs what commit A's run ran: each app
+  record requires them, and the node tests' record requires `ℹ skipped 0` (commit A: 306 tests, 306 pass, 0
+  skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
+  configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
+  second time, so that a failure RV already has reads as such.
+- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
+  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
+  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
+  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
+  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
+  cycle, which passed, used this trigger. The record's
+  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
+  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
+  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
+  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
+  original), and the trigger would fire on it before the new server is up.
+- **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
+  block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
+  strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
+- **G6.3**: blind_seed0 beside sighted_seed0 (CERT_PLAN_P.md); no reference report exists for it, so the driver runs
+  cf43fbb's evaluate.py on X1's original blind_seed0 in S/ref and diffs the two (`NO DIFFERENCE`), and l7_expect.py
+  rebuilds its rows (`--agent blind_seed0`).
+- **G6.4**: X1's scratch sighted_seed0 under d2 is refused with a PLANT MISMATCH on exactly `scenario` and
+  `episodes_sha` (the protocol's two FATAL fields; schema 4's other FATAL fields agree).
+- **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
+  `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
+  SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
+  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
+  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
+  result pending until the next test header.
+- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
+  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
+  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
+  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
+  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
+  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
+  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
+  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
+  runs.
+- **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
+- **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
+  record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
+  list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
+  (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
+  no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
+  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
+  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
+  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
+- **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
+  eight processes as run_l6.sh starts them; four evaluate.py at once in G6.
+
+## 8. What the kit asks of p_gate.sh and the plan (all done on 7 November, review fixes 2)
+
+1. Done as it was: `cert-kit` installs INTEGRATION.md into S (so it is archived) and appends a /dev/null diff of every
+   new file to S/TOOL_EDITS.md, beside the diffs TOOL_EDITS_commit_P.md already holds (the two must agree).
+2. Done: `cert_ready` ast-parses every kit `.py` and json-loads `reproduce_P.json` and cert_P.json, and requires
+   cert-kit's smoke step to have passed on the tools installed (`G/cert_kit_smoke.ok`).
+3. Done: `archive_ok`'s member list adds `reproduce_P.json`, `tools/failing_sets_P.py`, `tools/stated_counts_P.py`.
+4. Done: P_GATE_PLAN.md 5.2 marks K4-K8 written (drafts, reviewed once, revised); 7.2 and 7.23 point here; HP7.6 and
+   G7.5 are gates of pre (section 6, items 1-2).
+5. Also in p_gate.sh now: the cert-recheck phase (2.1b); make_cert_ok's acceptance of a re-checked FAIL (2.2); cert's
+   handling of the driver's exit 3 (2.1); check no longer depends on cert-kit's marker (a certificate redone on a new
+   S never clears the check's), and still refuses to start without the kit.
+
+The full-tree copies the kit makes outside S hold logs/epa/ like the clone (never opened): `CERT_ROOT/preRV` (G2.3,
+removed by the driver), `CERT_ROOT/vdcheck_P` (K8's pre-check, removed), and S/tcl holds commit A's EPA Test Car
+Lists and the NCAT folder (G7.1; not archived: SKIP_DIRS). P_GATE_PLAN.md's H4 discloses them and H8 deletes what
+is left.
+
+## 9. UNKNOWN
+
+1. Every expectation of section 7 holds on P's tree: nothing ran. In particular whether harness.py, l6_agents.py and
+   lab_dump.py still run at P (they call engine_env's constructors and records P edited: a crash reads as fewer
+   than N exit 0, or a failed run, never as identical), and whether P's evaluate.py, test_reward.py and check_roads.py
+   print what cf43fbb's printed (P edits all three; G3.1, G3.2, G6.3 and G6.4 would read a moved line as a FAIL).
+2. Whether the app suites, test_epa_map.py and fetch_engine_data.py behave in a clone as in the repository: the clone
+   has no runs/ (but X1's sighted_seed0 meta.json), runs_c4/ or other gitignored local data beyond the three paths
+   cert-prep copies (review fixes 3). A test that needs more may fail only in the clone, which failing_sets_P.py
+   reads as "candidate only" unless one of the references failed it too; the survey's committed_data stage shows it
+   before the window.
+3. ~~Whether cf43fbb's evaluate.py takes `--out` with X1's blind_seed0 by absolute path and labels it as P's does.~~
+   Answered by reading (review fixes 3): cf43fbb's evaluate.py:467-470 labels a model path containing "blind" as
+   `agent (blind) <path>`, and :556-557 writes only `--out` (its folder made if needed), nothing into the X1 run
+   directory.
+4. Whether the lab's node tests and launch.py behave in S/cand at P (B12 anchors on engine_env.py's text, which P
+   edits), and whether `timeout 300` stops launch.py's server so that port 8765 is free afterwards.
+5. Whether a class the driver judges by name has a test skipped by design (it would read FAIL).
+6. Whether test_preview_horizon.py, test_tit_cap.py and test_epa_plants.py accept `-v` (unittest's main does).
+7. The durations of section 5 (ASSUMED), and so whether the certificate ends inside the check's window.
+8. make_md.py's page for P beyond the edited lines: it was written for commit A's certificate; other sentences may
+   read oddly for P (read the draft).
+9. Whether verify_docs.py accepts the page: cert_P.json carries commit A's three page_markers; K8's pre-check runs
+   verify_docs.py with the draft in a copy of the clone and reports, without a record, before cert-docs.
+10. The base of TOOL_EDITS' diffs is the archive at the time of drafting (REPO's committed archive = RV's); if RV's
+    amendment replaced the archive, cert-kit's own diffs (against X) are the ones that count.
```

### cert_P.json

commit A: no such file (new in P)
commit P: sha256 ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193

```diff
--- commit A: cert_P.json
+++ commit P: cert_P.json
@@ -0,0 +1,163 @@
+{
+ "_what": "make_cert.py --config: P's certificate (build step 2, ORDER step 14; the interface sheet 6.8; row 138 (4); CERT_PLAN_P.md, amending CERT_PLAN_A.md). Commit A's cert_A.json as P amends it (P_GATE_PLAN.md 5.2, K6). Paths are relative to S unless absolute; x1_meta is relative to the live repository (runs/ is in no clone); the candidate's git questions are asked in candidate.tree. No hash and no count is typed here: make_cert.py reads every one from the files named. Written 7 November 2026, before any of P's certificate ran, reviewed with the kit, and not edited after the review: date stays empty (make_cert.py writes the day it runs), no file is declared changed during the run, and anything the run does that this config does not foresee goes into P's session report.",
+ "title": "The B58 identity certificate: commit P of build step 2 against cf43fbb",
+ "date": "",
+ "what": "Commit P of build step 2 (ORDER step 14; the interface sheet 6; rows 94, 117, 127, 136, 138-140 and 146) makes the preview horizon H a parameter of the environment, takes fingerprint schema 4 (transmission, the training and scoring backends with their contract, the protocol, preview_h_s and reward_knock among the FATAL fields), reads engines.trainable() from the committed records, and gives the reward its knock option. It edits two files of PLANT_CODE, engine_env.py and engines.py, so the B58's plant_sha moves; nothing it changes is meant to move a number the B58 computes at its defaults (row 94). Before P lands on GRA-test, the B58 built through it has to be X1's plant, the plant of cf43fbb: the same doubles, not the same figures to a tolerance. This page says how that was measured and what came out. results/B58_IDENTITY.json holds every number below, read by make_cert.py from the run groups' records and the runs' own output files; the tools, the plans of the run and the evidence are archived beside it (section 7).",
+ "asked_by": "It answers the interface sheet 6.8 (PLAN.md section 3.6, items 1 to 19 as AMENDMENTS.md amends them, against cf43fbb; commit A's added checks B1-B3, B8, B9, B11, B12, HA.2-HA.11, HP7.1, HP7.6 and HP7.7; test_tit_cap.py and test_preview_horizon.BlindBitForBit, row 138 (4)), as CERT_PLAN_P.md amends commit A's run plan, CERT_PLAN_A.md. Item 20 (L8, training) is pending: it runs on the training device at ORDER step 18 (decision 61), and its record goes to results/B58_IDENTITY/L8_device/ (row 146 (6)).",
+ "results": "cert_results/*.json",
+ "reference": {
+  "rev": "cf43fbb",
+  "tree": "ref",
+  "how": "git archive --format=tar cf43fbb extracted into S/ref and checked against the archive with tar --compare (no content or size difference; p_gate.sh cert-prep, and G1.0 again). Its evidence from commit A's and build step 1's certificates (out/ref's 34 dumps and their logs, L4/ref_*, L5/ref_*, L6's reference dumps made again by run_l6.sh, L7/ref_eval.txt, F11/ref_*, app/ref* and app/refgit_*, suites/ref_*, the lab's reference dump made again) is reused: the reference tree, the interpreter and the reference side of every tool are unchanged (the reference_side_of_the_tools control; G1.7). The reference dumps no archive holds were copied from commit A's own folder, its logs and status checked equal to the archive's first."
+ },
+ "candidate": {
+  "tree": "C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/p_gate/cert/candg",
+  "branch": "detached HEAD at P's candidate commit: the clone candg of the scratch clone build/clone_p, whose branch (p_gate.sh's P_BRANCH) names that commit",
+  "base": "HEAD~1",
+  "manifest_start": "manifest_start_P.txt",
+  "manifest_end": "manifest_end_P.txt",
+  "head_note": "P's candidate commit, made on RV (HEAD~1 here) in a scratch clone, committed and clean, in the place commit A's wp1-work held: REPO's role in every run of this certificate (P_GATE_PLAN.md D1; row 139 (2): every entry-point command in REPO or a git clone). The repository itself held the same tree uncommitted on RV while the roads re-verification ran there (roads_reverify.py check, row 140 (3)). P's own commit, made afterwards in the repository from this tree with the documents, this certificate, its archive and results/EPA_ROADS/reverify.json, is another commit whose code p_gate.sh checks is this commit's (git diff --name-only <this commit> P: documents and those records only). The page names this commit, never P's, which no file can hold before P exists.",
+  "files_changed_declared": [],
+  "files_changed_note": "No file of the clone is meant to change during the run; the start and end manifests are compared (F.1)."
+ },
+ "fingerprints": {
+  "reference": "out/fp_ref.txt",
+  "candidate": "out/P_G1_fp_cand.txt",
+  "candidate_end": "out/P_end_fp_cand.txt"
+ },
+ "previous_certificate": {"git": "HEAD~1:results/B58_IDENTITY.json"},
+ "x1_meta": "runs/extremes_dt1/sighted_seed0/meta.json",
+ "pip_freeze": "pip_freeze_P.txt",
+ "node_versions": "lab/P_G5_versions.txt",
+ "extracts": [
+  {"name": "engine_sha_over_build_step_1_keys", "file": "suites/cand_test_fuel_forms.txt",
+   "pattern": "engine_sha (\\w{16}); without \\[[^\\]]*\\]: (\\w{16})"},
+  {"name": "road_sha", "file": "suites/cand_random_road.txt", "pattern": "road_sha\\s*:?\\s*(\\w{16})"},
+  {"name": "verify_docs", "file": "suites/cand_verify_docs.txt", "pattern": "^(All \\d+ checks pass.*)$"},
+  {"name": "drift_test", "file": "suites/drift_test.txt", "pattern": "^(\\d+ of \\d+ drifts CAUGHT \\(all parts\\).*)$"},
+  {"name": "test_replay_full", "file": "app/cand_test_replay_full.txt", "pattern": "^(\\d+ of \\d+ checks pass.*)$"},
+  {"name": "lab_compare", "file": "lab/compare_P_cand_ref.txt", "pattern": "^(\\d+ leaf values compared.*)$"},
+  {"name": "stated_counts", "file": "suites/P_F_stated_counts.txt", "pattern": "^(HP7\\.6: .*)$"}
+ ],
+ "harness": {"a": "ref", "b": "P_G1_cand", "jobs_file": "tools/jobs_all.txt",
+             "what": "every job of tools/jobs_all.txt: units (L1), every road family and the conditions rollouts (L2), the premise's five rollouts (L3)"},
+ "controls": [
+  {"name": "reference_twice", "a": "ref", "b": "P_G1_ref2", "jobs_file": "tools/jobs_ctl.txt", "expect": "IDENTICAL", "environment": "none (the reference tree run again)", "what": "the reference against a second run of itself", "why_it_can_fail": "a job or a harness that is not deterministic, or a reference dump that is not cf43fbb's, reads DIFFERENT"},
+  {"name": "one_ulp_c_turb", "a": "P_G1_cand", "b": "P_G1_ctl_cturb", "jobs_file": "tools/jobs_ctl.txt", "expect": "DIFFERENT", "environment": "HARNESS_PERTURB=thermal.c_turb", "what": "one ulp on the housing's heat capacity, through the records and engines.get's cache", "why_it_can_fail": "IDENTICAL would mean the field never reached the outputs, so an IDENTICAL level proves nothing about it (mistakes 12 and 25)"},
+  {"name": "one_ulp_car_mass", "a": "P_G1_cand", "b": "P_G1_ctl_mass", "jobs_file": "tools/jobs_ctl.txt", "expect": "DIFFERENT", "environment": "HARNESS_PERTURB=car.mass", "what": "one ulp on the car's mass", "why_it_can_fail": "IDENTICAL would mean the car record does not reach step() (through engine_env.vehicle_for)"},
+  {"name": "one_ulp_afr_st", "a": "P_G1_cand", "b": "P_G1_ctl_afr", "jobs_file": "tools/jobs_units.txt", "expect": "DIFFERENT", "environment": "HARNESS_PERTURB=fuel.afr_st", "what": "one ulp on the fuel's stoichiometric air-fuel ratio (PLAN.md 3.5)", "why_it_can_fail": "IDENTICAL would mean the cycle burns a constant of its own, not the engine's fuel record"},
+  {"name": "one_ulp_lhv", "a": "P_G1_cand", "b": "P_G1_ctl_lhv", "jobs_file": "tools/jobs_units.txt", "expect": "DIFFERENT", "environment": "HARNESS_PERTURB=fuel.lhv_j_per_kg (through engines.with_fuel)", "what": "one ulp on the fuel's heating value, both copies (cycle and thermal network) moved together (PLAN.md 3.5)", "why_it_can_fail": "IDENTICAL, or IDENTICAL thermal keys, would mean the cycle or the network reads a heating value of its own"},
+  {"name": "bind_count_neutral", "a": "ref", "b": "P_G1_bind", "jobs_file": "tools/jobs_quick.txt", "expect": "IDENTICAL", "environment": "HARNESS_BIND_COUNT=1", "what": "amendment B1's pre-check: the bind-count wrapper alone, with the count printed", "why_it_can_fail": "a wrapper that changed step()'s outputs would read DIFFERENT, and its count would then mean nothing"},
+  {"name": "lam_floor_float32_step", "a": "P_G1_cand", "b": "P_G1_ctl_lamf32", "jobs_file": "tools/jobs_ctl_P2.txt", "expect": "DIFFERENT", "environment": "HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1", "what": "amendment B1: the lambda floor moved by one float32 step, at the one job where it binds", "why_it_can_fail": "IDENTICAL would mean the clip does not read the engine's floor; DIFFERENT first at another row than the bind step would mean it differs for another reason"},
+  {"name": "lam_floor_float64_ulp", "a": "P_G1_cand", "b": "P_G1_ctl_lamf64", "jobs_file": "tools/jobs_ctl_P2.txt", "expect": "IDENTICAL", "environment": "HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1", "what": "amendment B1's reason: one float64 ulp on the floor is below float32's resolution", "why_it_can_fail": "DIFFERENT would mean the clip compares in float64, which moves the B58's bits at a binding step (NEP 50; amendment B10)"},
+  {"name": "lam_ceiling_float32_step", "a": "P_G1_cand", "b": "P_G1_ctl_ceilf32", "jobs_file": "tools/jobs_ctl_P2.txt", "expect": "IDENTICAL", "environment": "HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1", "what": "the ceiling moved by one float32 step: no B58 lambda reaches it (at most 1 + ACT_HI[1] = 1.06), so this one cannot show it; test_fuel_forms.py shows it with a ceiling of 1", "why_it_can_fail": "DIFFERENT would mean a lambda reached the ceiling, which the bind count then names"},
+  {"name": "bind_census", "a": "ref", "b": "P_G1_census", "jobs_file": "tools/jobs_census_P2.txt", "expect": "IDENTICAL", "environment": "HARNESS_BIND_COUNT=1", "what": "amendment B1's census, three random-action jobs: the floor binds nowhere else", "why_it_can_fail": "a count other than 0 names another binding step, which a control would have to cover"},
+  {"name": "bind_census_rest", "a": "ref", "b": "P_G1_census_rest", "jobs_file": "tools/jobs_census_P2_rest.txt", "expect": "IDENTICAL", "environment": "HARNESS_BIND_COUNT=1", "what": "the census, the other random-action jobs", "why_it_can_fail": "as above"},
+  {"name": "form_AB_ve_map_0", "a": "ref", "b": "P_G1_ctl_AB0", "jobs_file": "tools/jobs_ctl_P3.txt", "expect": "IDENTICAL", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B;cycle.ve_map=0.0", "what": "amendment B2: form A+B at ve_map 0 gives form A's doubles (inv skipped by design)", "why_it_can_fail": "DIFFERENT would mean the B term adds something other than an exact 0.0"},
+  {"name": "form_ABC_slope_065", "a": "ref", "b": "P_G1_ctl_ABC065", "jobs_file": "tools/jobs_ctl_P3_C.txt", "expect": "IDENTICAL", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65", "what": "amendment B2: form A+B+C at the shared slope 0.65, on a job that runs rich", "why_it_can_fail": "DIFFERENT would mean form C's branch computes the rich efficiency another way"},
+  {"name": "form_ABCD_zeros", "a": "ref", "b": "P_G1_ctl_ABCD0", "jobs_file": "tools/jobs_ctl_P4.txt", "expect": "IDENTICAL", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B+C+D, its terms 0.0, ecu.cam_on=1 (the schedule's twelve fields 0.0)", "what": "amendment B2: form A+B+C+D with zeros", "why_it_can_fail": "DIFFERENT would mean the cam path changes a double with every term at zero"},
+  {"name": "form_D_schedule_ve_cam_0", "a": "ref", "b": "P_G1_ctl_D0", "jobs_file": "tools/jobs_ctl_P4.txt", "expect": "IDENTICAL", "allow_missing": ["inv"], "environment": "HARNESS_SET: form A+B+C+D, cam_c0 10, domain [800, 7000] x [20, 260], clamp [-60, 60], ve_cam 0.0", "what": "amendment B2: a cam off its reference, kept out of the breathing by ve_cam 0", "why_it_can_fail": "DIFFERENT would mean the cam reaches the cycle other than through ve_cam"},
+  {"name": "form_AB_ve_map_1e-4", "a": "P_G1_cand", "b": "P_G1_ctl_ABve", "jobs_file": "tools/jobs_ctl_P3.txt", "expect": "DIFFERENT", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B;cycle.ve_map=1e-4", "what": "amendment B2: a nonzero B term", "why_it_can_fail": "IDENTICAL would mean the B term never reaches the breathing, and the IDENTICAL form controls would prove nothing"},
+  {"name": "form_D_ve_cam_1e-4", "a": "P_G1_cand", "b": "P_G1_ctl_D1e4", "jobs_file": "tools/jobs_ctl_P4.txt", "expect": "DIFFERENT", "allow_missing": ["inv"], "environment": "HARNESS_SET: the same schedule at ve_cam 1e-4", "what": "amendment B2: the cam in the breathing", "why_it_can_fail": "IDENTICAL would mean the ECU's cam never reaches run_cycle"},
+  {"name": "form_ABC_slope_one_ulp", "a": "P_G1_cand", "b": "P_G1_ctl_ABCulp", "jobs_file": "tools/jobs_ctl_P3_C.txt", "expect": "DIFFERENT", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001", "what": "amendment B2: one ulp on the rich slope, visible at lambda 0.95 (predict) and in the rich random-trim episode", "why_it_can_fail": "IDENTICAL would mean form C's slope is not the record's"},
+  {"name": "form_ABC_slope_070", "a": "ref", "b": "P_G1_ctl_C070", "jobs_file": "tools/jobs_ctl_P3_C.txt", "expect": "DIFFERENT", "allow_missing": ["inv"], "environment": "HARNESS_SET=cycle.form=A+B+C;cycle.ce_rich_slope=0.7", "what": "the pre-check of the form C controls: each lists a job the slope reaches", "why_it_can_fail": "IDENTICAL would mean the jobs file holds no rich job, so the form C controls could not fail"},
+  {"name": "reference_side_of_the_tools", "a": "ref", "b": "P_G1_refside", "jobs_file": "tools/jobs_P7.txt", "expect": "IDENTICAL", "environment": "none; the reference tree with the edited harness", "what": "amendment B9: the reference side (NEW False) of the edited harness is the archive's", "why_it_can_fail": "a candidate-side edit that leaked into the reference branch reads DIFFERENT"}
+ ],
+ "value_counts": [
+  {"name": "l6_agents", "what": "four X1 agents on the twenty frozen episodes, the two trees' records", "key": "values",
+   "files": ["cmp/L6_sighted_seed0.json", "cmp/L6_sighted_seed4.json", "cmp/L6_blind_seed2.json", "cmp/L6_blind_seed6.json"]},
+  {"name": "build_dataset_columns", "what": "build_dataset.py on the drives with no derived file", "key": "values",
+   "files": ["F2/cmp.json"]}
+ ],
+ "required": [
+  {"item": "3.6.1", "group": "G1-harness", "asks": "the candidate's schema-4 fingerprint (G1.0) and L1-L3: the harness jobs of jobs_all.txt against cf43fbb's dumps"},
+  {"item": "3.6.2", "group": "G1-harness", "asks": "the controls: build step 1's (the reference twice; one ulp on thermal.c_turb and car.mass) and PLAN.md 3.5's as B1 and B2 amend them"},
+  {"item": "3.6.3", "group": "G2-writers", "asks": "check_premise.py in a copy; results/premise.json unchanged"},
+  {"item": "3.6.4", "group": "G3-roads", "asks": "test_reward.py and --road random in the clone, stdout byte for byte"},
+  {"item": "3.6.5", "group": "G3-roads", "asks": "check_roads.py --road extremes and wideair, the 40 terrain roads, check_random_road.py"},
+  {"item": "3.6.6", "group": "G4-data", "asks": "validate.py in the clone against cf43fbb's printout; validation_table.md does not move"},
+  {"item": "3.6.7", "group": "G2-writers", "asks": "generality_test.py in a copy"},
+  {"item": "3.6.8", "group": "G4-data", "asks": "derive_params.py in a copy, derived_check.py: derived_sha as committed"},
+  {"item": "3.6.9", "group": "G4-data", "asks": "build_dataset with no derived file (bd_dump.py) and new_drive.py on pull01 with the derived file aside"},
+  {"item": "3.6.10", "group": "G6-agents", "asks": "evaluate.py --engine b58 --protocol d2, compared with l7_diff.py; X1's agent refused under d2"},
+  {"item": "3.6.11", "group": "G5-app-lab", "asks": "the app suites in the clone at P's candidate, committed: run_app.sh, run_app_extra.sh, the node tests (app.test_results on P's own commit is the gate's, after the commit: pending below)"},
+  {"item": "3.6.12", "group": "G5-app-lab", "asks": "the learning lab: npm ci, npm run build, its tests, launch.py --no-browser and --check, lab_dump.py and lab_compare.py, and their controls"},
+  {"item": "3.6.13", "group": "G6-agents", "asks": "L6: four X1 agents in both trees, check_l6.sh, and L6's controls"},
+  {"item": "3.6.14", "group": "G6-agents", "asks": "L7: make_meta.py at schema 4, evaluate.py --engine b58, l7_diff.py and l7_expect.py, for sighted_seed0 and blind_seed0 (CERT_PLAN_P.md G6.3)"},
+  {"item": "3.6.15", "group": "G7-suites", "asks": "test_engine_threading alone after the roads check (G7.0), the MY2021 and MY2023 lists (G7.1), and the suites: test_wide_air, test_epa_map (twice), test_plant_guards, random_road.py, fingerprint.py, test_cars, test_trainable, test_fuel_forms, test_carried, test_preview_horizon, test_tit_cap, test_epa_plants (G7.2); the five entry points' --help (G7.3)"},
+  {"item": "3.6.16", "group": "G2-writers", "asks": "make_page.py, model_vs_data.py and substep_fit_check.py before (RV) and after (P), in copies"},
+  {"item": "3.6.17", "group": "G2-writers", "asks": "L9 in a copy: b58_propagation.run() and ecu_shift.run_all() against generator_inputs_sha256"},
+  {"item": "3.6.18", "group": "G7-suites", "asks": "verify_docs.py and run_drift.sh (drift_test.py in parts) in the clone; drift_control.py with the certificate in the repository (p_gate.sh cert-docs, F-certificate)"},
+  {"item": "3.6.19", "group": "F-certificate", "asks": "make_cert.py and make_md.py: the certificate made from the records (the draft p_gate.sh reads), then made again into the repository with the archive by p_gate.sh cert-docs, after commit A's page has moved verbatim to STATE_HISTORY.md (decision 67)"},
+  {"item": "B1", "group": "G1-harness", "asks": "the lam_floor control by a float32 step, DIFFERENT at the binding step, the bind count printed"},
+  {"item": "B2", "group": "G1-harness", "asks": "the form controls through HARNESS_SET, IDENTICAL and DIFFERENT as amended"},
+  {"item": "B3", "group": "G1-harness", "asks": "the harness runs step(): the step jobs among the harness jobs"},
+  {"item": "B8", "group": "G7-suites", "asks": "--help runs of the five entry points naming engines.trainable() on the real tree at P (G7.3); test_trainable.py's refusals with their controls (SummaryDrop, RecordsAbsent, BackendDrop)"},
+  {"item": "B9", "group": "G1-harness", "asks": "every tool edit recorded (TOOL_EDITS.md, commit P), the reference side of the tools unchanged, make_cert.py and make_md.py without --config build step 1's and with commit A's config commit A's (G1.7)"},
+  {"item": "B11", "group": "G7-suites", "asks": "engine_sha over build step 1's key set is build step 1's, with the one-ulp c_turb control (test_fuel_forms.EngineSha)"},
+  {"item": "B12", "group": "G5-app-lab", "asks": "the source-text anchors survive P's edits of engine_env.py: make_page.py builds, the lab's anchors resolve, the lab's node tests pass"},
+  {"item": "HA.2", "group": "G5-app-lab", "asks": "the lab's plant_sha pin (tests/test_catalog.py) is P's B58 plant_sha, and the test holding it passes"},
+  {"item": "HA.3", "group": "G5-app-lab", "asks": "every app suite and the lab on P's candidate"},
+  {"item": "HA.4", "group": "G7-suites", "asks": "CLAUDE.md's re-run rule names engines.py and engine_specs/"},
+  {"item": "HA.5", "group": "G7-suites", "asks": "README.md's layout and full_run.py's list name test_fuel_forms, test_cars, test_carried, test_trainable"},
+  {"item": "HA.6", "group": "G7-suites", "asks": "scipy pinned in requirements.txt, the 'imported by nothing' comment gone"},
+  {"item": "HA.7", "group": "G2-writers", "asks": "the study page built by make_page.py carries the corrected glossary sources"},
+  {"item": "HA.8", "group": "G5-app-lab", "asks": "lab_compare.py: the four intended differences and nothing else; every lab number identical"},
+  {"item": "HA.9", "group": "G1-harness", "asks": "the six cond jobs among the full harness"},
+  {"item": "HA.10", "group": "G7-suites", "asks": "the runs' fingerprints come from the fixed fingerprint._git (test_plant_guards.GitDirtyPlantFiles; git_dirty_plant_files empty)"},
+  {"item": "HA.11", "group": "G7-suites", "asks": "engine_specs/b58.toml cites REFERENCES.md's row by its text, not a line number"},
+  {"item": "HP7.1", "group": "G7-suites", "asks": "every WP1 test file runs: test_carried.py, test_fuel_forms.py, test_cars.py, test_trainable.py"},
+  {"item": "HP7.6", "group": "G7-suites", "asks": "every test count README.md and full_run.py state equals the count its run prints"},
+  {"item": "HP7.7", "group": "G5-app-lab", "asks": "app/static/driver.html's comment: the app suites run on the final tree"},
+  {"item": "R138-4 test_tit_cap", "group": "G7-suites", "asks": "row 138 (4): test_tit_cap.py in the certificate"},
+  {"item": "R138-4 BlindBitForBit", "group": "G7-suites", "asks": "row 138 (4): test_preview_horizon.BlindBitForBit (the blinded arm bit for bit at every H) in the certificate"}
+ ],
+ "pending": [
+  {"item": "3.6.11 (part)", "level": "L5", "asks": "app.test_results again after the commit, on P itself", "why": "P does not exist until p_gate.sh commits it in the repository, so this run comes after the commit, outside this certificate: no run of a commit can be inside the files that commit carries. app.test_results ran on P's candidate commit, in the clone (G5-app-lab), and p_gate.sh runs it again on P's would-be tree committed in a scratch clone (precommit) and on P's own commit (commit), outside these records"},
+  {"item": "3.6.20", "level": "L8", "asks": "L8: train.py, 600 SAC steps, both trees, with the wrapper and perturbed controls", "why": "training runs on the training device only (decision 61), at ORDER step 18; its record goes to results/B58_IDENTITY/L8_device/, a record of its own beside this certificate, never an edit of results/B58_IDENTITY.md (row 146 (6))"}
+ ],
+ "notes": {
+  "nothing_computed_moved": "Every value the harness, L6 and build_dataset compared is meant to be the same double in both trees (the counts are in the verdict line), and every writer's output and every report to equal cf43fbb's; the differences section 5 lists are labels, code hashes, run times and committed files older than the code on both trees.",
+  "why_plant_sha_moves": "plant_sha hashes the code of fingerprint.plant_files('b58') -- plant.py, thermal.py, engine_env.py, derived.py and engines.py -- and the values of the B58's two spec files. P edits engine_env.py (H a parameter, the reward's knock option) and engines.py (trainable() read from the committed records), so plant_sha moves although no computed value is meant to; it names P's plant, which every later step of build step 2 is compared against. fingerprint.py, which P also edits, is not in PLANT_CODE.",
+  "why_engine_sha_does_not_move": "engine_sha hashes every value of the plant as built (engines.engine_sha), and P adds and changes no field of the B58's records: engine_sha is commit A's (a check of section 1), and over build step 1's key set it is still build step 1's (amendment B11).",
+  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2).",
+  "first_run": "The first run of this certificate's groups (7-8 November 2026, 16:08Z to 03:00Z, 39139 s beside the roads check) wrote 101 PASS and 5 FAIL records: G1-harness record 29, G3-roads record 2, G5-app-lab record 10, G7-suites records 12 and 16. All five were defects of the kit's driver (tools/cert_driver_P.sh), not of P: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and three of the five makes exited 1, each only when printing, after writing its JSON: the driver ran them without -X utf8, and commit A's make_cert.py and P's alike stopped printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic text) to a cp1252 stdout. In G5.2 the launcher met its expectation ('is ready', exit 124), and --check ran only as its server stopped: the driver waited for a line launch.py prints to block-buffered stdout, which reaches the file only at the launcher's exit. G3.1 asked the --road random run for the default run's last line; G7.2's parser missed RealTree's ok, printed on a line of its own after RealTree's stderr line; G7.4 grepped one line for a rule that wraps (CLAUDE.md:137-138). The driver was corrected (TOOL_EDITS.md, section 'commit P', its part 'commit P, second edit'), reviewed again, installed on the same S after the roads check ended (TOOL_EDITS.md, section 'commit P, second install'), and G1, G3, G5 and G7 re-run there with cert-recheck: the re-check records say what each re-run found. The five FAIL records stay in this certificate; a re-run PASS record that re-checks one names it (rechecks), and the FAIL gains rechecked_by. The edited checks keep the first run's what and command texts, so that every run of one check is the same check: the re-run records of the checks of G1-harness record 29, G5-app-lab record 10 and G7-suites record 16 therefore carry the first run's command text (python -I -B; once it printed 'is ready'; the one-line grep), and each says in its expected what ran (-X utf8 on the five makes; --check once the server had logged the launcher's GET / with status 200; the rule's line and its continuation), as INTEGRATION.md section 7 does."
+ },
+ "environment": {
+  "interpreter": "C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe, for every run in both trees",
+  "machine": "Windows 11 Home 10.0.26200; 12th Gen Intel Core i9-12900H (14 cores, 20 threads)",
+  "threads": "Every Python process ran with OMP_NUM_THREADS=1 and MKL_NUM_THREADS=1 (L6 also torch.set_num_threads(1)), so how many ran at once changes the time, not a number. The run's groups ran one after another beside the roads re-verification (roads_reverify.py check --jobs 14), which shared the machine with nothing else.",
+  "rule_4": "CLAUDE.md's rule 4 pins Python 3.13.2 and NumPy 2 by requirements-lock.txt (decision 32 replaced 'Python 3.12'); this laptop's venv is that interpreter. L8 runs on the training device (decision 61)."
+ },
+ "not_covered": [
+  "**The training device.** Every run is the interpreter above, on this laptop. L8 runs on the training device at ORDER step 18 (decision 61), and is listed as pending.",
+  "**The precision of some comparisons**, measured in section 2: the per-step comparison against the committed eval_record.npz is float32, training sees float32, and the learning lab's 40-step sessions round one ulp of c_turb away (its relative 1e-9 control shows what it can see). The plant is certified at full precision by L1-L3 and by L6's comparison of the two trees' float64 records.",
+  "**The jobs, not every input.** The harness samples operating points, roads, seeds, airs and policies; the identity holds for the code paths those jobs run, at the defaults: H 30 s and the knock term in, as X1 trained. Other H and the knock term out are P's new options, which the plant's tests and test_preview_horizon.py cover (BlindBitForBit: the blinded arm bit for bit at every H), not the identity levels. No D2 agent is on this machine, so --protocol d2 is scored end to end on the hand-written policies only.",
+  "**The three EPA engines.** Run 2 dropped all three (engines.trainable() is ('b58',) on P's tree); this certificate is the B58's.",
+  "**The four frozen drive-C files** (drive_c_analysis.py, drive_c_rule_numbers.py, drive_c_check.py, test_drive_c_analysis.py) cannot run on GRA-test (build step 1's finding 14; test_engine_threading.FrozenFiles checks it).",
+  "**What this machine lacks**: pwsh (an error each in app.test_agents and app.test_results, skips in app.test_launcher), runs_c4/ (skips in app.test_agents) and any D2 agent.",
+  "**Where the runs ran.** The certificate's runs ran in a git clone at P's candidate commit and in copies of it, never in the repository, which held the same tree uncommitted while the roads re-verification ran there. test_engine_threading.py alone (G7.0) is the exception: p_gate.sh ran it in the repository after the roads check and every other run of this certificate, with P's candidate tree applied uncommitted on RV (its record says so). The clone also held three gitignored local paths copied from the repository before the runs (app/node_modules, app/static/vendor and X1's runs/extremes_dt1/sighted_seed0/meta.json; a G0-prepare record lists them), as commit A's run in the repository had them, so that G5 ran the app's tests commit A's run ran; being ignored, they are in no manifest and in no git status.",
+  "**The certificate is for this tree against cf43fbb.** A new drive re-derives the B58 (data/derived_params.json), and stage C may retune it; either needs a new certificate, and so does a later edit of PLANT_CODE.",
+  "**A check of this page cannot be inside it.** The draft p_gate.sh reads is made from every record; the certificate p_gate.sh cert-docs makes into the repository, with its archive and the drift control on its files, is checked there (cert-docs, precommit), after these records. Anything the run did that its plan did not foresee is in P's session report, not in this config, which was reviewed before the run and not edited after it."
+ ],
+ "page_markers": {
+  "_what": "verify_docs.py markers make_md.py writes above a table (the key: a level, or 'control' for section 2's table), each excusing the one figure it names, in that table only (AUDIT2.md H2-6). Commit A's three, carried: the conditions jobs' names and the build_dataset count read as figures they are not. cert_final_driver_P.sh runs verify_docs.py on the draft in a copy before p_gate.sh cert-docs, so a figure these do not cover is seen before the repository is touched.",
+  "control": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
+  "L2": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
+  "L5": "RETIRED-OK: 11 -- G4-data.json's build_dataset record counts the derivations, one per log, in the form verify_docs.py reads as validate.py's quantities inside their band; this table's validate.py rows are still checked"
+ },
+ "page_text": {
+  "previous_certificate": "commit A's certificate",
+  "plan": "S/CERT_PLAN_P.md, and S/CERT_PLAN_A.md, which it amends",
+  "plan_short": "CERT_PLAN_P.md, amending CERT_PLAN_A.md",
+  "rerun_list": "The interface sheet 6.8: `docs/build_step_2/PLAN.md` section 3.6 as `AMENDMENTS.md` amends it, commit A's added checks, `test_tit_cap.py` and `test_preview_horizon.BlindBitForBit` (row 138 (4)); each answered by the records that name it.",
+  "candidate_base": "RV (HEAD~1)"
+ },
+ "tools_note": "Commit A's tools (its archive, results/B58_IDENTITY/certificate_tools.tar.gz at RV) with every edit TOOL_EDITS.md records in its section 'commit P': -B wherever a tool starts Python, CAND without a default in the shell tools the drivers run, make_meta.py's schema-4 live block, make_cert.py's candidate tree and schema-4 fields, make_md.py's words, l7_expect.py's --agent and --repo, cert_record.py's --rechecks, and the new failing_sets_P.py, stated_counts_P.py, road_json_diff.py (commit A's g3/ copy), cert_driver_P.sh and cert_final_driver_P.sh. The reference side of every tool is unchanged (the reference_side_of_the_tools control), and make_cert.py and make_md.py without --config write build step 1's certificate, and with commit A's config commit A's, as before (G1.7).",
+ "archive_path": "results/B58_IDENTITY/certificate_tools.tar.gz",
+ "reproduce": "reproduce_P.json",
+ "verdict_text": {
+  "pass": "BIT-IDENTICAL at every level run on this machine (pending: L8 on the training device at ORDER step 18, and app.test_results on P itself after the commit)",
+  "fail": "NOT CERTIFIED: see the checks"
+ }
+}
```

### env_P.sh

commit A: no such file (new in P)
commit P: sha256 bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0

```diff
--- commit A: env_P.sh
+++ commit P: env_P.sh
@@ -0,0 +1,45 @@
+#!/usr/bin/env bash
+# env_P.sh -- the variables every command of P's certificate uses (CERT_PLAN_P.md; commit A's env_A.sh as P
+# amends it; build step 2, ORDER step 14). DRAFT of 7 November 2026, not run. Git Bash: `source <S>/env_P.sh`
+# at the top of every block (shell state does not persist between calls). S is this file's own folder.
+#
+# REPO's role -- the candidate every entry point, writer and suite runs in -- is taken by the git clone at P's
+# candidate, CERT_TREE (committed and clean; row 139 (2): every entry-point command in REPO or a git clone),
+# which p_gate.sh exports. The live repository is LIVE_REPO: read for runs/extremes_dt1 (gitignored, so not in
+# the clone: L6 and L7 read X1's agents there by absolute path, as l6_agents.py already does) and never
+# written by the certificate's runs; only F.3 (p_gate.sh cert-docs) writes the certificate's three files there.
+# CAND is the clone. Every archived tool fell back to the live repository's path when CAND was unset; the
+# tools the drivers run (TOOL_EDITS.md, commit P) now stop instead, and a writer still names its copy per call
+# (CAND=$S/candw ...).
+#
+# Exported for the drivers (P_GATE_PLAN.md 5.2, item 1): S and SW; PY; REPO and RW (the clone); LIVE_REPO and
+# LRW; X1_RUNS; CAND; CERT_ROOT (the folder above S: candg, X, and the drivers' scratch outside S); CERT_X (the
+# archive extracted whole, read only); COMMIT_A_S (commit A's own S: its tcl/ lists); P_GATE_OUT (p_gate.sh's
+# out/: RV's base logs, read only); NODE and NPM; the thread and bytecode variables; and rec.
+S=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
+export S
+export SW=$(cygpath -m "$S")                                  # S for Python arguments
+export PY=/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe
+[ -n "${CERT_TREE:-}" ] || { echo "env_P.sh: CERT_TREE is unset (p_gate.sh exports the clone at the candidate)" >&2; return 2 2>/dev/null || exit 2; }
+if [ -n "${CERT_S:-}" ] && [ "$(cd "$CERT_S" 2>/dev/null && pwd)" != "$S" ]; then
+  echo "env_P.sh: sourced from $S, and p_gate.sh's CERT_S is $CERT_S" >&2; return 2 2>/dev/null || exit 2
+fi
+export REPO="$CERT_TREE"                                       # the candidate, the clone (bash paths)
+export RW=$(cygpath -m "$CERT_TREE")                           # the same, for Python arguments
+export LIVE_REPO=/c/Users/badcl/Desktop/GRAD-project           # the live repository: runs/ read, nothing written
+export LRW=C:/Users/badcl/Desktop/GRAD-project
+export X1_RUNS="$LRW/runs/extremes_dt1"                        # X1's agents (L6, L7), by absolute path
+export CAND="$CERT_TREE"                                       # the tools' tree: the clone, never the live one
+export CERT_ROOT=$(dirname "$S")                               # p_gate.sh's GD/cert: S, X and candg live here
+export CERT_X="$CERT_ROOT/X"                                   # the archive extracted whole: read, never run, never packed
+export COMMIT_A_S="${COMMIT_A_S:-/c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2}"
+export P_GATE_OUT="${P_GATE_OUT:-$(dirname "$CERT_ROOT")/out}" # p_gate.sh's G: RV's base logs (base_app_*.log)
+export NODE="${NODE:-$(command -v node 2>/dev/null || echo '/c/Program Files/nodejs/node.exe')}"
+export NPM="${NPM:-$(command -v npm 2>/dev/null || echo '/c/Program Files/nodejs/npm')}"
+export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONIOENCODING=utf-8 PYTHONDONTWRITEBYTECODE=1
+export PIP_DISABLE_PIP_VERSION_CHECK=1
+# -I ignores PYTHONDONTWRITEBYTECODE: every `$PY -I` call of the plan is written `$PY -I -B` (the task's rule:
+# every python call with -B), and every tool that starts python itself passes -B (TOOL_EDITS.md, commit P)
+rec() { "$PY" -I -B "$SW/tools/cert_record.py" "$@"; }        # rec <group> --level ... (cert_record.py)
+[ "$(git -C "$CERT_TREE" rev-parse HEAD 2>/dev/null)" = "${P_CAND:-}" ] \
+  || { echo "env_P.sh: CERT_TREE's HEAD is not P_CAND (${P_CAND:-unset})" >&2; return 2 2>/dev/null || exit 2; }
```

### reproduce_P.json

commit A: no such file (new in P)
commit P: sha256 b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517

```diff
--- commit A: reproduce_P.json
+++ commit P: reproduce_P.json
@@ -0,0 +1,28 @@
+{
+ "_what": "The reproduce block of P's certificate (make_cert.py reads it through cert_P.json's 'reproduce'). Written 7 November 2026 before the run, from the drivers: each step as tools/cert_driver_P.sh and tools/cert_final_driver_P.sh, and p_gate.sh's phases cert-prep, cert, post and cert-docs, run it. Where the run departs from it, P's session report says so.",
+ "conventions": {
+  "S": "the certificate's folder: results/B58_IDENTITY/certificate_tools.tar.gz unpacked anywhere, or p_gate/cert/S of the run. Every tool finds S from its own location, S/tools; env_P.sh sets S from its own.",
+  "env": "export CERT_S=<S> CERT_TREE=<the clone> P_CAND=<the candidate commit> RV_SHA=<its parent>; source S/env_P.sh: PY (the venv's python.exe, Python 3.13.2), OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1, REPO and RW (the clone, bash and Windows form), LIVE_REPO (runs/extremes_dt1 only), CAND (the clone), CERT_ROOT, CERT_X, S and SW, and rec (tools/cert_record.py)",
+  "REPO": "a git clone (git clone --no-hardlinks) of the scratch clone that holds P's candidate commit, checked out detached at it, committed and clean: REPO's role in every run (row 139 (2)); the live repository held the same tree uncommitted on RV while roads_reverify.py check ran there",
+  "REF": "S/ref: git archive cf43fbb, tar --compared; S/refw a copy of it (G4's writers); S/pre git archive c47907b (left unused: item 16 at P compares RV with P); CERT_ROOT/preRV git archive of RV, outside S (item 16's before); out/ref, the label 'ref' every harness comparison names, is the reference run of tools/jobs_all.txt in S/ref, its dumps copied from commit A's S with its logs and status checked equal to the archive's",
+  "copies": "copy_tree.py <clone> S/cand, S/candd, S/candw, S/candt (what a commit of the clone holds), each equal to manifest_start_P.txt: S/cand (G3's road writers, G5's lab build, tests and launcher), S/candd (G4), S/candw (G2's writers and item 16's after), S/candt (L9). S/refw, S/candw, S/candt and S/pre are removed before the archive (make_archive.py's SKIP_DIRS does not name them)",
+  "records": "every check is a record in S/cert_results/<group>.json (cert_record.py); make_cert.py --config S/cert_P.json writes the JSON from them; CERT_PLAN_P.md and CERT_PLAN_A.md give every command with its expected outcome, and the drivers write each expectation into its record",
+  "shell": "Git Bash; tools/*.sh are bash scripts, run with bash, never sourced but env_P.sh"
+ },
+ "steps": [
+  {"step": "G0 prepare (p_gate.sh cert-prep)", "cwd": "the live repository, S", "command": "tar -xzf results/B58_IDENTITY/certificate_tools.tar.gz -C X (every member against archive_members.txt); the tools, plans, configs and the reference evidence copied into S; commit A's out/ref/*.npz and lab/lab_ref_{P4,A}.json copied into S; git archive cf43fbb into S/ref and S/refw, c47907b into S/pre (tar --compare); git clone --no-hardlinks <clone_p> candg, checkout --detach P_CAND; copy_tree.py candg S/{cand,candd,candw,candt}; manifest.py candg S/manifest_start_P.txt; five G0-prepare records"},
+  {"step": "the kit (p_gate.sh cert-kit)", "cwd": "S", "command": "S/tools rebuilt from X, every file of the kit installed over it (tools/*, env_P.sh, cert_P.json, reproduce_P.json), each diff appended to S/TOOL_EDITS.md, section 'commit P'"},
+  {"step": "G1.0 identity and G7.3 --help (p_gate.sh cert)", "cwd": "candg", "command": "python -B fingerprint.py --engine b58 > out/P_G1_fp_cand.txt; python -B engines.py; python -B -m pip freeze > pip_freeze_P.txt; git archive cf43fbb | tar --compare -C S/ref; git status; python -B <f>.py --help for train, train_all, run_phase_d, evaluate, benchmark_training"},
+  {"step": "G1 the harness and its controls (cert_driver_P.sh g1)", "cwd": "S", "command": "python -I -B tools/run_jobs.py candg P_G1_cand tools/jobs_all.txt 6; bash tools/compare_all.sh ref P_G1_cand; python -I -B tools/control_verdict.py ref P_G1_cand tools/jobs_all.txt IDENTICAL; then every control of cert_P.json's controls the same way (run_jobs.py with its HARNESS_* variables, compare_all.sh against its 'a', control_verdict.py), in waves of at most six processes; G1.7: make_cert.py and make_md.py with and without --config in fresh extractions of c47907b's and RV's archives (CERT_ROOT/g17, removed)"},
+  {"step": "G2 the writers, item 16 and L9 (cert_driver_P.sh g2)", "cwd": "S/candw, S/candt, CERT_ROOT/preRV", "command": "CAND=S/candw bash tools/run_writer.sh cand premise results/premise.json check_premise.py; the same for generality_test.py; cd S/candt: python -B -c 'from thresholds import b58_propagation as P; P.run()'; python -B -c 'from thresholds import ecu_shift as U; U.run_all(6)'; python -I -B tools/l9_check.py S/candt candg/results/ENGINE_THRESHOLDS.json --since <start>; item 16: git archive RV into CERT_ROOT/preRV; run_writer.sh for model_vs_data.py, substep_fit_check.py and make_page.py in preRV, then in S/candw; the outputs compared"},
+  {"step": "G3 test_reward.py and the roads (cert_driver_P.sh g3)", "cwd": "candg, S/cand", "command": "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random; CAND=S/cand bash tools/run_writer.sh cand roads_extremes results/training_roads_extremes.json check_roads.py --road extremes; the same for wideair; cd S/cand && python -B check_roads.py (the committed file put back); python -B check_random_road.py; each output against cf43fbb's (and commit A's, for check_random_road.py)"},
+  {"step": "G4 validate, build_dataset, new_drive, derive_params (cert_driver_P.sh g4)", "cwd": "candg, S/candd, S/refw", "command": "cd candg && python -B validate.py; python -I -B tools/bd_dump.py S/candd F2/cand.npz <drives> and S/refw F2/ref.npz <drives>; python -I -B tools/cmp.py F2/ref.npz F2/cand.npz; cd S/candd: new_drive.py on pull01 with data/derived_params.json aside; python -B derive_params.py; python -I -B tools/derived_check.py"},
+  {"step": "G5 the app and the lab (cert_driver_P.sh g5)", "cwd": "candg, S/cand/Explanatory Simulation", "command": "bash tools/run_app.sh cand; bash tools/run_app_extra.sh cand; cd candg/app && node --test --test-reporter=spec static/sim/*.test.mjs; python -I -B tools/failing_sets_P.py against cf43fbb's clone, commit A's runs and RV's base runs; npm ci; npm run build; timeout 300 python -B launch.py --no-browser and python -B launch.py --check; CATALOG_TEST_PYTHON=<PY> node --test --test-reporter=spec src/model/*.test.mjs; python -I -B tools/lab_dump.py S/ref and candg; lab_compare.py; LAB_PERTURB=thermal.c_turb and thermal.c_turb:1e-9"},
+  {"step": "G6 L6, L7 and d2 (cert_driver_P.sh g6)", "cwd": "S, candg, S/ref", "command": "bash tools/run_l6.sh; bash tools/check_l6.sh; HARNESS_PERTURB=<car.mass, thermal.c_turb, car.mass:1e-9, car.mass:1e-6> python -I -B tools/l6_agents.py candg sighted_seed0 ...; l6_check.py; python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/<sighted_seed0|blind_seed0> L7/cand_model/<tag>; cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval[_blind].txt L7/cand_model/<tag>; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0; python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; l7_diff.py and l7_expect.py (--agent blind_seed0); the scratch sighted_seed0 under d2: refused"},
+  {"step": "G7 the suites and the documents (cert_driver_P.sh g7)", "cwd": "candg", "command": "commit A's S/tcl copied, then python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list; one <label> candg python -B <suite>.py -v for test_wide_air, test_epa_map (twice, the second with GRAD_EXTRA_DATA), test_plant_guards, random_road.py, fingerprint.py --engine b58, test_cars, test_trainable, test_fuel_forms, test_carried, test_tit_cap, test_epa_plants, test_preview_horizon; the HA.4, HA.5, HA.6 and HA.11 greps; python -B verify_docs.py; bash tools/run_drift.sh"},
+  {"step": "G7.0 test_engine_threading, alone (p_gate.sh post)", "cwd": "the live repository, P's candidate applied uncommitted on RV", "command": "python -B test_engine_threading.py -v > S/suites/P_test_engine_threading.txt, after the roads check and every run above; git status unchanged after it"},
+  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md (every make with -X utf8, as commit A's F.3: -I ignores PYTHONIOENCODING, and a FAIL record's got may carry a character cp1252 lacks)"},
+  {"step": "F.3 into the repository (p_gate.sh cert-docs)", "cwd": "the live repository", "command": "the draft copied to results/B58_IDENTITY.json and .md; S/refw, candw, candt and pre removed; python -I -B tools/drift_control.py <repo> suites/P_drift_control_with_certificate.txt (a record); python -I -B tools/make_archive.py results/B58_IDENTITY/certificate_tools.tar.gz; python -I -B tools/make_cert.py results/B58_IDENTITY.json <archive> --config cert_P.json; python -I -B tools/make_md.py results/B58_IDENTITY.json results/B58_IDENTITY.md; drift_control.py again; python -B verify_docs.py"},
+  {"step": "not run here", "cwd": "-", "command": "L8 (item 20) on the training device at ORDER step 18; app.test_results on P's own commit (p_gate.sh commit)"}
+ ]
+}
```

### tools/cert_driver_P.sh

commit A: no such file (new in P)
commit P: sha256 17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21

```diff
--- commit A: tools/cert_driver_P.sh
+++ commit P: tools/cert_driver_P.sh
@@ -0,0 +1,1268 @@
+#!/usr/bin/env bash
+# cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
+# 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
+# run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
+# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
+# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
+# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
+# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
+# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
+# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
+# launcher record, HA.4). The edited lines have not run.
+#
+#     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
+#
+# p_gate.sh's phase cert runs it, beside the roads check and nothing else, after its own G1.0 (two records in
+# G1-harness) and G7.3 (one record in G7-suites). It does not repeat G1.0, G7.3 or G7.0 (test_engine_threading,
+# p_gate.sh post). The groups run ONE AT A TIME (the orchestrator's decision, 7 November 2026), in the order
+# G1 G2 G3 G4 G5 G6 G7; inside a group the steps CERT_PLAN_A.md runs together run together, with fewer processes
+# where the plan used 18 or 20 (CERT_PAR_* below), since the check's 14 jobs share the machine.
+#
+# The contract (P_GATE_PLAN.md 5.2):
+#   1. env_P.sh is sourced from CERT_S; the cwd is the clone candg (REPO's role); LIVE_REPO is read for
+#      runs/extremes_dt1 only (and the tools that read committed results there, unchanged by P: l6_check.py,
+#      l6_agents.py's X1 agents, harness.py's x1 jobs).
+#   2. Every entry point, writer and suite runs in the clone or in a copy (S/cand, S/candd, S/candw, S/candt,
+#      S/ref, S/refw, CERT_ROOT/preRV), never in the live repository.
+#   3. Labels and files are P_<group>_...; the tools that name their own files write cand_* (S holds none of
+#      commit A's: cert-prep left them in X). Commit A's candidate evidence that a check compares with is
+#      copied from X into S/commitA/ first (sha256 against the archive's own listing).
+#   4. Every check is one record (rec), PASS only for an output equal to the expected one. A check that could
+#      not run gets no record and a line in S/out/P_driver_report.txt, except G5's npm ci and the lab launcher's
+#      free port, which fail closed (a FAIL record that cert-recheck g5 re-checks; review fixes 3: otherwise 3.6.12
+#      and B12 read as answered with the lab's build, launcher and node tests never run). Each group starts from
+#      none of an earlier run's outputs that its checks count or compare (G1's harness folders, G5's lab dumps,
+#      G6's L6/L7/d2 outputs): a CERT_ONLY re-run is judged on its own files (review fixes 3). The driver exits 0 when every record
+#      was written, whatever their verdicts (make_cert.py judges them); 3 when cert_record.py refused a record
+#      or a precondition of its own failed, 2 when it could not start.
+#   5. Expected outcomes are CERT_PLAN_A.md's unless CERT_PLAN_P.md amends them; where P moves one that neither
+#      sheet amends (P_GATE_PLAN.md 7.23), the expectation is written here, at the check, before the run, and
+#      INTEGRATION.md lists each.
+# Nothing here writes to the vehicle, trains an agent or runs engine_thresholds.py. No fit runs.
+# No `set -u` and no `set -e`: an unset variable or a failing command must not end the run half-way through
+# the check's window (p_gate.sh's records_fresh refuses a second run on this S); every check reads its own
+# outputs and records what it found.
+
+# ----------------------------------------------------------------------------- start
+[ -n "${CERT_S:-}" ] || { echo "cert_driver_P.sh: CERT_S is unset (p_gate.sh exports it)" >&2; exit 2; }
+# shellcheck source=/dev/null
+source "$CERT_S/env_P.sh" || { echo "cert_driver_P.sh: env_P.sh refused" >&2; exit 2; }
+cd "$REPO" || exit 2
+REPORT="$S/out/P_driver_report.txt"
+RECLOG="$S/out/P_driver_records.log"
+BAD=0
+mkdir -p "$S/out" "$S/cmp" "$S/L4" "$S/L5/backup" "$S/L6" "$S/L7" "$S/L9" "$S/F2" "$S/F11" "$S/app" "$S/lab" \
+         "$S/suites" "$S/cert_out" "$S/commitA" "$S/prep"
+say() { echo "$(date -u +%FT%TZ) $*" | cut -c1-400 | tee -a "$REPORT"; }
+# (review fixes 2, 7 November 2026) The decision is one group at a time (decisions/cert_groups.txt): the driver
+# runs no other way. CERT_ONLY=<g1..g7> runs that one group again (p_gate.sh cert-recheck): commit A's evidence
+# is then checked, not copied again, and CERT_RECHECK_MAP (lines "<what><TAB><group>.json record <n>", written
+# by p_gate.sh from the team's decision file) gives each re-run PASS record whose --what is listed the
+# --rechecks field that pairs it with that earlier FAIL (make_cert.py's _rechecks; cert_record.py --rechecks):
+# one PASS record per line, when several FAILs of the same check are listed (a FAIL a re-run wrote: settle step).
+[ "${CERT_GROUPS:-}" = one-at-a-time ] || { say "REFUSED: CERT_GROUPS is '${CERT_GROUPS:-unset}', not one-at-a-time (decisions/cert_groups.txt)"; exit 2; }
+case "${CERT_ONLY:-}" in
+  "") RUN_GROUPS="g1 g2 g3 g4 g5 g6 g7";;
+  g1|g2|g3|g4|g5|g6|g7) RUN_GROUPS=$CERT_ONLY;;
+  *) say "REFUSED: CERT_ONLY is '$CERT_ONLY', not one of g1 ... g7"; exit 2;;
+esac
+if [ -n "${CERT_RECHECK_MAP:-}" ]; then
+  [ -n "${CERT_ONLY:-}" ] && [ -f "$CERT_RECHECK_MAP" ] || { say "REFUSED: CERT_RECHECK_MAP needs CERT_ONLY and an existing file"; exit 2; }
+fi
+R() {   # one record (env_P.sh's rec); a refusal by cert_record.py is the driver's own refusal
+  # (settle step, 7 November 2026) a re-run PASS of a listed check is written once per map line of its 'what',
+  # each with its own --rechecks: a check that failed on the first run and again on a re-run has two OPEN FAILs,
+  # and make_cert.py's _rechecks pairs one PASS record with one FAIL (cert_record.py --rechecks is one string)
+  local a prev="" w="" v="" rid rids=()
+  if [ -n "${CERT_RECHECK_MAP:-}" ]; then        # a re-run PASS of a listed check names the FAIL(s) it re-checks
+    for a in "$@"; do case "$prev" in --what) w=$a;; --verdict) v=$a;; esac; prev=$a; done
+    [ "$v" = PASS ] && [ -n "$w" ] && mapfile -t rids < <(W="$w" awk -F'\t' '$1 == ENVIRON["W"] && $2 != "" { print $2 }' "$CERT_RECHECK_MAP")
+  fi
+  if [ "${#rids[@]}" -gt 0 ]; then
+    for rid in "${rids[@]}"; do
+      rec "$@" --rechecks "$rid" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; return; }
+      say "re-check: '$w' PASS, recorded with --rechecks '$rid'"
+    done
+  else
+    rec "$@" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; }
+  fi
+}
+verdict() { [ -z "$1" ] && echo PASS || echo FAIL; }     # verdict "$bad": PASS when nothing was found wrong
+lf() { tr -d '\r' < "$1"; }
+ran_of() { lf "$1" 2>/dev/null | grep -aoE '^Ran [0-9]+ tests?' | tail -1 | grep -oE '[0-9]+'; }
+ut_ok() { [ -f "$1" ] && lf "$1" | grep -aqE '^OK( |$)' && [ -n "$(ran_of "$1")" ]; }
+ut_line() { lf "$1" 2>/dev/null | grep -aE '^(Ran |OK|FAILED)' | tr '\n' ' ' | cut -c1-200; }
+exit_of() { lf "$1" 2>/dev/null | grep -aoE '^exit -?[0-9]+' | tail -1 | grep -oE -- '-?[0-9]+$'; }
+fpv() { lf "$1" | awk -v k="$2" '$1 == k { sub(/^ *[^ ]+ */, ""); print; exit }'; }
+secs_since() { echo $(( $(date +%s) - $1 )); }
+same() { cmp -s <(lf "$1") <(lf "$2"); }                 # two text files equal, CR ignored
+nz() { [ -n "${1:-}" ] && echo "$1" || echo 0; }         # a number for --seconds, 0 when none was read
+secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
+blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
+tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
+              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
+              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
+              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
+  lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
+    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
+                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
+                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
+                      return 0 }
+    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
+    pend { if (res($0)) { pend = 0; next } }
+    $0 ~ h { if (!res($0)) pend = 1; next }
+    $0 ~ f { bad++ }
+    END { exit !(ok > 0 && sk == 0 && bad == 0) }'
+}
+cls_ok() {    # cls_ok FILE CLASS: the class's tests all ran ok (bracket expressions: awk -v reads backslashes)
+  tests_ok "$1" "^test_[A-Za-z0-9_]+ [(]([A-Za-z0-9_]+[.])*$2[.]test_[A-Za-z0-9_]+[)]" \
+                "^(FAIL|ERROR): test_[A-Za-z0-9_]+ [(]([A-Za-z0-9_]+[.])*$2[.]"
+}
+
+DRIVER_T0=$(date +%s)
+say "BEGIN cert_driver_P.sh in $(pwd); P_CAND ${P_CAND:0:12}; S $S"
+# preconditions of its own
+RV=$(git -C "$REPO" rev-parse HEAD~1 2>/dev/null)
+[ "$RV" = "${RV_SHA:-}" ] || { say "REFUSED: the clone's HEAD~1 is ${RV:0:12}, not RV ${RV_SHA:-unset}"; exit 3; }
+[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean"; exit 3; }
+for f in tools/run_jobs.py tools/compare_all.sh tools/control_verdict.py tools/cert_record.py tools/make_meta.py \
+         tools/failing_sets_P.py tools/stated_counts_P.py tools/road_json_diff.py tools/l7_expect.py out/ref/_status.txt \
+         out/fp_ref.txt out/P_G1_fp_cand.txt manifest_start_P.txt L7/ref_eval.txt F11/ref_d2.txt lab/lab_ref_A.json; do
+  [ -f "$S/$f" ] || { say "REFUSED: S lacks $f"; exit 3; }
+done
+for d in ref refw pre cand candd candw candt; do [ -d "$S/$d" ] || { say "REFUSED: S lacks the tree $d"; exit 3; }; done
+[ -d "$CERT_X" ] || { say "REFUSED: no archive extraction at $CERT_X"; exit 3; }
+B58_PLANT=$(fpv "$S/out/P_G1_fp_cand.txt" plant_sha)
+B58_ENGINE_SHA=$(fpv "$S/out/P_G1_fp_cand.txt" engine_sha)
+A_B11=$(blob HEAD~1:results/B58_IDENTITY.json | grep -oE '"over_build_step_1_keys": *"[0-9a-f]{16}"' \
+        | head -1 | grep -oE '[0-9a-f]{16}')
+B58_DERIVED=$(fpv "$S/out/P_G1_fp_cand.txt" derived_sha)
+say "G1.0's plant_sha $B58_PLANT, engine_sha $B58_ENGINE_SHA; commit A's B11 reading $A_B11 (read, not typed)"
+[ -n "$B58_PLANT" ] && [ -n "$B58_ENGINE_SHA" ] && [ -n "$A_B11" ] || { say "REFUSED: G1.0's fields or commit A's B11 value unread"; exit 3; }
+# the processes beside the check (numbers do not depend on them: every process is single-threaded)
+PAR_L1=${CERT_PAR_L1:-6}            # CERT_PLAN_A.md G1.1: 6
+L9_PROCS=${CERT_L9_PROCS:-6}        # CERT_PLAN_A.md G2.4: ecu_shift.run_all(20); commit A ran 16, with 25 of 25
+
+# commit A's candidate evidence a check compares with, copied from X into S/commitA (contract 3)
+COPYA=(app/cand_test_replay_full.txt app/cand_test_simulation.txt app/cand_test_agents.txt app/cand_test_results.txt
+       app/cand_lab_tests.txt app/A_G5_lab_tests_pinned.txt app/cand_node_tests.txt
+       lab/A_G5_lab_node_tests.txt lab/A_G5_ref_lab_node_tests.txt lab/compare_A_cand_ref.txt
+       lab/compare_A_ctl_cturb_ulp.txt lab/compare_A_ctl_cturb_1e-9.txt
+       L5/cand_premise_stdout.txt F11/cand_random_road_stdout.txt F11/cand_random_road_stderr.txt
+       cmp/A_G1_ref_vs_cand.txt suites/cand_random_road.txt)
+EXTRA=(test_agent_generations test_agent_sources test_artifact_api test_artifacts test_graphics_revisions
+       test_launcher test_records test_results_comparisons test_results_graphics test_results_records test_results_sets)
+for m in "${EXTRA[@]}"; do COPYA+=("app/cand_$m.txt"); done
+t0=$(date +%s); bad=""
+if [ -n "${CERT_ONLY:-}" ]; then
+  # a re-run of one group: the copies of the first run, checked, not made again (no second G0-prepare record)
+  [ -s "$S/commitA/_sha256.txt" ] && ( cd "$S/commitA" && sha256sum --quiet -c _sha256.txt ) >> "$REPORT" 2>&1 \
+    || { say "REFUSED: S/commitA is not the first run's copy (sha256sum -c commitA/_sha256.txt)"; exit 3; }
+  say "CERT_ONLY=$CERT_ONLY: S/commitA checked against its _sha256.txt; only $CERT_ONLY runs"
+else
+for f in "${COPYA[@]}"; do
+  if [ ! -f "$CERT_X/$f" ]; then bad="$bad $f(not in the archive)"; continue; fi
+  mkdir -p "$S/commitA/$(dirname "$f")"; cp -p "$CERT_X/$f" "$S/commitA/$f"
+  want=$(awk -v f="$f" '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); if (p == f) { print $1; exit } }' "$CERT_X/archive_members.txt")
+  got=$(sha256sum < "$S/commitA/$f" | cut -c1-64)
+  [ "$want" = "$got" ] || bad="$bad $f(sha256)"
+  echo "$got  $f" >> "$S/commitA/_sha256.txt"
+done
+R G0-prepare --level prep --item prep --what "commit A's candidate evidence the driver compares with, copied into S/commitA" \
+  --command "cp -p X/<f> S/commitA/<f> for the ${#COPYA[@]} files of cert_driver_P.sh's COPYA; sha256 of each against X/archive_members.txt" \
+  --cwd S --expected "every file present in the archive and its sha256 the archive's listing's" \
+  --got "$( [ -z "$bad" ] && echo "${#COPYA[@]} files, every sha256 the listing's" || echo "differs:$bad")" \
+  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence commitA/_sha256.txt
+fi
+
+# ============================================================================= G1-harness
+ctl_run() {   # ctl_run LABEL TREE JOBS PAR [NAME=VALUE ...]: run_jobs.py, its print-out in out/LABEL_run.txt
+  local label=$1 tree=$2 jobs=$3 par=$4; shift 4
+  "$PY" -I -B "$SW/tools/run_jobs.py" "$tree" "$label" "$SW/tools/$jobs" "$par" "$@" > "$S/out/${label}_run.txt" 2>&1
+}
+ctl_secs() { nz "$(grep -aoE 'exit 0 in [0-9]+ s' "$S/out/$1_run.txt" 2>/dev/null | grep -oE '[0-9]+ s' | grep -oE '[0-9]+' | tail -1)"; }
+ctl_judge() { # ctl_judge LABEL A EXPECT JOBS ITEMS WHAT ENVTEXT [ALLOW] -- compare_all.sh, control_verdict.py, one record
+  local label=$1 a=$2 expect=$3 jobs=$4 items=$5 what=$6 envt=$7 allow=${8:-} short=${1#P_G1_} st last extra=""
+  bash "$S/tools/compare_all.sh" "$a" "$label" > "$S/cmp/P_G1_${a#P_G1_}_vs_${short}.txt" 2>&1
+  if [ -n "$allow" ]; then
+    "$PY" -I -B "$SW/tools/control_verdict.py" "$a" "$label" "$SW/tools/$jobs" "$expect" --allow-missing "$allow" \
+      > "$S/cmp/P_G1_verdict_${short}.txt" 2>&1; st=$?
+  else
+    "$PY" -I -B "$SW/tools/control_verdict.py" "$a" "$label" "$SW/tools/$jobs" "$expect" > "$S/cmp/P_G1_verdict_${short}.txt" 2>&1; st=$?
+  fi
+  last=$(lf "$S/cmp/P_G1_verdict_${short}.txt" | grep -a '^CONTROL ' | tail -1)
+  CTL_BAD=""; [ "$st" = 0 ] && [[ $last == *": PASS" ]] || CTL_BAD=" control_verdict.py exit $st"
+  R G1-harness --level control --item "$items" --what "$what" \
+    --command "python -I -B tools/run_jobs.py <tree> $label tools/$jobs <n> $envt; bash tools/compare_all.sh $a $label; python -I -B tools/control_verdict.py $a $label tools/$jobs $expect${allow:+ --allow-missing $allow}" \
+    --cwd S --environment "${envt:-none}" --expected "$expect against $a on every job of tools/$jobs${CTL_EXTRA_EXPECT:+; $CTL_EXTRA_EXPECT}" \
+    --got "${last:-no CONTROL line}${CTL_EXTRA_GOT:+; $CTL_EXTRA_GOT}" \
+    --verdict "$(verdict "$CTL_BAD${CTL_EXTRA_BAD:-}")" --seconds "$(ctl_secs "$label")" \
+    --evidence "cmp/P_G1_${a#P_G1_}_vs_${short}.txt" "cmp/P_G1_verdict_${short}.txt" "out/$label/_status.txt"
+  CTL_EXTRA_EXPECT=""; CTL_EXTRA_GOT=""; CTL_EXTRA_BAD=""
+}
+CTL_EXTRA_EXPECT=""; CTL_EXTRA_GOT=""; CTL_EXTRA_BAD=""
+SCHED='ecu.cam_on=1;ecu.cam_c0=10;ecu.cam_rpm_lo=800;ecu.cam_rpm_hi=7000;ecu.cam_map_lo=20;ecu.cam_map_hi=260;ecu.cam_lo=-60;ecu.cam_hi=60'
+SET_AB0='cycle.form=A+B;cycle.ve_map=0.0'
+SET_ABC065='cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65'
+SET_ABCD0='cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.ve_cam=0.0;cycle.cam_ref_deg=0.0;ecu.cam_on=1'
+SET_D0="cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=0.0;$SCHED"
+SET_D1E4="cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=1e-4;$SCHED"
+SET_ABVE='cycle.form=A+B;cycle.ve_map=1e-4'
+SET_ABCULP='cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001'
+SET_C070='cycle.form=A+B+C;cycle.ce_rich_slope=0.7'
+
+g1() {
+  local t0 n bad got sum suma lines bi st f d
+  say "G1 begins"
+  # (review fixes 3, 7 November 2026) every run starts from none of an earlier run's harness outputs: run_jobs.py
+  # appends to out/<label>/_status.txt and compare_all.sh prints one line per status line, so on a CERT_ONLY=g1
+  # re-run the first run's lines would be counted again (2n lines: L1 and every control FAIL), and a job that
+  # crashed would leave the first run's dump to be compared. p_gate.sh cert-recheck has copied the first run's
+  # evidence aside before the re-run. G1.0's own files (out/P_G1_*.txt) are files, not these folders.
+  for d in "$S"/out/P_G1_*/ "$S"/cmp/ref_vs_P_G1_*/ "$S"/cmp/P_G1_cand_vs_P_G1_*/; do [ -d "$d" ] && rm -rf "${d%/}"; done
+  # ---- G1.1 L1-L3: the 34 jobs (CERT_PLAN_A.md G1.1), one wave of PAR_L1
+  t0=$(date +%s)
+  ctl_run P_G1_cand "$RW" jobs_all.txt "$PAR_L1"
+  bash "$S/tools/compare_all.sh" ref P_G1_cand > "$S/cmp/P_G1_ref_vs_cand.txt" 2>&1
+  "$PY" -I -B "$SW/tools/control_verdict.py" ref P_G1_cand "$SW/tools/jobs_all.txt" IDENTICAL > "$S/cmp/P_G1_verdict_cand.txt" 2>&1; st=$?
+  n=$(grep -vcE '^(#|[[:space:]]*$)' "$S/tools/jobs_all.txt")
+  lines=$(grep -ac ' | ' "$S/cmp/P_G1_ref_vs_cand.txt"); bi=$(grep -ac ' | VERDICT: BIT-IDENTICAL (' "$S/cmp/P_G1_ref_vs_cand.txt")
+  sum=$(grep -aoE '\([0-9]+ values in' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -oE '[0-9]+' | awk '{ s += $1 } END { print s + 0 }')
+  suma=$(grep -aoE '\([0-9]+ values in' "$S/commitA/cmp/A_G1_ref_vs_cand.txt" | grep -oE '[0-9]+' | awk '{ s += $1 } END { print s + 0 }')
+  bad=""
+  grep -aq "^DONE P_G1_cand: $n of $n exit 0" "$S/out/P_G1_cand_run.txt" || bad="$bad run($(grep -a '^DONE' "$S/out/P_G1_cand_run.txt"))"
+  [ "$lines" = "$n" ] && [ "$bi" = "$n" ] || bad="$bad $bi of $lines lines BIT-IDENTICAL, $n jobs"
+  [ "$st" = 0 ] || bad="$bad control_verdict.py exit $st"
+  [ "$sum" = "$suma" ] || bad="$bad values $sum, commit A's $suma"
+  R G1-harness --level L1 --item 3.6.1 --what "L1-L3: the $n harness jobs of jobs_all.txt against cf43fbb's dumps" \
+    --command "python -I -B tools/run_jobs.py candg P_G1_cand tools/jobs_all.txt $PAR_L1 > out/P_G1_cand_run.txt; bash tools/compare_all.sh ref P_G1_cand > cmp/P_G1_ref_vs_cand.txt; python -I -B tools/control_verdict.py ref P_G1_cand tools/jobs_all.txt IDENTICAL > cmp/P_G1_verdict_cand.txt" \
+    --cwd S --expected "DONE P_G1_cand: $n of $n exit 0; every line VERDICT: BIT-IDENTICAL; control_verdict PASS; the values compared as many as commit A's comparison (cmp/A_G1_ref_vs_cand.txt: $suma), which the reference dumps fix" \
+    --got "$( [ -z "$bad" ] && echo "$n of $n exit 0, $bi BIT-IDENTICAL, $sum values; $(lf "$S/cmp/P_G1_verdict_cand.txt" | grep -a '^CONTROL' | tail -1)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" \
+    --evidence out/P_G1_cand_run.txt cmp/P_G1_ref_vs_cand.txt cmp/P_G1_verdict_cand.txt out/P_G1_cand/_status.txt
+  bad=""
+  for f in 'extremes:double:12:random' 'terrain:single:11:neutral'; do
+    grep -aqF "$f | VERDICT: BIT-IDENTICAL (" "$S/cmp/P_G1_ref_vs_cand.txt" || bad="$bad $f"
+  done
+  got=$(grep -aE '^(extremes|terrain|wideair|wideseq|cond):' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -avc 'VERDICT: BIT-IDENTICAL (')
+  [ "$got" = 0 ] || bad="$bad $got step-family lines not BIT-IDENTICAL"
+  R G1-harness --level L2 --item B3 --what "the harness runs step(): the step jobs among the $n" \
+    --command "as the L1 record (cmp/P_G1_ref_vs_cand.txt), the step() jobs read off it" --cwd S \
+    --expected "extremes:double:12:random and terrain:single:11:neutral, and every other extremes, terrain, wideair, wideseq and cond job, BIT-IDENTICAL" \
+    --got "$( [ -z "$bad" ] && echo "both named jobs and every step-family job BIT-IDENTICAL" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_ref_vs_cand.txt
+  bad=""; got=$(grep -ac '^cond:' "$S/cmp/P_G1_ref_vs_cand.txt")
+  [ "$got" = 6 ] && [ "$(grep -a '^cond:' "$S/cmp/P_G1_ref_vs_cand.txt" | grep -ac 'VERDICT: BIT-IDENTICAL (')" = 6 ] || bad=" $got cond lines"
+  R G1-harness --level L2 --item HA.9 --what "the six cond jobs among the full harness" \
+    --command "as the L1 record (cmp/P_G1_ref_vs_cand.txt), the cond: lines" --cwd S \
+    --expected "six cond: jobs, each BIT-IDENTICAL" --got "$( [ -z "$bad" ] && echo "six, each BIT-IDENTICAL" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_ref_vs_cand.txt
+
+  # ---- G1.2-G1.6 the controls, in waves of at most six processes (CERT_PLAN_A.md runs them at once)
+  ctl_run P_G1_ref2 "$SW/ref" jobs_ctl.txt 2 &
+  ctl_run P_G1_ctl_cturb "$RW" jobs_ctl.txt 2 HARNESS_PERTURB=thermal.c_turb &
+  ctl_run P_G1_ctl_mass "$RW" jobs_ctl.txt 2 HARNESS_PERTURB=car.mass &
+  wait
+  ctl_run P_G1_ctl_afr "$RW" jobs_units.txt 1 HARNESS_PERTURB=fuel.afr_st &
+  ctl_run P_G1_ctl_lhv "$RW" jobs_units.txt 1 HARNESS_PERTURB=fuel.lhv_j_per_kg &
+  ctl_run P_G1_ctl_divergent "$RW" jobs_units.txt 1 HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg &
+  ctl_run P_G1_bind "$RW" jobs_quick.txt 3 HARNESS_BIND_COUNT=1 &
+  wait
+  ctl_run P_G1_ctl_lamf32 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1 &
+  ctl_run P_G1_ctl_lamf64 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1 &
+  ctl_run P_G1_ctl_ceilf32 "$RW" jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1 &
+  ctl_run P_G1_census "$RW" jobs_census_P2.txt 3 HARNESS_BIND_COUNT=1 &
+  wait
+  ctl_run P_G1_census_rest "$RW" jobs_census_P2_rest.txt 6 HARNESS_BIND_COUNT=1
+  ctl_run P_G1_ctl_AB0 "$RW" jobs_ctl_P3.txt 3 "HARNESS_SET=$SET_AB0" &
+  ctl_run P_G1_ctl_ABC065 "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_ABC065" &
+  wait
+  ctl_run P_G1_ctl_ABCD0 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_ABCD0" &
+  ctl_run P_G1_ctl_D0 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_D0" &
+  wait
+  ctl_run P_G1_ctl_D1e4 "$RW" jobs_ctl_P4.txt 3 "HARNESS_SET=$SET_D1E4" &
+  ctl_run P_G1_ctl_ABve "$RW" jobs_ctl_P3.txt 3 "HARNESS_SET=$SET_ABVE" &
+  wait
+  ctl_run P_G1_ctl_ABCulp "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_ABCULP" &
+  ctl_run P_G1_ctl_C070 "$RW" jobs_ctl_P3_C.txt 3 "HARNESS_SET=$SET_C070" &
+  wait
+  ctl_run P_G1_refside "$SW/ref" jobs_P7.txt 3
+
+  # G1.2 build step 1's controls
+  ctl_judge P_G1_ref2 ref IDENTICAL jobs_ctl.txt 3.6.2 "the reference against a second run of itself" ""
+  ctl_judge P_G1_ctl_cturb P_G1_cand DIFFERENT jobs_ctl.txt 3.6.2 "one ulp on thermal.c_turb (build step 1's control)" HARNESS_PERTURB=thermal.c_turb
+  ctl_judge P_G1_ctl_mass P_G1_cand DIFFERENT jobs_ctl.txt 3.6.2 "one ulp on car.mass (build step 1's control)" HARNESS_PERTURB=car.mass
+  # G1.3 the fuel controls
+  ctl_judge P_G1_ctl_afr P_G1_cand DIFFERENT jobs_units.txt 3.6.2 "one ulp on fuel.afr_st (through engines.with_fuel and _TYPED)" HARNESS_PERTURB=fuel.afr_st
+  ctl_judge P_G1_ctl_lhv P_G1_cand DIFFERENT jobs_units.txt 3.6.2 "one ulp on fuel.lhv_j_per_kg, both copies (engines.with_fuel)" HARNESS_PERTURB=fuel.lhv_j_per_kg
+  # (the thermal_* keys of the lhv control, judged on control_verdict's own line, written as a record of its own)
+  bad=""; got=$(lf "$S/cmp/P_G1_verdict_ctl_lhv.txt" | grep -a '^units |' | grep -aoE 'thermal_[A-Za-z0-9_.]+ \(' | wc -l)
+  [ "$got" -ge 3 ] || bad=" $got thermal_* keys DIFFERENT"
+  R G1-harness --level control --item 3.6.2 --what "the lhv control moves the thermal network's heating value too" \
+    --command "control_verdict.py's units line of P_G1_ctl_lhv (cmp/P_G1_verdict_ctl_lhv.txt)" --cwd S \
+    --environment HARNESS_PERTURB=fuel.lhv_j_per_kg --expected "at least the three thermal_* keys among the DIFFERENT keys (commit A: thermal_60000.0, thermal_800.0 and thermal_None, 34 of 5403 each)" \
+    --got "$( [ -z "$bad" ] && echo "$got thermal_* keys DIFFERENT: $(lf "$S/cmp/P_G1_verdict_ctl_lhv.txt" | grep -a '^units |' | cut -c1-160)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence cmp/P_G1_verdict_ctl_lhv.txt
+  bad=""
+  grep -aq '^DONE P_G1_ctl_divergent: 0 of 1 exit 0' "$S/out/P_G1_ctl_divergent_run.txt" || bad="$bad run($(grep -a '^DONE' "$S/out/P_G1_ctl_divergent_run.txt"))"
+  grep -aq 'the network would burn another fuel than the cycle' "$S/out/P_G1_ctl_divergent/units.log" || bad="$bad no ValueError line"
+  R G1-harness --level control --item 3.6.2 --what "one copy of the LHV moved alone is refused" \
+    --command "python -I -B tools/run_jobs.py candg P_G1_ctl_divergent tools/jobs_units.txt 1 HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg" \
+    --cwd S --environment HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg \
+    --expected "DONE P_G1_ctl_divergent: 0 of 1 exit 0; the log ends in Engine's ValueError: the network would burn another fuel than the cycle" \
+    --got "$( [ -z "$bad" ] && echo "0 of 1 exit 0; $(lf "$S/out/P_G1_ctl_divergent/units.log" | grep -a 'ValueError' | tail -1 | cut -c1-160)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/out/P_G1_ctl_divergent_run.txt")" \
+    --evidence out/P_G1_ctl_divergent_run.txt out/P_G1_ctl_divergent/units.log
+  # G1.4 amendment B1
+  CTL_EXTRA_EXPECT="its count 'floor 1 [780]' in extremes:double:12:random, ceiling 0, terrain 0 and 0"
+  CTL_EXTRA_GOT=$(grep -ah '^BIND COUNT' "$S/out/P_G1_bind/extremes_double_12_random.log" | head -1)
+  grep -aqE '^BIND COUNT over [0-9]+ steps: floor 1 \[780\], ceiling 0 \[\]' "$S/out/P_G1_bind/extremes_double_12_random.log" || CTL_EXTRA_BAD=" the bind count"
+  ctl_judge P_G1_bind ref IDENTICAL jobs_quick.txt "3.6.2, B1" "amendment B1's pre-check: the bind-count wrapper alone, with the count printed" HARNESS_BIND_COUNT=1
+  bash "$S/tools/compare_all.sh" P_G1_cand P_G1_ctl_lamf32 > /dev/null 2>&1     # its JSONs, read before ctl_judge
+  "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); print({k['key']: k['first_index'] for k in c['keys'] if k['status']=='DIFFERENT'})" \
+    "$SW/cmp/P_G1_cand_vs_P_G1_ctl_lamf32/extremes_double_12_random.json" > "$S/out/P_G1_lamf32_first_rows.txt" 2>&1
+  CTL_EXTRA_EXPECT="info, obs, reward and state first differing at row 780, the bind step"; CTL_EXTRA_GOT=$(lf "$S/out/P_G1_lamf32_first_rows.txt" | cut -c1-160)
+  for f in info obs reward state; do grep -aq "'$f': \[780" "$S/out/P_G1_lamf32_first_rows.txt" || CTL_EXTRA_BAD="$CTL_EXTRA_BAD $f"; done
+  ctl_judge P_G1_ctl_lamf32 P_G1_cand DIFFERENT jobs_ctl_P2.txt "3.6.2, B1" "the lambda floor moved by one float32 step, at the one job where it binds" "HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1"
+  ctl_judge P_G1_ctl_lamf64 P_G1_cand IDENTICAL jobs_ctl_P2.txt "3.6.2, B1" "one float64 ulp on the floor is below float32's resolution" "HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1"
+  CTL_EXTRA_EXPECT="ceiling count 0"; grep -aqE 'ceiling 0 \[\]' "$S/out/P_G1_ctl_ceilf32/extremes_double_12_random.log" || CTL_EXTRA_BAD=" the ceiling count"
+  ctl_judge P_G1_ctl_ceilf32 P_G1_cand IDENTICAL jobs_ctl_P2.txt "3.6.2, B1" "the ceiling moved by one float32 step (no B58 lambda reaches it)" "HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1"
+  grep -ah "^BIND" "$S"/out/P_G1_bind/*.log "$S"/out/P_G1_ctl_lamf32/*.log "$S"/out/P_G1_census/*.log "$S"/out/P_G1_census_rest/*.log > "$S/out/P_G1_bind_lines.txt" 2>&1
+  CTL_EXTRA_EXPECT="every BIND COUNT line floor 0 [], ceiling 0 []"
+  got=$(cat "$S"/out/P_G1_census/*.log | grep -a '^BIND COUNT' | grep -avc 'floor 0 \[\], ceiling 0 \[\]'); [ "$got" = 0 ] || CTL_EXTRA_BAD=" $got counts above 0"
+  ctl_judge P_G1_census ref IDENTICAL jobs_census_P2.txt "3.6.2, B1" "amendment B1's census, three random-action jobs: the floor binds nowhere else" HARNESS_BIND_COUNT=1
+  CTL_EXTRA_EXPECT="every BIND COUNT line floor 0 [], ceiling 0 []"
+  got=$(cat "$S"/out/P_G1_census_rest/*.log | grep -a '^BIND COUNT' | grep -avc 'floor 0 \[\], ceiling 0 \[\]'); [ "$got" = 0 ] || CTL_EXTRA_BAD=" $got counts above 0"
+  ctl_judge P_G1_census_rest ref IDENTICAL jobs_census_P2_rest.txt "3.6.2, B1" "the bind census, the other random-action jobs" HARNESS_BIND_COUNT=1
+  # G1.5 amendment B2, the form controls
+  ctl_judge P_G1_ctl_AB0 ref IDENTICAL jobs_ctl_P3.txt "3.6.2, B2" "form A+B at ve_map 0 gives form A's doubles (inv skipped by design)" "HARNESS_SET=$SET_AB0" inv
+  ctl_judge P_G1_ctl_ABC065 ref IDENTICAL jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C at the shared slope 0.65, on a job that runs rich" "HARNESS_SET=$SET_ABC065" inv
+  CTL_EXTRA_EXPECT="its log's CAM ON line 0.0 to 0.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_ABCD0/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
+  grep -aqE '0\.0 to 0\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
+  ctl_judge P_G1_ctl_ABCD0 ref IDENTICAL jobs_ctl_P4.txt "3.6.2, B2" "form A+B+C+D with zeros" "HARNESS_SET=$SET_ABCD0" inv
+  CTL_EXTRA_EXPECT="its log's CAM ON line 10.0 to 10.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_D0/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
+  grep -aqE '10\.0 to 10\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
+  ctl_judge P_G1_ctl_D0 ref IDENTICAL jobs_ctl_P4.txt "3.6.2, B2" "B2's cam schedule (cam 10 deg) at ve_cam 0" "HARNESS_SET=$SET_D0" inv
+  CTL_EXTRA_EXPECT="its log's CAM ON line 10.0 to 10.0 deg"; CTL_EXTRA_GOT=$(cat "$S"/out/P_G1_ctl_D1e4/*.log | grep -a '^CAM ON' | head -1 | cut -c1-120)
+  grep -aqE '10\.0 to 10\.0 deg' <<< "$CTL_EXTRA_GOT" || CTL_EXTRA_BAD=" the CAM ON line"
+  ctl_judge P_G1_ctl_D1e4 P_G1_cand DIFFERENT jobs_ctl_P4.txt "3.6.2, B2" "the cam schedule at ve_cam 1e-4 (the cam reaches the cycle)" "HARNESS_SET=$SET_D1E4" inv
+  ctl_judge P_G1_ctl_ABve P_G1_cand DIFFERENT jobs_ctl_P3.txt "3.6.2, B2" "form A+B at ve_map 1e-4 (the B term reaches the breathing)" "HARNESS_SET=$SET_ABVE" inv
+  ctl_judge P_G1_ctl_ABCulp P_G1_cand DIFFERENT jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C, the slope one ulp above 0.65 (predict at lambda 0.95, the rich episode)" "HARNESS_SET=$SET_ABCULP" inv
+  ctl_judge P_G1_ctl_C070 ref DIFFERENT jobs_ctl_P3_C.txt "3.6.2, B2" "form A+B+C, slope 0.7 (the pre-check: the file has a job the slope reaches)" "HARNESS_SET=$SET_C070" inv
+  # G1.6 the reference side of the tools
+  ( cd "$S" && sha256sum tools/*.py tools/*.sh tools/*.txt ) > "$S/out/P_G1_tool_hashes.txt" 2>&1
+  ctl_judge P_G1_refside ref IDENTICAL jobs_P7.txt "3.6.2, B9" "the reference side of the edited tools (P_G1_refside; out/P_G1_tool_hashes.txt)" ""
+
+  # ---- G1.7 make_cert.py and make_md.py: P's edits leave the reference side and commit A's route as they were
+  g1_7
+  say "G1 ends"
+}
+
+g1_7() {      # B9 (CERT_PLAN_A.md G1.7, carried to P: INTEGRATION.md, "G1.7 at P")
+  # (review fixes 2) make_cert.py takes S from its own path, so G1.7 runs the archived tools inside their own
+  # fresh extraction: the one exception to "no tool runs from inside an extracted archive" (P_GATE_PLAN.md 11.2).
+  # Each extraction is first checked member by member against its own archive_members.txt (as cert-prep checks
+  # X); nothing in it runs unless that check passes; every call runs with -I -B (neither the script's folder nor
+  # the cwd on sys.path) and with the cwd CERT_ROOT, outside the extraction.
+  local T TW t0 bad got st n mb
+  T="$CERT_ROOT/g17"; rm -rf "$T"; mkdir -p "$T/bs1" "$T/a"; TW=$(cygpath -m "$T")
+  t0=$(date +%s)
+  # (a) build step 1's archive (c47907b's), unpacked; its make_cert/make_md and P's, side by side, without --config
+  blob c47907b:results/B58_IDENTITY/certificate_tools.tar.gz > "$T/bs1.tar.gz" && tar -xzf "$T/bs1.tar.gz" -C "$T/bs1"
+  ( cd "$T/bs1" && awk '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); print $1 "  " p }' archive_members.txt | sha256sum --quiet -c - ) \
+    > "$S/out/P_G1_b9_bs1_members.txt" 2>&1; mb=$?
+  echo "members of c47907b's archive against its archive_members.txt: exit $mb ($(grep -c . "$T/bs1/archive_members.txt" 2>/dev/null) listed)" >> "$S/out/P_G1_b9_bs1_members.txt"
+  cp -p "$S/tools/make_cert.py" "$T/bs1/tools/make_cert_P.py"; cp -p "$S/tools/make_md.py" "$T/bs1/tools/make_md_P.py"
+  if [ "$mb" = 0 ]; then
+    ( cd "$CERT_ROOT" || exit 9
+      "$PY" -I -B "$TW/bs1/tools/make_cert.py" "$TW/orig.json" "$TW/bs1.tar.gz"; echo "make_cert exit $?"
+      "$PY" -I -B "$TW/bs1/tools/make_cert_P.py" "$TW/edit.json" "$TW/bs1.tar.gz"; echo "make_cert_P exit $?"
+      "$PY" -I -B "$TW/bs1/tools/make_md.py" "$TW/orig.json" "$TW/orig.md"; echo "make_md exit $?"
+      "$PY" -I -B "$TW/bs1/tools/make_md_P.py" "$TW/orig.json" "$TW/edit.md"; echo "make_md_P exit $?"
+    ) > "$S/out/P_G1_b9_bs1_mode.txt" 2>&1
+  else
+    echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_bs1_members.txt)" > "$S/out/P_G1_b9_bs1_mode.txt"
+  fi
+  blob c47907b:results/B58_IDENTITY.md > "$T/committed_bs1.md"
+  n=$(diff "$T/orig.md" "$T/committed_bs1.md" 2>/dev/null | grep -c '^[<>]')
+  bad=""
+  [ "$mb" = 0 ] || bad="$bad the extraction is not its archive_members.txt"
+  [ "$(grep -c ' exit 0$' "$S/out/P_G1_b9_bs1_mode.txt")" = 4 ] || bad="$bad an exit"
+  cmp -s "$T/orig.json" "$T/edit.json" || bad="$bad the JSONs differ"
+  cmp -s "$T/orig.md" "$T/edit.md" || bad="$bad the pages differ"
+  echo "orig.json vs edit.json: $(cmp -s "$T/orig.json" "$T/edit.json" && echo identical || echo DIFFERENT); orig.md vs edit.md: $(cmp -s "$T/orig.md" "$T/edit.md" && echo identical || echo DIFFERENT); orig.md against c47907b's committed page: $n lines differ" >> "$S/out/P_G1_b9_bs1_mode.txt"
+  R G1-harness --level control --item B9 --what "make_cert.py and make_md.py without --config are build step 1's (P's edits)" \
+    --command "T=CERT_ROOT/g17: git show c47907b:results/B58_IDENTITY/certificate_tools.tar.gz unpacked into T/bs1, every member checked against its archive_members.txt (sha256sum -c) before anything in it runs; S/tools/make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py T/orig.json <archive>; make_cert_P.py T/edit.json <archive>; make_md.py T/orig.json T/orig.md; make_md_P.py T/orig.json T/edit.md; cmp; diff T/orig.md against c47907b's results/B58_IDENTITY.md; T removed" \
+    --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/bs1, removed afterwards)" \
+    --expected "the extraction equal to its own archive_members.txt; four exit 0; the two JSONs byte-identical and the two pages byte-identical; the lines in which the page differs from build step 1's committed page are counted, not judged (commit A found line 30 only, HEAD and the cf43fbb tar's sha256; the repository's committed files have moved since)" \
+    --got "$( [ -z "$bad" ] && echo "the extraction is its listing; four exit 0; JSONs and pages byte-identical; $n lines differ from the committed page" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_bs1_mode.txt out/P_G1_b9_bs1_members.txt
+  # (b) commit A's archive (RV's), unpacked: commit A's tools and P's on commit A's own config and records
+  t0=$(date +%s)
+  blob HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz > "$T/a.tar.gz" && tar -xzf "$T/a.tar.gz" -C "$T/a"
+  ( cd "$T/a" && awk '{ p = $0; sub(/^[0-9a-f]+ +[0-9]+  /, "", p); print $1 "  " p }' archive_members.txt | sha256sum --quiet -c - ) \
+    > "$S/out/P_G1_b9_commitA_members.txt" 2>&1; mb=$?
+  echo "members of commit A's archive (RV's) against its archive_members.txt: exit $mb ($(grep -c . "$T/a/archive_members.txt" 2>/dev/null) listed)" >> "$S/out/P_G1_b9_commitA_members.txt"
+  cp -p "$S/tools/make_cert.py" "$T/a/tools/make_cert_P.py"; cp -p "$S/tools/make_md.py" "$T/a/tools/make_md_P.py"
+  if [ "$mb" = 0 ]; then
+    ( cd "$CERT_ROOT" || exit 9
+      "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
+        "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
+      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
+      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
+      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
+    ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
+  else
+    echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
+    : > "$S/out/P_G1_b9_ctl_config.txt"
+  fi
+  bad=""
+  [ "$mb" = 0 ] || bad="$bad the extraction is not its archive_members.txt"
+  [ "$(grep -c ' exit 0$' "$S/out/P_G1_b9_commitA_mode.txt")" = 5 ] || bad="$bad an exit"
+  cmp -s "$T/a_orig.json" "$T/a_edit.json" || bad="$bad the JSONs differ"
+  cmp -s "$T/a_orig.md" "$T/a_edit.md" || bad="$bad the pages differ"
+  R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
+    --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
+    --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
+    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+    --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
+  bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
+  cmp -s "$T/a_orig.json" "$T/a_ctl.json" && bad="$bad the JSON did not move"
+  [ "$got" = "$P_CAND" ] || bad="$bad candidate.head ${got:0:12}"
+  R G1-harness --level control --item B9 --what "the control of the two above: make_cert_P.py asks git in the configured tree" \
+    --command "make_cert_P.py T/a_ctl.json --config T/a/cert_A_ctl_tree.json (commit A's config with candidate.tree = the clone candg)" \
+    --cwd "CERT_ROOT/g17 (removed afterwards)" --expected "the JSON differs from T/a_orig.json, and its candidate.head is P's candidate $P_CAND" \
+    --got "$( [ -z "$bad" ] && echo "differs; candidate.head $got" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_ctl_config.txt
+  rm -rf "$T"
+}
+
+# ============================================================================= G2-writers
+g2() {
+  local t0 t1 bad got since rc1 rc2 d
+  say "G2 begins"
+  t0=$(date +%s)
+  # G2.1 and G2.2 at once (two files), G2.4 beside them in its own copy
+  ( CAND="$S/candw" bash "$S/tools/run_writer.sh" cand premise results/premise.json check_premise.py > "$S/L5/P_G2_premise_run.txt" 2>&1 ) &
+  ( CAND="$S/candw" bash "$S/tools/run_writer.sh" cand generality results/generality.json generality_test.py > "$S/L5/P_G2_generality_run.txt" 2>&1 ) &
+  (
+    since=$(date +%s); echo "$since" > "$S/L9/P_G2_since.txt"
+    s=$(date +%s); ( cd "$S/candt" && "$PY" -B -c "from thresholds import b58_propagation as P; P.run()" ) > "$S/L9/P_G2_b58_propagation.txt" 2>&1
+    echo "exit $? in $(( $(date +%s) - s )) s" >> "$S/L9/P_G2_b58_propagation.txt"
+    s=$(date +%s); ( cd "$S/candt" && "$PY" -B -c "from thresholds import ecu_shift as U; U.run_all($L9_PROCS)" ) > "$S/L9/P_G2_ecu_shift.txt" 2>&1
+    echo "exit $? in $(( $(date +%s) - s )) s" >> "$S/L9/P_G2_ecu_shift.txt"
+    "$PY" -I -B "$SW/tools/l9_check.py" "$SW/candt" "$RW/results/ENGINE_THRESHOLDS.json" --since "$since" --json "$SW/L9/P_G2_l9_check.json" > "$S/L9/P_G2_l9_check.txt" 2>&1
+    echo "l9_check exit $?" >> "$S/L9/P_G2_l9_check.txt"; echo "$(( $(date +%s) - since ))" > "$S/L9/P_G2_seconds.txt"
+  ) &
+  wait
+  # G2.1 check_premise.py (L3, 3.6.3)
+  bad=""
+  grep -aqE '^exit 0 in [0-9]+ s; results/premise.json .*\(UNCHANGED\)' "$S/L5/cand_premise_exit.txt" || bad="$bad $(cat "$S/L5/cand_premise_exit.txt" 2>/dev/null | cut -c1-120)"
+  cmp -s "$S/L5/cand_premise_OUT_premise.json" "$S/L5/ref_premise_OUT_premise.json" || bad="$bad OUT against cf43fbb's"
+  cmp -s "$S/L5/cand_premise_OUT_premise.json" "$REPO/results/premise.json" || bad="$bad OUT against the committed file"
+  same "$S/L5/cand_premise_stdout.txt" "$S/commitA/L5/cand_premise_stdout.txt" || bad="$bad stdout against commit A's candidate's"
+  [ ! -s "$S/L5/cand_premise_stderr.txt" ] || bad="$bad stderr"
+  diff "$S/L5/ref_premise_stdout.txt" "$S/L5/cand_premise_stdout.txt" > "$S/L5/P_G2_premise_stdout_diff.txt" 2>&1
+  R G2-writers --level L3 --item 3.6.3 --what "check_premise.py in a copy" \
+    --command "CAND=S/candw bash tools/run_writer.sh cand premise results/premise.json check_premise.py; cmp OUT with L5/ref_premise_OUT_premise.json and with candg's results/premise.json; the stdout against commit A's candidate's (commitA/L5/cand_premise_stdout.txt) and diffed with cf43fbb's" \
+    --cwd S/candw --expected "exit 0, results/premise.json UNCHANGED; the output byte-identical to cf43fbb's and to the committed file; stdout byte-identical to commit A's candidate's, which differs from cf43fbb's by the one line 'plant: b58b30o1/a90-supra-zf8hp51' (build step 1's difference); stderr empty" \
+    --got "$( [ -z "$bad" ] && echo "as expected; the stdout's difference from cf43fbb's: $(lf "$S/L5/P_G2_premise_stdout_diff.txt" | tr '\n' ' ' | cut -c1-120)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/L5/cand_premise_exit.txt")" \
+    --difference "check_premise.py's stdout gains the line 'plant: b58b30o1/a90-supra-zf8hp51' (the candidate names its engine), as on commit A; results/premise.json byte-identical" \
+    --evidence L5/cand_premise_exit.txt L5/cand_premise_stdout.txt L5/cand_premise_stderr.txt L5/P_G2_premise_stdout_diff.txt
+  # G2.2 generality_test.py (L5, 3.6.7)
+  bad=""
+  grep -aqE '^exit 0 in [0-9]+ s; results/generality.json .*\(UNCHANGED\)' "$S/L5/cand_generality_exit.txt" || bad="$bad $(cat "$S/L5/cand_generality_exit.txt" 2>/dev/null | cut -c1-120)"
+  cmp -s "$S/L5/cand_generality_OUT_generality.json" "$S/L5/ref_generality_OUT_generality.json" || bad="$bad OUT against cf43fbb's"
+  cmp -s "$S/L5/cand_generality_OUT_generality.json" "$REPO/results/generality.json" || bad="$bad OUT against the committed file"
+  same "$S/L5/cand_generality_stdout.txt" "$S/L5/ref_generality_stdout.txt" || bad="$bad stdout"
+  R G2-writers --level L5 --item 3.6.7 --what "generality_test.py in a copy" \
+    --command "CAND=S/candw bash tools/run_writer.sh cand generality results/generality.json generality_test.py; cmp OUT with L5/ref_generality_OUT_generality.json and candg's results/generality.json; the stdouts compared" \
+    --cwd S/candw --expected "exit 0, UNCHANGED; the output byte-identical to cf43fbb's and to the committed file; stdout identical to cf43fbb's" \
+    --got "$( [ -z "$bad" ] && echo "as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_in "$S/L5/cand_generality_exit.txt")" \
+    --evidence L5/cand_generality_exit.txt L5/cand_generality_stdout.txt L5/cand_generality_stderr.txt
+  # G2.4 L9 (3.6.17)
+  bad=""
+  [ "$(exit_of "$S/L9/P_G2_b58_propagation.txt")" = 0 ] || bad="$bad b58_propagation"
+  [ "$(exit_of "$S/L9/P_G2_ecu_shift.txt")" = 0 ] || bad="$bad ecu_shift"
+  got=$(lf "$S/L9/P_G2_l9_check.txt" | grep -a '^L9: ' | tail -1)
+  [[ $got == *"-> PASS" ]] && grep -aq '^l9_check exit 0' "$S/L9/P_G2_l9_check.txt" || bad="$bad l9_check"
+  R G2-writers --level L9 --item 3.6.17 --what "L9: the contract's B58 steps re-made in a copy (never engine_thresholds.py)" \
+    --command "cd S/candt: python -B -c 'from thresholds import b58_propagation as P; P.run()'; python -B -c 'from thresholds import ecu_shift as U; U.run_all($L9_PROCS)'; python -I -B tools/l9_check.py S/candt candg/results/ENGINE_THRESHOLDS.json --since <start> --json L9/P_G2_l9_check.json" \
+    --cwd S/candt --environment "ecu_shift.run_all($L9_PROCS): CERT_PLAN_A.md's 20 processes lowered beside the roads check; commit A ran 16 with 25 of 25" \
+    --expected "both exit 0; 'L9: N of N step outputs equal the contract's generator_inputs_sha256 and were rewritten after <since> -> PASS' (N the contract's own count; commit A: 25)" \
+    --got "$( [ -z "$bad" ] && echo "$got" || echo "differs:$bad; ${got:-no L9 line}")" --verdict "$(verdict "$bad")" \
+    --seconds "$(nz "$(cat "$S/L9/P_G2_seconds.txt" 2>/dev/null)")" \
+    --evidence L9/P_G2_b58_propagation.txt L9/P_G2_ecu_shift.txt L9/P_G2_l9_check.txt L9/P_G2_l9_check.json L9/P_G2_since.txt
+  # G2.3 item 16, before (RV) and after (P): CERT_PLAN_A.md's three scripts (INTEGRATION.md, "item 16 at P")
+  t1=$(date +%s); d="$CERT_ROOT/preRV"; rm -rf "$d"; mkdir -p "$d"
+  git -C "$REPO" archive --format=tar "$RV" | tar -x -C "$d"
+  git -C "$REPO" archive --format=tar "$RV" | tar --compare -C "$d" 2>&1 | grep -v -E 'Mode differs|Uid differs|Gid differs|Mod time differs' > "$S/prep/P_G2_preRV_tar_compare.txt"
+  bad=""; [ ! -s "$S/prep/P_G2_preRV_tar_compare.txt" ] || bad=" tar --compare"
+  R G2-writers --level prep --item prep --what "item 16's 'before' tree: git archive of RV, outside S" \
+    --command "git -C candg archive --format=tar HEAD~1 (RV $RV) | tar -x -C CERT_ROOT/preRV; the same | tar --compare (mode, uid, gid, mtime lines dropped)" \
+    --cwd CERT_ROOT/preRV --expected "no content or size difference" --got "$( [ -z "$bad" ] && echo none || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence prep/P_G2_preRV_tar_compare.txt
+  for t in pre candw; do
+    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
+    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_mvd" results/model_vs_data.json model_vs_data.py > /dev/null 2>&1
+  done
+  bad=""
+  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_mvd_exit.txt" || bad="$bad $t exit"; done
+  cmp -s "$S/L5/cand_P16pre_mvd_OUT_model_vs_data.json" "$S/L5/cand_P16candw_mvd_OUT_model_vs_data.json" || bad="$bad before and after differ"
+  got=$(cmp -s "$S/L5/cand_P16candw_mvd_OUT_model_vs_data.json" "$REPO/results/model_vs_data.json" && echo "equal to the committed file" || echo "unlike the committed file (both trees alike: a stale committed file, not P's)")
+  R G2-writers --level L5 --item "3.6.16, B12" --what "item 16: model_vs_data.py before (RV) and after (P), in copies" \
+    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_mvd results/model_vs_data.json model_vs_data.py; cmp the two outputs; cmp the candidate's with the committed file" \
+    --cwd "CERT_ROOT/preRV, S/candw" --expected "both exit 0; results/model_vs_data.json byte-identical before and after; against the committed file: recorded, not judged" \
+    --got "$( [ -z "$bad" ] && echo "byte-identical; $got" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence L5/cand_P16pre_mvd_exit.txt L5/cand_P16candw_mvd_exit.txt L5/cand_P16pre_mvd_stdout.txt L5/cand_P16candw_mvd_stdout.txt
+  t1=$(date +%s)
+  for t in pre candw; do
+    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
+    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_substep" results/substep_fit_check.json substep_fit_check.py > /dev/null 2>&1
+  done
+  "$PY" -I -B -c "import json,sys; a,b=(json.load(open(f,encoding='utf-8')) for f in sys.argv[1:3]); [d.pop('seconds',None) for d in (a,b)]; print('EQUAL apart from seconds' if a==b else 'DIFFERENT'); sys.exit(a!=b)" \
+    "$SW/L5/cand_P16pre_substep_OUT_substep_fit_check.json" "$SW/L5/cand_P16candw_substep_OUT_substep_fit_check.json" > "$S/L5/P_G2_substep_compare.txt" 2>&1; rc1=$?
+  bad=""
+  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_substep_exit.txt" || bad="$bad $t exit"; done
+  [ "$rc1" = 0 ] || bad="$bad $(head -1 "$S/L5/P_G2_substep_compare.txt")"
+  R G2-writers --level L5 --item "3.6.16, B12" --what "item 16: substep_fit_check.py before (RV) and after (P), in copies" \
+    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_substep results/substep_fit_check.json substep_fit_check.py; the two JSONs compared with 'seconds' dropped" \
+    --cwd "CERT_ROOT/preRV, S/candw" --expected "both exit 0; the two results equal apart from 'seconds'" \
+    --got "$( [ -z "$bad" ] && echo "EQUAL apart from seconds" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence L5/P_G2_substep_compare.txt L5/cand_P16pre_substep_stdout.txt L5/cand_P16candw_substep_stdout.txt
+  t1=$(date +%s)
+  for t in pre candw; do
+    local tree; [ $t = pre ] && tree="$d" || tree="$S/candw"
+    CAND="$tree" bash "$S/tools/run_writer.sh" cand "P16${t}_page" results/page/index.html make_page.py > /dev/null 2>&1
+  done
+  "$PY" -I -B -c "import difflib,sys; a,b=(open(f,encoding='utf-8').read().splitlines() for f in sys.argv[1:3]); d=[l[:300] for l in difflib.unified_diff(a,b,'RV','P',lineterm='',n=0)]; print(len(d),'diff lines'); print(*d,sep='\n'); sys.exit(1 if d else 0)" \
+    "$SW/L5/cand_P16pre_page_OUT_index.html" "$SW/L5/cand_P16candw_page_OUT_index.html" > "$S/L5/P_G2_page_diff.txt" 2>&1; rc2=$?
+  bad=""
+  for t in pre candw; do grep -aq '^exit 0 ' "$S/L5/cand_P16${t}_page_exit.txt" || bad="$bad $t exit"; done
+  [ "$rc2" = 0 ] || bad="$bad $(head -1 "$S/L5/P_G2_page_diff.txt")"
+  for got in 'engines.DamageCal.turb_knee_k' 'engines.Fuel.afr_st'; do
+    grep -aqF "$got" "$S/L5/cand_P16candw_page_OUT_index.html" || bad="$bad no '$got' (HA.7)"
+  done
+  R G2-writers --level L5 --item "3.6.16, HA.7, B12" --what "item 16: the study page built before (RV) and after (P), in copies" \
+    --command "for t in CERT_ROOT/preRV S/candw: CAND=<t> bash tools/run_writer.sh cand P16<t>_page results/page/index.html make_page.py; difflib of the two pages (L5/P_G2_page_diff.txt); grep the candidate's page for commit A's two glossary sources" \
+    --cwd "CERT_ROOT/preRV, S/candw" \
+    --expected "both exit 0 (make_page.py's _src and glossary() stop a build whose anchored text is gone: B12); the two pages identical line for line (a build date across midnight would read as a difference, to be read); HA.7: the candidate's page carries engines.DamageCal.turb_knee_k and engines.Fuel.afr_st" \
+    --got "$( [ -z "$bad" ] && echo "both exit 0; 0 diff lines; both glossary sources present" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_since "$t1")" --evidence L5/P_G2_page_diff.txt L5/cand_P16pre_page_exit.txt L5/cand_P16candw_page_exit.txt
+  rm -rf "$d"
+  say "G2 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= G3-roads
+g3() {
+  local t0 t1 bad got diffc want
+  say "G3 begins"; t0=$(date +%s)
+  t1=$(date +%s); bad=""
+  ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
+  R G3-roads --level identity --item prep --what "S/cand equals the start manifest before G3's writers" \
+    --command "cd S/cand && sha256sum -c --quiet manifest_start_P.txt" --cwd S/cand --expected "every file equal" \
+    --got "$( [ -z "$bad" ] && echo "every file equal" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence prep/P_G3_cand_before.txt
+  # G3.1 test_reward.py in the clone, beside the roads (L4)
+  ( bash "$S/tools/run_l4.sh" cand > "$S/L4/P_G3_run_l4.txt" 2>&1 ) &
+  ( bash "$S/tools/run_l4.sh" cand --road random > "$S/L4/P_G3_run_l4_random.txt" 2>&1 ) &
+  # G3.2 the roads in S/cand, one after another (each up to 18 workers)
+  CAND="$S/cand" bash "$S/tools/run_writer.sh" cand roads_extremes results/training_roads_extremes.json check_roads.py --road extremes > /dev/null 2>&1
+  CAND="$S/cand" bash "$S/tools/run_writer.sh" cand roads_wideair results/training_roads_wideair.json check_roads.py --road wideair > /dev/null 2>&1
+  ( cd "$S/cand" && cp -p results/training_roads.json "$S/F11/cand_training_roads_committed.json" && s=$(date +%s) \
+    && "$PY" -B check_roads.py > "$S/F11/cand_roads_terrain_stdout.txt" 2> "$S/F11/cand_roads_terrain_stderr.txt"; \
+    echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_roads_terrain_exit.txt"; \
+    cp -p results/training_roads.json "$S/F11/cand_roads_terrain_OUT_training_roads.json"; \
+    cp -p "$S/F11/cand_training_roads_committed.json" results/training_roads.json )
+  ( cd "$S/cand" && s=$(date +%s) && "$PY" -B check_random_road.py > "$S/F11/cand_random_road_stdout.txt" 2> "$S/F11/cand_random_road_stderr.txt"; \
+    echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
+  wait
+  # G3.1's record
+  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
+  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
+  bad=""
+  for t in "" _random; do
+    case "$t" in
+      "")      want="All checks pass. The reward is safe to train against.";;
+      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
+    esac
+    grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
+    cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
+    [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
+    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
+  done
+  R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
+    --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
+    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
+    --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
+    --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
+  # G3.2's records
+  local r
+  for r in extremes wideair; do
+    bad=""
+    grep -aq '^exit 0 ' "$S/L5/cand_roads_${r}_exit.txt" || bad="$bad exit"
+    cmp -s "$S/L5/cand_roads_${r}_OUT_training_roads_${r}.json" "$S/L5/ref_roads_${r}_OUT_training_roads_${r}.json" || bad="$bad OUT"
+    cmp -s "$S/L5/cand_roads_${r}_stdout.txt" "$S/L5/ref_roads_${r}_stdout.txt" || bad="$bad stdout"
+    "$PY" -I -B "$SW/tools/road_json_diff.py" "$RW/results/training_roads_${r}.json" "$SW/L5/cand_roads_${r}_OUT_training_roads_${r}.json" \
+      --json "$SW/L5/P_G3_roads_${r}_vs_committed.json" > "$S/L5/P_G3_roads_${r}_vs_committed.txt" 2>&1
+    diffc=$(lf "$S/L5/P_G3_roads_${r}_vs_committed.txt" | tr '\n' ' ' | cut -c1-300)
+    R G3-roads --level L5 --item 3.6.5 --what "check_roads.py --road $r, the candidate against cf43fbb" \
+      --command "CAND=S/cand bash tools/run_writer.sh cand roads_$r results/training_roads_$r.json check_roads.py --road $r; cmp OUT and stdout with L5/ref_roads_${r}_*; road_json_diff.py candg's committed file against the OUT" \
+      --cwd S/cand --expected "exit 0; the output and the stdout byte-identical to cf43fbb's ($( [ $r = extremes ] && echo "baseline past 850 C: 10 of 40 roads" || echo "2 of 40 roads")); the comparison with the committed file recorded as a difference, not judged" \
+      --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/L5/cand_roads_${r}_stdout.txt" | grep -a 'baseline past' | tail -1 | cut -c1-80)" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/L5/cand_roads_${r}_exit.txt")" \
+      --difference "results/training_roads_$r.json, committed, against the file both trees write: $diffc" \
+      --evidence "L5/cand_roads_${r}_exit.txt" "L5/cand_roads_${r}_stdout.txt" "L5/P_G3_roads_${r}_vs_committed.txt"
+  done
+  bad=""
+  grep -aq '^exit 0 ' "$S/F11/cand_roads_terrain_exit.txt" || bad="$bad exit"
+  cmp -s "$S/F11/cand_roads_terrain_OUT_training_roads.json" "$S/F11/ref_roads_terrain_OUT_training_roads.json" || bad="$bad OUT"
+  cmp -s "$S/F11/cand_roads_terrain_stdout.txt" "$S/F11/ref_roads_terrain_stdout.txt" || bad="$bad stdout"
+  cmp -s "$S/F11/cand_training_roads_committed.json" "$S/cand/results/training_roads.json" || bad="$bad the copy's committed file not restored"
+  "$PY" -I -B "$SW/tools/road_json_diff.py" "$RW/results/training_roads.json" "$SW/F11/cand_roads_terrain_OUT_training_roads.json" \
+    --json "$SW/F11/P_G3_terrain_vs_committed.json" > "$S/F11/P_G3_terrain_vs_committed.txt" 2>&1
+  diffc=$(lf "$S/F11/P_G3_terrain_vs_committed.txt" | tr '\n' ' ' | cut -c1-300)
+  R G3-roads --level L5 --item 3.6.5 --what "check_roads.py, the 40 terrain roads (finding 11), the candidate against cf43fbb" \
+    --command "cd S/cand && python -B check_roads.py (the copy's committed results/training_roads.json kept aside and put back); cmp OUT and stdout with F11/ref_roads_terrain_*; road_json_diff.py candg's committed file against the OUT" \
+    --cwd S/cand --expected "exit 0; the output and the stdout byte-identical to cf43fbb's (baseline past 850 C: 14 of 40 roads); the committed file, stale since 75ca65f (build step 1's finding 13, for main), recorded as a difference" \
+    --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/F11/cand_roads_terrain_stdout.txt" | grep -a 'baseline past' | tail -1 | cut -c1-80)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/F11/cand_roads_terrain_exit.txt")" \
+    --difference "results/training_roads.json, committed, against the file both trees write: $diffc" \
+    --evidence F11/cand_roads_terrain_exit.txt F11/cand_roads_terrain_stdout.txt F11/cand_roads_terrain_stderr.txt F11/P_G3_terrain_vs_committed.txt
+  bad=""
+  grep -aq '^exit 0 ' "$S/F11/cand_random_road_exit.txt" || bad="$bad exit"
+  diff <(lf "$S/commitA/F11/cand_random_road_stdout.txt" | grep -avE '^\([0-9.]+ min\)$') <(lf "$S/F11/cand_random_road_stdout.txt" | grep -avE '^\([0-9.]+ min\)$') > "$S/F11/P_G3_random_road_vs_commitA.txt" 2>&1 || bad="$bad stdout against commit A's candidate's"
+  same "$S/F11/cand_random_road_stderr.txt" "$S/commitA/F11/cand_random_road_stderr.txt" || bad="$bad stderr"
+  diff "$S/F11/ref_random_road_stdout.txt" "$S/F11/cand_random_road_stdout.txt" > "$S/F11/P_G3_random_road_vs_ref.txt" 2>&1
+  R G3-roads --level L5 --item 3.6.5 --what "check_random_road.py (finding 11), the candidate against cf43fbb and commit A" \
+    --command "cd S/cand && python -B check_random_road.py; diff against commit A's candidate's stdout (commitA/F11/, the run-time line dropped) and against cf43fbb's (F11/ref_random_road_stdout.txt)" \
+    --cwd S/cand --expected "exit 0; stdout identical to commit A's candidate's but for the run-time line '(N min)'; stderr as commit A's; against cf43fbb's it differs in road_sha (random_road.py's code hash, be19b3d0bcef435d against e44153fd81eeaa1e) and the run time, as on commit A" \
+    --got "$( [ -z "$bad" ] && echo "as expected; $(lf "$S/F11/cand_random_road_stdout.txt" | grep -aoE 'road_sha [0-9a-f]{16}' | head -1)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_in "$S/F11/cand_random_road_exit.txt")" \
+    --difference "check_random_road.py's header prints road_sha, random_road.code_sha(): be19b3d0bcef435d on the candidate (as on commit A and build step 1), e44153fd81eeaa1e on cf43fbb; random_road.py's code changed between cf43fbb and c47907b, not in P" \
+    --evidence F11/cand_random_road_exit.txt F11/cand_random_road_stdout.txt F11/P_G3_random_road_vs_commitA.txt F11/P_G3_random_road_vs_ref.txt
+  t1=$(date +%s); bad=""
+  ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_after.txt" 2>&1 || bad=" a file differs"
+  R G3-roads --level identity --item prep --what "S/cand equals the start manifest after G3's writers" \
+    --command "cd S/cand && sha256sum -c --quiet manifest_start_P.txt" --cwd S/cand --expected "every file equal" \
+    --got "$( [ -z "$bad" ] && echo "every file equal" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence prep/P_G3_cand_after.txt
+  say "G3 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= G4-data
+g4() {
+  local t0 t1 bad got before after n csvs pull
+  say "G4 begins"; t0=$(date +%s)
+  # G4.1 validate.py in the clone (it only prints)
+  t1=$(date +%s)
+  before=$(sha256sum < "$REPO/validation_table.md" | cut -c1-64)
+  ( cd "$REPO" && "$PY" -B validate.py ) > "$S/L5/P_G4_cand_validate.txt" 2>&1; echo "exit $?" > "$S/L5/P_G4_cand_validate_exit.txt"
+  after=$(sha256sum < "$REPO/validation_table.md" | cut -c1-64)
+  git -C "$REPO" status --porcelain=v1 --untracked-files=all > "$S/L5/P_G4_status_after_validate.txt"
+  bad=""
+  [ "$(exit_of "$S/L5/P_G4_cand_validate_exit.txt")" = 0 ] || bad="$bad exit"
+  cmp -s "$S/L5/P_G4_cand_validate.txt" "$S/L5/ref_validate.txt" || bad="$bad the printout"
+  [ "$before" = "$after" ] && [ ! -s "$S/L5/P_G4_status_after_validate.txt" ] || bad="$bad validation_table.md or the clone moved"
+  R G4-data --level L5 --item 3.6.6 --what "validate.py, candidate against cf43fbb" \
+    --command "cd candg && python -B validate.py > L5/P_G4_cand_validate.txt 2>&1; cmp with L5/ref_validate.txt; sha256 of validation_table.md before and after; git status of the clone" \
+    --cwd candg --expected "exit 0; the printout byte-identical to cf43fbb's (2497 bytes, 8 of 11 quantities inside their band); validation_table.md the same bytes and the clone's status empty. A moved printout is a finding: FAIL, and the table is never edited" \
+    --got "$( [ -z "$bad" ] && echo "byte-identical; $(lf "$S/L5/P_G4_cand_validate.txt" | grep -a 'quantities inside' | tail -1 | cut -c1-80); the table and the clone unchanged" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence L5/P_G4_cand_validate.txt L5/P_G4_cand_validate_exit.txt L5/P_G4_status_after_validate.txt
+  # G4.2 build_dataset with no derived file, both trees at once
+  t1=$(date +%s)
+  csvs=$(cd "$REPO/logs/raw" && ls *.csv); n=$(echo "$csvs" | grep -c .)
+  ( "$PY" -I -B "$SW/tools/bd_dump.py" "$SW/candd" "$SW/F2/cand.npz" $csvs > "$S/F2/cand.txt" 2>&1; echo "cand exit $?" >> "$S/F2/cand.txt" ) &
+  ( "$PY" -I -B "$SW/tools/bd_dump.py" "$SW/refw" "$SW/F2/ref.npz" $csvs > "$S/F2/ref.txt" 2>&1; echo "ref exit $?" >> "$S/F2/ref.txt" ) &
+  wait
+  "$PY" -I -B "$SW/tools/cmp.py" "$SW/F2/ref.npz" "$SW/F2/cand.npz" --quiet --json "$SW/F2/cmp.json" > "$S/F2/cmp.txt" 2>&1
+  bad=""
+  for t in cand ref; do
+    [ "$(grep -ac ': derive OK' "$S/F2/$t.txt")" = "$n" ] || bad="$bad $t derive OK lines"
+    grep -aq '^derived file restored: True' "$S/F2/$t.txt" || bad="$bad $t restored"
+    grep -aq "^$t exit 0" "$S/F2/$t.txt" || bad="$bad $t exit"
+  done
+  got=$(lf "$S/F2/cmp.txt" | grep -a '^VERDICT' | tail -1)
+  [[ $got == "VERDICT: BIT-IDENTICAL ("* ]] || bad="$bad $got"
+  R G4-data --level L5 --item 3.6.9 --what "finding 2: build_dataset with no derived file, both trees" \
+    --command "CSVS=\$(cd candg/logs/raw && ls *.csv); python -I -B tools/bd_dump.py S/candd F2/cand.npz \$CSVS; the same in S/refw (the two at once); python -I -B tools/cmp.py F2/ref.npz F2/cand.npz --quiet --json F2/cmp.json" \
+    --cwd "S (bd_dump.py chdirs into S/candd and S/refw)" --expected "a derive OK line per drive and 'derived file restored: True' in each, both exit 0; VERDICT: BIT-IDENTICAL (commit A: 3617501 values)" \
+    --got "$( [ -z "$bad" ] && echo "$n derive OK lines each, restored, $got" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_since "$t1")" --evidence F2/cand.txt F2/ref.txt F2/cmp.txt F2/cmp.json
+  # G4.3 new_drive.py on pull01, the derived file aside, in S/candd (after G4.2)
+  t1=$(date +%s)
+  pull=$(cd "$S/candd" && ls logs/raw/pull01-*.csv 2>/dev/null | head -1)
+  ( cd "$S/candd" && mv data/derived_params.json data/derived_params.json.aside \
+    && "$PY" -B new_drive.py "$pull" > "$S/F2/new_drive_candd.txt" 2>&1; echo "exit $?" >> "$S/F2/new_drive_candd.txt"; \
+    mv data/derived_params.json.aside data/derived_params.json )
+  bad=""
+  [ -n "$pull" ] || bad="$bad no pull01 drive"
+  cmp -s "$S/F2/new_drive_candd.txt" "$S/F2/new_drive_ref.txt" || bad="$bad the output"
+  [ -f "$S/candd/data/derived_params.json" ] && [ ! -e "$S/candd/data/derived_params.json.aside" ] || bad="$bad the derived file not back"
+  R G4-data --level L5 --item 3.6.9 --what "finding 2: new_drive.py on pull01 with the derived file aside" \
+    --command "cd S/candd && mv data/derived_params.json aside && python -B new_drive.py $pull > F2/new_drive_candd.txt 2>&1; echo \"exit \$?\" >> (as build step 1 captured it); the file back; cmp with F2/new_drive_ref.txt" \
+    --cwd S/candd --expected "byte-identical to cf43fbb's output (build step 1's F2/new_drive_ref.txt, 2483 bytes with its 'exit 0' line); the derived file back" \
+    --got "$( [ -z "$bad" ] && echo "byte-identical; the derived file back" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_since "$t1")" --evidence F2/new_drive_candd.txt
+  # G4.4 derive_params.py in S/candd (after G4.3: it rewrites the copy's derived file)
+  t1=$(date +%s)
+  ( cd "$S/candd" && "$PY" -B derive_params.py ) > "$S/L5/derive_cand.txt" 2>&1; echo "exit $?" >> "$S/L5/derive_cand.txt"
+  cp -p "$S/candd/data/derived_params.json" "$S/L5/derived_params_DERIVED_cand.json"
+  "$PY" -I -B "$SW/tools/derived_check.py" "$RW/data/derived_params.json" "$SW/L5/derived_params_DERIVED_cand.json" \
+    "$SW/L5/derived_params_DERIVED_ref.json" --json "$SW/L5/derived_check.json" > "$S/L5/derived_check.txt" 2>&1; echo "derived_check exit $?" >> "$S/L5/derived_check.txt"
+  bad=""
+  [ "$(exit_of "$S/L5/derive_cand.txt")" = 0 ] || bad="$bad derive exit"
+  grep -aq '^derived_check exit 0' "$S/L5/derived_check.txt" || bad="$bad derived_check exit"
+  [ "$(grep -acE "^(committed|derived in the candidate copy|derived in the reference copy) +derived_sha $B58_DERIVED " "$S/L5/derived_check.txt")" = 3 ] \
+    || bad="$bad derived_sha not G1.0's $B58_DERIVED on all three"
+  grep -aqE ', [1-9][0-9]* of them values' "$S/L5/derived_check.txt" && bad="$bad a value differs"
+  R G4-data --level L5 --item 3.6.8 --what "derive_params.py in a copy; derived_sha as committed" \
+    --command "cd S/candd && python -B derive_params.py; cp data/derived_params.json L5/derived_params_DERIVED_cand.json; python -I -B tools/derived_check.py candg/data/derived_params.json L5/derived_params_DERIVED_cand.json L5/derived_params_DERIVED_ref.json --json L5/derived_check.json" \
+    --cwd "S/candd (derive_params.py); S (derived_check.py)" --expected "exit 0; derived_sha $B58_DERIVED (G1.0's; CERT_PLAN_A.md: 326c0835548975e2) for the committed file, the candidate's and the reference's; every difference '_' bookkeeping (/_generated), 0 values" \
+    --got "$( [ -z "$bad" ] && echo "$(lf "$S/L5/derived_check.txt" | grep -a 'of them values' | tr '\n' ' ' | cut -c1-200)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence L5/derive_cand.txt L5/derived_check.txt L5/derived_check.json
+  say "G4 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= G5-app-lab
+fsets() {   # fsets OUTFILE CAND REF...: failing_sets_P.py; 0 when the candidate fails nowhere a reference does not
+  local out=$1; shift
+  "$PY" -I -B "$SW/tools/failing_sets_P.py" "$@" > "$out" 2>&1
+}
+g5() {
+  local t0 t1 bad got s refs info m L st pin lp i d data_bad st_ref st_cand st_ulp st_1e9
+  say "G5 begins"; t0=$(date +%s)
+  # (review fixes 3, 7 November 2026) the ignored local data commit A's run in the repository had: p_gate.sh
+  # cert-prep copies these three paths from the live repository into the clone (gitignored there, so the clone's
+  # status, the manifests and git_dirty do not see them). Without them agent-scene.test.mjs skips its tests and
+  # app.test_agents' test_page_assets_ids fails (and cf43fbb's clone failed it too, so the strict judgement would
+  # excuse it): G5 would cover less than commit A's run did. Each G5.1 record of the app requires them.
+  data_bad=""
+  for d in app/node_modules app/static/vendor runs/extremes_dt1/sighted_seed0/meta.json; do
+    { [ -e "$REPO/$d" ] && git -C "$REPO" check-ignore -q -- "$d"; } || data_bad="$data_bad $d"
+  done
+  say "G5: the clone's ignored local data (app/node_modules, app/static/vendor, X1's sighted_seed0 meta.json): $( [ -z "$data_bad" ] && echo "present and ignored" || echo "MISSING or not ignored:$data_bad")"
+  # G5.1 the app suites and the lab's Python tests in the clone, then the eleven, then the node tests
+  t1=$(date +%s)
+  bash "$S/tools/run_app.sh" cand > "$S/app/P_G5_run_app.txt" 2>&1
+  bash "$S/tools/run_app_extra.sh" cand > "$S/app/P_G5_run_app_extra.txt" 2>&1
+  ( cd "$REPO/app" && "$NODE" --test --test-reporter=spec static/sim/*.test.mjs ) > "$S/app/cand_node_tests.txt" 2>&1
+  echo "exit $?" >> "$S/app/cand_node_tests.txt"
+  # app.test_replay --full
+  bad=""; got=$(lf "$S/app/cand_test_replay_full.txt" | grep -aE '^[0-9]+ of [0-9]+ checks pass' | tail -1)
+  [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($1 == $3) }')" = 1 ] || bad=" ${got:-no 'N of M checks pass' line}"
+  # (settle step) the three ignored local paths, as every other G5.1 app record (review fixes 3, R1.M2's claim)
+  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
+  diff "$S/commitA/app/cand_test_replay_full.txt" "$S/app/cand_test_replay_full.txt" > "$S/app/P_G5_test_replay_vs_commitA.txt" 2>&1
+  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "app.test_replay --full" \
+    --command "bash tools/run_app.sh cand (CAND = candg; its first line: python -B -m app.test_replay --full > app/cand_test_replay_full.txt); diffed with commit A's (commitA/app/)" \
+    --cwd candg --expected "'N of N checks pass' (every check passes; commit A: 59 of 59); the clone holds the three ignored local paths commit A's run had (p_gate.sh cert-prep); the diff with commit A's run recorded, not judged" \
+    --got "$( [ -z "$bad" ] && echo "$got; $(grep -c '^[<>]' "$S/app/P_G5_test_replay_vs_commitA.txt") lines differ from commit A's" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(nz "$(awk '$3 == "test_replay_full" { print $2 }' "$S/app/cand_status.txt" 2>/dev/null | tail -1)")" \
+    --evidence app/cand_test_replay_full.txt app/P_G5_test_replay_vs_commitA.txt app/cand_status.txt
+  # (review fixes 2) judged as CERT_PLAN_A.md G5.1 judges, which CERT_PLAN_P.md does not amend: "candidate only:
+  # []" against cf43fbb's git clone (app/refgit_*) alone, the eleven against cf43fbb's copy run (app/ref_*) alone,
+  # the lab's node tests against cf43fbb's run of them (commit A's A_G5_ref_lab_node_tests) alone. Commit A's
+  # candidate runs and RV's base runs excuse nothing: they are compared too, for information only (*_info.txt,
+  # named in the record's got), so that a failure RV's ancestors brought in after cf43fbb reads as a FAIL.
+  for s in test_simulation test_agents test_results lab_tests; do
+    refs=("$S/app/refgit_$s.txt"); info=("$S/app/refgit_$s.txt")
+    [ $s = lab_tests ] && info+=("$S/commitA/app/A_G5_lab_tests_pinned.txt") || info+=("$S/commitA/app/cand_$s.txt")
+    [ $s != lab_tests ] && [ -f "$P_GATE_OUT/base_app_$s.log" ] && info+=("$P_GATE_OUT/base_app_$s.log")
+    fsets "$S/app/P_G5_failing_$s.txt" "$S/app/cand_$s.txt" "${refs[@]}"; st=$?
+    fsets "$S/app/P_G5_failing_${s}_info.txt" "$S/app/cand_$s.txt" "${info[@]}"
+    bad=""
+    [ -n "$(ran_of "$S/app/cand_$s.txt")" ] && lf "$S/app/cand_$s.txt" | grep -aqE '^(OK|FAILED)( |$)' || bad="$bad did not complete"
+    [ "$st" = 0 ] || bad="$bad $(lf "$S/app/P_G5_failing_$s.txt" | grep -a '^candidate only:' | cut -c1-200); for information, against cf43fbb's, commit A's and RV's runs together: $(lf "$S/app/P_G5_failing_${s}_info.txt" | grep -a '^candidate only:' | cut -c1-160)"
+    [ $s = lab_tests ] || [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
+    if [ $s = lab_tests ]; then
+      pin=$(grep -aoE '"current_plant_sha"\], "[0-9a-f]{16}"' "$REPO/Explanatory Simulation/tests/test_catalog.py" | grep -oE '[0-9a-f]{16}' | head -1)
+      [ "$pin" = "$B58_PLANT" ] || bad="$bad the pin $pin, not G1.0's plant_sha $B58_PLANT"
+      tests_ok "$S/app/cand_lab_tests.txt" "^test_results_are_current_and_inconclusive_with_explicit_caveats [(]" \
+        "^(FAIL|ERROR): test_results_are_current_and_inconclusive_with_explicit_caveats " || bad="$bad the pin's test not ok"
+    fi
+    R G5-app-lab --level L5 --item "$( [ $s = lab_tests ] && echo "3.6.12, HA.2, HA.3" || echo "3.6.11, HA.3, HP7.7")" \
+      --what "$( [ $s = lab_tests ] && echo "the lab's Python tests, and its plant_sha pin" || echo "app.$s")" \
+      --command "bash tools/run_app.sh cand (CAND = candg); python -I -B tools/failing_sets_P.py app/cand_$s.txt app/refgit_$s.txt > app/P_G5_failing_$s.txt (judged); the same against $(printf '%s ' "${info[@]##*/}")> app/P_G5_failing_${s}_info.txt (information only)" \
+      --cwd "candg$( [ $s = lab_tests ] && echo '/Explanatory Simulation')" \
+      --expected "the run complete (Ran N, OK or FAILED); candidate only: [] against cf43fbb's git clone (app/refgit_$s.txt) alone, as CERT_PLAN_A.md G5.1 (commit A's candidate run$( [ $s != lab_tests ] && echo " and RV's base run") compared for information only, excusing nothing)$( [ $s = lab_tests ] && echo "; test_results_are_current_and_inconclusive_with_explicit_caveats ... ok, and the pin in tests/test_catalog.py is G1.0's plant_sha $B58_PLANT" || echo "; the clone holds the three ignored local paths commit A's run had (app/node_modules, app/static/vendor, runs/extremes_dt1/sighted_seed0/meta.json; p_gate.sh cert-prep)")" \
+      --got "$( [ -z "$bad" ] && echo "$(ut_line "$S/app/cand_$s.txt"); candidate only: []" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+      --seconds "$(nz "$(awk -v l="$s" '$3 == l { print $2 }' "$S/app/cand_status.txt" 2>/dev/null | tail -1)")" \
+      --evidence "app/cand_$s.txt" "app/P_G5_failing_$s.txt" "app/P_G5_failing_${s}_info.txt"
+  done
+  bad=""
+  for m in "${EXTRA[@]}"; do
+    info=("$S/app/ref_$m.txt" "$S/commitA/app/cand_$m.txt")
+    [ -f "$P_GATE_OUT/base_app_$m.log" ] && info+=("$P_GATE_OUT/base_app_$m.log")
+    fsets "$S/app/P_G5_failing_${m}_info.txt" "$S/app/cand_$m.txt" "${info[@]}"
+    fsets "$S/app/P_G5_failing_$m.txt" "$S/app/cand_$m.txt" "$S/app/ref_$m.txt" \
+      || bad="$bad $m(candidate only; with commit A's and RV's runs: $(lf "$S/app/P_G5_failing_${m}_info.txt" | grep -a '^candidate only:' | cut -c16-120))"
+    [ -n "$(ran_of "$S/app/cand_$m.txt")" ] && lf "$S/app/cand_$m.txt" | grep -aqE '^(OK|FAILED)( |$)' || bad="$bad $m(incomplete)"
+  done
+  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
+  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "the eleven other app suites (run_app_extra.sh)" \
+    --command "bash tools/run_app_extra.sh cand (CAND = candg; python -B -m unittest -v app.<m>); python -I -B tools/failing_sets_P.py app/cand_<m>.txt app/ref_<m>.txt for each (judged); with commitA/app/cand_<m>.txt and RV's base log too (information only, app/P_G5_failing_<m>_info.txt)" \
+    --cwd candg --expected "each of the eleven complete; for each, candidate only: [] against cf43fbb's copy run (build step 1's app/ref_<m>.txt) alone (pwsh's absence errs on both alike); commit A's and RV's runs excuse nothing; the clone holds the three ignored local paths commit A's run had (p_gate.sh cert-prep)" \
+    --got "$( [ -z "$bad" ] && echo "eleven complete; candidate only: [] for each" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(awk '{ s += $2 } END { print s + 0 }' "$S/app/cand_extra_status.txt" 2>/dev/null)" \
+    --evidence app/cand_extra_status.txt app/P_G5_run_app_extra.txt
+  info=("$S/app/refgit_node_tests.txt" "$S/commitA/app/cand_node_tests.txt")
+  [ -f "$P_GATE_OUT/base_app_node.log" ] && info+=("$P_GATE_OUT/base_app_node.log")
+  fsets "$S/app/P_G5_failing_node.txt" "$S/app/cand_node_tests.txt" "$S/app/refgit_node_tests.txt"; st=$?
+  fsets "$S/app/P_G5_failing_node_info.txt" "$S/app/cand_node_tests.txt" "${info[@]}"
+  bad=""; got=$(lf "$S/app/cand_node_tests.txt" | grep -aE '^ℹ (tests|pass|fail|skipped) [0-9]+' | tr '\n' ' ')
+  grep -aqE '^ℹ tests [0-9]+' <(lf "$S/app/cand_node_tests.txt") || bad="$bad no 'tests N' line"
+  [ "$st" = 0 ] || bad="$bad candidate only (with commit A's and RV's runs: $(lf "$S/app/P_G5_failing_node_info.txt" | grep -a '^candidate only:' | cut -c16-120))"
+  # (review fixes 3) no test skipped, as on commit A's run (cf43fbb's clone, without the ignored data, skipped 12)
+  grep -aqxE 'ℹ skipped 0' <(lf "$S/app/cand_node_tests.txt") || bad="$bad not 'skipped 0'"
+  [ -z "$data_bad" ] || bad="$bad the clone lacks the ignored local data:$data_bad"
+  R G5-app-lab --level L5 --item "3.6.11, HA.3, HP7.7" --what "the app's node tests" \
+    --command "cd candg/app && node --test --test-reporter=spec static/sim/*.test.mjs > app/cand_node_tests.txt; failing_sets_P.py against cf43fbb's clone's run (judged), and with commit A's and RV's base run too (information only)" \
+    --cwd candg/app --expected "the summary printed with 'ℹ skipped 0' (the clone holds app/node_modules, app/static/vendor and X1's sighted_seed0 meta.json, copied by p_gate.sh cert-prep, as commit A's run in the repository had them: commit A 306 tests, 306 pass, 0 skipped; cf43fbb's clone, without them, 294 pass, 12 skipped); candidate only: [] against cf43fbb's git clone alone" \
+    --got "$( [ -z "$bad" ] && echo "$got; candidate only: []" || echo "differs:$bad; $got")" --verdict "$(verdict "$bad")" --seconds 0 \
+    --evidence app/cand_node_tests.txt app/P_G5_failing_node.txt app/P_G5_failing_node_info.txt
+  # G5.2 the lab's build and launcher, in S/cand (network for npm ci)
+  L="$S/cand/Explanatory Simulation"
+  { "$NODE" --version; "$NPM" --version; } > "$S/lab/P_G5_versions.txt" 2>&1
+  t1=$(date +%s)
+  ( cd "$L" && "$NPM" ci ) > "$S/lab/P_G5_npm_ci.txt" 2>&1; echo "exit $? in $(secs_since "$t1") s" >> "$S/lab/P_G5_npm_ci.txt"
+  # (review fixes 3) npm ci's record is written whatever its outcome: without the network it is a FAIL, which
+  # stands until cert-recheck g5 runs G5 again with it, so that the certificate cannot pass without the lab's build,
+  # launcher and node tests (3.6.12, B12) having run. Before, a failed npm ci left no record, and 3.6.12 and B12
+  # read as answered by the other records.
+  bad=""; [ "$(exit_of "$S/lab/P_G5_npm_ci.txt")" = 0 ] && grep -aq '^added ' "$S/lab/P_G5_npm_ci.txt" || bad=" exit $(exit_of "$S/lab/P_G5_npm_ci.txt")"
+  R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab: npm ci" --command "cd \"S/cand/Explanatory Simulation\" && npm ci > lab/P_G5_npm_ci.txt" \
+    --cwd "S/cand/Explanatory Simulation" --expected "exit 0, 'added ... packages' (a FAIL here, the network absent, means the lab's build, launcher and node tests did not run: cert-recheck g5)" \
+    --got "$(lf "$S/lab/P_G5_npm_ci.txt" | grep -aE '^added|^exit' | tr '\n' ' ' | cut -c1-160)$( [ -n "$bad" ] && echo "; the build, the launcher and the lab's node tests not run")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_ci.txt lab/P_G5_versions.txt
+  if [ -n "$bad" ]; then
+    say "npm ci failed ($bad; the network?): its record is a FAIL; G5.2's build and launcher and G5.3 did not run (lab/P_G5_npm_ci.txt)"
+  else
+    t1=$(date +%s)
+    ( cd "$L" && "$NPM" run build ) > "$S/lab/P_G5_npm_build.txt" 2>&1; echo "exit $? in $(secs_since "$t1") s" >> "$S/lab/P_G5_npm_build.txt"
+    bad=""; [ "$(exit_of "$S/lab/P_G5_npm_build.txt")" = 0 ] && grep -aq 'built in' "$S/lab/P_G5_npm_build.txt" || bad=" $(tail -1 "$S/lab/P_G5_npm_build.txt")"
+    R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab: npm run build" --command "cd \"S/cand/Explanatory Simulation\" && npm run build > lab/P_G5_npm_build.txt" \
+      --cwd "S/cand/Explanatory Simulation" --expected "exit 0, 'built in'" --got "$( [ -z "$bad" ] && echo "exit 0, built" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
+    if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
+      t1=$(date +%s)
+      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
+      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
+      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
+      # which the trigger below would fire before this run's server is up (a false FAIL)
+      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
+      ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
+        echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
+      lp=$!
+      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
+      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
+      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
+      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
+      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
+      ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
+      wait "$lp"
+      # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
+      # p_gate.sh post's no_other_python would then refuse: a listener left on 8765 is killed, with its recorded
+      # descendants (settle step, below).
+      # (review fixes 3) Only the process that listens on 127.0.0.1:8765 (Get-NetTCPConnection's OwningProcess):
+      # the port was free when the launcher started (checked above), so the listener is S/cand's server. Before,
+      # every python.exe on the machine whose command line named launch.py was killed.
+      if ! "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
+        lp=$(powershell.exe -NoProfile -NonInteractive -Command "Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique" < /dev/null 2>/dev/null | tr -d '\r' | grep -E '^[0-9]+$' | grep -vx 0)
+        # (settle step, 7 November 2026) not taskkill /T, which walks children by ParentProcessId alone: a process
+        # whose parent had exited and whose parent's pid the listener reused would be killed too. The listener and
+        # its Win32_Process descendants no older than their parent (as p_gate.sh's sv_win_tree) are recorded, and
+        # exactly those pids are killed, each without /T.
+        for i in $lp; do
+          d=$(powershell.exe -NoProfile -NonInteractive -Command "\$all = @(Get-CimInstance Win32_Process); \$ct = @{}; foreach (\$x in \$all) { \$ct[[int]\$x.ProcessId] = \$x.CreationDate }; \$keep = @{}; if (\$ct.ContainsKey($i)) { \$keep[$i] = 1 }; do { \$n = 0; foreach (\$x in \$all) { \$p = [int]\$x.ParentProcessId; if (-not \$keep.ContainsKey([int]\$x.ProcessId) -and \$keep.ContainsKey(\$p) -and \$x.CreationDate -ge \$ct[\$p]) { \$keep[[int]\$x.ProcessId] = 1; \$n++ } } } while (\$n -gt 0); \$all | Where-Object { \$keep.ContainsKey([int]\$_.ProcessId) } | ForEach-Object { 'listener tree of $i: ' + [string]\$_.ProcessId + ' ' + [string]\$_.ParentProcessId + ' ' + \$_.Name + ' ' + \$_.CommandLine }" < /dev/null 2>/dev/null | tr -d '\r' | grep -aE "^listener tree of $i: [0-9]+ ")
+          [ -n "$d" ] && printf '%s\n' "$d" >> "$S/lab/P_G5_launch_cleanup.txt"
+          for m in $(printf '%s\n' "$d" | awk 'NF >= 5 { print $5 }'); do
+            taskkill.exe //F //PID "$m" >> "$S/lab/P_G5_launch_cleanup.txt" 2>&1
+          done
+        done
+        say "the launcher's server still listened on 8765 after the timeout: the listening process and its recorded descendants killed, each by its pid: [${lp:-none found}] (lab/P_G5_launch_cleanup.txt)"
+      fi
+      bad=""
+      grep -aq 'Supra Lab is ready: http://127.0.0.1:8765' "$S/lab/P_G5_launch_no_browser.txt" || bad="$bad not ready"
+      grep -aq '^exit 124 ' "$S/lab/P_G5_launch_no_browser.txt" || bad="$bad launcher exit"
+      grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
+      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
+        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+        --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+        --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
+    else
+      # (review fixes 3) fail closed, as npm ci: a FAIL record, re-checked by cert-recheck g5 once the port is free
+      say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
+      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
+        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+        --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
+    fi
+    # G5.3 the lab's node tests (after npm ci)
+    t1=$(date +%s)
+    ( cd "$L" && CATALOG_TEST_PYTHON="$(cygpath -w "$PY")" "$NODE" --test --test-reporter=spec src/model/*.test.mjs ) > "$S/lab/P_G5_lab_node_tests.txt" 2>&1
+    echo "exit $?" >> "$S/lab/P_G5_lab_node_tests.txt"
+    fsets "$S/lab/P_G5_lab_node_failing_sets_info.txt" "$S/lab/P_G5_lab_node_tests.txt" "$S/commitA/lab/A_G5_ref_lab_node_tests.txt" "$S/commitA/lab/A_G5_lab_node_tests.txt"
+    fsets "$S/lab/P_G5_lab_node_failing_sets.txt" "$S/lab/P_G5_lab_node_tests.txt" "$S/commitA/lab/A_G5_ref_lab_node_tests.txt"; st=$?
+    bad=""; grep -aqE '^ℹ tests [0-9]+' <(lf "$S/lab/P_G5_lab_node_tests.txt") || bad="$bad no summary"
+    [ "$st" = 0 ] || bad="$bad $(lf "$S/lab/P_G5_lab_node_failing_sets.txt" | grep -a '^candidate only' | cut -c1-200); with commit A's candidate run too: $(lf "$S/lab/P_G5_lab_node_failing_sets_info.txt" | grep -a '^candidate only' | cut -c16-120)"
+    R G5-app-lab --level L5 --item "3.6.12, B12" --what "the lab's node tests" \
+      --command "cd \"S/cand/Explanatory Simulation\" && CATALOG_TEST_PYTHON=<PY> node --test --test-reporter=spec src/model/*.test.mjs; failing_sets_P.py against commit A's run of them on cf43fbb's tree (judged: CERT_PLAN_A.md G5.3 classifies a failure by the same command on S/ref), and with commit A's candidate run too (information only)" \
+      --cwd "S/cand/Explanatory Simulation" --expected "the summary printed; candidate only: [] against the cf43fbb run alone (commit A: one failure on both trees, provenance.test.mjs's oil row; command-explanations.test.mjs anchors on engine_env.py's text, which P edits: B12)" \
+      --got "$( [ -z "$bad" ] && echo "$(lf "$S/lab/P_G5_lab_node_tests.txt" | grep -aE '^ℹ (tests|fail) [0-9]+' | tr '\n' ' '); candidate only: []" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_lab_node_tests.txt lab/P_G5_lab_node_failing_sets.txt lab/P_G5_lab_node_failing_sets_info.txt
+  fi
+  # G5.4 the lab's outputs. (review fixes 3) Each dump is removed before lab_dump.py writes it, its exit code is
+  # recorded in its log, and every record that reads a dump requires that dump's exit 0 and its file: on a
+  # CERT_ONLY=g5 re-run a crashed dump would otherwise leave the first run's JSON to be compared as if it had run.
+  t1=$(date +%s)
+  rm -f "$S/lab/lab_ref_P.json"
+  "$PY" -I -B "$SW/tools/lab_dump.py" "$SW/ref" "$SW/lab/lab_ref_P.json" > "$S/lab/lab_ref_P.log" 2>&1; st_ref=$?
+  echo "lab_dump exit $st_ref" >> "$S/lab/lab_ref_P.log"
+  bad=""; { [ "$st_ref" = 0 ] && [ -s "$S/lab/lab_ref_P.json" ]; } || bad="$bad lab_dump exit $st_ref"
+  cmp -s "$S/lab/lab_ref_P.json" "$S/lab/lab_ref_A.json" || bad="$bad differs from commit A's reference dump"
+  R G5-app-lab --level L5 --item "3.6.12, HA.8" --what "the lab: cf43fbb's dump made again" \
+    --command "python -I -B tools/lab_dump.py S/ref lab/lab_ref_P.json; cmp lab/lab_ref_P.json lab/lab_ref_A.json (commit A's, from its S)" --cwd S \
+    --expected "lab_dump.py exit 0; byte-identical to commit A's reference dump" --got "$( [ -z "$bad" ] && echo "exit 0; byte-identical" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/lab_ref_P.log
+  t1=$(date +%s)
+  rm -f "$S/lab/lab_cand_P.json"
+  "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_cand_P.json" > "$S/lab/lab_cand_P.log" 2>&1; st_cand=$?
+  echo "lab_dump exit $st_cand" >> "$S/lab/lab_cand_P.log"
+  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_ref_P.json" "$SW/lab/lab_cand_P.json" > "$S/lab/compare_P_cand_ref.txt" 2>&1; st=$?
+  echo "exit $st" >> "$S/lab/compare_P_cand_ref.txt"
+  bad=""
+  { [ "$st_ref" = 0 ] && [ -s "$S/lab/lab_ref_P.json" ]; } || bad="$bad cf43fbb's dump (lab_dump exit $st_ref)"
+  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
+  [ "$st" = 1 ] && grep -aq '^VERDICT: DIFFERENT' "$S/lab/compare_P_cand_ref.txt" || bad="$bad exit $st"
+  cmp -s <(lf "$S/lab/compare_P_cand_ref.txt" | awk '/^VERDICT:/ { exit } f || /^  \// { f = 1; print }') \
+         <(lf "$S/commitA/lab/compare_A_cand_ref.txt" | awk '/^VERDICT:/ { exit } f || /^  \// { f = 1; print }') || bad="$bad the other differences are not commit A's four"
+  [ "$(lf "$S/lab/compare_P_cand_ref.txt" | head -1 | grep -oE '^[0-9]+ leaf values compared')" = "$(lf "$S/commitA/lab/compare_A_cand_ref.txt" | head -1 | grep -oE '^[0-9]+ leaf values compared')" ] \
+    && lf "$S/lab/compare_P_cand_ref.txt" | head -1 | grep -aq '; 4 other differences$' || bad="$bad the summary line"
+  R G5-app-lab --level L5 --item "3.6.12, HA.8, B12" --what "the lab's outputs against cf43fbb's" \
+    --command "python -I -B tools/lab_dump.py candg lab/lab_cand_P.json; python -I -B -X utf8 tools/lab_compare.py lab/lab_ref_P.json lab/lab_cand_P.json > lab/compare_P_cand_ref.txt" --cwd S \
+    --expected "both dumps lab_dump.py exit 0; VERDICT: DIFFERENT, exit 1, which is the expected outcome (HANDOFFS commit A item 8): as many leaf values as commit A's comparison; 4 other differences, exactly commit A's four with their values (/meta_en and /meta_ar concepts[4]/source/match 'm_air' -> 'm_air =', concepts[7]/range); no value differs. The counts of moved source lines and re-worded strings are P's own (P edits engine_env.py) and are not judged" \
+    --got "$( [ -z "$bad" ] && echo "$(lf "$S/lab/compare_P_cand_ref.txt" | head -1 | cut -c1-160); the four are commit A's" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/compare_P_cand_ref.txt lab/lab_cand_P.log
+  # G5.5 the lab's controls
+  t1=$(date +%s)
+  rm -f "$S/lab/lab_P_ctl_cturb_ulp.json"
+  LAB_PERTURB=thermal.c_turb "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_P_ctl_cturb_ulp.json" > "$S/lab/lab_P_ctl_cturb_ulp.log" 2>&1; st_ulp=$?
+  echo "lab_dump exit $st_ulp" >> "$S/lab/lab_P_ctl_cturb_ulp.log"
+  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_cand_P.json" "$SW/lab/lab_P_ctl_cturb_ulp.json" > "$S/lab/compare_P_ctl_cturb_ulp.txt" 2>&1; st=$?
+  bad=""; [ "$st" = 0 ] && grep -aq '; 0 other differences$' <(lf "$S/lab/compare_P_ctl_cturb_ulp.txt" | head -1) || bad=" exit $st"
+  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
+  { [ "$st_ulp" = 0 ] && [ -s "$S/lab/lab_P_ctl_cturb_ulp.json" ]; } || bad="$bad the control's dump (lab_dump exit $st_ulp)"
+  R G5-app-lab --level control --item 3.6.12 --what "lab one ulp (a measured limit)" --environment LAB_PERTURB=thermal.c_turb \
+    --command "LAB_PERTURB=thermal.c_turb python -I -B tools/lab_dump.py candg lab/lab_P_ctl_cturb_ulp.json; lab_compare.py lab/lab_cand_P.json it" --cwd S \
+    --expected "both dumps lab_dump.py exit 0 (the candidate's and this one); IDENTICAL, exit 0, 0 other differences: the lab's 40-step sessions round one ulp away (a measured limit, as on commit A)" \
+    --got "$(lf "$S/lab/compare_P_ctl_cturb_ulp.txt" | head -1 | cut -c1-160); exit $st; lab_dump exits $st_cand and $st_ulp" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence lab/compare_P_ctl_cturb_ulp.txt lab/lab_P_ctl_cturb_ulp.log
+  t1=$(date +%s)
+  rm -f "$S/lab/lab_P_ctl_cturb_1e-9.json"
+  LAB_PERTURB=thermal.c_turb:1e-9 "$PY" -I -B "$SW/tools/lab_dump.py" "$RW" "$SW/lab/lab_P_ctl_cturb_1e-9.json" > "$S/lab/lab_P_ctl_cturb_1e-9.log" 2>&1; st_1e9=$?
+  echo "lab_dump exit $st_1e9" >> "$S/lab/lab_P_ctl_cturb_1e-9.log"
+  "$PY" -I -B -X utf8 "$SW/tools/lab_compare.py" "$SW/lab/lab_cand_P.json" "$SW/lab/lab_P_ctl_cturb_1e-9.json" > "$S/lab/compare_P_ctl_cturb_1e-9.txt" 2>&1; st=$?
+  bad=""; [ "$st" = 1 ] && grep -aq '^VERDICT: DIFFERENT' "$S/lab/compare_P_ctl_cturb_1e-9.txt" || bad=" exit $st"
+  { [ "$st_cand" = 0 ] && [ -s "$S/lab/lab_cand_P.json" ]; } || bad="$bad the candidate's dump (lab_dump exit $st_cand)"
+  { [ "$st_1e9" = 0 ] && [ -s "$S/lab/lab_P_ctl_cturb_1e-9.json" ]; } || bad="$bad the control's dump (lab_dump exit $st_1e9)"
+  R G5-app-lab --level control --item 3.6.12 --what "lab relative 1e-9" --environment LAB_PERTURB=thermal.c_turb:1e-9 \
+    --command "LAB_PERTURB=thermal.c_turb:1e-9 python -I -B tools/lab_dump.py candg lab/lab_P_ctl_cturb_1e-9.json; lab_compare.py lab/lab_cand_P.json it" --cwd S \
+    --expected "both dumps lab_dump.py exit 0 (the candidate's and this one); VERDICT: DIFFERENT, exit 1 (the control that must come out DIFFERENT; build step 1: 1212 other differences)" \
+    --got "$(lf "$S/lab/compare_P_ctl_cturb_1e-9.txt" | head -1 | cut -c1-160); exit $st; lab_dump exits $st_cand and $st_1e9" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" \
+    --evidence lab/compare_P_ctl_cturb_1e-9.txt lab/lab_P_ctl_cturb_1e-9.log
+  say "G5 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= G6-agents
+g6() {
+  local t0 t1 bad got tag sec n c st fields
+  say "G6 begins"; t0=$(date +%s)
+  # (review fixes 3, 7 November 2026) every run starts from none of an earlier run's L6, L7 and d2 outputs (p_gate.sh
+  # cert-recheck has copied the first run's evidence aside). run_l6.sh appends each job's exit to L6/_status.txt
+  # and counts every line, so a re-run read "L6 done: 16 of 16 exit 0" and FAILed against "8 of 8"; the controls
+  # append to L6/P_G6_ctl_status.txt, whose first-run "0 <name>" line passed a re-run control that crashed, with
+  # l6_check.py reading the first run's dump; and check_l6.sh would compare the first run's dumps of an
+  # l6_agents.py that crashed. The references S/L7/ref_eval.txt and S/F11/ref_d2.txt (build step 1's) stay.
+  rm -f "$S/L6/_status.txt" "$S/L6/P_G6_ctl_status.txt" "$S"/L6/cand_*.npz "$S"/L6/ref_*.npz "$S"/L6/P_G6_ctl_*.npz \
+        "$S"/cmp/L6_*.json "$S"/cmp/P_G6_L6_ctl_*_committed.json \
+        "$S"/L7/cand_*.txt "$S"/L7/ref_eval_blind.txt "$S"/L7/ref_blind_*.txt "$S"/L7/make_meta*.txt "$S"/L7/l7_diff*.txt \
+        "$S"/L7/l7_diff*.json "$S"/L7/l7_expect*.txt "$S"/F11/cand_d2*.txt "$S"/F11/d2_diff.*
+  rm -rf "$S/L7/cand_model"
+  # G6.1 L6 (8 processes) and G6.2's four controls after it
+  t1=$(date +%s)
+  bash "$S/tools/run_l6.sh" > "$S/L6/P_G6_run_l6.txt" 2>&1
+  sec=$(secs_since "$t1")
+  bash "$S/tools/check_l6.sh" > "$S/cmp/P_G6_L6_report.txt" 2>&1
+  bad=""; got=$(lf "$S/L6/P_G6_run_l6.txt" | grep -a '^L6 done' | tail -1)
+  [ "$got" = "L6 done: 8 of 8 exit 0" ] || bad=" ${got:-no L6 done line}"
+  R G6-agents --level L6 --item 3.6.13 --what "L6 run: four X1 agents x twenty frozen episodes in both trees" \
+    --command "bash tools/run_l6.sh (per tag and tree: python -I -B tools/l6_agents.py <candg|S/ref> <tag> L6/<cand|ref>_<tag>.npz)" --cwd S \
+    --expected "L6 done: 8 of 8 exit 0" --got "${got:-none}" --verdict "$(verdict "$bad")" --seconds "$sec" --evidence L6/P_G6_run_l6.txt L6/_status.txt
+  for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
+    lf "$S/cmp/P_G6_L6_report.txt" | awk -v t="=================== $tag" '$0 == t { f = 1; next } /^===================/ { f = 0 } f' > "$S/cmp/P_G6_L6_$tag.txt"
+    bad=""
+    grep -aq '^VERDICT: BIT-IDENTICAL (' "$S/cmp/P_G6_L6_$tag.txt" || bad="$bad cand against ref"
+    [ "$(grep -ac '^VERDICT: EQUAL TO THE COMMITTED FILES' "$S/cmp/P_G6_L6_$tag.txt")" = 2 ] || bad="$bad against the committed files"
+    R G6-agents --level L6 --item 3.6.13 --what "L6 $tag: candidate against reference, and each tree against the committed files" \
+      --command "bash tools/check_l6.sh > cmp/P_G6_L6_report.txt (for $tag: cmp.py L6/ref_$tag.npz L6/cand_$tag.npz --json cmp/L6_$tag.json; l6_check.py L6/<cand|ref>_$tag.npz $tag --json cmp/L6_<cand|ref>_${tag}_committed.json)" \
+      --cwd S --expected "candidate against reference VERDICT: BIT-IDENTICAL; each tree against the committed files 'VERDICT: EQUAL TO THE COMMITTED FILES' (140 of 140 scores at full precision; 46 fields, all identical)" \
+      --got "$( [ -z "$bad" ] && echo "$(grep -a '^VERDICT: BIT-IDENTICAL' "$S/cmp/P_G6_L6_$tag.txt" | head -1); both trees EQUAL TO THE COMMITTED FILES" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds 0 --evidence "cmp/P_G6_L6_$tag.txt" "cmp/L6_$tag.json" "cmp/L6_cand_${tag}_committed.json" "cmp/L6_ref_${tag}_committed.json"
+  done
+  t1=$(date +%s)
+  for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do
+    set -- $c
+    ( HARNESS_PERTURB=$1 "$PY" -I -B "$SW/tools/l6_agents.py" "$RW" sighted_seed0 "$SW/L6/P_G6_ctl_$3.npz" "$2" > "$S/L6/P_G6_ctl_$3.log" 2>&1; echo "$? $3" >> "$S/L6/P_G6_ctl_status.txt" ) &
+  done
+  wait
+  sec=$(secs_since "$t1")
+  for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do
+    set -- $c
+    "$PY" -I -B "$SW/tools/l6_check.py" "$SW/L6/P_G6_ctl_$3.npz" sighted_seed0 --json "$SW/cmp/P_G6_L6_ctl_$3_committed.json" > "$S/L6/P_G6_ctl_$3_check.txt" 2>&1; st=$?
+    bad=""
+    grep -aq "^0 $3\$" "$S/L6/P_G6_ctl_status.txt" || bad="$bad the run's exit"
+    [ "$st" != 0 ] && grep -aq '^VERDICT: NOT EQUAL' "$S/L6/P_G6_ctl_$3_check.txt" || bad="$bad l6_check exit $st"
+    R G6-agents --level control --item 3.6.13 --what "L6 control: $1, sighted_seed0, $2 episodes" --environment "HARNESS_PERTURB=$1" \
+      --command "HARNESS_PERTURB=$1 python -I -B tools/l6_agents.py candg sighted_seed0 L6/P_G6_ctl_$3.npz $2; python -I -B tools/l6_check.py L6/P_G6_ctl_$3.npz sighted_seed0 --json cmp/P_G6_L6_ctl_$3_committed.json" \
+      --cwd S --expected "VERDICT: NOT EQUAL, l6_check exit 1 (the expected outcome; commit A: one ulp on the mass 23 of 35 scores equal, on c_turb 30 of 35; 1e-9 on the mass 2 of 14)" \
+      --got "$( [ -z "$bad" ] && echo "$(lf "$S/L6/P_G6_ctl_$3_check.txt" | grep -aE '^(scores|per step|VERDICT)' | tr '\n' ' ' | cut -c1-220)" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds "$sec" --evidence "L6/P_G6_ctl_$3_check.txt" "L6/P_G6_ctl_$3.log" "cmp/P_G6_L6_ctl_$3_committed.json"
+  done
+  # G6.3 L7: make_meta for sighted_seed0 and blind_seed0 (CERT_PLAN_P.md G6.3), then four evaluate.py runs at once
+  "$PY" -I -B "$SW/tools/make_meta.py" "$RW" "$X1_RUNS/sighted_seed0" "$SW/L7/cand_model/sighted_seed0" > "$S/L7/make_meta.txt" 2>&1; echo "exit $?" >> "$S/L7/make_meta.txt"
+  "$PY" -I -B "$SW/tools/make_meta.py" "$RW" "$X1_RUNS/blind_seed0" "$SW/L7/cand_model/blind_seed0" > "$S/L7/make_meta_blind.txt" 2>&1; echo "exit $?" >> "$S/L7/make_meta_blind.txt"
+  for f in make_meta make_meta_blind; do
+    bad=""
+    [ "$(exit_of "$S/L7/$f.txt")" = 0 ] || bad="$bad exit"
+    grep -aq '^FATAL disagreements with the live tree: none' "$S/L7/$f.txt" || bad="$bad FATAL disagreements"
+    grep -aq '^schema_problem: None' "$S/L7/$f.txt" || bad="$bad schema_problem"
+    got=$(lf "$S/L7/$f.txt" | grep -a '^final.zip sha256' | head -1)
+    [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($3 == $5) }')" = 1 ] || bad="$bad final.zip"
+    R G6-agents --level L7 --item 3.6.14 --what "L7 make_meta.py: the scratch model directory for X1's $( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0)" \
+      --command "python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/$( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0) L7/cand_model/$( [ $f = make_meta ] && echo sighted_seed0 || echo blind_seed0) > L7/$f.txt" \
+      --cwd S --expected "final.zip sha256 the same on both sides; 'FATAL disagreements with the live tree: none'; 'schema_problem: None' (the schema-4 block, through FP.for_arm$( [ $f = make_meta_blind ] && echo ": the blinded arm, preview_h_s None, row 117"))" \
+      --got "$( [ -z "$bad" ] && echo "as expected; $(echo "$got" | cut -c1-40)..." || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds 0 --evidence "L7/$f.txt"
+  done
+  t1=$(date +%s)
+  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --out "$SW/L7/cand_eval.txt" "$SW/L7/cand_model/sighted_seed0" > "$S/L7/cand_stdout.txt" 2>&1; \
+    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/cand_exit.txt" ) &
+  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --out "$SW/L7/cand_eval_blind.txt" "$SW/L7/cand_model/blind_seed0" > "$S/L7/cand_blind_stdout.txt" 2>&1; \
+    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/cand_blind_exit.txt" ) &
+  ( cd "$S/ref" && "$PY" -B evaluate.py --out "$SW/L7/ref_eval_blind.txt" "$X1_RUNS/blind_seed0" > "$S/L7/ref_blind_stdout.txt" 2>&1; \
+    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/L7/ref_blind_exit.txt" ) &
+  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --protocol d2 --out "$SW/F11/cand_d2.txt" > "$S/F11/cand_d2_stdout.txt" 2>&1; \
+    { echo "exit $?"; echo "$(( $(date +%s) - t1 )) s"; } > "$S/F11/cand_d2_exit.txt" ) &
+  wait
+  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/L7/ref_eval.txt" "$X1_RUNS/sighted_seed0" "$SW/L7/cand_eval.txt" "$SW/L7/cand_model/sighted_seed0" --json "$SW/L7/l7_diff.json" > "$S/L7/l7_diff.txt" 2>&1
+  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/L7/ref_eval_blind.txt" "$X1_RUNS/blind_seed0" "$SW/L7/cand_eval_blind.txt" "$SW/L7/cand_model/blind_seed0" --json "$SW/L7/l7_diff_blind.json" > "$S/L7/l7_diff_blind.txt" 2>&1
+  "$PY" -I -B "$SW/tools/l7_expect.py" --repo "$RW" "$SW/L7/cand_eval.txt" > "$S/L7/l7_expect.txt" 2>&1
+  "$PY" -I -B "$SW/tools/l7_expect.py" --agent blind_seed0 --repo "$RW" "$SW/L7/cand_eval_blind.txt" > "$S/L7/l7_expect_blind.txt" 2>&1
+  for tag in sighted_seed0 blind_seed0; do
+    local sfx=""; [ $tag = blind_seed0 ] && sfx=_blind
+    bad=""
+    [ "$(exit_of "$S/L7/cand${sfx}_exit.txt")" = 0 ] || bad="$bad evaluate.py exit"
+    grep -aq 'force-plant-mismatch was given' "$S/L7/cand${sfx}_stdout.txt" && bad="$bad a forced mismatch"
+    grep -aq '^NO DIFFERENCE' "$S/L7/l7_diff${sfx}.txt" || bad="$bad l7_diff"
+    grep -aq '^VERDICT: every row equals the committed raw scores' "$S/L7/l7_expect${sfx}.txt" || bad="$bad l7_expect"
+    [ $tag = blind_seed0 ] && { [ "$(exit_of "$S/L7/ref_blind_exit.txt")" = 0 ] || bad="$bad cf43fbb's run exit"; }
+    R G6-agents --level L7 --item 3.6.14 --what "L7 evaluate.py end to end: X1's $tag (scratch model) on the twenty frozen Phase D episodes" \
+      --command "cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval${sfx}.txt L7/cand_model/$tag$( [ $tag = blind_seed0 ] && echo "; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0 (cf43fbb's own run: build step 1 scored sighted_seed0 only)"); python -I -B tools/l7_diff.py L7/ref_eval${sfx}.txt LIVE_REPO/runs/extremes_dt1/$tag L7/cand_eval${sfx}.txt L7/cand_model/$tag; python -I -B tools/l7_expect.py$( [ $tag = blind_seed0 ] && echo " --agent blind_seed0") --repo candg L7/cand_eval${sfx}.txt" \
+      --cwd candg --expected "evaluate.py exit 0 with no --force-plant-mismatch (no --reward-knock: absent reads 'in' on phase-d, row 138 (1)); NO DIFFERENCE after the fingerprint block and the model path, against cf43fbb's report$( [ $tag = sighted_seed0 ] && echo " (build step 1's L7/ref_eval.txt)" || echo " (made here in S/ref)"); VERDICT: every row equals the committed raw scores" \
+      --got "$( [ -z "$bad" ] && echo "exit 0; $(lf "$S/L7/l7_diff${sfx}.txt" | grep -a '^compared' | tail -1); NO DIFFERENCE; every row equals the committed raw scores" || echo "differs:$bad")" \
+      --verdict "$(verdict "$bad")" --seconds "$(lf "$S/L7/cand${sfx}_exit.txt" | grep -oE '^[0-9]+ s$' | grep -oE '[0-9]+' || echo 0)" \
+      --evidence "L7/cand${sfx}_stdout.txt" "L7/cand${sfx}_exit.txt" "L7/l7_diff${sfx}.txt" "L7/l7_expect${sfx}.txt"
+  done
+  # G6.4 evaluate.py --protocol d2 (finding 11), and X1's agent refused under d2
+  "$PY" -I -B "$SW/tools/l7_diff.py" "$SW/F11/ref_d2.txt" NONE "$SW/F11/cand_d2.txt" NONE --json "$SW/F11/d2_diff.json" > "$S/F11/d2_diff.txt" 2>&1
+  bad=""
+  [ "$(exit_of "$S/F11/cand_d2_exit.txt")" = 0 ] || bad="$bad exit"
+  grep -aq '^NO DIFFERENCE' "$S/F11/d2_diff.txt" || bad="$bad l7_diff"
+  R G6-agents --level L5 --item 3.6.10 --what "finding 11's d2: evaluate.py --protocol d2, the three hand-written policies on the twenty frozen D2 episodes, against cf43fbb's" \
+    --command "cd candg && python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; python -I -B tools/l7_diff.py F11/ref_d2.txt NONE F11/cand_d2.txt NONE --json F11/d2_diff.json" \
+    --cwd candg --expected "exit 0; NO DIFFERENCE (commit A: 23 lines compared after stripping)" \
+    --got "$( [ -z "$bad" ] && echo "exit 0; $(lf "$S/F11/d2_diff.txt" | grep -a '^compared' | tail -1); NO DIFFERENCE" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(lf "$S/F11/cand_d2_exit.txt" | grep -oE '^[0-9]+ s$' | grep -oE '[0-9]+' || echo 0)" \
+    --evidence F11/cand_d2_stdout.txt F11/cand_d2_exit.txt F11/d2_diff.txt
+  ( cd "$REPO" && "$PY" -B evaluate.py --engine b58 --protocol d2 --out "$SW/F11/cand_d2_x1.txt" "$SW/L7/cand_model/sighted_seed0" ) > "$S/F11/cand_d2_x1_stdout.txt" 2>&1
+  echo "exit $?" >> "$S/F11/cand_d2_x1_stdout.txt"
+  fields=$(lf "$S/F11/cand_d2_x1_stdout.txt" | awk '/PLANT MISMATCH/ { f = 1; next } f && /^     [a-z_]+ +model / { print $1; next } f { exit }' | LC_ALL=C sort | tr '\n' ' ' | sed 's/ $//')
+  bad=""
+  [ "$(exit_of "$S/F11/cand_d2_x1_stdout.txt")" != 0 ] || bad="$bad exit 0"
+  grep -aq 'PLANT MISMATCH' "$S/F11/cand_d2_x1_stdout.txt" && grep -aq '^REFUSING to evaluate' "$S/F11/cand_d2_x1_stdout.txt" || bad="$bad no refusal"
+  [ "$fields" = "episodes_sha scenario" ] || bad="$bad the fields [$fields]"
+  R G6-agents --level L5 --item 3.6.10 --what "finding 11's d2: X1's sighted_seed0 (L7's scratch model, schema 4) under --protocol d2 is refused" \
+    --command "cd candg && python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2_x1.txt L7/cand_model/sighted_seed0" \
+    --cwd candg --expected "PLANT MISMATCH on exactly scenario and episodes_sha (the protocol's two FATAL fields; the schema-4 block's other FATAL fields agree), REFUSING, a nonzero exit (the refusal is the expected outcome)" \
+    --got "$( [ -z "$bad" ] && echo "PLANT MISMATCH on [$fields], REFUSING, exit $(exit_of "$S/F11/cand_d2_x1_stdout.txt")" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence F11/cand_d2_x1_stdout.txt
+  say "G6 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= G7-suites
+one() {   # run_suites.sh's own function (CERT_PLAN_A.md G7): one <label> <dir> <command...>
+  local label=$1 dir=$2; shift 2
+  local s; s=$(date +%s)
+  ( cd "$dir" && "$@" ) > "$S/suites/$label.txt" 2>&1
+  echo "$? $(( $(date +%s) - s )) $label" >> "$S/suites/_status.txt"
+}
+st_of() { awk -v l="$1" '$3 == l { e = $1; s = $2 } END { print e " " s }' "$S/suites/_status.txt"; }
+suite_rec() {   # suite_rec LABEL ITEMS WHAT EXTRA_EXPECT EXTRA_BAD EXTRA_GOT [ARGS]: OK with its own Ran N, plus the extras
+  local label=$1 items=$2 what=$3 xe=$4 xb=$5 xg=$6 args=${7:--v} e s bad=""
+  read -r e s <<< "$(st_of "$label")"
+  [ "${e:-x}" = 0 ] || bad="$bad exit ${e:-none}"
+  ut_ok "$S/suites/$label.txt" || bad="$bad not OK"
+  bad="$bad$xb"
+  R G7-suites --level suite --item "$items" --what "$what" \
+    --command "one $label candg python -B ${label#cand_}.py${args:+ $args}" --cwd candg \
+    --expected "OK, with the run's own 'Ran N tests' (HP7.6: no count typed here)${xe:+; $xe}" \
+    --got "$( [ -z "$bad" ] && echo "$(ut_line "$S/suites/$label.txt")${xg:+; $xg}" || echo "differs:$bad; $(ut_line "$S/suites/$label.txt")")" \
+    --verdict "$(verdict "$bad")" --seconds "$(nz "$s")" --evidence "suites/$label.txt"
+}
+g7() {
+  local t0 t1 bad got xb xg c TCL e s
+  say "G7 begins"; t0=$(date +%s)
+  # (review fixes 3) the one G7 output whose record depends on the file's existence: a re-run without the MY2021
+  # and MY2023 lists must not record the first run's file (every other label is rewritten, and st_of reads the
+  # last suites/_status.txt line of each label, which is this run's)
+  rm -f "$S/suites/cand_test_epa_map_with_2021_2023.txt"
+  # G7.1 the MY2021 and MY2023 Test Car Lists: commit A's S/tcl (lists and package zips) copied, then the plan's fetch
+  t1=$(date +%s)
+  [ -d "$COMMIT_A_S/tcl" ] && [ ! -e "$S/tcl" ] && cp -a "$COMMIT_A_S/tcl" "$S/tcl"
+  ( cd "$REPO" && "$PY" -B fetch_engine_data.py --target "$SW/tcl" --group epa-test-car-list ) > "$S/suites/P_G7_fetch_tcl.txt" 2>&1
+  echo "exit $?" >> "$S/suites/P_G7_fetch_tcl.txt"
+  bad=""; [ "$(exit_of "$S/suites/P_G7_fetch_tcl.txt")" = 0 ] && grep -aq '^ALL VERIFIED' "$S/suites/P_G7_fetch_tcl.txt" || bad=" exit $(exit_of "$S/suites/P_G7_fetch_tcl.txt")"
+  R G7-suites --level suite --item 3.6.15 --what "G7.1: the MY2021 and MY2023 Test Car Lists, verified in S/tcl" \
+    --command "cp -a <commit A's S>/tcl S/tcl (its lists and the seven package zips, commit A's record 30); cd candg && python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list" \
+    --cwd candg --expected "exit 0, ALL VERIFIED (every file against logs/epa/D3_AND_EPA_SOURCES.csv's sha256; the script fetches only what is missing and writes only under the target)" \
+    --got "$( [ -z "$bad" ] && echo "exit 0, $(lf "$S/suites/P_G7_fetch_tcl.txt" | grep -a '^ALL VERIFIED' | cut -c1-100)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence suites/P_G7_fetch_tcl.txt
+  # G7.2 the suites in the clone, in three waves
+  one cand_test_wide_air "$REPO" "$PY" -B test_wide_air.py &
+  one cand_test_epa_map "$REPO" "$PY" -B test_epa_map.py -v &
+  if [ -d "$S/tcl/epa-test-car-list/MY2021" ] && [ -d "$S/tcl/epa-test-car-list/MY2023" ]; then
+    TCL=$(cygpath -m "$S/tcl/epa-test-car-list")
+    ( export GRAD_EXTRA_DATA="$TCL/MY2021;$TCL/MY2023"; one cand_test_epa_map_with_2021_2023 "$REPO" "$PY" -B test_epa_map.py -v ) &
+  fi
+  one cand_test_plant_guards "$REPO" "$PY" -B test_plant_guards.py -v &
+  one cand_random_road "$REPO" "$PY" -B random_road.py &
+  one cand_fingerprint "$REPO" "$PY" -B fingerprint.py --engine b58 &
+  wait
+  one cand_test_cars "$REPO" "$PY" -B test_cars.py -v &
+  one cand_test_trainable "$REPO" "$PY" -B test_trainable.py -v &
+  one cand_test_fuel_forms "$REPO" "$PY" -B test_fuel_forms.py -v &
+  one cand_test_carried "$REPO" "$PY" -B test_carried.py -v &
+  one cand_test_tit_cap "$REPO" "$PY" -B test_tit_cap.py -v &
+  one cand_test_epa_plants "$REPO" "$PY" -B test_epa_plants.py -v &
+  wait
+  one cand_test_preview_horizon "$REPO" "$PY" -B test_preview_horizon.py -v      # 8 worker processes: alone
+  suite_rec cand_test_wide_air "3.6.15, HP7.6" "test_wide_air.py" "" "" "" " "
+  suite_rec cand_test_epa_map 3.6.15 "test_epa_map.py (the team's data folder)" "" "" ""
+  if [ -f "$S/suites/cand_test_epa_map_with_2021_2023.txt" ]; then
+    suite_rec cand_test_epa_map_with_2021_2023 3.6.15 "test_epa_map.py again, GRAD_EXTRA_DATA naming the MY2021 and MY2023 Test Car Lists" "" "" "" \
+      "-v (GRAD_EXTRA_DATA=S/tcl/epa-test-car-list/MY2021;MY2023)"
+  else
+    say "NO RECORD: test_epa_map.py with the MY2021 and MY2023 lists: S/tcl lacks them"
+  fi
+  xb=""; cls_ok "$S/suites/cand_test_plant_guards.txt" GitDirtyPlantFiles || xb=" GitDirtyPlantFiles"
+  [ -z "$(fpv "$S/out/P_G1_fp_cand.txt" git_dirty_plant_files)" ] || xb="$xb G1.0's git_dirty_plant_files"
+  suite_rec cand_test_plant_guards "3.6.15, HA.10, HP7.6" "test_plant_guards.py" "HA.10: test_plant_guards.GitDirtyPlantFiles ok, and G1.0's git_dirty_plant_files empty" "$xb" "GitDirtyPlantFiles ok"
+  read -r e s <<< "$(st_of cand_random_road)"
+  bad=""; [ "$e" = 0 ] && grep -aq 'SELF-TEST PASSES' "$S/suites/cand_random_road.txt" || bad="$bad the self-test"
+  diff <(lf "$S/suites/ref_random_road.txt" | grep -av road_sha) <(lf "$S/suites/cand_random_road.txt" | grep -av road_sha) > "$S/suites/P_G7_random_road_diff.txt" 2>&1 || bad="$bad a line beside road_sha differs from cf43fbb's"
+  R G7-suites --level suite --item 3.6.15 --what "random_road.py self-test" --command "one cand_random_road candg python -B random_road.py; diff with suites/ref_random_road.txt, the road_sha line dropped" \
+    --cwd candg --expected "SELF-TEST PASSES; road_sha be19b3d0bcef435d, the only line unlike cf43fbb's (e44153fd81eeaa1e)" \
+    --got "$( [ -z "$bad" ] && echo "SELF-TEST PASSES; $(lf "$S/suites/cand_random_road.txt" | grep -aoE 'road_sha *:? *[0-9a-f]{16}' | head -1)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_random_road.txt suites/P_G7_random_road_diff.txt
+  read -r e s <<< "$(st_of cand_fingerprint)"
+  bad=""; [ "$e" = 0 ] && same "$S/suites/cand_fingerprint.txt" "$S/out/P_G1_fp_cand.txt" || bad=" differs from G1.0's"
+  R G7-suites --level suite --item "3.6.15, HA.10" --what "fingerprint.py --engine b58" --command "one cand_fingerprint candg python -B fingerprint.py --engine b58" \
+    --cwd candg --expected "exit 0; the block G1.0 printed (out/P_G1_fp_cand.txt), line for line" --got "$( [ -z "$bad" ] && echo "the same block" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_fingerprint.txt
+  xb=""; cls_ok "$S/suites/cand_test_fuel_forms.txt" EngineSha || xb=" EngineSha"
+  got=$(lf "$S/suites/cand_test_fuel_forms.txt" | grep -aoE 'engine_sha [0-9a-f]{16}; without \[[^]]*\]: [0-9a-f]{16}' | head -1)
+  [ "$(echo "$got" | awk '{ print $2 }' | tr -d ';')" = "$B58_ENGINE_SHA" ] || xb="$xb engine_sha"
+  [ "$(echo "$got" | awk '{ print $NF }')" = "$A_B11" ] || xb="$xb the build-step-1 key set's hash"
+  suite_rec cand_test_fuel_forms "3.6.15, HP7.1, B11, HP7.6" "test_fuel_forms.py (EngineSha: amendment B11)" \
+    "B11: EngineSha ok; its line 'engine_sha $B58_ENGINE_SHA; without [...]: $A_B11' (G1.0's engine_sha; commit A's certificate's over_build_step_1_keys, read from RV's results/B58_IDENTITY.json)" "$xb" \
+    "$(echo "$got" | sed -E 's/without \[[^]]*\]/without [...]/')"
+  suite_rec cand_test_cars "3.6.15, HP7.1, HP7.6" "test_cars.py" "" "" ""
+  suite_rec cand_test_carried "3.6.15, HP7.1, HP7.6" "test_carried.py (run_suites.sh quick does not run it)" "" "" ""
+  xb=""; for c in Help B58 RecordsAbsent SummaryDrop BackendDrop RealTree; do cls_ok "$S/suites/cand_test_trainable.txt" "$c" || xb="$xb $c"; done
+  suite_rec cand_test_trainable "3.6.15, HP7.1, B8, HP7.6" "test_trainable.py (B8: the refusals and their controls, SummaryDrop the literal case)" \
+    "B8: Help, B58, RecordsAbsent, SummaryDrop, BackendDrop and RealTree each ok" "$xb" \
+    "$(lf "$S/suites/cand_test_trainable.txt" | grep -aE 'engines\.trainable\(\)' | head -1 | cut -c1-120)"
+  xb=""; cls_ok "$S/suites/cand_test_preview_horizon.txt" BlindBitForBit || xb=" BlindBitForBit"
+  suite_rec cand_test_preview_horizon "R138-4 BlindBitForBit, 3.6.15" "test_preview_horizon.py, whole (BlindBitForBit; row 138 (4))" \
+    "BlindBitForBit ok" "$xb" "BlindBitForBit ok"
+  suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
+  suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
+  # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
+  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
+  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
+  ( cd "$REPO" && {
+      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
+      echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
+      echo "== HA.6"; grep -n -i "scipy" requirements.txt
+      echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
+    } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
+  bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
+  R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
+    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
+  bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
+  echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
+  R G7-suites --level docs --item HA.5 --what "README.md and full_run.py name the four test files" --command "grep -c <t>.py candg/README.md candg/full_run.py, t in test_fuel_forms test_cars test_carried test_trainable" \
+    --cwd candg --expected "each of the four named at least once in each document (README states no count for test_trainable.py; CERT_PLAN_P.md G7.4)" \
+    --got "$( [ -z "$bad" ] && echo "$(echo "$got" | tr '\n' ';')" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
+  bad=""; got=$(awk '/^== HA.6/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
+  echo "$got" | grep -qE 'scipy==' || bad=" no pin"; echo "$got" | grep -qi 'imported by nothing' && bad="$bad the old comment"
+  R G7-suites --level docs --item HA.6 --what "scipy pinned in requirements.txt" --command "grep -n -i scipy candg/requirements.txt" --cwd candg \
+    --expected "a scipy== pin and no 'imported by nothing'" --got "$( [ -z "$bad" ] && echo "$(echo "$got" | grep 'scipy==' | head -1)" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
+  bad=""; grep -q '^line 433: 0$' "$S/suites/P_G7_docs_checks.txt" || bad=" a line number cited"; grep -qE '^fuel properties: [1-9]' "$S/suites/P_G7_docs_checks.txt" || bad="$bad no row text"
+  R G7-suites --level docs --item HA.11 --what "engine_specs/b58.toml cites REFERENCES.md's row by its text" --command "grep -c 'line 433' and 'fuel properties' candg/engine_specs/b58.toml" \
+    --cwd candg --expected "no 'line 433'; the row cited by its text ('fuel properties')" --got "$( [ -z "$bad" ] && echo "as expected" || echo "differs:$bad")" \
+    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
+  # G7.5 verify_docs.py and drift_test (run_drift.sh) in the clone
+  one cand_verify_docs "$REPO" "$PY" -B verify_docs.py
+  read -r e s <<< "$(st_of cand_verify_docs)"
+  bad=""; got=$(lf "$S/suites/cand_verify_docs.txt" | grep -aE '^All [0-9]+ checks pass' | tail -1); [ "$e" = 0 ] && [ -n "$got" ] || bad=" exit $e"
+  R G7-suites --level docs --item 3.6.18 --what "verify_docs.py in the clone (P's candidate, before the sweep's document edits)" \
+    --command "one cand_verify_docs candg python -B verify_docs.py" --cwd candg \
+    --expected "exit 0, 'All N checks pass (M figure mentions scanned in the documents).' (the run's own numbers; p_gate.sh pre ran it on the same tree first: a failure there is known before this run)" \
+    --got "$( [ -z "$bad" ] && echo "$got" || echo "differs:$bad; $(lf "$S/suites/cand_verify_docs.txt" | tail -2 | tr '\n' ' ' | cut -c1-160)")" \
+    --verdict "$(verdict "$bad")" --seconds "${s:-0}" --evidence suites/cand_verify_docs.txt
+  t1=$(date +%s)
+  bash "$S/tools/run_drift.sh" > "$S/suites/P_G7_run_drift.txt" 2>&1
+  bad=""; got=$(lf "$S/suites/drift_test.txt" | grep -aE '^[0-9]+ of [0-9]+ drifts CAUGHT \(all parts\)' | tail -1)
+  [ -n "$got" ] && [ "$(echo "$got" | awk '{ print ($1 == $3 && $1 > 0) }')" = 1 ] || bad=" ${got:-no verdict line}"
+  [ "$(grep -h '^exit' "$S"/suites/drift_part*.txt | grep -vc '^exit 0 ')" = 0 ] || bad="$bad a part's exit"
+  R G7-suites --level docs --item 3.6.18 --what "run_drift.sh: drift_test.py in six parts, each with drift_test's own control" \
+    --command "bash tools/run_drift.sh (CAND = candg)" --cwd candg --expected "every part exit 0 (each runs drift_test's own control first); 'N of N drifts CAUGHT (all parts)' (commit A: 18 of 18)" \
+    --got "$( [ -z "$bad" ] && echo "$got; $(cat "$S/suites/drift_test_exit.txt" | cut -c1-120)" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+    --seconds "$(secs_since "$t1")" --evidence suites/drift_test.txt suites/drift_test_exit.txt
+  say "G7 ends ($(secs_since "$t0") s)"
+}
+
+# ============================================================================= run
+for G in $RUN_GROUPS; do      # one group at a time, each to its end (decisions/cert_groups.txt)
+  T=$(date +%s); "$G"; say "$G took $(secs_since "$T") s"
+done
+# the clone and the live repository's runs untouched: the clone clean at P_CAND
+if [ "$(git -C "$REPO" rev-parse HEAD)" != "$P_CAND" ] || [ -n "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ]; then
+  say "REFUSED: the clone is not clean at P_CAND after the groups"; BAD=1
+fi
+say "END cert_driver_P.sh after $(secs_since "$DRIVER_T0") s; records: $(cat "$S"/cert_results/*.json | grep -c '"verdict": "PASS"') PASS, $(cat "$S"/cert_results/*.json | grep -c '"verdict": "FAIL"') FAIL; driver refusals: $( [ "$BAD" = 0 ] && echo none || echo "at least one (the REFUSED lines above)")"
+[ "$BAD" = 0 ] || exit 3
+exit 0
```

### tools/cert_final_driver_P.sh

commit A: no such file (new in P)
commit P: sha256 f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1

```diff
--- commit A: tools/cert_final_driver_P.sh
+++ commit P: tools/cert_final_driver_P.sh
@@ -0,0 +1,172 @@
+#!/usr/bin/env bash
+# cert_final_driver_P.sh -- P's B58 identity certificate, F.1 and F.2 (CERT_FINAL_DRIVER of p_gate.sh; P_GATE_PLAN.md
+# 5.2, K8). DRAFT of 7 November 2026, NOT RUN. Read INTEGRATION.md first.
+#
+#     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_final_driver_P.sh
+#
+# p_gate.sh's phase cert-final runs it, after post (test_engine_threading alone, the certificate's G7.0, recorded
+# in G7-suites). It writes, in this order:
+#   F.1  the end fingerprint (out/P_end_fp_cand.txt) and the end manifest (manifest_end_P.txt), one record each;
+#   HP7.6 every test count README.md and full_run.py state, against the runs (tools/stated_counts_P.py): it
+#        needs G7.0's count, so it runs here and not in G7.4;
+#   3.6.19's record: the certificate made from every record once (cert_out/P_F2_draft0.*), its print-out read;
+#        the only item open then is 3.6.19 itself, which this record answers;
+#   F.2  the draft certificate, cert_out/B58_IDENTITY.json and .md, make_cert.py's print-out kept in
+#        cert_out/make_cert_stdout.txt (p_gate.sh reads it: every check ok, no PROBLEM, FAIL or MISSING line);
+#   a pre-check that is no record: verify_docs.py in a copy of the clone with the draft in results/
+#        (cert_out/P_F2_verify_docs_precheck.txt), so that a figure verify_docs.py would refuse in the page is
+#        seen before p_gate.sh cert-docs, where the page_markers of cert_P.json can no longer change.
+# Exit 0 when it wrote what it should, whatever the verdicts (p_gate.sh judges the draft); 3 on a refusal of
+# its own (cert_record.py refused a record, an input is missing, the clone is not clean, or, before any record, a
+# FAIL record that no later PASS re-checks: review fixes 3); 2 if it cannot start.
+# No `set -u` and no `set -e`, as cert_driver_P.sh.
+[ -n "${CERT_S:-}" ] || { echo "cert_final_driver_P.sh: CERT_S is unset (p_gate.sh exports it)" >&2; exit 2; }
+# shellcheck source=/dev/null
+source "$CERT_S/env_P.sh" || { echo "cert_final_driver_P.sh: env_P.sh refused" >&2; exit 2; }
+cd "$REPO" || exit 2
+REPORT="$S/out/P_final_driver_report.txt"
+RECLOG="$S/out/P_final_driver_records.log"
+BAD=0
+say() { echo "$(date -u +%FT%TZ) $*" | cut -c1-400 | tee -a "$REPORT"; }
+R() { rec "$@" >> "$RECLOG" 2>&1 || { say "REFUSED by cert_record.py (group $1): see $RECLOG"; BAD=1; }; }
+verdict() { [ -z "$1" ] && echo PASS || echo FAIL; }
+lf() { tr -d '\r' < "$1"; }
+same() { cmp -s <(lf "$1") <(lf "$2"); }
+secs_since() { echo $(( $(date +%s) - $1 )); }
+
+say "BEGIN cert_final_driver_P.sh in $(pwd); P_CAND ${P_CAND:0:12}"
+[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean"; exit 3; }
+for f in out/P_G1_fp_cand.txt manifest_start_P.txt suites/P_test_engine_threading.txt cert_P.json tools/make_cert.py \
+         tools/make_md.py tools/manifest.py tools/stated_counts_P.py tools/copy_tree.py; do
+  [ -f "$S/$f" ] || { say "REFUSED: S lacks $f (post and cert run first)"; exit 3; }
+done
+mkdir -p "$S/cert_out"
+
+# ---- (review fixes 3, 7 November 2026) no record while a FAIL record is open. A FAIL that no later PASS record of
+# its own file re-checks (make_cert.py's _rechecks rule, which p_gate.sh's cert_fail_list reads alike) would make
+# the 3.6.19 record below a FAIL, and no run can re-check a record of this driver (cert-recheck runs g1 ... g7):
+# the certificate would be stuck until a new S. So the driver refuses before its first record (exit 3; it writes
+# nothing in cert_results): re-check the group (cert-recheck <g>), then post and cert-final again. A FAIL record of
+# a group no driver group writes again (G0-prepare, G1.0, G7.3, G7.0, HP7.6, F-certificate) needs a new S.
+"$PY" -I -B - "$SW" > "$S/out/P_F0_open_fails.txt" 2>&1 <<'EOF'
+import glob, json, os, re, sys
+S = sys.argv[1]
+out = []
+for f in sorted(glob.glob(os.path.join(S, "cert_results", "*.json"))):
+    name = os.path.basename(f)
+    try:
+        with open(f, encoding="utf-8") as fh:
+            rows = json.load(fh)
+    except Exception as e:                                      # unreadable: nothing can be judged
+        out.append(f"{name}: unreadable ({type(e).__name__})")
+        continue
+    if not isinstance(rows, list):
+        out.append(f"{name}: not a list of records")
+        continue
+    closed = set()
+    for i, r in enumerate(rows):                                # a later PASS (or "PASS (<why>)") that names it
+        if not isinstance(r, dict) or not r.get("rechecks"):
+            continue
+        v = r.get("verdict")
+        m = re.search(r"([\w-]+\.json) record (\d+)", str(r.get("rechecks")))
+        if m and m.group(1) == name and int(m.group(2)) < i + 1 and isinstance(v, str) and re.match(r"^PASS( \(.+\))?$", v):
+            closed.add(int(m.group(2)))
+    for i, r in enumerate(rows):
+        if isinstance(r, dict) and r.get("verdict") == "FAIL" and (i + 1) not in closed:
+            out.append(f"{name} record {i + 1}: OPEN FAIL, item {r.get('item')}: {r.get('what')}")
+print("\n".join(out) if out else "no open FAIL record")
+raise SystemExit(1 if out else 0)
+EOF
+rc=$?
+if [ "$rc" != 0 ]; then
+  say "REFUSED: a FAIL record is open, or a record file unreadable ($(grep -c . "$S/out/P_F0_open_fails.txt") lines, out/P_F0_open_fails.txt): no record written; cert-recheck <g> first (a FAIL of G0-prepare, G1.0, G7.3, G7.0, HP7.6 or F-certificate needs a new S)"
+  exit 3
+fi
+
+# ---- F.1 the end of the run: nothing may have changed in the clone
+t0=$(date +%s)
+( cd "$REPO" && "$PY" -B fingerprint.py --engine b58 ) > "$S/out/P_end_fp_cand.txt" 2>&1; rc=$?
+bad=""; [ "$rc" = 0 ] || bad=" exit $rc"; same "$S/out/P_end_fp_cand.txt" "$S/out/P_G1_fp_cand.txt" || bad="$bad the block differs from G1.0's"
+R F-certificate --level identity --item "3.6.1, HA.10" --what "F.1: the candidate's fingerprint at the end of the run" \
+  --command "cd candg && python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; compared line for line with out/P_G1_fp_cand.txt" \
+  --cwd candg --expected "exit 0; the block G1.0 printed, every field the same (plant_sha $(awk '$1 == "plant_sha" { print $2 }' "$S/out/P_G1_fp_cand.txt"), git_dirty False, git_head P_CAND)" \
+  --got "$( [ -z "$bad" ] && echo "the same block" || echo "differs:$bad")" --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" \
+  --evidence out/P_end_fp_cand.txt out/P_G1_fp_cand.txt
+t0=$(date +%s)
+"$PY" -I -B "$SW/tools/manifest.py" "$RW" "$SW/manifest_end_P.txt" > "$S/out/P_F1_manifest.txt" 2>&1; rc=$?
+git -C "$REPO" status --porcelain=v1 --untracked-files=all > "$S/out/P_F1_git_status_end.txt"
+bad=""; [ "$rc" = 0 ] || bad=" exit $rc"; cmp -s "$S/manifest_start_P.txt" "$S/manifest_end_P.txt" || bad="$bad the manifests differ"
+[ ! -s "$S/out/P_F1_git_status_end.txt" ] || bad="$bad git status"
+R F-certificate --level manifest --item 3.6.1 --what "F.1: the candidate manifest at the end against the start" \
+  --command "python -I -B tools/manifest.py candg manifest_end_P.txt; cmp manifest_start_P.txt manifest_end_P.txt; git -C candg status --porcelain --untracked-files=all" \
+  --cwd S --expected "the two manifests identical; the clone's status empty (cert_P.json declares no file changed during the run)" \
+  --got "$( [ -z "$bad" ] && echo "identical ($(grep -c . "$S/manifest_end_P.txt") files); status empty" || echo "differs:$bad")" \
+  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence manifest_end_P.txt out/P_F1_git_status_end.txt
+
+# ---- HP7.6 every stated test count against its run (G7.4's last check, after G7.0)
+t0=$(date +%s)
+M=()
+for t in test_plant_guards test_fuel_forms test_cars test_carried test_trainable test_wide_air test_epa_map \
+         test_preview_horizon test_tit_cap test_epa_plants; do
+  M+=("$t=$SW/suites/cand_$t.txt")
+done
+M+=("test_engine_threading=$SW/suites/P_test_engine_threading.txt")
+for t in test_agents test_simulation test_results; do M+=("app.$t=$SW/app/cand_$t.txt"); done
+"$PY" -I -B "$SW/tools/stated_counts_P.py" "$RW" "${M[@]}" > "$S/suites/P_F_stated_counts.txt" 2>&1; rc=$?
+bad=""; [ "$rc" = 0 ] || bad=" exit $rc"
+R G7-suites --level docs --item HP7.6 --what "every test count README.md and full_run.py state, against its run (G7.4, after G7.0)" \
+  --command "python -I -B tools/stated_counts_P.py candg <suite>=<its output> for the suites G5, G7 and G7.0 ran (suites/P_F_stated_counts.txt)" \
+  --cwd S --expected "every statement of '<N> tests' in candg's README.md and full_run.py names a suite this certificate ran, and each count (and stated skip count) equals that run's 'Ran N tests' (and skipped=K); exit 0" \
+  --got "$(lf "$S/suites/P_F_stated_counts.txt" | grep -a '^HP7.6:' | tail -1)$( [ -n "$bad" ] && echo "; $(lf "$S/suites/P_F_stated_counts.txt" | grep -avE '^(equal|HP7.6:)' | head -3 | tr '\n' ' ' | cut -c1-240)")" \
+  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence suites/P_F_stated_counts.txt
+
+# ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
+t0=$(date +%s)
+# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
+# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
+# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
+head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
+bad=""
+[ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
+[ "$rc2" = 0 ] || bad="$bad make_md exit $rc2"
+# (review fixes 2) While 3.6.19 has no record, make_cert.py prints "  NO  every item of the re-run list answered"
+# by construction: that one line is dropped, and the next test keeps 3.6.19 the only item MISSING, so the line is
+# 3.6.19's alone (any other unanswered item prints its own "  FAIL item" or "  MISSING item" line). A "  FAIL {...}"
+# line is accepted only for a FAIL record that a later PASS re-checks (make_cert.py's dict ends with a non-empty
+# 'rechecked_by'), and only with the "ok  every record PASS, or a FAIL that a later PASS record re-checks" line.
+lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aE '^  (NO  |PROBLEM |FAIL )' \
+  | grep -avxF '  NO  every item of the re-run list answered' \
+  | grep -avE "^  FAIL \{.*'rechecked_by': \['[^]]+'\]\}$" | grep -aq . && bad="$bad a check NO, a PROBLEM or a FAIL"
+lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aqxF '  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)' \
+  || bad="$bad the records' check is not ok"
+got=$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -aE '^  MISSING ' | grep -avE '^  MISSING item 3\.6\.19:' | wc -l)
+[ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
+[ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
+R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
+  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
+  --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
+  --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
+  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt
+
+# ---- F.2 the draft certificate in scratch
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
+say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
+[ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }
+
+# ---- the pre-check (no record): verify_docs.py with the draft in a copy of the clone
+V="$CERT_ROOT/vdcheck_P"; rm -rf "$V"
+if "$PY" -I -B "$SW/tools/copy_tree.py" "$RW" "$(cygpath -m "$V")" > "$S/cert_out/P_F2_verify_docs_copy.txt" 2>&1; then
+  cp -p "$S/cert_out/B58_IDENTITY.json" "$V/results/B58_IDENTITY.json"; cp -p "$S/cert_out/B58_IDENTITY.md" "$V/results/B58_IDENTITY.md"
+  ( cd "$V" && "$PY" -B verify_docs.py ) > "$S/cert_out/P_F2_verify_docs_precheck.txt" 2>&1
+  say "pre-check, no record: verify_docs.py with the draft in a copy of the clone: exit $? ($(lf "$S/cert_out/P_F2_verify_docs_precheck.txt" | grep -aE '^All [0-9]+ checks pass|FAIL' | head -2 | tr '\n' ' ' | cut -c1-200)); cert_out/P_F2_verify_docs_precheck.txt"
+else
+  say "pre-check not run: copy_tree.py into $V failed"
+fi
+rm -rf "$V"
+[ -z "$(git -C "$REPO" status --porcelain=v1 --untracked-files=all)" ] || { say "REFUSED: the clone is not clean at the end"; BAD=1; }
+say "END cert_final_driver_P.sh; refusals: $BAD"
+[ "$BAD" = 0 ] || exit 3
+exit 0
```

### tools/cert_record.py

commit A: sha256 dc4850149ae586bb76496354efc1b905809647ce9fa08e90d2c33b20e4ac76fd
commit P: sha256 c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3

```diff
--- commit A: tools/cert_record.py
+++ commit P: tools/cert_record.py
@@ -15,6 +15,13 @@
 the group's report instead). The file is rewritten whole through a temporary file and
 os.replace, so a reader never sees half a list; one group writes one file, so two groups never
 race on a file.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): an optional
+--rechecks "<group>.json record <n>" is carried into the record as "rechecks", the field
+make_cert.py's _rechecks() (commit A's final step) pairs with an earlier FAIL of the same file.
+Commit A wrote that field by editing its records afterwards; P's route after a FAIL (a re-check
+record, written by hand once the cause is read) writes it here. Without --rechecks a record is
+what it was.
 """
 import argparse
 import json
@@ -33,6 +40,7 @@
 ap.add_argument("--what")
 ap.add_argument("--environment")
 ap.add_argument("--difference")
+ap.add_argument("--rechecks")                  # (commit P) "<group>.json record <n>": the FAIL this record re-checks
 a = ap.parse_args()
 
 if not a.group.replace("-", "").replace("_", "").isalnum():
@@ -40,7 +48,7 @@
 rec = dict(level=a.level, item=a.item, command=a.command, cwd=a.cwd, expected=a.expected, got=a.got,
            verdict=a.verdict, seconds=round(a.seconds, 1),
            evidence_files=[e.replace("\\", "/") for e in a.evidence])
-for k in ("what", "environment", "difference"):
+for k in ("what", "environment", "difference", "rechecks"):
     if getattr(a, k):
         rec[k] = getattr(a, k)
 missing = [e for e in rec["evidence_files"]
```

### tools/check_l6.sh

commit A: sha256 06be554f8fab326ba159c939e38a3cd92eb199043f1181a0a341173dab302501
commit P: sha256 6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b

```diff
--- commit A: tools/check_l6.sh
+++ commit P: tools/check_l6.sh
@@ -1,15 +1,17 @@
 #!/usr/bin/env bash
 # check_l6.sh -- L6's three comparisons for each agent: cand vs ref (every value, tobytes),
 # each tree vs the committed raw scores (full precision) and eval_record.npz (per step)
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): cmp.py and l6_check.py start with
+# -I -B. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 mkdir -p $S/cmp
 for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
   echo "=================== $tag"
   echo "--- candidate against reference"
-  $PY -I $S/tools/cmp.py $S/L6/ref_$tag.npz $S/L6/cand_$tag.npz --quiet --json $S/cmp/L6_$tag.json
+  $PY -I -B $S/tools/cmp.py $S/L6/ref_$tag.npz $S/L6/cand_$tag.npz --quiet --json $S/cmp/L6_$tag.json
   for t in cand ref; do
     echo "--- $t against the committed files"
-    $PY -I $S/tools/l6_check.py $S/L6/${t}_$tag.npz $tag --json $S/cmp/L6_${t}_${tag}_committed.json
+    $PY -I -B $S/tools/l6_check.py $S/L6/${t}_$tag.npz $tag --json $S/cmp/L6_${t}_${tag}_committed.json
   done
 done
```

### tools/compare_all.sh

commit A: sha256 2220420c6c97787868fd5b35ecaf73f1fb144683f3d2a33068d7a06c64ca3c5c
commit P: sha256 2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5

```diff
--- commit A: tools/compare_all.sh
+++ commit P: tools/compare_all.sh
@@ -1,5 +1,7 @@
 #!/usr/bin/env bash
 # compare_all.sh <label_a> <label_b> -- every harness job finished in both, compared (cmp.py), one line each
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): cmp.py starts with -I -B (-I ignores
+# PYTHONDONTWRITEBYTECODE). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 A=$1; B=$2; mkdir -p $S/cmp/${A}_vs_$B
@@ -7,6 +9,6 @@
 tr -d '\r' < $S/out/$A/_status.txt | while read -r rc secs job; do
   f=$(echo "$job" | sed -E 's/[^A-Za-z0-9.-]+/_/g; s/^_+|_+$//g')
   grep -q " $job\$" $S/cmp/${A}_vs_$B/_b_status.txt || continue
-  line=$($PY -I $S/tools/cmp.py $S/out/$A/$f.npz $S/out/$B/$f.npz --quiet --json $S/cmp/${A}_vs_$B/$f.json | tail -1)
+  line=$($PY -I -B $S/tools/cmp.py $S/out/$A/$f.npz $S/out/$B/$f.npz --quiet --json $S/cmp/${A}_vs_$B/$f.json | tail -1)
   echo "$job | $line"
 done
```

### tools/failing_sets_P.py

commit A: no such file (new in P)
commit P: sha256 56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc

```diff
--- commit A: tools/failing_sets_P.py
+++ commit P: tools/failing_sets_P.py
@@ -0,0 +1,67 @@
+"""failing_sets_P.py -- the tests that fail in a candidate's run and in no reference run (P's G5).
+
+    python -I -B failing_sets_P.py <candidate output> <reference output> [<reference output> ...]
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"). New in P. CERT_PLAN_A.md
+G5.1 compared a suite's failing sets with a one-line snippet (the candidate's run against cf43fbb's git
+clone). P compares the candidate's run with every reference run it is given (cf43fbb's clone, commit A's
+candidate run, RV's base run) and reads the two layouts the runs write:
+  unittest   "FAIL: <test> (<id>)" and "ERROR: <test> (<id>)", a failed subTest's " [<msg>]" ignored
+  node       "✖ <name> (<time>)" of node --test's spec reporter (its "✖ failing tests:" heading, which
+             has no time, is not a test)
+A unittest failure is named by the last two dotted parts of its id ("<Class>.<test>"), so that a run
+started as `python -m app.x` (ids "__main__....") and one started as `-m unittest app.x` name the same
+test alike; a node failure by its printed name.
+
+Prints the candidate's failing set, each reference's, "candidate only: [...]" (failing in the candidate
+and in no reference), "both: [...]" and the reference files that do not exist. Exit 0 when the
+candidate's output exists and "candidate only" is empty; 1 when it is not empty; 2 when the candidate's
+output does not exist. It judges failures only: whether a run completed is the caller's check.
+"""
+import os
+import re
+import sys
+
+UNITTEST = re.compile(r"^(?:FAIL|ERROR): (\S+) \(([^)]*)\)", re.M)
+NODE = re.compile(r"^\s*✖ (.+?) \([0-9.]+m?s\)\s*$", re.M)
+# (review fixes 2, 7 November 2026) a fixture's error names its class (or module) in the parentheses, whose
+# module part differs between `python -m app.x` ("__main__.Class") and `-m unittest app.x` ("app.x.Class"):
+# it is named "<Class>.<fixture>" alike in both
+FIXTURES = ("setUpClass", "tearDownClass", "setUpModule", "tearDownModule")
+
+
+def failing(path):
+    """The set of failing tests one output names."""
+    with open(path, encoding="utf-8", errors="replace") as fh:
+        text = fh.read().replace("\r\n", "\n")
+    out = set()
+    for test, ident in UNITTEST.findall(text):
+        parts = ident.split(".")
+        if test in FIXTURES:       # "ERROR: setUpClass (<module>.<Class>)": the id is the class, not a test
+            out.add(f"{parts[-1] if test.endswith('Class') else '<module>'}.{test}")
+        else:
+            out.add(".".join(parts[-2:]) if len(parts) >= 2 else f"{ident}.{test}")
+    for name in NODE.findall(text):
+        out.add(name.strip())
+    return out
+
+
+cand, refs = sys.argv[1], sys.argv[2:]
+if not os.path.isfile(cand):
+    print(f"MISSING: the candidate's output {cand}")
+    sys.exit(2)
+c = failing(cand)
+seen, missing = set(), []
+for r in refs:
+    if not os.path.isfile(r):
+        missing.append(r)
+        continue
+    f = failing(r)
+    seen |= f
+    print(f"reference {r}: {len(f)} failing: {sorted(f)}")
+print(f"candidate {cand}: {len(c)} failing: {sorted(c)}")
+print("references missing:", missing or "none")
+only = sorted(c - seen)
+print("candidate only:", only)
+print("both:", sorted(c & seen))
+sys.exit(1 if only else 0)
```

### tools/l7_expect.py

commit A: sha256 955fb2e4b526ed139f808d719903e1ad60bfe9e34e630595eab79197cad1be55
commit P: sha256 72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164

```diff
--- commit A: tools/l7_expect.py
+++ commit P: tools/l7_expect.py
@@ -4,6 +4,14 @@
 largest episode peak), then looked for in the two reports.
 
     python l7_expect.py <report.txt> [<report.txt> ...]
+    python l7_expect.py --agent blind_seed0 --repo <tree> <report.txt> ...      (build step 2, commit P)
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"; CERT_PLAN_P.md G6.3: L7 scores
+blind_seed0 beside sighted_seed0): --agent <tag> names X1's agent whose rows are rebuilt (default
+sighted_seed0, as before), and --repo <tree> the tree whose committed raw scores are read (default
+the repository, as before). evaluate.py labels the blinded agent's rows "agent (blind) <path>", which
+start with "agent" as the sighted agent's do, so the rows are found as before. Without the two
+options the tool is unchanged.
 """
 import json
 import sys
@@ -11,9 +19,24 @@
 import numpy as np
 
 REPO = r"C:\Users\badcl\Desktop\GRAD-project"
+ARGS = sys.argv[1:]
+
+
+def _opt(name, default):
+    """(commit P) one '--name value' pair taken out of the arguments, or the default."""
+    if name in ARGS:
+        i = ARGS.index(name)
+        value = ARGS[i + 1]
+        del ARGS[i:i + 2]
+        return value
+    return default
+
+
+AGENT = _opt("--agent", "sighted_seed0")
+REPO = _opt("--repo", REPO)
 raw = json.load(open(f"{REPO}/results/phase_d_extremes_dt1_raw.json", encoding="utf-8"))
 POL = {"baseline ECU": "baseline ECU", "reactive": "reactive", "current-grade": "current-grade",
-       "agent": "runs/extremes_dt1/sighted_seed0"}
+       "agent": f"runs/extremes_dt1/{AGENT}"}
 
 
 def rows_of(label):
@@ -37,7 +60,7 @@
 cuts = {n: f"cuts median damage {100 * (1 - np.median([r['damage'] for r in rows_of(l)]) / base):5.1f} %"
         for n, l in POL.items() if n != "baseline ECU"}
 ok_all = True
-for rep in sys.argv[1:]:
+for rep in ARGS:
     text = open(rep, encoding="utf-8").read().splitlines()
     print(f"== {rep}")
     for name, tail in expect.items():
```

### tools/make_cert.py

commit A: sha256 583a69d36ff1716370331cefd3789905d14da637d0dfdd9fdcf67f94c9ccafa8
commit P: sha256 28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea

```diff
--- commit A: tools/make_cert.py
+++ commit P: tools/make_cert.py
@@ -7,6 +7,28 @@
 of build step 2 is written by commit_a() from the run groups' records and the run's own
 files, as the config names them; without it, build step 1's certificate, as before.
 
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"; P_GATE_PLAN.md D21
+and 5.2 K5). Four changes, all inside the --config route; without --config nothing changed:
+  1. The candidate's git questions (HEAD, the branch, base..HEAD, the base, the previous
+     certificate's blob, cf43fbb's archive) are asked in the config's candidate.tree, when it
+     names one (P's certificate: the clone at P's candidate, committed and clean), and in REPO
+     otherwise, as before. x1_meta is still read in REPO (runs/ is gitignored, in no clone).
+     candidate.branch, when the config gives it, is written instead of git's answer (a
+     detached HEAD answers "HEAD").
+  2. Fingerprint schema 4 prints gears and final_drive inside one field, transmission, and
+     backend as train_backend, score_backend and backend_contract. The shared FATAL fields read
+     gears and final_drive out of the candidate's transmission field when its block has no field
+     of either name; the plant's fields through the run add the schema-4 fields; the identity
+     gains backends. A schema-3 block (commit A's) is read as before.
+  3. A previous certificate of certificate_format 2 (commit A's) holds engine_sha as a dict: its
+     candidate's value is the previous engine_sha, and its own reading over build step 1's key
+     set is what amendment B11's check compares with. With such a certificate one check is added:
+     engine_sha is the previous certificate's candidate's (row 94: P moves plant_sha, not
+     engine_sha). Build step 1's certificate (format 1, one value) is read as before.
+  4. The config's page_text, when it has one, is carried into the JSON for make_md.py.
+With commit A's config (no candidate.tree, no candidate.branch, no page_text, a schema-3
+candidate and build step 1's previous certificate) the JSON is byte for byte what it was.
+
 Every value below is READ from a file the certification wrote (the dumps'
 comparisons, the suites' outputs, the manifests, review.json); nothing is typed
 except the descriptions. A level whose evidence file is missing is written as
@@ -179,14 +201,33 @@
     return (a if r.startswith("..") else r).replace("\\", "/")
 
 
+_GIT_TREE = REPO        # (commit P) where the candidate's git questions are asked: commit_a() sets it
+
+
 def _git_out(*args, binary=False):
-    """git's stdout in REPO, or None."""
-    r = __import__("subprocess").run(["git", *args], cwd=REPO, capture_output=True)
+    """git's stdout in the candidate's tree (REPO, or since commit P the config's candidate.tree), or None."""
+    r = __import__("subprocess").run(["git", *args], cwd=_GIT_TREE, capture_output=True)
     if r.returncode != 0:
         return None
     return r.stdout if binary else r.stdout.decode("utf-8", errors="replace")
 
 
+def _with_transmission(f):
+    """(commit P, 7 November 2026; TOOL_EDITS.md, "commit P") A fingerprint's fields, with gears and final_drive
+    read out of schema 4's transmission field ("final_drive=3.15 gears=5.25 ... kind=stepped") when the block
+    has no field of either name; any other block (schema 3, commit A's) is returned as it is. The values are
+    the block's own text: nothing is typed."""
+    t = f.get("transmission") if isinstance(f, dict) else None
+    if not t or "gears" in f or "final_drive" in f:
+        return f
+    m = re.match(r"^final_drive=(\S+) gears=(.+?) kind=(\S+)$", t)
+    return f if m is None else dict(f, final_drive=m.group(1), gears=m.group(2))
+
+
+SCHEMA4_STABLE = ("train_backend", "score_backend", "backend_contract", "transmission", "preview_h_s",
+                  "reward_knock", "preview_samples_s")      # (commit P) schema 4's FATAL fields beyond schema 3's
+
+
 def _text(path):
     try:
         with open(_cfg_path(path), encoding="utf-8", errors="replace") as fh:
@@ -371,8 +412,11 @@
 
 def commit_a(config_path):
     import datetime
+    global _GIT_TREE
     with open(config_path, encoding="utf-8") as fh:
         cfg = json.load(fh)
+    # (commit P) the candidate's own git tree, when the config names one; REPO otherwise, as before
+    _GIT_TREE = (cfg.get("candidate") or {}).get("tree") or REPO
     files, records, problems = _records(cfg.get("results", "cert_results/*.json"))
     rechecked = _rechecks(records, problems)                         # (F, 23 Oct)
     fpc = cfg["fingerprints"]
@@ -413,7 +457,8 @@
     base = cc.get("base")
     log = _git_out("log", "--format=%h %s", f"{base}..HEAD") if base else None
     out["candidate"] = dict(
-        tree=REPO, branch=(_git_out("rev-parse", "--abbrev-ref", "HEAD") or "").strip() or None, head=head,
+        tree=cc.get("tree") or REPO,                                   # (commit P) the configured tree
+        branch=cc.get("branch") or (_git_out("rev-parse", "--abbrev-ref", "HEAD") or "").strip() or None, head=head,
         base=base, base_commit=(_git_out("rev-parse", base) or "").strip() or None if base else None,
         commits_on_base=None if log is None else log.strip().splitlines()[::-1],
         head_note=cc.get("head_note"),
@@ -440,8 +485,16 @@
     # the identity
     shared = ("gears", "final_drive", "dtheta_deg", "turb_protect_k", "oil_protect_k", "scenario", "episodes_sha",
               "eval_dt", "eval_duration", "n_episodes")
-    stable = {k: (f_cand.get(k) == f_end.get(k)) if f_end else MISSING
-              for k in ("plant_sha", "plant_text_sha", "derived_sha", "engine", "engine_sha", "backend")}
+    fcv = _with_transmission(f_cand)               # (commit P) schema 4: gears and final_drive in transmission
+    st_keys = ("plant_sha", "plant_text_sha", "derived_sha", "engine", "engine_sha", "backend")
+    if "train_backend" in f_cand:                  # (commit P) schema 4: backend is two fields and a contract
+        st_keys = st_keys[:-1] + SCHEMA4_STABLE
+    stable = {k: (f_cand.get(k) == f_end.get(k)) if f_end else MISSING for k in st_keys}
+    pe = prev_id.get("engine_sha")
+    if isinstance(pe, dict):       # (commit P) certificate_format 2 (commit A's): its candidate's, and its B11 reading
+        prev_es, prev_b11 = pe.get("candidate"), pe.get("over_build_step_1_keys")
+    else:                          # build step 1's certificate: one value, over build step 1's key set
+        prev_es, prev_b11 = pe, pe
     ex11 = extracts.get("engine_sha_over_build_step_1_keys", {}).get("groups")
     out["identity"] = dict(
         plant_sha=dict(reference=f_ref.get("plant_sha"), candidate=f_cand.get("plant_sha"),
@@ -452,10 +505,10 @@
                          x1_meta_json=(x1 or {}).get("derived_sha"),
                          previous_certificate=(prev_id.get("derived_sha") or {}).get("candidate")),
         engine=f_cand.get("engine"), backend=f_cand.get("backend"),
-        engine_sha=dict(candidate=f_cand.get("engine_sha"), previous_certificate=prev_id.get("engine_sha"),
+        engine_sha=dict(candidate=f_cand.get("engine_sha"), previous_certificate=prev_es,
                         over_build_step_1_keys=ex11[1] if isinstance(ex11, list) and len(ex11) > 1 else MISSING,
                         printed_by=extracts.get("engine_sha_over_build_step_1_keys", {}).get("file")),
-        shared_fatal_fields={k: [f_ref.get(k), f_cand.get(k)] for k in shared},
+        shared_fatal_fields={k: [f_ref.get(k), fcv.get(k)] for k in shared},
         fields_only_in_the_candidate=sorted(set(f_cand) - set(f_ref)),
         git=dict(git_head=f_cand.get("git_head"), git_dirty=f_cand.get("git_dirty"),
                  git_dirty_plant_files=f_cand.get("git_dirty_plant_files")),
@@ -466,6 +519,16 @@
                                   archive_sha256=(prev.get("archive") or {}).get("sha256")),
         read_from_runs=extracts,
         notes=cfg.get("notes") or {})
+    # (commit P) schema 4: what computes the engine in training and in scoring, and the contract; the shared
+    # fields read out of transmission; commit A's B11 reading of build step 1's key set. Each key is added only
+    # when it applies, so a schema-3 candidate against build step 1's certificate writes the JSON as before.
+    if "train_backend" in f_cand:
+        out["identity"]["backends"] = dict(train=f_cand.get("train_backend"), score=f_cand.get("score_backend"),
+                                           contract=f_cand.get("backend_contract"))
+    if fcv is not f_cand:
+        out["identity"]["shared_read_from_transmission"] = ["gears", "final_drive"]
+    if isinstance(pe, dict):
+        out["identity"]["engine_sha"]["over_build_step_1_keys_in_previous_certificate"] = prev_b11
 
     # the environment
     freeze = _text(cfg["pip_freeze"]) if cfg.get("pip_freeze") else None
@@ -568,14 +631,18 @@
         f_ref.get("derived_sha") == f_cand.get("derived_sha"),
         "engine_sha over build step 1's keys is build step 1's (B11)": (
             out["identity"]["engine_sha"]["over_build_step_1_keys"] not in (MISSING, None)
-            and out["identity"]["engine_sha"]["over_build_step_1_keys"]
-            == out["identity"]["engine_sha"]["previous_certificate"]),
+            and out["identity"]["engine_sha"]["over_build_step_1_keys"] == prev_b11),    # (commit P) prev_b11
         "the repository unchanged during the run (manifests), but for the files the config declares, none a plant "
         "file": (m0 is not None and m1 is not None and out["candidate"]["files_changed_as_declared"] and (
             r0 == r1 or (f_end.get("git_dirty_plant_files") == "" and bool(f_cand.get("git_head"))
                          and f_cand.get("git_head") == f_end.get("git_head")))),
         "every value count read": all(v["values"] != MISSING for v in counts.values()),
     }
+    if isinstance(pe, dict):       # (commit P) against a format-2 certificate: the plant as built has not moved
+        checks["engine_sha is the previous certificate's candidate's (row 94: plant_sha moves, engine_sha does "
+               "not)"] = prev_es not in (MISSING, None) and f_cand.get("engine_sha") == prev_es
+    if cfg.get("page_text"):       # (commit P) the page's words for this certificate, read by make_md.py
+        out["page_text"] = cfg["page_text"]
     vt = cfg.get("verdict_text") or {}
     out["verdict"] = dict(
         result=vt.get("pass", "CERTIFIED") if all(checks.values()) else vt.get("fail", "NOT CERTIFIED: see checks"),
@@ -586,8 +653,8 @@
             **{k: v["values"] for k, v in counts.items()}))
     order = ["certificate_format", "title", "what", "date", "asked_by", "verdict", "reference", "candidate",
              "identity", "environment", "harness", "controls", "values_compared", "records", "levels", "required",
-             "pending", "different", "not_covered", "page_markers", "tools", "tool_edits", "tools_note", "archive",
-             "reproduce",
+             "pending", "different", "not_covered", "page_markers", "page_text", "tools", "tool_edits", "tools_note",
+             "archive", "reproduce",
              "config"]
     out = {k: out[k] for k in order if k in out}
     with open(OUT, "w", encoding="utf-8", newline="\n") as fh:
```

### tools/make_md.py

commit A: sha256 dd6ebaf5ef49c91cb514ce904775250b0c399dbeeb6ce4aca17c1cb961ae9301
commit P: sha256 44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98

```diff
--- commit A: tools/make_md.py
+++ commit P: tools/make_md.py
@@ -9,6 +9,14 @@
 A JSON written by make_cert.py --config (build step 2, commit A; "certificate_format": 2;
 22 October 2026, amendment B9, TOOL_EDITS.md) is written by commit_a_page(); any other
 JSON is build step 1's, and its page is written by the code below as before.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): commit_a_page()
+named the previous certificate "build step 1's certificate", the plan CERT_PLAN_A.md and the
+re-run list commit A's, in its own words. A JSON that carries page_text (make_cert.py copies
+the config's) gives those words: previous_certificate, plan, plan_short, rerun_list and
+candidate_base; a schema-4 candidate's backends (train, score and the contract) are written
+where schema 3 had one backend. Without page_text and backends the page is byte for byte what
+it was. Build step 1's page (the code after commit_a_page) is unchanged.
 """
 import json
 import sys
@@ -52,6 +60,8 @@
         return f"; {esc(r['record_id'])}" if r.get("record_id") else ""
 
     V, I, ID = c["verdict"], c["identity"], c["identity"]
+    PT = c.get("page_text") or {}                  # (commit P) the certificate's own words, when it gives them
+    PREV = PT.get("previous_certificate", "build step 1's certificate")
     lines = []
     w = lines.append
     w(f"# {c['title']}")
@@ -83,7 +93,7 @@
     w("| | reference | candidate |")
     w("|---|---|---|")
     commits = cand.get("commits_on_base") or []
-    ctext = (f"{len(commits)} commits on `{(cand.get('base') or '?')}`" + (f" ({esc(commits[0].split()[0])} to "
+    ctext = (f"{len(commits)} commits on `{(PT.get('candidate_base') or cand.get('base') or '?')}`" + (f" ({esc(commits[0].split()[0])} to "
              f"{esc(commits[-1].split()[0])})" if commits else ""))
     w(f"| code | `{ref['rev']}` (`{(ref.get('commit') or '?')[:12]}`), `git archive` (tar sha256 "
       f"{short(ref.get('archive_sha256'))}), extracted in `S/{ref.get('tree') or 'ref'}` | `{cand.get('branch')}` at "
@@ -92,16 +102,20 @@
       "the last |")
     ps, ds, es = ID["plant_sha"], ID["derived_sha"], ID["engine_sha"]
     w(f"| `plant_sha` | {code(ps.get('reference'))} (X1's `meta.json`: {code(ps.get('x1_meta_json'))}) | "
-      f"{code(ps.get('candidate'))} (build step 1's certificate: {code(ps.get('previous_certificate'))}); at the end "
+      f"{code(ps.get('candidate'))} ({PREV}: {code(ps.get('previous_certificate'))}); at the end "
       f"of the run {code(ps.get('candidate_at_the_end'))} |")
     w(f"| `plant_text_sha` | {code(ID['plant_text_sha'].get('reference'))} | "
       f"{code(ID['plant_text_sha'].get('candidate'))} |")
-    w(f"| `derived_sha` | {code(ds.get('reference'))} | {code(ds.get('candidate'))} (build step 1's certificate: "
+    w(f"| `derived_sha` | {code(ds.get('reference'))} | {code(ds.get('candidate'))} ({PREV}: "
       f"{code(ds.get('previous_certificate'))}) |")
-    w(f"| `engine`, `engine_sha`, `backend` | none | {code(ID.get('engine'))}, {code(es.get('candidate'))} (build step "
-      f"1's certificate: {code(es.get('previous_certificate'))}; over build step 1's key set, amendment B11: "
+    bk = ID.get("backends")                        # (commit P) schema 4: train_backend, score_backend, the contract
+    bname = "`train_backend`, `score_backend`" if bk and ID.get("backend") is None else "`backend`"
+    btext = (f"train {code(bk.get('train'))}, score {code(bk.get('score'))} (backend_contract "
+             f"{code(bk.get('contract'))})" if bk and ID.get("backend") is None else code(ID.get('backend')))
+    w(f"| `engine`, `engine_sha`, {bname} | none | {code(ID.get('engine'))}, {code(es.get('candidate'))} ("
+      f"{PREV}: {code(es.get('previous_certificate'))}; over build step 1's key set, amendment B11: "
       f"{code(es.get('over_build_step_1_keys'))}, printed by {code(es.get('printed_by'))}), "
-      f"{code(ID.get('backend'))} |")
+      f"{btext} |")
     sf = ID["shared_fatal_fields"]
     same = all(a == b for a, b in sf.values())
     w("| " + ", ".join(f"`{k}`" for k in sf) + " | " + "; ".join(esc(v[0]) for v in sf.values()) + " | "
@@ -155,7 +169,8 @@
         w(f"| {esc(r.get('what') or r.get('command'))} ({esc(r.get('record_id'))}) | {code(r.get('environment'))} | "
           f"{esc(r.get('item'))} | {esc(r.get('expected'))} | {esc(r.get('got'))} | {vcell(r)} |")
     w("")
-    w("Why each control can fail is in the JSON (`controls[].why_it_can_fail`) and in `S/CERT_PLAN_A.md`.")
+    w("Why each control can fail is in the JSON (`controls[].why_it_can_fail`) and in "
+      f"`{PT.get('plan', 'S/CERT_PLAN_A.md')}`.")
     w("")
 
     w("## 3. The levels")
@@ -195,8 +210,8 @@
 
     w("## 4. The re-run list")
     w("")
-    w("`docs/build_step_2/PLAN.md` section 3.6 as `AMENDMENTS.md` amends it, and `HANDOFFS.md`'s items for "
-      "commit A; each answered by the records that name it.")
+    w(PT.get("rerun_list", "`docs/build_step_2/PLAN.md` section 3.6 as `AMENDMENTS.md` amends it, and "
+             "`HANDOFFS.md`'s items for commit A; each answered by the records that name it."))
     w("")
     w("| item | asks | records | verdict |")
     w("|---|---|---|---|")
@@ -255,7 +270,8 @@
     w("")
     a = c.get("archive") or {}
     if a:
-        w(f"Every tool, `TOOL_EDITS.md`, this run's plan (`CERT_PLAN_A.md`), its records (`cert_results/`) and the "
+        w(f"Every tool, `TOOL_EDITS.md`, this run's plan (`{PT.get('plan_short', 'CERT_PLAN_A.md')}`), its records "
+          "(`cert_results/`) and the "
           f"small evidence files are in `{a['path']}` ({n(a['bytes'])} bytes, sha256 `{a['sha256']}`, "
           f"{n(a['members'])} members). Unpacked anywhere, that folder is `S`: the tools find it from their own "
           "location. The dumps (`.npz`), the scratch trees and the models are not archived; the commands re-make them.")
```

### tools/make_meta.py

commit A: sha256 27afe1f07be4cba57d7ea8151274e19f9a1eb1d0e0954d61ed344592d289728a
commit P: sha256 c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b

```diff
--- commit A: tools/make_meta.py
+++ commit P: tools/make_meta.py
@@ -1,17 +1,26 @@
-"""make_meta.py -- L7's candidate model directory: X1's sighted_seed0, its meta.json
-re-stamped with this tree's schema-3 fingerprint for the identity test only.
+"""make_meta.py -- L7's candidate model directory: an X1 agent (sighted_seed0, and blind_seed0 beside it),
+its meta.json re-stamped with this tree's schema-4 fingerprint for the identity test only.
 
-    python -I make_meta.py <candidate_tree> <src_run_dir> <dest_run_dir>
+    python -I -B make_meta.py <candidate_tree> <src_run_dir> <dest_run_dir>
 
 final.zip is copied byte for byte (sha256 printed for both). meta.json keeps
 every ADVISORY field of the original (train_dt, steps_requested, seed, tag, ...)
-and takes the FATAL fields and the schema from the live candidate fingerprint
-(fingerprint.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d",
-backend=fingerprint.BACKEND_CYCLE); backend required since the review of 21 October),
-so evaluate.py's check passes without --force-plant-mismatch. The re-stamp is
-declared inside the file, in "identity_override": the original schema and
-plant_sha, the original meta.json's sha256, and why. This is not a result
+and takes the FATAL fields and the schema from the live candidate fingerprint,
+built as evaluate.py builds its live side at P, with every FATAL input passed
+(rule 1.7, mistake 19): fingerprint.plant_fingerprint(protocol="phase-d",
+plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE, score_backend=FP.BACKEND_CYCLE,
+preview_h_s=engine_env.PREVIEW_H_S, reward_knock=engine_env.REWARD_KNOCK_DEFAULT),
+then fingerprint.for_arm(..., sighted=...), the arm read from the source directory's
+name as evaluate.py reads it ("blind" in it: the blinded arm, whose preview_h_s is
+None, row 117), so evaluate.py's check passes without --force-plant-mismatch. The
+re-stamp is declared inside the file, in "identity_override": the arm, the original
+schema and plant_sha, the original meta.json's sha256, and why. This is not a result
 directory; it lives in scratch and nothing under runs/ is touched.
+
+Build step 2, commit P (ORDER step 14; CERT_PLAN_P.md G6.3 and the interface sheet 6.8; recorded in
+TOOL_EDITS.md, section "commit P"): schema 3's plant_fingerprint(plant=, protocol=, backend=) is schema 4's
+call above, the blinded arm goes through for_arm, and the reason names P's certificate and this tree's
+schema-4 block instead of build step 1's and schema 3. Nothing else changed.
 """
 import hashlib
 import json
@@ -22,6 +31,7 @@
 tree, src, dest = (os.path.abspath(p) for p in sys.argv[1:4])
 os.chdir(tree)
 sys.path.insert(0, tree)
+import engine_env as E  # noqa: E402
 import engines  # noqa: E402
 import fingerprint as FP  # noqa: E402
 
@@ -34,17 +44,25 @@
 os.makedirs(dest, exist_ok=True)
 shutil.copyfile(os.path.join(src, "final.zip"), os.path.join(dest, "final.zip"))
 orig = FP.read(os.path.join(src, "meta.json"))
-live = FP.plant_fingerprint(plant=engines.get("b58"), protocol="phase-d", backend=FP.BACKEND_CYCLE)
+live = FP.plant_fingerprint(protocol="phase-d", plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE,
+                            score_backend=FP.BACKEND_CYCLE, preview_h_s=E.PREVIEW_H_S,
+                            reward_knock=E.REWARD_KNOCK_DEFAULT)
+sighted = "blind" not in os.path.basename(src)
+live = FP.for_arm(live, sighted=sighted)    # evaluate.py's arm rule
 meta = {k: v for k, v in orig.items() if k not in FP.FATAL}
 meta.update({k: live[k] for k in FP.FATAL})
 meta["schema"] = live["schema"]
 meta["identity_override"] = dict(
-    reason=("build step 1's identity certificate (results/B58_IDENTITY.md, level L7): X1's "
-            "sighted_seed0 scored end to end by this tree's evaluate.py and diffed against "
-            "cf43fbb's evaluate.py on the original directory. Its FATAL fields are this tree's "
-            "schema-3 block, stamped by make_meta.py so that no --force-plant-mismatch is "
-            "needed; whether the plant behind them is cf43fbb's is what the certificate's "
-            "levels measure. Not a result directory"),
+    reason=("P's identity certificate (build step 2, ORDER step 14; results/B58_IDENTITY.md, level L7; "
+            "CERT_PLAN_P.md G6.3): X1's " + os.path.basename(src) + " scored end to end by this tree's "
+            "evaluate.py and compared with the committed raw scores, and diffed against cf43fbb's "
+            "evaluate.py on the original directory (sighted_seed0 against build step 1's report, blind_seed0 "
+            "against cf43fbb's run made in the certificate's S/ref). Its FATAL fields are this tree's "
+            "schema-4 block (" + ("sighted" if sighted else "blinded: preview_h_s None") + ", "
+            "fingerprint.for_arm), stamped by make_meta.py so that no --force-plant-mismatch is needed; "
+            "whether the plant behind them is cf43fbb's is what the certificate's levels measure. Not a "
+            "result directory"),
+    arm="sighted" if sighted else "blind",
     original_schema=orig.get("schema"), original_plant_sha=orig.get("plant_sha"),
     original_derived_sha=orig.get("derived_sha"),
     original_meta_sha256=sha(os.path.join(src, "meta.json")),
```

### tools/road_json_diff.py

commit A: no such file (new in P)
commit P: sha256 dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7

```diff
--- commit A: tools/road_json_diff.py
+++ commit P: tools/road_json_diff.py
@@ -0,0 +1,53 @@
+"""road_json_diff.py -- what differs between two check_roads.py outputs (G3-roads, commit A).
+
+    python -I road_json_diff.py <a.json> <b.json> [--json out.json]
+
+Exact comparison (==, no tolerance) of the top-level fields and of every road, key by key:
+keys only in a, keys only in b, keys in both with a different value (the first such value
+is printed). Prints IDENTICAL when the two parsed documents are equal, else a summary.
+Used for the comparison against the committed file, which the byte comparison (cmp) cannot
+explain; the identity against the reference is cmp's, byte for byte.
+"""
+import json
+import sys
+
+a_path, b_path = sys.argv[1], sys.argv[2]
+out = sys.argv[sys.argv.index("--json") + 1] if "--json" in sys.argv else None
+with open(a_path, encoding="utf-8") as fh:
+    A = json.load(fh)
+with open(b_path, encoding="utf-8") as fh:
+    B = json.load(fh)
+
+res = dict(a=a_path, b=b_path, identical=(A == B))
+top = sorted(set(A) | set(B))
+res["top_only_a"] = [k for k in top if k not in B]
+res["top_only_b"] = [k for k in top if k not in A]
+res["top_changed"] = {k: [A[k], B[k]] for k in top if k in A and k in B and k != "roads" and A[k] != B[k]}
+ra, rb = A.get("roads", []), B.get("roads", [])
+res["n_roads"] = [len(ra), len(rb)]
+only_a, only_b, changed, first = {}, {}, {}, None
+for i, (x, y) in enumerate(zip(ra, rb)):
+    for k in sorted(set(x) | set(y)):
+        if k not in y:
+            only_a[k] = only_a.get(k, 0) + 1
+        elif k not in x:
+            only_b[k] = only_b.get(k, 0) + 1
+        elif x[k] != y[k]:
+            changed[k] = changed.get(k, 0) + 1
+            if first is None:
+                first = dict(road=i, seed=x.get("seed"), key=k, a=x[k] if not isinstance(x[k], list) else x[k][:3],
+                             b=y[k] if not isinstance(y[k], list) else y[k][:3])
+res.update(keys_only_a=only_a, keys_only_b=only_b, keys_changed=changed, first_changed=first)
+if res["identical"]:
+    print(f"IDENTICAL: {len(ra)} roads, {len(top)} top-level fields")
+else:
+    print(f"DIFFERENT: roads {len(ra)} / {len(rb)}")
+    print(f"  top-level only in a: {res['top_only_a']}; only in b: {res['top_only_b']}; changed: {res['top_changed']}")
+    print(f"  road keys only in a (count of roads): {only_a}")
+    print(f"  road keys only in b (count of roads): {only_b}")
+    print(f"  road keys with another value (count of roads): {changed}")
+    print(f"  first changed value: {first}")
+if out:
+    with open(out, "w", encoding="utf-8", newline="\n") as fh:
+        json.dump(res, fh, indent=1, default=str)
+        fh.write("\n")
```

### tools/run_app.sh

commit A: sha256 45a596885d918478dff00a5a524b684429bb788669a1a163b3a7a2a86fd2c452
commit P: sha256 5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91

```diff
--- commit A: tools/run_app.sh
+++ commit P: tools/run_app.sh
@@ -1,8 +1,10 @@
 #!/usr/bin/env bash
 # run_app.sh <cand|ref> -- the app suites and the learning lab's tests, one after another, in one tree
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): every suite starts with -B, and CAND
+# has no default (an unset CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-t=$1; tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
+t=$1; tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
 mkdir -p $S/app
 export PYTHONIOENCODING=utf-8
 one() {   # one <label> <dir> <command...>
@@ -12,9 +14,9 @@
   echo "$? $(( $(date +%s) - s )) $label" >> $S/app/${t}_status.txt
 }
 rm -f $S/app/${t}_status.txt
-one test_replay_full "$tree" $PY -m app.test_replay --full
-one test_simulation "$tree" $PY -m app.test_simulation
-one test_agents "$tree" $PY -m app.test_agents
-one test_results "$tree" $PY -m app.test_results
-one lab_tests "$tree/Explanatory Simulation" $PY -m unittest discover -s tests -v
+one test_replay_full "$tree" $PY -B -m app.test_replay --full
+one test_simulation "$tree" $PY -B -m app.test_simulation
+one test_agents "$tree" $PY -B -m app.test_agents
+one test_results "$tree" $PY -B -m app.test_results
+one lab_tests "$tree/Explanatory Simulation" $PY -B -m unittest discover -s tests -v
 cat $S/app/${t}_status.txt
```

### tools/run_app_extra.sh

commit A: sha256 ac998584317787175c5dc912d2b62559e78eb0753a898d9e1fc88781b965d395
commit P: sha256 b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777

```diff
--- commit A: tools/run_app_extra.sh
+++ commit P: tools/run_app_extra.sh
@@ -1,15 +1,17 @@
 #!/usr/bin/env bash
 # run_app_extra.sh <cand|ref> -- the other eleven app/test_*.py suites (mistake 25: every suite that
 # may read the plant), each with python -m unittest -v, in one tree
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): every suite starts with -B, and CAND
+# has no default (an unset CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-t=$1; tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
+t=$1; tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refa; [ $t = refgit ] && tree=$S/refgit
 export PYTHONIOENCODING=utf-8
 rm -f $S/app/${t}_extra_status.txt
 for m in test_agent_generations test_agent_sources test_artifact_api test_artifacts test_graphics_revisions \
          test_launcher test_records test_results_comparisons test_results_graphics test_results_records test_results_sets; do
   s=$(date +%s)
-  ( cd "$tree" && $PY -m unittest -v app.$m ) > $S/app/${t}_$m.txt 2>&1
+  ( cd "$tree" && $PY -B -m unittest -v app.$m ) > $S/app/${t}_$m.txt 2>&1
   echo "$? $(( $(date +%s) - s )) $m" >> $S/app/${t}_extra_status.txt
 done
 cat $S/app/${t}_extra_status.txt
```

### tools/run_drift.sh

commit A: sha256 80695caef6b7506a82e1bd01889a208640e04222ad3b03cc0b4c008aaf38a61e
commit P: sha256 98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f

```diff
--- commit A: tools/run_drift.sh
+++ commit P: tools/run_drift.sh
@@ -3,9 +3,12 @@
 # joined on 21 October 2026). Each part runs drift_test's own control on an undrifted copy first,
 # then its rows, each on a fresh copy; the rows are independent, so the six parts are the one
 # command split for time. The verdict line sums the parts.
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): drift_test.py starts with -B, and
+# CAND has no default (an unset CAND stops the tool). drift_test's own children (verify_docs.py in each
+# copy, sys.executable without flags) inherit PYTHONDONTWRITEBYTECODE=1 from env_P.sh. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-cd "${CAND:-/c/Users/badcl/Desktop/GRAD-project}" || exit 9
+cd "${CAND:?CAND is unset: the certificate names every tree, env_P.sh}" || exit 9
 export PYTHONIOENCODING=utf-8
 mkdir -p $S/suites
 rm -f $S/suites/drift_part*.txt
@@ -13,7 +16,7 @@
 i=0
 for rows in "1 2 3" "4 5 6" "7 8 9" "10 11 12" "13 14 15" "16 17 18"; do
   i=$((i+1))
-  ( $PY drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
+  ( $PY -B drift_test.py $rows > $S/suites/drift_part$i.txt 2>&1; echo "exit $? rows $rows" >> $S/suites/drift_part$i.txt ) &
 done
 wait
 { for j in $(seq 1 $i); do echo "### part $j"; cat $S/suites/drift_part$j.txt; done; } > $S/suites/drift_test.txt
```

### tools/run_jobs.py

commit A: sha256 015510b4b81193155b078791d8f6dc9f42d2073ae6a2f0181563977ae962bf18
commit P: sha256 24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26

```diff
--- commit A: tools/run_jobs.py
+++ commit P: tools/run_jobs.py
@@ -2,9 +2,14 @@
 
     python run_jobs.py <tree_dir> <label> <jobs.txt> <parallel> [NAME=VALUE ...]
 
-Each job is `python -I harness.py <tree> <job> out/<label>/<slug>.npz` with
+Each job is `python -I -B harness.py <tree> <job> out/<label>/<slug>.npz` with
 OMP_NUM_THREADS=1; NAME=VALUE pairs are added to the job's environment (the
 control's HARNESS_PERTURB). _status.txt gets "<exit> <seconds> <job>" per job.
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"): each job starts
+with -B beside -I. -I makes Python ignore PYTHONDONTWRITEBYTECODE, so harness.py wrote
+__pycache__ beside every module it imported, in the candidate and in S/ref; -B writes none.
+-B changes no number a job computes. Nothing else changed.
 """
 import os
 import re
@@ -35,7 +40,7 @@
     while pending and len(running) < par:
         j = pending.pop(0)
         log = open(os.path.join(outdir, slug(j) + ".log"), "w", encoding="utf-8")
-        p = subprocess.Popen([PY, "-I", os.path.join(HERE, "harness.py"), tree, j,
+        p = subprocess.Popen([PY, "-I", "-B", os.path.join(HERE, "harness.py"), tree, j,
                               os.path.join(outdir, slug(j) + ".npz")], stdout=log, stderr=subprocess.STDOUT,
                              env=env)
         running.append((p, j, log, time.time()))
```

### tools/run_l4.sh

commit A: sha256 4640165e0723464e27d342beea609be576112d29cd844d5d4eaf577870a71507
commit P: sha256 6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c

```diff
--- commit A: tools/run_l4.sh
+++ commit P: tools/run_l4.sh
@@ -1,12 +1,14 @@
 #!/usr/bin/env bash
 # run_l4.sh <cand|ref> [extra test_reward args] -- L4: test_reward.py in one tree, stdout and stderr kept apart
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): -B, and CAND has no default (an unset
+# CAND stops the tool). Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 t=$1; shift; tag=""; [ "$1" = "--road" ] && tag="_$2"
-tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/ref
+tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/ref
 cd $tree || exit 9
 s=$(date +%s)
-PYTHONIOENCODING=utf-8 $PY test_reward.py "$@" > $S/L4/${t}${tag}_stdout.txt 2> $S/L4/${t}${tag}_stderr.txt
+PYTHONIOENCODING=utf-8 $PY -B test_reward.py "$@" > $S/L4/${t}${tag}_stdout.txt 2> $S/L4/${t}${tag}_stderr.txt
 rc=$?
 echo "exit $rc in $(( $(date +%s) - s )) s" > $S/L4/${t}${tag}_exit.txt
 cat $S/L4/${t}${tag}_exit.txt
```

### tools/run_l6.sh

commit A: sha256 5ffd5ab8ed97fc450a72516638728a3681c1b3c7b9f2a380bf345cd1e66849bb
commit P: sha256 d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7

```diff
--- commit A: tools/run_l6.sh
+++ commit P: tools/run_l6.sh
@@ -1,14 +1,20 @@
 #!/usr/bin/env bash
 # run_l6.sh -- L6: four X1 agents x twenty frozen episodes, in both trees, 8 processes at once
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): l6_agents.py starts with -I -B, and
+# CAND has no default. Here (unlike the other five tools) the `${CAND:?...}` sits inside `$(...)`, so an unset CAND
+# ends only that subshell and does NOT stop the tool: CAND is then empty, and l6_agents.py takes the empty path as
+# its working directory (os.path.abspath(""), archive tools/l6_agents.py:28), so the candidate side runs in the
+# folder run_l6.sh was started from. env_P.sh always exports CAND (the clone), and cert_driver_P.sh starts this tool
+# from the clone. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 SW=$(cygpath -m "$S")
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
-CAND=$(cygpath -m "${CAND:-/c/Users/badcl/Desktop/GRAD-project}")
+CAND=$(cygpath -m "${CAND:?CAND is unset: the certificate names every tree, env_P.sh}")
 REF="$SW/ref"
 for tag in sighted_seed0 sighted_seed4 blind_seed2 blind_seed6; do
   for t in cand ref; do
     tree=$CAND; [ $t = ref ] && tree=$REF
-    ( $PY -I "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
+    ( $PY -I -B "$SW/tools/l6_agents.py" "$tree" $tag "$SW/L6/${t}_${tag}.npz" > "$S/L6/${t}_${tag}.log" 2>&1; echo "$? $t $tag" >> "$S/L6/_status.txt" ) &
   done
 done
 wait
```

### tools/run_writer.sh

commit A: sha256 f2dd6109b29dd65f88971766b7b2ce97a9392c9a4357282040becc47dd03057b
commit P: sha256 28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382

```diff
--- commit A: tools/run_writer.sh
+++ commit P: tools/run_writer.sh
@@ -3,16 +3,19 @@
 # A script that rewrites a committed file. In the candidate (the working tree) the
 # committed file is backed up first, the run's output is kept in scratch, and the
 # backup is put back, so the working tree ends as it began (sha256 checked).
+# Build step 2, commit P (7 November 2026; TOOL_EDITS.md, "commit P"): the script starts with -B, and CAND
+# has no default (it was the live repository, which holds P uncommitted while the roads check runs there):
+# an unset CAND stops the tool before it runs anything. Nothing else changed.
 S=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)   # the folder above tools/: certify, fixes, or an unpacked archive
 PY=${PY:-/c/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe}
 t=$1; label=$2; rel=$3; shift 3
-tree=${CAND:-/c/Users/badcl/Desktop/GRAD-project}; [ $t = ref ] && tree=$S/refw
+tree=${CAND:?CAND is unset: the certificate names every tree, env_P.sh}; [ $t = ref ] && tree=$S/refw
 cd "$tree" || exit 9
 bak=$S/L5/backup/${t}_$(basename "$rel")
 cp -p "$rel" "$bak"
 before=$(sha256sum < "$rel" | cut -c1-64)
 s=$(date +%s)
-PYTHONIOENCODING=utf-8 $PY "$@" > $S/L5/${t}_${label}_stdout.txt 2> $S/L5/${t}_${label}_stderr.txt
+PYTHONIOENCODING=utf-8 $PY -B "$@" > $S/L5/${t}_${label}_stdout.txt 2> $S/L5/${t}_${label}_stderr.txt
 rc=$?
 cp -p "$rel" $S/L5/${t}_${label}_OUT_$(basename "$rel")
 after=$(sha256sum < "$rel" | cut -c1-64)
```

### tools/stated_counts_P.py

commit A: no such file (new in P)
commit P: sha256 7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7

```diff
--- commit A: tools/stated_counts_P.py
+++ commit P: tools/stated_counts_P.py
@@ -0,0 +1,92 @@
+"""stated_counts_P.py -- every test count README.md and full_run.py state, against the run that printed it.
+
+    python -I -B stated_counts_P.py <tree> <suite>=<output file> [<suite>=<output file> ...]
+
+Build step 2, commit P (7 November 2026; TOOL_EDITS.md, section "commit P"). New in P: amendment HP7.6
+(CERT_PLAN_A.md G7.4: "every count README.md and full_run.py state equal to its run's"), which commit A
+checked by reading grep's lines, written out so that the check can fail by itself.
+
+A statement is
+  - a line of <tree>/README.md holding "<N> tests"; its suite is the first test_<name> or
+    app.test_<name> on that line;
+  - a line of <tree>/full_run.py holding "<N> tests"; its suite is the one its block runs: the nearest
+    line above it, at most six lines up, that lists ["<name>.py" or "-m", "app.test_<name>".
+A statement that also says "<K> skip..." or "<K> of them skipped" is compared on that count too.
+A run's count is the last "Ran <N> tests" of the output given for the suite (<suite>=<file>), and its
+skip count the "skipped=<K>" of its last OK or FAILED line, 0 when that line names none.
+
+Prints one line per statement. Exit 0 when every statement names a suite that has an output, and every
+stated count (and stated skip count) equals the run's; 1 otherwise; 2 when a document is missing.
+"""
+import os
+import re
+import sys
+
+tree = sys.argv[1]
+outputs = dict(a.split("=", 1) for a in sys.argv[2:])
+COUNT = re.compile(r"\b(\d+) tests\b")
+SKIP = re.compile(r"\b(\d+)(?: of them)? skip")
+SUITE = re.compile(r"\b((?:app\.)?test_\w+)")
+BLOCK = re.compile(r'\["((?:app\.)?test_\w+)\.py"|"-m", "(app\.test_\w+)"')
+
+
+def lines_of(name):
+    p = os.path.join(tree, name)
+    if not os.path.isfile(p):
+        print(f"MISSING: {p}")
+        sys.exit(2)
+    with open(p, encoding="utf-8", errors="replace") as fh:
+        return fh.read().replace("\r\n", "\n").splitlines()
+
+
+def run_of(path):
+    """(tests run, tests skipped) of a unittest output, or None when it has no 'Ran N tests' line."""
+    if not path or not os.path.isfile(path):
+        return None
+    with open(path, encoding="utf-8", errors="replace") as fh:
+        text = fh.read().replace("\r\n", "\n")
+    ran = re.findall(r"^Ran (\d+) tests?\b", text, re.M)
+    if not ran:
+        return None
+    tail = re.findall(r"^(?:OK|FAILED)\b.*$", text, re.M)
+    skip = re.search(r"skipped=(\d+)", tail[-1]) if tail else None
+    return int(ran[-1]), int(skip.group(1)) if skip else 0
+
+
+statements = []
+for i, ln in enumerate(lines_of("README.md")):
+    m = COUNT.search(ln)
+    if m:
+        s = SUITE.search(ln)
+        statements.append(("README.md", i + 1, s.group(1) if s else None, ln))
+full = lines_of("full_run.py")
+for i, ln in enumerate(full):
+    m = COUNT.search(ln)
+    if not m:
+        continue
+    suite = None
+    for j in range(i, max(-1, i - 7), -1):
+        b = BLOCK.search(full[j])
+        if b:
+            suite = b.group(1) or b.group(2)
+            break
+    statements.append(("full_run.py", i + 1, suite, ln))
+
+equal = untied = 0
+for doc, no, suite, ln in statements:
+    n = int(COUNT.search(ln).group(1))
+    sk = SKIP.search(ln)
+    k = int(sk.group(1)) if sk else None
+    said = f"{n} tests" + (f", {k} skipped" if k is not None else "")
+    got = run_of(outputs.get(suite)) if suite else None
+    if suite is None or got is None:
+        untied += 1
+        why = "names no suite" if suite is None else f"no run of {suite} given ({outputs.get(suite) or 'none'})"
+        print(f"NOT TIED  {doc}:{no} {suite}: states {said} | {why} | {ln.strip()[:120]}")
+        continue
+    same = got[0] == n and (k is None or got[1] == k)
+    equal += same
+    print(f"{'equal    ' if same else 'DIFFERENT'} {doc}:{no} {suite}: states {said} | its run {got[0]} tests, "
+          f"{got[1]} skipped ({outputs[suite]})")
+print(f"HP7.6: {equal} of {len(statements)} stated counts equal their runs; {untied} not tied to a run")
+sys.exit(0 if statements and equal == len(statements) else 1)
```

## commit P, second install (2026-11-08): the corrected kit installed again on the same S, for the re-checks

Installed by p_gate.sh cert-kit on 2026-11-08 over the first install (installed on 2026-11-07), on the team's decision
decisions/cert_kit_reinstall.txt (sha256 b8582bc58bd802d0e4a49fa4e8287d096be03d973a5d08e78e4f1e3544b04609), quoted whole below.
Section "commit P" above was written again by this install from the corrected kit: its diffs against commit A are
the tools as they now stand. S held the first run's records when this install ran, and it did not touch them:
S/cert_results, 8 files, each with the same sha256 before and after. Every record written before
this install was made with the first install's tools; every record written after it (each cert-recheck's
G0-prepare record, and every record of the groups it re-runs) with this install's. Each kit file is
listed below with its sha256 in S before this install (the first install's) and after, and each changed file
with its diff from the first install's copy. Last comes the diff of the first install's TOOL_EDITS.md against
this file as this install wrote it, up to this section: it carries TOOL_EDITS_commit_P.md's first text, which is
not installed as a file. So the first install's bytes, of every kit file and of its TOOL_EDITS.md, can be read
back from this file.
The review list: decisions/cert_kit_reviewed.txt, sha256 ac2668a55f6adce5906eee57f65bb93a849956f4f089272a9f7e7eae3f2ed818. The smoke step passed
again on this install: its list, sha256 1fc629ba6682022b7954af80f56c54780a597ec4627305dff8a677f50e739435 (the first install's: c8a443d4d2ffc145cf24773d1ae786372f32dbfda5477012c451f7ab61a7369d).

```text
MODE reinstall
WHY P's certificate's first run on this S (7-8 November 2026, 39139 s beside the roads check) wrote 106 records, 101 PASS and 5 FAIL, and all five FAILs are defects of the kit's driver tools/cert_driver_P.sh, not of P (hand/cert_fails_plan.md, read against each FAIL's evidence): G1.7(b) ran the makes without -X utf8 (G1-harness.json record 29); G3.1 asked the --road random run for the default run's last line (G3-roads.json record 2); G5.2 waited for a line launch.py prints to block-buffered stdout (G5-app-lab.json record 10); G7.2's tests_ok missed RealTree's ok after its stderr line (G7-suites.json record 12); G7.4 grepped one line for a rule that wraps (G7-suites.json record 16). The kit is corrected (E1-E5, and E6: -X utf8 on the final driver's makes), each record's --what and --command kept as the first run wrote them (the --expected of the B9, G5.2 launcher and HA.4 records names what now runs), reviewed again, and fixed after those reviews (G5.2 also removes the first run's launcher log before the launcher starts; the texts that ship say only what the evidence shows); this second install puts it on the same S so that groups g1, g3, g5 and g7 are re-run there with cert-recheck, the five FAIL records staying in the certificate beside the re-check records, each re-run PASS naming the FAIL it re-checks, as commit A re-checked its FAILs.
DECIDED 8 November 2026 under Ghassan's standing instruction, recorded by the orchestrator: the re-check on the same S (hand/cert_fails_plan.md section 4, route 2), not a new S.
EDITED INTEGRATION.md
EDITED TOOL_EDITS_commit_P.md
EDITED cert_P.json
EDITED reproduce_P.json
EDITED tools/cert_driver_P.sh
EDITED tools/cert_final_driver_P.sh
READ p_gate.sh cert-kit installs the kit again on an S that holds records only when this file says MODE reinstall, has a WHY line of at least 20 characters, and its EDITED lines are exactly the kit files that differ from the first install (by sha256; TOOL_EDITS_commit_P.md by its text in the first install's TOOL_EDITS.md), and the review list holds the kit as it stands; it never touches S/cert_results, and keeps the first install's state in out/cert_kit_reinstall/before.
```

```text
INTEGRATION.md  before cf8f49b56cc75c1fa50990a1bc67849c57a7bb2d0170a1f087a5a444a2c74e18  after e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3  CHANGED
TOOL_EDITS_commit_P.md  not installed as a file (its text opens section "commit P"); kit sha256 afb6abdb8013003131098bcb753ee3e147b05428effa2007c4c12399c6fe5275; CHANGED: its text is not the first install's
cert_P.json  before c0f3dc95cf26a32dfc5efa4fa074e6dd1a29492fcaa4c98545510804b8c70202  after ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193  CHANGED
env_P.sh  before bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0  after bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0  unchanged
reproduce_P.json  before bd1c99a0755558cc0e4d7bcb7c0e7445c5ee34a503f59098ef43377fc83a3888  after b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517  CHANGED
tools/cert_driver_P.sh  before bfec15faca167a16bfd8faa4cedf4f5002cf14959a2a919545bdcc6515a11a59  after 17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21  CHANGED
tools/cert_final_driver_P.sh  before ab46791e31bba212e0c9356a9551f5c4c2bd5707efecc21d0f99d76fbd2d822d  after f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1  CHANGED
tools/cert_record.py  before c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3  after c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3  unchanged
tools/check_l6.sh  before 6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b  after 6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b  unchanged
tools/compare_all.sh  before 2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5  after 2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5  unchanged
tools/failing_sets_P.py  before 56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc  after 56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc  unchanged
tools/l7_expect.py  before 72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164  after 72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164  unchanged
tools/make_cert.py  before 28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea  after 28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea  unchanged
tools/make_md.py  before 44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98  after 44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98  unchanged
tools/make_meta.py  before c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b  after c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b  unchanged
tools/road_json_diff.py  before dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7  after dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7  unchanged
tools/run_app.sh  before 5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91  after 5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91  unchanged
tools/run_app_extra.sh  before b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777  after b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777  unchanged
tools/run_drift.sh  before 98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f  after 98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f  unchanged
tools/run_jobs.py  before 24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26  after 24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26  unchanged
tools/run_l4.sh  before 6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c  after 6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c  unchanged
tools/run_l6.sh  before d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7  after d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7  unchanged
tools/run_writer.sh  before 28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382  after 28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382  unchanged
tools/stated_counts_P.py  before 7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7  after 7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7  unchanged
TOOL_EDITS.md  before b5851131a747269436ba647ff930a1e5d362843b02201361c623e3df5828bcbe  after 1d77c0794efab2da2a6580ebcbc629eb1f895235723feb584990af7101745431 (written again, before this section)
CERT_PLAN_P.md  before 26a0d63b809b6ef4d8e40bd693d30461d0258f5b54f109a81e035c366d804cbd  after 26a0d63b809b6ef4d8e40bd693d30461d0258f5b54f109a81e035c366d804cbd
```

### INTEGRATION.md: the first install's copy and the second install's

```diff
--- commit P, first install: INTEGRATION.md
+++ commit P, second install: INTEGRATION.md
@@ -125,7 +125,8 @@
 
 A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
 (review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
-before its lab_dump.py; G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
+before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
+(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
 `cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
 `suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
 first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
@@ -311,7 +312,11 @@
 - **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
   takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
   runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
-  P_GATE_PLAN.md 11.2.) (a) In a fresh extraction of build step 1's archive (`c47907b`'s), build step 1's
+  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
+  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
+  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
+  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
+  extraction of build step 1's archive (`c47907b`'s), build step 1's
   make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
   committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
   since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
@@ -324,6 +329,11 @@
 - **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
 - **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
   cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
+- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
+  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
+  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
+  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
+  road. The reward is safe to train against on the randomised climb.' (`--road random`).
 - **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
   each committed file (road_json_diff.py) is a `--difference` text, not judged.
 - **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
@@ -339,6 +349,17 @@
   skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
   configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
   second time, so that a failure RV already has reads as such.
+- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
+  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
+  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
+  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
+  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
+  cycle, which passed, used this trigger. The record's
+  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
+  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
+  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
+  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
+  original), and the trigger would fire on it before the new server is up.
 - **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
   block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
   strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
@@ -350,14 +371,27 @@
 - **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
   `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
   SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
-  ran ok and none was skipped or failed.
+  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
+  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
+  result pending until the next test header.
+- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
+  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
+  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
+  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
+  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
+  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
+  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
+  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
+  runs.
 - **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
 - **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
   record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
   list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
   (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
   no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
-  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it).
+  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
+  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
+  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
 - **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
   eight processes as run_l6.sh starts them; four evaluate.py at once in G6.
 
```

### cert_P.json: the first install's copy and the second install's

```diff
--- commit P, first install: cert_P.json
+++ commit P, second install: cert_P.json
@@ -120,7 +120,8 @@
   "nothing_computed_moved": "Every value the harness, L6 and build_dataset compared is meant to be the same double in both trees (the counts are in the verdict line), and every writer's output and every report to equal cf43fbb's; the differences section 5 lists are labels, code hashes, run times and committed files older than the code on both trees.",
   "why_plant_sha_moves": "plant_sha hashes the code of fingerprint.plant_files('b58') -- plant.py, thermal.py, engine_env.py, derived.py and engines.py -- and the values of the B58's two spec files. P edits engine_env.py (H a parameter, the reward's knock option) and engines.py (trainable() read from the committed records), so plant_sha moves although no computed value is meant to; it names P's plant, which every later step of build step 2 is compared against. fingerprint.py, which P also edits, is not in PLANT_CODE.",
   "why_engine_sha_does_not_move": "engine_sha hashes every value of the plant as built (engines.engine_sha), and P adds and changes no field of the B58's records: engine_sha is commit A's (a check of section 1), and over build step 1's key set it is still build step 1's (amendment B11).",
-  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2)."
+  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2).",
+  "first_run": "The first run of this certificate's groups (7-8 November 2026, 16:08Z to 03:00Z, 39139 s beside the roads check) wrote 101 PASS and 5 FAIL records: G1-harness record 29, G3-roads record 2, G5-app-lab record 10, G7-suites records 12 and 16. All five were defects of the kit's driver (tools/cert_driver_P.sh), not of P: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and three of the five makes exited 1, each only when printing, after writing its JSON: the driver ran them without -X utf8, and commit A's make_cert.py and P's alike stopped printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic text) to a cp1252 stdout. In G5.2 the launcher met its expectation ('is ready', exit 124), and --check ran only as its server stopped: the driver waited for a line launch.py prints to block-buffered stdout, which reaches the file only at the launcher's exit. G3.1 asked the --road random run for the default run's last line; G7.2's parser missed RealTree's ok, printed on a line of its own after RealTree's stderr line; G7.4 grepped one line for a rule that wraps (CLAUDE.md:137-138). The driver was corrected (TOOL_EDITS.md, section 'commit P', its part 'commit P, second edit'), reviewed again, installed on the same S after the roads check ended (TOOL_EDITS.md, section 'commit P, second install'), and G1, G3, G5 and G7 re-run there with cert-recheck: the re-check records say what each re-run found. The five FAIL records stay in this certificate; a re-run PASS record that re-checks one names it (rechecks), and the FAIL gains rechecked_by. The edited checks keep the first run's what and command texts, so that every run of one check is the same check: the re-run records of the checks of G1-harness record 29, G5-app-lab record 10 and G7-suites record 16 therefore carry the first run's command text (python -I -B; once it printed 'is ready'; the one-line grep), and each says in its expected what ran (-X utf8 on the five makes; --check once the server had logged the launcher's GET / with status 200; the rule's line and its continuation), as INTEGRATION.md section 7 does."
  },
  "environment": {
   "interpreter": "C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe, for every run in both trees",
```

### reproduce_P.json: the first install's copy and the second install's

```diff
--- commit P, first install: reproduce_P.json
+++ commit P, second install: reproduce_P.json
@@ -21,7 +21,7 @@
   {"step": "G6 L6, L7 and d2 (cert_driver_P.sh g6)", "cwd": "S, candg, S/ref", "command": "bash tools/run_l6.sh; bash tools/check_l6.sh; HARNESS_PERTURB=<car.mass, thermal.c_turb, car.mass:1e-9, car.mass:1e-6> python -I -B tools/l6_agents.py candg sighted_seed0 ...; l6_check.py; python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/<sighted_seed0|blind_seed0> L7/cand_model/<tag>; cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval[_blind].txt L7/cand_model/<tag>; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0; python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; l7_diff.py and l7_expect.py (--agent blind_seed0); the scratch sighted_seed0 under d2: refused"},
   {"step": "G7 the suites and the documents (cert_driver_P.sh g7)", "cwd": "candg", "command": "commit A's S/tcl copied, then python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list; one <label> candg python -B <suite>.py -v for test_wide_air, test_epa_map (twice, the second with GRAD_EXTRA_DATA), test_plant_guards, random_road.py, fingerprint.py --engine b58, test_cars, test_trainable, test_fuel_forms, test_carried, test_tit_cap, test_epa_plants, test_preview_horizon; the HA.4, HA.5, HA.6 and HA.11 greps; python -B verify_docs.py; bash tools/run_drift.sh"},
   {"step": "G7.0 test_engine_threading, alone (p_gate.sh post)", "cwd": "the live repository, P's candidate applied uncommitted on RV", "command": "python -B test_engine_threading.py -v > S/suites/P_test_engine_threading.txt, after the roads check and every run above; git status unchanged after it"},
-  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md"},
+  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md (every make with -X utf8, as commit A's F.3: -I ignores PYTHONIOENCODING, and a FAIL record's got may carry a character cp1252 lacks)"},
   {"step": "F.3 into the repository (p_gate.sh cert-docs)", "cwd": "the live repository", "command": "the draft copied to results/B58_IDENTITY.json and .md; S/refw, candw, candt and pre removed; python -I -B tools/drift_control.py <repo> suites/P_drift_control_with_certificate.txt (a record); python -I -B tools/make_archive.py results/B58_IDENTITY/certificate_tools.tar.gz; python -I -B tools/make_cert.py results/B58_IDENTITY.json <archive> --config cert_P.json; python -I -B tools/make_md.py results/B58_IDENTITY.json results/B58_IDENTITY.md; drift_control.py again; python -B verify_docs.py"},
   {"step": "not run here", "cwd": "-", "command": "L8 (item 20) on the training device at ORDER step 18; app.test_results on P's own commit (p_gate.sh commit)"}
  ]
```

### tools/cert_driver_P.sh: the first install's copy and the second install's

```diff
--- commit P, first install: tools/cert_driver_P.sh
+++ commit P, second install: tools/cert_driver_P.sh
@@ -2,6 +2,13 @@
 # cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
 # 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
 # run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
+# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
+# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
+# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
+# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
+# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
+# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
+# launcher record, HA.4). The edited lines have not run.
 #
 #     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
 #
@@ -93,11 +100,16 @@
 secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
 blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
 tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
-              # unittest -v prints a test's result on its own line, or on the next one when the test has a docstring.
+              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
+              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
+              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
   lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
-    function res(l) { if (l ~ /\.\.\. ok$/) { ok++; return 1 } if (l ~ /\.\.\. skipped/) { sk++; return 1 }
-                      if (l ~ /\.\.\. (FAIL|ERROR)$/) { bad++; return 1 } return 0 }
-    pend { pend = 0; if (res($0)) next }
+    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
+                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
+                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
+                      return 0 }
+    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
+    pend { if (res($0)) { pend = 0; next } }
     $0 ~ h { if (!res($0)) pend = 1; next }
     $0 ~ f { bad++ }
     END { exit !(ok > 0 && sk == 0 && bad == 0) }'
@@ -396,11 +408,14 @@
     ( cd "$CERT_ROOT" || exit 9
       "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
         "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
-      "$PY" -I -B "$TW/a/tools/make_cert.py" "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
-      "$PY" -I -B "$TW/a/tools/make_md.py" "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
-      "$PY" -I -B "$TW/a/tools/make_md_P.py" "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
+      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
+      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
+      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
+      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
     ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
   else
     echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
@@ -414,7 +429,7 @@
   R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
     --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
     --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
-    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's)" \
+    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
     --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
     --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
   bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
@@ -548,7 +563,7 @@
 
 # ============================================================================= G3-roads
 g3() {
-  local t0 t1 bad got diffc
+  local t0 t1 bad got diffc want
   say "G3 begins"; t0=$(date +%s)
   t1=$(date +%s); bad=""
   ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
@@ -571,16 +586,22 @@
     echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
   wait
   # G3.1's record
+  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
+  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
   bad=""
   for t in "" _random; do
+    case "$t" in
+      "")      want="All checks pass. The reward is safe to train against.";;
+      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
+    esac
     grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
     cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
     [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
-    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "All checks pass. The reward is safe to train against." ] || bad="$bad${t:- default} last line"
+    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
   done
   R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
     --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
-    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last line 'All checks pass. The reward is safe to train against.' (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
+    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
     --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
     --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
     --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
@@ -834,10 +855,19 @@
       --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
     if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
       t1=$(date +%s)
+      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
+      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
+      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
+      # which the trigger below would fire before this run's server is up (a false FAIL)
+      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
       ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
         echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
       lp=$!
-      for i in $(seq 1 280); do grep -aq 'is ready' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
+      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
+      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
+      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
+      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
+      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
       ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
       wait "$lp"
       # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
@@ -867,7 +897,7 @@
       grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
         --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
         --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
     else
@@ -875,7 +905,7 @@
       say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
         --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
     fi
     # G5.3 the lab's node tests (after npm ci)
@@ -1178,15 +1208,17 @@
   suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
   suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
   # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
+  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
+  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
   ( cd "$REPO" && {
-      echo "== HA.4"; grep -n "engines.py" CLAUDE.md | grep -n "engine_specs"
+      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
       echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
       echo "== HA.6"; grep -n -i "scipy" requirements.txt
       echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
     } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
   bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
   R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
-    --cwd candg --expected "at least one line" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
+    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
     --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
   bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
   echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
```

### tools/cert_final_driver_P.sh: the first install's copy and the second install's

```diff
--- commit P, first install: tools/cert_final_driver_P.sh
+++ commit P, second install: tools/cert_final_driver_P.sh
@@ -122,8 +122,11 @@
 
 # ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
 t0=$(date +%s)
-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
+# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
+# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
+# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
 head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
 bad=""
 [ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
@@ -142,14 +145,14 @@
 [ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
 [ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
 R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
-  --command "python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
+  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
   --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
   --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
   --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt
 
 # ---- F.2 the draft certificate in scratch
-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
+"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
 say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
 [ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }
 
```

### TOOL_EDITS.md: the first install's and this install's, up to this section

Applied in reverse (patch --binary -R) to the lines of this file above this section's heading, less the blank
line before it, it gives the first install's TOOL_EDITS.md byte for byte. It is fenced with four backticks,
because it quotes this file's own three-backtick fences.

````diff
--- S/TOOL_EDITS.md, first install
+++ S/TOOL_EDITS.md, second install (up to its section)
@@ -1139,13 +1139,15 @@
 
 ## commit P (build step 2, ORDER step 14): the tools as P's certificate runs them
 
-Installed by p_gate.sh cert-kit on 2026-11-07 from the kit cert_kit/, reviewed (its
+Installed by p_gate.sh cert-kit on 2026-11-08 from the kit cert_kit/, reviewed (its
 sha256 list: decisions/cert_kit_reviewed.txt). Each file below: commit A's sha256 (the archive's), P's, and the diff.
 
 P's certificate (CERT_PLAN_P.md; the interface sheet 6.8; row 138 (4)) runs commit A's tools as commit A left them, but for the files listed below, each with its diff against the archive's copy. The kit was written before the run, reviewed, and its sha256 list recorded (decisions/cert_kit_reviewed.txt); nothing here changed during the run. Drafted 7 November 2026; nothing in it has run: `bash -n` parsed the shell files, and no Python file was executed.
 
 Commit A's copy of every edited tool is the archive's (results/B58_IDENTITY/certificate_tools.tar.gz at RV), read out of it; commit A's own S (scratchpad cert2) holds the same bytes. p_gate.sh cert-kit appends, below this section, each kit file's two sha256 and its diff again, computed at install time against X: the two must agree.
 
+Second edit, 8 November 2026 (after the first run's five FAIL records): the section "commit P, second edit" at the end names each FAIL and its fix, gives the sha256 of each file it changed before and after, and its diff against the first run's copy (S's installed one). The table of the new files below gives each sha256 as the file now stands.
+
 ### Why each file changed
 
 - `tools/make_meta.py` (CERT_PLAN_P G6.3 and G6.4; the interface sheet 6.8). Schema 3's `plant_fingerprint(plant=, protocol="phase-d", backend=)` cannot be called at P: schema 4's takes every FATAL input by keyword, with no default (rule 1.7, mistake 19). The live block is now `FP.plant_fingerprint(protocol="phase-d", plant=engines.get("b58"), train_backend=FP.BACKEND_CYCLE, score_backend=FP.BACKEND_CYCLE, preview_h_s=engine_env.PREVIEW_H_S, reward_knock=engine_env.REWARD_KNOCK_DEFAULT)`, then `FP.for_arm(live, sighted="blind" not in os.path.basename(src))`, evaluate.py's arm rule, so that `blind_seed0` is stamped with the blinded arm's block (preview_h_s None, row 117) and `sighted_seed0` with the sighted one. The `identity_override` reason names P's certificate and this tree's schema-4 block, and records the arm. (Review fixes 3, P_GATE_PLAN.md section 12: the reason says that both agents are diffed against cf43fbb's evaluate.py, sighted_seed0 against build step 1's report and blind_seed0 against cf43fbb's run made in S/ref, as the driver does; before, it named sighted_seed0 alone.)
@@ -1977,21 +1979,401 @@
 |---|---|
 | `tools/failing_sets_P.py` | `56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc` |
 | `tools/stated_counts_P.py` | `7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7` |
-| `tools/cert_driver_P.sh` | `bfec15faca167a16bfd8faa4cedf4f5002cf14959a2a919545bdcc6515a11a59` |
-| `tools/cert_final_driver_P.sh` | `ab46791e31bba212e0c9356a9551f5c4c2bd5707efecc21d0f99d76fbd2d822d` |
-| `cert_P.json` | `c0f3dc95cf26a32dfc5efa4fa074e6dd1a29492fcaa4c98545510804b8c70202` |
-| `reproduce_P.json` | `bd1c99a0755558cc0e4d7bcb7c0e7445c5ee34a503f59098ef43377fc83a3888` |
-| `INTEGRATION.md` | `cf8f49b56cc75c1fa50990a1bc67849c57a7bb2d0170a1f087a5a444a2c74e18` |
+| `tools/cert_driver_P.sh` | `17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21` |
+| `tools/cert_final_driver_P.sh` | `f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1` |
+| `cert_P.json` | `ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193` |
+| `reproduce_P.json` | `b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517` |
+| `INTEGRATION.md` | `e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3` |
+
+(The sha256 of the five files the second edit changed are the edited files'. The first run's, as cert-kit installed them on S on 7 November, are in the section below.)
+
+### commit P, second edit (after the first run's five FAILs, 8 November 2026)
+
+The first run of P's certificate (p_gate.sh cert, 16:08Z on 7 November to 03:00Z on 8 November 2026, 39139 s beside the roads check) wrote 106 records: 101 PASS, 5 FAIL (`out/cert_fail_records.txt`, all five OPEN). Each FAIL was read in its evidence (`hand/cert_fails_plan.md`, sections 1 and 2). All five are defects of the kit's driver, `tools/cert_driver_P.sh`; none is in P's code: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and the exits were lost to a cp1252 print, in commit A's tool as in P's. In G5.2 the launcher met its expectation, and `--check` ran only as the server stopped. The route is the orchestrator's decision (Ghassan's standing instruction): the re-check on the same S, as commit A re-checked its FAILs (its records name the re-checked FAILs, and its TOOL_EDITS.md records its edits), not a new S. The edited kit is installed on the started S through one new, explicit, recorded route of p_gate.sh, applied after the roads check ends; then g1, g3, g5 and g7 are re-run there with `p_gate.sh cert-recheck <g>`, each re-run PASS naming the FAIL it re-checks, and the five FAIL records stay in the certificate beside the re-check records that name them (`rechecks`; make_cert.py adds `rechecked_by`). The kit was edited after the cert phase had ended, while the roads check still ran (no running phase reads the kit again); none of the edited lines has run, and no Python ran for this edit.
+
+#### The five FAIL records, each with its fix
+
+- **E1: G1-harness.json record 29** (control, B9, "commit A's certificate route (--config) is unchanged by P's edits"; got `differs: an exit`, 2 of the 5 `exit 0` lines). G1.7(b) ran commit A's make_cert.py, P's make_cert_P.py and the control under `-I -B` without `-X utf8`. `-I` ignores env_P.sh's PYTHONIOENCODING, so stdout, redirected to a file, was cp1252; commit A's cert_A.json carries commit A's re-checked FAIL records, and printing G5-app-lab record 22's got (Arabic text, launch.py's title) raised UnicodeEncodeError after the JSON had been written, in commit A's unedited make_cert.py and in P's alike (the same characters, positions 464-468). Both JSONs and both pages were byte-identical, which is what B9 asks. Fix: `-X utf8` on (b)'s five calls (`cert_driver_P.sh` g1_7 part (b)); the json snippet before them is unchanged. Commit A had met it: its TOOL_EDITS.md, "commit A, the final step": "F.3 runs make_cert.py and make_md.py with `-X utf8` (`-I` ignores PYTHONIOENCODING, and printing a record with a character cp1252 lacks raised UnicodeEncodeError after the JSON was written)"; reproduce_A.json runs every make with `-I -X utf8`.
+- **E2: G3-roads.json record 2** (L4, 3.6.4, "test_reward.py and --road random, the candidate's stdouts against cf43fbb's"; got `differs:_random last line`). The driver asked the `--road random` run for the default run's last line. `test_reward.py --road random` ends, on cf43fbb as on the candidate, with "All checks pass on every D2 road. The reward is safe to train against on the randomised climb."; both stdouts were byte-identical to cf43fbb's, exit 0 twice (2701 s and 2255 s), stderr empty. Fix: each run's own expected last line (`want`, declared local in g3); `--expected` names both lines. CERT_PLAN_A G3.1 types the default line once for both runs; its byte-identity clause, and commit A's records of the same stdout (commit A's candidate's random stdout is the same bytes), fix the D2 line.
+- **E3: G5-app-lab.json record 10** (L5, "3.6.12, HA.3", "the lab launcher and launch.py --check"; got `differs: --check`). The driver waited for `is ready`, which launch.py prints to block-buffered stdout: the line reached the file only at the launcher's exit, at the 300 s timeout, so `--check` ran as the server stopped and printed "Local app is not running with its built frontend", exit 1. The launcher itself logged `GET /api/meta` 200 and `GET /` 200, then "Supra Lab is ready", then exit 124; launch.py is byte-identical in the candidate, cf43fbb and commit A's candidate. Fix: the trigger is the server's own access line `"GET / HTTP/1.1" 200` for the launcher's request, which uvicorn's logging writes record by record. Commit A had met it: its first-cycle launcher record ("printed to block-buffered stdout, so it reached the file only at exit: the plan's wait for it cannot fire early"), and its second cycle, which passed with the trigger "when the launcher's own GET / was served". Rejected: `-u` on the launcher (it changes how the program under test runs) and PYTHONUNBUFFERED (it changes all fifteen G5 runs, and no record would declare it). Before the launcher starts, the driver now also removes an earlier run's launcher log and `--check` output (added after the reviews: see "Revised after the second edit's two reviews" below).
+- **E4: G7-suites.json record 12** (suite, "3.6.15, HP7.1, B8, HP7.6", "test_trainable.py (B8: the refusals and their controls, SummaryDrop the literal case)"; got `differs: RealTree; Ran 23 tests ... OK`). `tests_ok` read a test's result only on its header line or the next one. RealTree.test_the_real_records_decide writes its expectation to stderr in the middle of the test, by design (its docstring, CERT_PLAN_P G7.3 and section 4, P_GATE_PLAN H6a), so unittest's `ok` stands alone two lines after the header, and RealTree counted no test ok. 23 tests ran, OK, exit 0, and RealTree's own line reads `('b58',)` against `('b58',)`. pre's log (`out/pre_test_trainable.log`) already had the same layout before the window. Fix: a result is pending until the next test header, and a bare `ok`, `FAIL`, `ERROR` or `skipped ...` line counts while it is pending. Otherwise the rule is as before, but that a test header now ends a pending result, so that the next test's own result line is never counted for the pending one.
+- **E5: G7-suites.json record 16** (docs, HA.4, "CLAUDE.md's re-run rule names engines.py and engine_specs/"; got `differs: no line`). The driver ran CERT_PLAN_A G7.4's one-line grep (CERT_PLAN_A.md:604, verbatim) as a check of at least one line; the rule wraps (CLAUDE.md:137-138), so no single line holds both names. Fix: `grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, the rule's line and its continuation, both kept as evidence; `--expected` says so; the judgement (at least one line) is unchanged. Commit A had met it: its F-certificate HA.4 record, a PASS: "the plan's one-line grep ... prints nothing, because the rule wraps: CLAUDE.md:137-138 ...; both names present in the one rule".
+- **E6 (hardening; no FAIL record).** `tools/cert_final_driver_P.sh` runs its four makes (3.6.19's draft0, F.2's draft) with `-X utf8`, and says so in the 3.6.19 record's `--command` (a record no run has written yet) and in reproduce_P.json's F.1/F.2 step. Only G5's two node records can carry a got with a character cp1252 lacks (the node runner's info sign); if one FAILed, a later make would print it and stop. cert-docs' makes (p_gate.sh) still run with `-I -B`: p_gate.sh is not edited here.
+
+#### The texts kept, and what the re-run runs
+
+- Every record of the edited checks keeps its `--what` as the first run wrote it: CERT_RECHECK_MAP pairs a re-run PASS with its FAIL by the `what` (the driver's `R`), and each of the five `what`s names one record of its file.
+- Every record keeps its `--command` too (cert_fails_plan.md section 4, the re-check route): p_gate.sh's recheck_prep treats the records of one `what` as one check only when level, item and command agree, so a changed command would make a second re-check of the same check refuse ("another check", P_GATE_PLAN 13.5). The commands of G1-harness record 29 ("... python -I -B: ..."), G5-app-lab record 10 ("once it printed 'is ready'") and G7-suites record 16 ("grep -n engines.py candg/CLAUDE.md | grep engine_specs") therefore name what the first run ran, in the first run's records and in every re-run record of those checks alike; what the re-run runs is above (E1, E3, E5), in INTEGRATION.md section 7, in cert_P.json's `notes.first_run`, which the page prints, and in each of those records' `--expected`.
+- `--expected` changes for G3-roads record 2 (both last lines) and G7-suites record 16 (the grep that runs, and the two lines), and, so that each says what runs, for G1-harness record 29 (the five makes with `-X utf8`) and G5-app-lab record 10 (the trigger; both of the check's R calls, the launcher's and the port-taken one); no record's level or item changes. `cert_driver_P.sh` lines that carry `--what` or `--command`: none changed (diff below).
+
+#### Replayed by text (bash and awk on the first run's own files, read-only; no Python)
+
+The functions and the loop were taken from the edited driver's own text (and, for contrast, from S's installed copy, the first run's), and run on the first run's outputs in S.
+
+- **E2** (G3.1's judgement): the first run's `S/L4` files: before, `bad=[_random last line]`, FAIL; after, `bad=[]`, PASS. Negative control (a scratch copy whose `--road random` stdout ends with the default line, its reference copy alike): before PASS; after `bad=[_random last line]`, FAIL. The files: `cand` ends "All checks pass. The reward is safe to train against.", `cand_random` "All checks pass on every D2 road. The reward is safe to train against on the randomised climb."; both cmp-equal to `ref*`, exit 0 in 2701 s and 2255 s, stderr 0 bytes.
+- **E4** (`tests_ok` and `cls_ok`): `S/suites/cand_test_trainable.txt`, before: Help, B58, RecordsAbsent, SummaryDrop, BackendDrop ok, RealTree FAIL; after: all six ok. `out/pre_test_trainable.log`: the same, before and after. Negative control (a scratch copy with RealTree's bare `ok` changed to `FAIL`, one line): after, RealTree FAIL and the other five ok. Unchanged verdicts, before and after: EngineSha (`cand_test_fuel_forms.txt`) ok, BlindBitForBit (`cand_test_preview_horizon.txt`) ok, GitDirtyPlantFiles (`cand_test_plant_guards.txt`) ok, and G5's lab pin test (`app/cand_lab_tests.txt`, the other caller of `tests_ok`) ok.
+- **E5** (HA.4, in candg at P's candidate, clean): before, 0 lines, FAIL (" no line"), as the first run's `suites/P_G7_docs_checks.txt` holds; after, 2 lines (`137:- After changing ... engines.py ...` and `138-  engine_specs/ ...`), PASS. Negative control (a scratch copy of candg's CLAUDE.md, CRLF kept, with `engine_specs/` removed, one line changed): 0 lines, FAIL.
+- **E1 and E3** cannot be replayed without Python. E1 rests on commit A's F.3 makes, which exited 0 with `-X utf8` on the same records; E3 on commit A's second cycle, which passed with the same trigger. By text only: the first run's launcher log holds the line `"GET / HTTP/1.1" 200`, on which the new trigger fires; when it would have fired cannot be replayed. The removal of an earlier run's log before the launcher starts (below) has not run either.
+- `bash -n` parses every kit shell file (the two drivers, env_P.sh and the eight tools).
+
+#### Revised after the second edit's two reviews (8 November 2026)
+
+Two independent, read-only reviews of the second edit and of the p_gate.sh patch for the second install found no blocking item and five material ones: four in the kit (two of them one item, the wording below, found by both) and one in the text the patch writes into S/TOOL_EDITS.md for the second install. The kit's are fixed here, by a fixer who wrote neither the edit nor the patch; the patch's is fixed in the patch.
+
+- **The commands kept, what runs named.** The B9 record (G1-harness record 29's check), G5.2's launcher record (both of its R calls) and HA.4 keep their `--command` text, so that recheck_prep reads every run of each as one check (its key: level, item, command; make_cert.py pairs records only by `rechecks`, so `--expected` is free). Each now says in its `--expected` what runs, so that no re-run record states a command and contradicts it (before, HA.4's re-run would have read: command, the one-line grep; expected, "the one-line grep prints nothing"; got, 2 lines).
+- **G5.2: the first run's launcher log removed before the launcher starts.** `cert-recheck g5` never removed `lab/P_G5_launch_no_browser.txt`: recheck_prep copies a record's evidence aside and leaves the original, and the launcher's own truncation of the file happens in the background subshell, unordered against the trigger's first grep. The first run's log already holds `"GET / HTTP/1.1" 200`, so the trigger could fire on it before the new server was up: a false FAIL, never a false PASS. The driver now runs `rm -f` on that log and on `lab/P_G5_launch_check.txt` in the foreground, before the launcher starts. The first run's copies are by then under `recheck/G5-app-lab_<stamp>/`, and record 10's evidence_files name them. No `--what` or `--command` changed.
+- **The texts that ship worded as measured facts, whatever the re-checks find.** cert_P.json's `notes.first_run` and this section said that in each of the five FAILs the output under test met the expectation, and they and INTEGRATION.md 7 said that G1, G3, G5 and G7 were re-run, or re-checked, once each. In G1.7(b) three makes exited 1 (the JSONs and pages were byte-identical), and in G5.2 `--check` exited 1 (it ran as the server stopped); and a second re-check of one check is a planned fallback. Each text now says what the evidence shows of each FAIL, and that the four groups are re-run with cert-recheck, the re-check records saying what each re-run found.
+- None of these lines has run; `bash -n` parses the driver.
+
+#### The files the second edit changed (sha256)
+
+| file | the first run's (S's installed copy, 7 November) | after the second edit |
+|---|---|---|
+| `tools/cert_driver_P.sh` | `bfec15faca167a16bfd8faa4cedf4f5002cf14959a2a919545bdcc6515a11a59` | `17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21` |
+| `tools/cert_final_driver_P.sh` | `ab46791e31bba212e0c9356a9551f5c4c2bd5707efecc21d0f99d76fbd2d822d` | `f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1` |
+| `cert_P.json` | `c0f3dc95cf26a32dfc5efa4fa074e6dd1a29492fcaa4c98545510804b8c70202` | `ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193` |
+| `reproduce_P.json` | `bd1c99a0755558cc0e4d7bcb7c0e7445c5ee34a503f59098ef43377fc83a3888` | `b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517` |
+| `INTEGRATION.md` | `cf8f49b56cc75c1fa50990a1bc67849c57a7bb2d0170a1f087a5a444a2c74e18` | `e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3` |
+
+Every other kit file is unchanged: cmp-equal to the copy cert-kit installed on S for the first run (`env_P.sh` and `tools/` `cert_record.py`, `check_l6.sh`, `compare_all.sh`, `failing_sets_P.py`, `l7_expect.py`, `make_cert.py`, `make_md.py`, `make_meta.py`, `road_json_diff.py`, `run_app.sh`, `run_app_extra.sh`, `run_drift.sh`, `run_jobs.py`, `run_l4.sh`, `run_l6.sh`, `run_writer.sh`, `stated_counts_P.py`); this file is the twenty-fourth.
+
+#### The diffs of the second edit (the first run's copy, S's installed one, against the kit's)
+
+##### tools/cert_driver_P.sh
+
+```diff
+--- commit P, the first run: tools/cert_driver_P.sh
++++ commit P, second edit: tools/cert_driver_P.sh
+@@ -2,6 +2,13 @@
+ # cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
+ # 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
+ # run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
++# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
++# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
++# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
++# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
++# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
++# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
++# launcher record, HA.4). The edited lines have not run.
+ #
+ #     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
+ #
+@@ -93,11 +100,16 @@
+ secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
+ blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
+ tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
+-              # unittest -v prints a test's result on its own line, or on the next one when the test has a docstring.
++              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
++              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
++              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
+   lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
+-    function res(l) { if (l ~ /\.\.\. ok$/) { ok++; return 1 } if (l ~ /\.\.\. skipped/) { sk++; return 1 }
+-                      if (l ~ /\.\.\. (FAIL|ERROR)$/) { bad++; return 1 } return 0 }
+-    pend { pend = 0; if (res($0)) next }
++    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
++                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
++                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
++                      return 0 }
++    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
++    pend { if (res($0)) { pend = 0; next } }
+     $0 ~ h { if (!res($0)) pend = 1; next }
+     $0 ~ f { bad++ }
+     END { exit !(ok > 0 && sk == 0 && bad == 0) }'
+@@ -396,11 +408,14 @@
+     ( cd "$CERT_ROOT" || exit 9
+       "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
+         "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
+-      "$PY" -I -B "$TW/a/tools/make_cert.py" "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
+-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
+-      "$PY" -I -B "$TW/a/tools/make_md.py" "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
+-      "$PY" -I -B "$TW/a/tools/make_md_P.py" "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
+-      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
++      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
++      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
++      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
+     ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
+   else
+     echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
+@@ -414,7 +429,7 @@
+   R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
+     --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
+     --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
+-    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's)" \
++    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+     --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
+     --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
+   bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
+@@ -548,7 +563,7 @@
+ 
+ # ============================================================================= G3-roads
+ g3() {
+-  local t0 t1 bad got diffc
++  local t0 t1 bad got diffc want
+   say "G3 begins"; t0=$(date +%s)
+   t1=$(date +%s); bad=""
+   ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
+@@ -571,16 +586,22 @@
+     echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
+   wait
+   # G3.1's record
++  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
++  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
+   bad=""
+   for t in "" _random; do
++    case "$t" in
++      "")      want="All checks pass. The reward is safe to train against.";;
++      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
++    esac
+     grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
+     cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
+     [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
+-    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "All checks pass. The reward is safe to train against." ] || bad="$bad${t:- default} last line"
++    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
+   done
+   R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
+     --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
+-    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last line 'All checks pass. The reward is safe to train against.' (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
++    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
+     --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+     --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
+     --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
+@@ -834,10 +855,19 @@
+       --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
+     if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
+       t1=$(date +%s)
++      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
++      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
++      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
++      # which the trigger below would fire before this run's server is up (a false FAIL)
++      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
+       ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
+         echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
+       lp=$!
+-      for i in $(seq 1 280); do grep -aq 'is ready' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
++      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
++      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
++      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
++      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
++      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
+       ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
+       wait "$lp"
+       # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
+@@ -867,7 +897,7 @@
+       grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
+       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
+         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
+-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
++        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+         --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
+         --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
+     else
+@@ -875,7 +905,7 @@
+       say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
+       R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
+         --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
+-        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
++        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
+         --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
+     fi
+     # G5.3 the lab's node tests (after npm ci)
+@@ -1178,15 +1208,17 @@
+   suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
+   suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
+   # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
++  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
++  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
+   ( cd "$REPO" && {
+-      echo "== HA.4"; grep -n "engines.py" CLAUDE.md | grep -n "engine_specs"
++      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
+       echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
+       echo "== HA.6"; grep -n -i "scipy" requirements.txt
+       echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
+     } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
+   bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
+   R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
+-    --cwd candg --expected "at least one line" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
++    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
+     --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
+   bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
+   echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
+```
+
+##### tools/cert_final_driver_P.sh
+
+```diff
+--- commit P, the first run: tools/cert_final_driver_P.sh
++++ commit P, second edit: tools/cert_final_driver_P.sh
+@@ -122,8 +122,11 @@
+ 
+ # ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
+ t0=$(date +%s)
+-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
+-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
++# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
++# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
++# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
++"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
+ head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
+ bad=""
+ [ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
+@@ -142,14 +145,14 @@
+ [ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
+ [ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
+ R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
+-  --command "python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
++  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
+   --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
+   --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
+   --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt
+ 
+ # ---- F.2 the draft certificate in scratch
+-"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
+-"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
+ say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
+ [ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }
+ 
+```
+
+##### cert_P.json
+
+```diff
+--- commit P, the first run: cert_P.json
++++ commit P, second edit: cert_P.json
+@@ -120,7 +120,8 @@
+   "nothing_computed_moved": "Every value the harness, L6 and build_dataset compared is meant to be the same double in both trees (the counts are in the verdict line), and every writer's output and every report to equal cf43fbb's; the differences section 5 lists are labels, code hashes, run times and committed files older than the code on both trees.",
+   "why_plant_sha_moves": "plant_sha hashes the code of fingerprint.plant_files('b58') -- plant.py, thermal.py, engine_env.py, derived.py and engines.py -- and the values of the B58's two spec files. P edits engine_env.py (H a parameter, the reward's knock option) and engines.py (trainable() read from the committed records), so plant_sha moves although no computed value is meant to; it names P's plant, which every later step of build step 2 is compared against. fingerprint.py, which P also edits, is not in PLANT_CODE.",
+   "why_engine_sha_does_not_move": "engine_sha hashes every value of the plant as built (engines.engine_sha), and P adds and changes no field of the B58's records: engine_sha is commit A's (a check of section 1), and over build step 1's key set it is still build step 1's (amendment B11).",
+-  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2)."
++  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2).",
++  "first_run": "The first run of this certificate's groups (7-8 November 2026, 16:08Z to 03:00Z, 39139 s beside the roads check) wrote 101 PASS and 5 FAIL records: G1-harness record 29, G3-roads record 2, G5-app-lab record 10, G7-suites records 12 and 16. All five were defects of the kit's driver (tools/cert_driver_P.sh), not of P: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and three of the five makes exited 1, each only when printing, after writing its JSON: the driver ran them without -X utf8, and commit A's make_cert.py and P's alike stopped printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic text) to a cp1252 stdout. In G5.2 the launcher met its expectation ('is ready', exit 124), and --check ran only as its server stopped: the driver waited for a line launch.py prints to block-buffered stdout, which reaches the file only at the launcher's exit. G3.1 asked the --road random run for the default run's last line; G7.2's parser missed RealTree's ok, printed on a line of its own after RealTree's stderr line; G7.4 grepped one line for a rule that wraps (CLAUDE.md:137-138). The driver was corrected (TOOL_EDITS.md, section 'commit P', its part 'commit P, second edit'), reviewed again, installed on the same S after the roads check ended (TOOL_EDITS.md, section 'commit P, second install'), and G1, G3, G5 and G7 re-run there with cert-recheck: the re-check records say what each re-run found. The five FAIL records stay in this certificate; a re-run PASS record that re-checks one names it (rechecks), and the FAIL gains rechecked_by. The edited checks keep the first run's what and command texts, so that every run of one check is the same check: the re-run records of the checks of G1-harness record 29, G5-app-lab record 10 and G7-suites record 16 therefore carry the first run's command text (python -I -B; once it printed 'is ready'; the one-line grep), and each says in its expected what ran (-X utf8 on the five makes; --check once the server had logged the launcher's GET / with status 200; the rule's line and its continuation), as INTEGRATION.md section 7 does."
+  },
+  "environment": {
+   "interpreter": "C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe, for every run in both trees",
+```
+
+##### reproduce_P.json
+
+```diff
+--- commit P, the first run: reproduce_P.json
++++ commit P, second edit: reproduce_P.json
+@@ -21,7 +21,7 @@
+   {"step": "G6 L6, L7 and d2 (cert_driver_P.sh g6)", "cwd": "S, candg, S/ref", "command": "bash tools/run_l6.sh; bash tools/check_l6.sh; HARNESS_PERTURB=<car.mass, thermal.c_turb, car.mass:1e-9, car.mass:1e-6> python -I -B tools/l6_agents.py candg sighted_seed0 ...; l6_check.py; python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/<sighted_seed0|blind_seed0> L7/cand_model/<tag>; cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval[_blind].txt L7/cand_model/<tag>; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0; python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; l7_diff.py and l7_expect.py (--agent blind_seed0); the scratch sighted_seed0 under d2: refused"},
+   {"step": "G7 the suites and the documents (cert_driver_P.sh g7)", "cwd": "candg", "command": "commit A's S/tcl copied, then python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list; one <label> candg python -B <suite>.py -v for test_wide_air, test_epa_map (twice, the second with GRAD_EXTRA_DATA), test_plant_guards, random_road.py, fingerprint.py --engine b58, test_cars, test_trainable, test_fuel_forms, test_carried, test_tit_cap, test_epa_plants, test_preview_horizon; the HA.4, HA.5, HA.6 and HA.11 greps; python -B verify_docs.py; bash tools/run_drift.sh"},
+   {"step": "G7.0 test_engine_threading, alone (p_gate.sh post)", "cwd": "the live repository, P's candidate applied uncommitted on RV", "command": "python -B test_engine_threading.py -v > S/suites/P_test_engine_threading.txt, after the roads check and every run above; git status unchanged after it"},
+-  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md"},
++  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md (every make with -X utf8, as commit A's F.3: -I ignores PYTHONIOENCODING, and a FAIL record's got may carry a character cp1252 lacks)"},
+   {"step": "F.3 into the repository (p_gate.sh cert-docs)", "cwd": "the live repository", "command": "the draft copied to results/B58_IDENTITY.json and .md; S/refw, candw, candt and pre removed; python -I -B tools/drift_control.py <repo> suites/P_drift_control_with_certificate.txt (a record); python -I -B tools/make_archive.py results/B58_IDENTITY/certificate_tools.tar.gz; python -I -B tools/make_cert.py results/B58_IDENTITY.json <archive> --config cert_P.json; python -I -B tools/make_md.py results/B58_IDENTITY.json results/B58_IDENTITY.md; drift_control.py again; python -B verify_docs.py"},
+   {"step": "not run here", "cwd": "-", "command": "L8 (item 20) on the training device at ORDER step 18; app.test_results on P's own commit (p_gate.sh commit)"}
+  ]
+```
+
+##### INTEGRATION.md
+
+```diff
+--- commit P, the first run: INTEGRATION.md
++++ commit P, second edit: INTEGRATION.md
+@@ -125,7 +125,8 @@
+ 
+ A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
+ (review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
+-before its lab_dump.py; G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
++before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
++(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
+ `cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
+ `suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
+ first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
+@@ -311,7 +312,11 @@
+ - **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
+   takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
+   runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
+-  P_GATE_PLAN.md 11.2.) (a) In a fresh extraction of build step 1's archive (`c47907b`'s), build step 1's
++  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
++  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
++  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
++  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
++  extraction of build step 1's archive (`c47907b`'s), build step 1's
+   make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
+   committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
+   since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
+@@ -324,6 +329,11 @@
+ - **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
+ - **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
+   cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
++- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
++  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
++  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
++  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
++  road. The reward is safe to train against on the randomised climb.' (`--road random`).
+ - **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
+   each committed file (road_json_diff.py) is a `--difference` text, not judged.
+ - **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
+@@ -339,6 +349,17 @@
+   skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
+   configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
+   second time, so that a failure RV already has reads as such.
++- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
++  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
++  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
++  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
++  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
++  cycle, which passed, used this trigger. The record's
++  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
++  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
++  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
++  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
++  original), and the trigger would fire on it before the new server is up.
+ - **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
+   block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
+   strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
+@@ -350,14 +371,27 @@
+ - **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
+   `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
+   SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
+-  ran ok and none was skipped or failed.
++  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
++  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
++  result pending until the next test header.
++- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
++  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
++  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
++  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
++  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
++  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
++  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
++  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
++  runs.
+ - **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
+ - **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
+   record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
+   list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
+   (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
+   no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
+-  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it).
++  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
++  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
++  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
+ - **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
+   eight processes as run_l6.sh starts them; four evaluate.py at once in G6.
+ 
+```
 
 ### INTEGRATION.md
 
 commit A: no such file (new in P)
-commit P: sha256 cf8f49b56cc75c1fa50990a1bc67849c57a7bb2d0170a1f087a5a444a2c74e18
+commit P: sha256 e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3
 
 ```diff
 --- commit A: INTEGRATION.md
 +++ commit P: INTEGRATION.md
-@@ -0,0 +1,407 @@
+@@ -0,0 +1,441 @@
 +# P's B58 certificate kit: how p_gate.sh uses it
 +
 +Drafted 7 November 2026 for P_GATE_PLAN.md section 5.2 (K1-K8) and section 8 (R1.B3, R2.B2). **Nothing in the kit
@@ -2119,7 +2501,8 @@
 +
 +A `CERT_ONLY=<g>` run (cert-recheck) first removes the group's own earlier outputs that its checks count or compare
 +(review fixes 3): G1 `out/P_G1_*/`, `cmp/ref_vs_P_G1_*/`, `cmp/P_G1_cand_vs_P_G1_*/`; G5 each `lab/lab_*_P*.json` just
-+before its lab_dump.py; G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
++before its lab_dump.py, and `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt` just before the launcher
++(second edit, 8 November 2026: the launcher's trigger reads the first, section 7, G5.2); G6 `L6/_status.txt`, `L6/P_G6_ctl_status.txt`, `L6/{cand,ref,P_G6_ctl}_*.npz`, `cmp/L6_*.json`,
 +`cmp/P_G6_L6_ctl_*_committed.json`, L7's and F11's candidate outputs and `L7/cand_model/`; G7
 +`suites/cand_test_epa_map_with_2021_2023.txt`. The first run does the same (there is nothing to remove then). The
 +first run's evidence is safe: p_gate.sh cert-recheck copies it aside first. References (`S/L7/ref_eval.txt`,
@@ -2305,7 +2688,11 @@
 +- **G1.7 at P** (B9): three records. (The one place a tool runs from inside an extracted archive, since make_cert.py
 +  takes S from its own path: each extraction is first checked against its own archive_members.txt, nothing in it
 +  runs unless that passes, and every call runs with `-I -B` and the cwd CERT_ROOT, outside the extraction;
-+  P_GATE_PLAN.md 11.2.) (a) In a fresh extraction of build step 1's archive (`c47907b`'s), build step 1's
++  P_GATE_PLAN.md 11.2; (second edit, 8 November 2026) (b)'s five makes also run with `-X utf8`, as commit A's F.3
++  ran every make: `-I` ignores PYTHONIOENCODING, and commit A's config carries its re-checked FAIL records, whose
++  G5-app-lab 22 got holds Arabic text, so on a cp1252 stdout commit A's make_cert.py and P's alike raised
++  UnicodeEncodeError after writing byte-identical JSONs (the first run's G1-harness record 29).) (a) In a fresh
++  extraction of build step 1's archive (`c47907b`'s), build step 1's
 +  make_cert/make_md and P's, without --config: byte-identical JSON and page; the difference from build step 1's
 +  committed page is counted, not judged (commit A found line 30 only; the repository's committed files have moved
 +  since). (b) In a fresh extraction of commit A's archive (RV's): commit A's tools and P's on commit A's own
@@ -2318,6 +2705,11 @@
 +- **G2.4**: L9's count is the contract's own (`N of N ... -> PASS`), not a typed 25.
 +- **G2.1**: check_premise.py's stdout equals commit A's candidate's byte for byte (commitA/L5/), which differs from
 +  cf43fbb's by the line `plant: b58b30o1/a90-supra-zf8hp51`.
++- **G3.1** (second edit, 8 November 2026; the first run's G3-roads record 2): CERT_PLAN_A G3.1 types the default
++  run's last line once for both runs; the plan's byte-identity clause and commit A's G2/G3 records fix the D2 line
++  for `--road random`, which test_reward.py ends with on cf43fbb as on the candidate. So each run is asked for its
++  own: 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2
++  road. The reward is safe to train against on the randomised climb.' (`--road random`).
 +- **G3.2**: check_random_road.py's stdout equals commit A's candidate's but for the run-time line; the comparison with
 +  each committed file (road_json_diff.py) is a `--difference` text, not judged.
 +- **G5.1** (review fixes 2: CERT_PLAN_A.md's judgement, which CERT_PLAN_P.md does not amend): a suite's failures may
@@ -2333,6 +2725,17 @@
 +  skipped; cf43fbb's clone, without them: 294 pass, 12 skipped). The survey's prediction now runs in that
 +  configuration (its committed_data stage), and prints each suite's list twice, with RV's run beside cf43fbb's the
 +  second time, so that a failure RV already has reads as such.
++- **G5.2** (second edit, 8 November 2026; the first run's G5-app-lab record 10), amending CERT_PLAN_A G5.2's "wait
++  for 'is ready'": `launch.py --check` runs once the server has logged the launcher's own `"GET / HTTP/1.1" 200`
++  (uvicorn's logging writes record by record). launch.py prints 'is ready' to block-buffered stdout, so the line
++  reaches the file only at the launcher's exit (commit A's first-cycle record): the first run's `--check` ran as the
++  300 s window closed and printed "Local app is not running with its built frontend", exit 1. Commit A's second
++  cycle, which passed, used this trigger. The record's
++  `--command` text still says "once it printed 'is ready'", as the first run wrote it, and its `--expected` names the
++  trigger (see the G7.4 HA.4 line). Before the launcher starts, the driver removes an earlier run's
++  `lab/P_G5_launch_no_browser.txt` and `lab/P_G5_launch_check.txt`: on cert-recheck g5 the first run's log, which
++  already holds that access line, is still at its path (recheck_prep copies a record's evidence aside and leaves the
++  original), and the trigger would fire on it before the new server is up.
 +- **G5.4**: `VERDICT: DIFFERENT`, exit 1; as many leaf values as commit A's comparison; `4 other differences`, and the
 +  block of the four (path, ref, new) byte-identical to commit A's; the counts of moved source lines and re-worded
 +  strings are P's own (P edits engine_env.py) and not judged. lab_ref_P.json byte-identical to commit A's lab_ref_A.json.
@@ -2344,14 +2747,27 @@
 +- **G7.2**: counts are the runs' own; classes judged by name: GitDirtyPlantFiles (HA.10), EngineSha with its line
 +  `engine_sha <G1.0's>; without [...]: <commit A's over_build_step_1_keys>` (B11), Help, B58, RecordsAbsent,
 +  SummaryDrop, BackendDrop, RealTree (B8), BlindBitForBit (row 138 (4)); a class passes when at least one of its tests
-+  ran ok and none was skipped or failed.
++  ran ok and none was skipped or failed. (Second edit, 8 November 2026; the first run's G7-suites record 12) A
++  test's result may stand on a line of its own after the test's stderr output, and RealTree's does: `tests_ok` keeps a
++  result pending until the next test header.
++- **G7.4 HA.4** (second edit, 8 November 2026; the first run's G7-suites record 16): the rule wraps (CLAUDE.md:137-138),
++  so CERT_PLAN_A G7.4's one-line grep prints nothing; the driver reads the rule's line and its continuation
++  (`grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"`, as commit A's F-certificate HA.4 record read the
++  two lines), and the judgement (at least one line) is unchanged. On the re-check route (the same S; g1, g3, g5 and
++  g7 re-run with cert-recheck), each edited record keeps its `--what` and `--command` as the first run wrote them, so
++  that each re-run PASS pairs with its FAIL as the same check (p_gate.sh recheck_prep: one level, item and command):
++  the re-run records of G1.7(b)'s B9 check ("python -I -B"), G5.2's launcher check and HA.4 then carry the first
++  run's flags, trigger and grep in their command, and these lines, and each of those records' `--expected`, name what
++  runs.
 +- **G7.4 HP7.6** runs in K8, after G7.0, since it compares G7.0's count too (section 6, item 1).
 +- **3.6.19**: K8 makes the certificate once from every record (draft0), reads its print-out, writes the 3.6.19
 +  record, then the draft. Expected print-out (review fixes 2): every check ok but `  NO  every item of the re-run
 +  list answered`, which make_cert.py prints by construction while 3.6.19 has no record, and which is dropped
 +  (that one line, exactly); nothing MISSING but 3.6.19 itself, so the dropped line is 3.6.19's alone; no PROBLEM;
 +  no FAIL line but a re-checked FAIL record's (with the records' check line ok); candidate.head P_CAND. The final
-+  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it).
++  make in cert-docs is checked by p_gate.sh, outside the records (no run of a page can be inside it). (Second edit,
++  8 November 2026, E6) K8's four makes run with `-X utf8`, so that a FAIL record whose got carries a character cp1252
++  lacks (only G5's node records can) cannot stop them; cert-docs' makes (p_gate.sh) still run with `-I -B` alone.
 +- **Processes**: L1 at 6 jobs; controls in waves of at most six; L9 at 6; check_roads.py's own pool unchanged; L6's
 +  eight processes as run_l6.sh starts them; four evaluate.py at once in G6.
 +
@@ -2404,12 +2820,12 @@
 ### cert_P.json
 
 commit A: no such file (new in P)
-commit P: sha256 c0f3dc95cf26a32dfc5efa4fa074e6dd1a29492fcaa4c98545510804b8c70202
+commit P: sha256 ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193
 
 ```diff
 --- commit A: cert_P.json
 +++ commit P: cert_P.json
-@@ -0,0 +1,162 @@
+@@ -0,0 +1,163 @@
 +{
 + "_what": "make_cert.py --config: P's certificate (build step 2, ORDER step 14; the interface sheet 6.8; row 138 (4); CERT_PLAN_P.md, amending CERT_PLAN_A.md). Commit A's cert_A.json as P amends it (P_GATE_PLAN.md 5.2, K6). Paths are relative to S unless absolute; x1_meta is relative to the live repository (runs/ is in no clone); the candidate's git questions are asked in candidate.tree. No hash and no count is typed here: make_cert.py reads every one from the files named. Written 7 November 2026, before any of P's certificate ran, reviewed with the kit, and not edited after the review: date stays empty (make_cert.py writes the day it runs), no file is declared changed during the run, and anything the run does that this config does not foresee goes into P's session report.",
 + "title": "The B58 identity certificate: commit P of build step 2 against cf43fbb",
@@ -2532,7 +2948,8 @@
 +  "nothing_computed_moved": "Every value the harness, L6 and build_dataset compared is meant to be the same double in both trees (the counts are in the verdict line), and every writer's output and every report to equal cf43fbb's; the differences section 5 lists are labels, code hashes, run times and committed files older than the code on both trees.",
 +  "why_plant_sha_moves": "plant_sha hashes the code of fingerprint.plant_files('b58') -- plant.py, thermal.py, engine_env.py, derived.py and engines.py -- and the values of the B58's two spec files. P edits engine_env.py (H a parameter, the reward's knock option) and engines.py (trainable() read from the committed records), so plant_sha moves although no computed value is meant to; it names P's plant, which every later step of build step 2 is compared against. fingerprint.py, which P also edits, is not in PLANT_CODE.",
 +  "why_engine_sha_does_not_move": "engine_sha hashes every value of the plant as built (engines.engine_sha), and P adds and changes no field of the B58's records: engine_sha is commit A's (a check of section 1), and over build step 1's key set it is still build step 1's (amendment B11).",
-+  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2)."
++  "fingerprint_fields": "Schema 4 (P): plant_sha, plant_text_sha and engine_sha name the code and the record set; transmission holds the gearing (final_drive and gears, which schema 3 printed as fields of their own, read here out of it for the shared fields); train_backend, score_backend and backend_contract replace schema 3's backend; preview_h_s, reward_knock and preview_samples_s are new; git_head names the commit the run was on. The reference, a git archive of cf43fbb, has no git fields and no engine fields (schema 2).",
++  "first_run": "The first run of this certificate's groups (7-8 November 2026, 16:08Z to 03:00Z, 39139 s beside the roads check) wrote 101 PASS and 5 FAIL records: G1-harness record 29, G3-roads record 2, G5-app-lab record 10, G7-suites records 12 and 16. All five were defects of the kit's driver (tools/cert_driver_P.sh), not of P: in each, the evidence places the fault in the driver's check, not in P's output. In G3.1, G7.2 and G7.4 the output under test met the expectation CERT_PLAN_A.md and CERT_PLAN_P.md state. In G1.7(b) the two JSONs and the two pages were byte-identical, which is what B9 asks, and three of the five makes exited 1, each only when printing, after writing its JSON: the driver ran them without -X utf8, and commit A's make_cert.py and P's alike stopped printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic text) to a cp1252 stdout. In G5.2 the launcher met its expectation ('is ready', exit 124), and --check ran only as its server stopped: the driver waited for a line launch.py prints to block-buffered stdout, which reaches the file only at the launcher's exit. G3.1 asked the --road random run for the default run's last line; G7.2's parser missed RealTree's ok, printed on a line of its own after RealTree's stderr line; G7.4 grepped one line for a rule that wraps (CLAUDE.md:137-138). The driver was corrected (TOOL_EDITS.md, section 'commit P', its part 'commit P, second edit'), reviewed again, installed on the same S after the roads check ended (TOOL_EDITS.md, section 'commit P, second install'), and G1, G3, G5 and G7 re-run there with cert-recheck: the re-check records say what each re-run found. The five FAIL records stay in this certificate; a re-run PASS record that re-checks one names it (rechecks), and the FAIL gains rechecked_by. The edited checks keep the first run's what and command texts, so that every run of one check is the same check: the re-run records of the checks of G1-harness record 29, G5-app-lab record 10 and G7-suites record 16 therefore carry the first run's command text (python -I -B; once it printed 'is ready'; the one-line grep), and each says in its expected what ran (-X utf8 on the five makes; --check once the server had logged the launcher's GET / with status 200; the rule's line and its continuation), as INTEGRATION.md section 7 does."
 + },
 + "environment": {
 +  "interpreter": "C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe, for every run in both trees",
@@ -2633,7 +3050,7 @@
 ### reproduce_P.json
 
 commit A: no such file (new in P)
-commit P: sha256 bd1c99a0755558cc0e4d7bcb7c0e7445c5ee34a503f59098ef43377fc83a3888
+commit P: sha256 b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517
 
 ```diff
 --- commit A: reproduce_P.json
@@ -2662,7 +3079,7 @@
 +  {"step": "G6 L6, L7 and d2 (cert_driver_P.sh g6)", "cwd": "S, candg, S/ref", "command": "bash tools/run_l6.sh; bash tools/check_l6.sh; HARNESS_PERTURB=<car.mass, thermal.c_turb, car.mass:1e-9, car.mass:1e-6> python -I -B tools/l6_agents.py candg sighted_seed0 ...; l6_check.py; python -I -B tools/make_meta.py candg LIVE_REPO/runs/extremes_dt1/<sighted_seed0|blind_seed0> L7/cand_model/<tag>; cd candg && python -B evaluate.py --engine b58 --out L7/cand_eval[_blind].txt L7/cand_model/<tag>; cd S/ref && python -B evaluate.py --out L7/ref_eval_blind.txt LIVE_REPO/runs/extremes_dt1/blind_seed0; python -B evaluate.py --engine b58 --protocol d2 --out F11/cand_d2.txt; l7_diff.py and l7_expect.py (--agent blind_seed0); the scratch sighted_seed0 under d2: refused"},
 +  {"step": "G7 the suites and the documents (cert_driver_P.sh g7)", "cwd": "candg", "command": "commit A's S/tcl copied, then python -B fetch_engine_data.py --target S/tcl --group epa-test-car-list; one <label> candg python -B <suite>.py -v for test_wide_air, test_epa_map (twice, the second with GRAD_EXTRA_DATA), test_plant_guards, random_road.py, fingerprint.py --engine b58, test_cars, test_trainable, test_fuel_forms, test_carried, test_tit_cap, test_epa_plants, test_preview_horizon; the HA.4, HA.5, HA.6 and HA.11 greps; python -B verify_docs.py; bash tools/run_drift.sh"},
 +  {"step": "G7.0 test_engine_threading, alone (p_gate.sh post)", "cwd": "the live repository, P's candidate applied uncommitted on RV", "command": "python -B test_engine_threading.py -v > S/suites/P_test_engine_threading.txt, after the roads check and every run above; git status unchanged after it"},
-+  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md"},
++  {"step": "F.1, HP7.6 and F.2 (cert_final_driver_P.sh)", "cwd": "candg, S", "command": "python -B fingerprint.py --engine b58 > out/P_end_fp_cand.txt; python -I -B tools/manifest.py candg manifest_end_P.txt; python -I -B tools/stated_counts_P.py candg <suite>=<output> ...; python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_cert.py cert_out/B58_IDENTITY.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/B58_IDENTITY.json cert_out/B58_IDENTITY.md (every make with -X utf8, as commit A's F.3: -I ignores PYTHONIOENCODING, and a FAIL record's got may carry a character cp1252 lacks)"},
 +  {"step": "F.3 into the repository (p_gate.sh cert-docs)", "cwd": "the live repository", "command": "the draft copied to results/B58_IDENTITY.json and .md; S/refw, candw, candt and pre removed; python -I -B tools/drift_control.py <repo> suites/P_drift_control_with_certificate.txt (a record); python -I -B tools/make_archive.py results/B58_IDENTITY/certificate_tools.tar.gz; python -I -B tools/make_cert.py results/B58_IDENTITY.json <archive> --config cert_P.json; python -I -B tools/make_md.py results/B58_IDENTITY.json results/B58_IDENTITY.md; drift_control.py again; python -B verify_docs.py"},
 +  {"step": "not run here", "cwd": "-", "command": "L8 (item 20) on the training device at ORDER step 18; app.test_results on P's own commit (p_gate.sh commit)"}
 + ]
@@ -2672,16 +3089,23 @@
 ### tools/cert_driver_P.sh
 
 commit A: no such file (new in P)
-commit P: sha256 bfec15faca167a16bfd8faa4cedf4f5002cf14959a2a919545bdcc6515a11a59
+commit P: sha256 17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21
 
 ```diff
 --- commit A: tools/cert_driver_P.sh
 +++ commit P: tools/cert_driver_P.sh
-@@ -0,0 +1,1236 @@
+@@ -0,0 +1,1268 @@
 +#!/usr/bin/env bash
 +# cert_driver_P.sh -- P's B58 identity certificate, the groups G1-G7 (CERT_DRIVER of p_gate.sh; P_GATE_PLAN.md
 +# 5.2, K7). DRAFT of 7 November 2026: written from CERT_PLAN_A.md as CERT_PLAN_P.md amends it, from commit A's
 +# run (its records, scratchpad cert2) and from the tools; NOT RUN, not even once. Read INTEGRATION.md first.
++# (Second edit, 8 November 2026.) It then ran once, 7-8 November, and wrote 101 PASS and 5 FAIL records; all five
++# were defects of this driver, not of P (hand/cert_fails_plan.md). E1-E5 (G1.7(b), G3.1, G5.2, G7.2's tests_ok, G7.4)
++# fix them; TOOL_EDITS_commit_P.md, "commit P, second edit", names each FAIL and its fix. Each record's --what and
++# --command are as the first run wrote them, so that cert-recheck pairs each re-run PASS with its FAIL as the same
++# check (p_gate.sh recheck_prep: one level, item and command); INTEGRATION.md 7 says what each edited check now runs,
++# and so does the --expected of each record whose command text no longer says it (G1.7(b)'s B9 record, G5.2's
++# launcher record, HA.4). The edited lines have not run.
 +#
 +#     cd <candg> && CERT_S=<S> CERT_TREE=<candg> P_CAND=<sha> RV_SHA=<sha> bash <S>/tools/cert_driver_P.sh
 +#
@@ -2773,11 +3197,16 @@
 +secs_in() { nz "$(lf "$1" 2>/dev/null | grep -aoE 'in [0-9]+ s' | head -1 | grep -oE '[0-9]+')"; }   # "... in N s"
 +blob() { git -C "$REPO" cat-file blob "$1"; }             # a committed file's bytes, as git holds them
 +tests_ok() {  # tests_ok FILE HEAD_ERE FAIL_ERE: >= 1 test whose -v line matches HEAD_ERE ran ok, none skipped or failed.
-+              # unittest -v prints a test's result on its own line, or on the next one when the test has a docstring.
++              # unittest -v prints a test's result on its header line, on the next one when the test has a docstring,
++              # or alone on a later line ("ok", "FAIL", "ERROR", "skipped ...") when the test wrote to stderr after its
++              # description (RealTree: P_GATE cert fix, 8 November 2026): a result is pending until the next test header.
 +  lf "$1" 2>/dev/null | awk -v h="$2" -v f="$3" '
-+    function res(l) { if (l ~ /\.\.\. ok$/) { ok++; return 1 } if (l ~ /\.\.\. skipped/) { sk++; return 1 }
-+                      if (l ~ /\.\.\. (FAIL|ERROR)$/) { bad++; return 1 } return 0 }
-+    pend { pend = 0; if (res($0)) next }
++    function res(l) { if (l ~ /\.\.\. ok$/ || (pend && l == "ok")) { ok++; return 1 }
++                      if (l ~ /\.\.\. skipped/ || (pend && l ~ /^skipped /)) { sk++; return 1 }
++                      if (l ~ /\.\.\. (FAIL|ERROR)$/ || (pend && (l == "FAIL" || l == "ERROR"))) { bad++; return 1 }
++                      return 0 }
++    /^test_[A-Za-z0-9_]+ [(]/ { pend = 0 }
++    pend { if (res($0)) { pend = 0; next } }
 +    $0 ~ h { if (!res($0)) pend = 1; next }
 +    $0 ~ f { bad++ }
 +    END { exit !(ok > 0 && sk == 0 && bad == 0) }'
@@ -3076,11 +3505,14 @@
 +    ( cd "$CERT_ROOT" || exit 9
 +      "$PY" -I -B -c "import json,sys; c=json.load(open(sys.argv[1], encoding='utf-8')); c['candidate']['tree']=sys.argv[2]; json.dump(c, open(sys.argv[3], 'w', encoding='utf-8'), indent=1)" \
 +        "$TW/a/cert_A.json" "$RW" "$TW/a/cert_A_ctl_tree.json" > "$S/out/P_G1_b9_ctl_config.txt" 2>&1
-+      "$PY" -I -B "$TW/a/tools/make_cert.py" "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
-+      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
-+      "$PY" -I -B "$TW/a/tools/make_md.py" "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
-+      "$PY" -I -B "$TW/a/tools/make_md_P.py" "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
-+      "$PY" -I -B "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
++      # (second edit, 8 November 2026; G1-harness record 29) -X utf8, as commit A's F.3 ran every make: -I ignores
++      # PYTHONIOENCODING, and printing commit A's re-checked FAIL record G5-app-lab 22 (Arabic) to a cp1252 stdout
++      # raised UnicodeEncodeError after the JSON was written, in commit A's make_cert.py and P's alike
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert.py"   "$TW/a_orig.json" --config "$TW/a/cert_A.json"; echo "make_cert exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_edit.json" --config "$TW/a/cert_A.json"; echo "make_cert_P exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_md.py"     "$TW/a_orig.json" "$TW/a_orig.md"; echo "make_md exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_md_P.py"   "$TW/a_orig.json" "$TW/a_edit.md"; echo "make_md_P exit $?"
++      "$PY" -I -B -X utf8 "$TW/a/tools/make_cert_P.py" "$TW/a_ctl.json" --config "$TW/a/cert_A_ctl_tree.json"; echo "make_cert_P ctl exit $?"
 +    ) > "$S/out/P_G1_b9_commitA_mode.txt" 2>&1
 +  else
 +    echo "not run: the extraction does not match its archive_members.txt (out/P_G1_b9_commitA_members.txt)" > "$S/out/P_G1_b9_commitA_mode.txt"
@@ -3094,7 +3526,7 @@
 +  R G1-harness --level control --item B9 --what "commit A's certificate route (--config) is unchanged by P's edits" \
 +    --command "T=CERT_ROOT/g17: git show HEAD~1:results/B58_IDENTITY/certificate_tools.tar.gz (commit A's) unpacked into T/a, every member checked against its archive_members.txt before anything in it runs; P's make_cert.py and make_md.py copied in as make_cert_P.py, make_md_P.py; with the cwd CERT_ROOT and python -I -B: make_cert.py and make_cert_P.py T/a_<orig|edit>.json --config T/a/cert_A.json; make_md.py and make_md_P.py on T/a_orig.json; cmp" \
 +    --cwd "CERT_ROOT (the tools in CERT_ROOT/g17/a, removed afterwards)" \
-+    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's)" \
++    --expected "the extraction equal to its own archive_members.txt; four exit 0 (five with the control below); the two JSONs byte-identical and the two pages byte-identical (commit A's config names no candidate.tree, branch or page_text; its candidate is schema 3 and its previous certificate build step 1's). What runs (second edit, 8 November 2026): the five makes with python -I -B -X utf8, as commit A's F.3 ran every make; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
 +    --got "$( [ -z "$bad" ] && echo "the extraction is its listing; JSONs and pages byte-identical" || echo "differs:$bad")" \
 +    --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence out/P_G1_b9_commitA_mode.txt out/P_G1_b9_commitA_members.txt
 +  bad=""; got=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$T/a_ctl.json" | head -1 | grep -oE '[0-9a-f]{40}')
@@ -3228,7 +3660,7 @@
 +
 +# ============================================================================= G3-roads
 +g3() {
-+  local t0 t1 bad got diffc
++  local t0 t1 bad got diffc want
 +  say "G3 begins"; t0=$(date +%s)
 +  t1=$(date +%s); bad=""
 +  ( cd "$S/cand" && sha256sum --quiet -c "$S/manifest_start_P.txt" ) > "$S/prep/P_G3_cand_before.txt" 2>&1 || bad=" a file differs"
@@ -3251,16 +3683,22 @@
 +    echo "exit $? in $(( $(date +%s) - s )) s" > "$S/F11/cand_random_road_exit.txt" )
 +  wait
 +  # G3.1's record
++  # (second edit, 8 November 2026; G3-roads record 2) each run's own last line: test_reward.py --road random ends,
++  # on cf43fbb as on the candidate, with the D2 line; the driver asked it for the default run's
 +  bad=""
 +  for t in "" _random; do
++    case "$t" in
++      "")      want="All checks pass. The reward is safe to train against.";;
++      _random) want="All checks pass on every D2 road. The reward is safe to train against on the randomised climb.";;
++    esac
 +    grep -aq '^exit 0 ' "$S/L4/cand${t}_exit.txt" || bad="$bad${t:- default} exit"
 +    cmp -s "$S/L4/cand${t}_stdout.txt" "$S/L4/ref${t}_stdout.txt" || bad="$bad${t:- default} stdout"
 +    [ ! -s "$S/L4/cand${t}_stderr.txt" ] || bad="$bad${t:- default} stderr"
-+    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "All checks pass. The reward is safe to train against." ] || bad="$bad${t:- default} last line"
++    [ "$(lf "$S/L4/cand${t}_stdout.txt" | grep -a . | tail -1)" = "$want" ] || bad="$bad${t:- default} last line"
 +  done
 +  R G3-roads --level L4 --item 3.6.4 --what "test_reward.py and --road random, the candidate's stdouts against cf43fbb's" \
 +    --command "bash tools/run_l4.sh cand; bash tools/run_l4.sh cand --road random (CAND = candg); cmp L4/cand_stdout.txt L4/ref_stdout.txt; cmp L4/cand_random_stdout.txt L4/ref_random_stdout.txt" \
-+    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last line 'All checks pass. The reward is safe to train against.' (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
++    --cwd candg --expected "exit 0 twice; both stdouts byte-identical to cf43fbb's (build step 1's L4/ref_*), stderr empty, the last lines 'All checks pass. The reward is safe to train against.' (the default run) and 'All checks pass on every D2 road. The reward is safe to train against on the randomised climb.' (--road random, as cf43fbb's prints it) (test_reward.py changed in C1, C1b and P, not in the plant: any other line is a finding)" \
 +    --got "$( [ -z "$bad" ] && echo "both byte-identical, stderr empty, the last line as expected" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
 +    --seconds "$(secs_in "$S/L4/cand_exit.txt")" \
 +    --evidence L4/cand_stdout.txt L4/cand_stderr.txt L4/cand_exit.txt L4/cand_random_stdout.txt L4/cand_random_stderr.txt L4/cand_random_exit.txt
@@ -3514,10 +3952,19 @@
 +      --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t1")" --evidence lab/P_G5_npm_build.txt
 +    if "$PY" -I -B -c "import socket; s=socket.socket(); s.bind(('127.0.0.1', 8765)); s.close()" > /dev/null 2>&1; then
 +      t1=$(date +%s)
++      # (second edit, after its reviews, 8 November 2026) an earlier run's launcher log and --check output removed
++      # before the launcher starts: on cert-recheck g5 the first run's are still at these paths (recheck_prep copies
++      # a record's evidence aside and leaves the original), and that log already holds '"GET / HTTP/1.1" 200', on
++      # which the trigger below would fire before this run's server is up (a false FAIL)
++      rm -f "$S/lab/P_G5_launch_no_browser.txt" "$S/lab/P_G5_launch_check.txt"
 +      ( cd "$L" && timeout 300 "$PY" -B launch.py --no-browser > "$S/lab/P_G5_launch_no_browser.txt" 2>&1; \
 +        echo "exit $? (124 = stopped by timeout after the check, as intended)" >> "$S/lab/P_G5_launch_no_browser.txt" ) &
 +      lp=$!
-+      for i in $(seq 1 280); do grep -aq 'is ready' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
++      # (second edit, 8 November 2026; G5-app-lab record 10) the trigger is the server's own access line for the
++      # launcher's GET /, which uvicorn's logging writes record by record: launch.py prints 'is ready' to
++      # block-buffered stdout, which reaches the file only at the launcher's exit (commit A's first-cycle record),
++      # so --check ran as the 300 s window closed; commit A's second cycle, which passed, used this trigger
++      for i in $(seq 1 280); do grep -aqF '"GET / HTTP/1.1" 200' "$S/lab/P_G5_launch_no_browser.txt" 2>/dev/null && break; sleep 1; done
 +      ( cd "$L" && "$PY" -B launch.py --check ) > "$S/lab/P_G5_launch_check.txt" 2>&1; echo "exit $?" >> "$S/lab/P_G5_launch_check.txt"
 +      wait "$lp"
 +      # (review fixes 2) timeout stops the venv's launcher process; a server it started may outlive it, and
@@ -3547,7 +3994,7 @@
 +      grep -aq 'Local app healthy' "$S/lab/P_G5_launch_check.txt" && [ "$(exit_of "$S/lab/P_G5_launch_check.txt")" = 0 ] || bad="$bad --check"
 +      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
 +        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
++        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
 +        --got "$( [ -z "$bad" ] && echo "ready, exit 124; Local app healthy, exit 0" || echo "differs:$bad")" --verdict "$(verdict "$bad")" \
 +        --seconds "$(secs_since "$t1")" --evidence lab/P_G5_launch_no_browser.txt lab/P_G5_launch_check.txt
 +    else
@@ -3555,7 +4002,7 @@
 +      say "port 8765 is taken: the lab launcher did not run; its record is a FAIL"
 +      R G5-app-lab --level L5 --item "3.6.12, HA.3" --what "the lab launcher and launch.py --check" \
 +        --command "( cd \"S/cand/Explanatory Simulation\" && timeout 300 python -B launch.py --no-browser ) in the background; once it printed 'is ready': python -B launch.py --check" \
-+        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0" \
++        --cwd "S/cand/Explanatory Simulation" --expected "'Supra Lab is ready: http://127.0.0.1:8765', then exit 124 (the timeout, after the check); 'Local app healthy', exit 0. What runs (second edit, 8 November 2026): --check once the server has logged the launcher's own GET / with status 200 (its access line), not once 'is ready' was printed, which reaches the file only at the launcher's exit; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check (INTEGRATION.md 7)" \
 +        --got "not run: port 8765 was taken before the launcher started (cert-recheck g5 once it is free)" --verdict FAIL --seconds 0 --evidence lab/P_G5_npm_build.txt
 +    fi
 +    # G5.3 the lab's node tests (after npm ci)
@@ -3858,15 +4305,17 @@
 +  suite_rec cand_test_tit_cap "R138-4 test_tit_cap, 3.6.15" "test_tit_cap.py (row 138 (4))" "" "" ""
 +  suite_rec cand_test_epa_plants 3.6.15 "test_epa_plants.py (CERT_PLAN_P.md G7.2)" "" "" ""
 +  # G7.4 the documents P's candidate carries (HA.4, HA.5, HA.6, HA.11; HP7.6 is the final driver's, after G7.0)
++  # (second edit, 8 November 2026; G7-suites record 16) HA.4 reads the rule's line and its continuation: the rule
++  # wraps (CLAUDE.md:137-138), so CERT_PLAN_A G7.4's one-line grep prints nothing (commit A's F-certificate HA.4)
 +  ( cd "$REPO" && {
-+      echo "== HA.4"; grep -n "engines.py" CLAUDE.md | grep -n "engine_specs"
++      echo "== HA.4"; grep -n -A1 "engines\.py" CLAUDE.md | grep -B1 "engine_specs/"
 +      echo "== HA.5"; for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" README.md), full_run $(grep -c "$t.py" full_run.py)"; done
 +      echo "== HA.6"; grep -n -i "scipy" requirements.txt
 +      echo "== HA.11"; echo "line 433: $(grep -c "line 433" engine_specs/b58.toml)"; echo "fuel properties: $(grep -c "fuel properties" engine_specs/b58.toml)"
 +    } ) > "$S/suites/P_G7_docs_checks.txt" 2>&1
 +  bad=""; [ "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .)" -ge 1 ] || bad=" no line"
 +  R G7-suites --level docs --item HA.4 --what "CLAUDE.md's re-run rule names engines.py and engine_specs/" --command "grep -n engines.py candg/CLAUDE.md | grep engine_specs" \
-+    --cwd candg --expected "at least one line" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
++    --cwd candg --expected "grep -n -A1 engines\.py CLAUDE.md | grep -B1 engine_specs/ (what runs, second edit, 8 November 2026; the command field keeps the text of this certificate's first run, so that cert-recheck pairs the records as one check, INTEGRATION.md 7) prints the rule's line naming engines.py and its continuation naming engine_specs/: at least one line (CERT_PLAN_A G7.4's one-line grep prints nothing, because the rule wraps)" --got "$( [ -z "$bad" ] && echo "$(awk '/^== HA.4/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt" | grep -c .) lines" || echo "differs:$bad")" \
 +    --verdict "$(verdict "$bad")" --seconds 0 --evidence suites/P_G7_docs_checks.txt
 +  bad=""; got=$(awk '/^== HA.5/ { f = 1; next } /^== / { f = 0 } f' "$S/suites/P_G7_docs_checks.txt")
 +  echo "$got" | grep -qE 'README 0|full_run 0' && bad=" a file not named"; [ "$(echo "$got" | grep -c .)" = 4 ] || bad="$bad the four lines"
@@ -3919,12 +4368,12 @@
 ### tools/cert_final_driver_P.sh
 
 commit A: no such file (new in P)
-commit P: sha256 ab46791e31bba212e0c9356a9551f5c4c2bd5707efecc21d0f99d76fbd2d822d
+commit P: sha256 f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1
 
 ```diff
 --- commit A: tools/cert_final_driver_P.sh
 +++ commit P: tools/cert_final_driver_P.sh
-@@ -0,0 +1,169 @@
+@@ -0,0 +1,172 @@
 +#!/usr/bin/env bash
 +# cert_final_driver_P.sh -- P's B58 identity certificate, F.1 and F.2 (CERT_FINAL_DRIVER of p_gate.sh; P_GATE_PLAN.md
 +# 5.2, K8). DRAFT of 7 November 2026, NOT RUN. Read INTEGRATION.md first.
@@ -4049,8 +4498,11 @@
 +
 +# ---- 3.6.19: the certificate made once from every record (draft0), its print-out read
 +t0=$(date +%s)
-+"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
-+"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
++# (second edit, 8 November 2026; E6) every make runs with -X utf8, as commit A's F.3 ran them: -I ignores
++# PYTHONIOENCODING, and make_cert.py prints each FAIL record, whose got may carry a character cp1252 lacks (G5's
++# node records' got holds the node runner's info sign); printed to a cp1252 stdout it raises after the JSON is written
++"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/P_F2_draft0.json" --config "$SW/cert_P.json" > "$S/cert_out/P_F2_draft0_stdout.txt" 2>&1; rc=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/P_F2_draft0.json" "$SW/cert_out/P_F2_draft0.md" > "$S/cert_out/P_F2_draft0_md_stdout.txt" 2>&1; rc2=$?
 +head0=$(grep -aoE '"head": *"[0-9a-f]{40}"' "$S/cert_out/P_F2_draft0.json" 2>/dev/null | head -1 | grep -oE '[0-9a-f]{40}')
 +bad=""
 +[ "$rc" = 0 ] && grep -aq '^written ' "$S/cert_out/P_F2_draft0_stdout.txt" || bad="$bad make_cert exit $rc"
@@ -4069,14 +4521,14 @@
 +[ "$got" = 0 ] || bad="$bad $got items MISSING beside 3.6.19"
 +[ "$head0" = "$P_CAND" ] || bad="$bad candidate.head ${head0:0:12}"
 +R F-certificate --level docs --item 3.6.19 --what "the certificate made from every record (draft0), before the draft p_gate.sh reads" \
-+  --command "python -I -B tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
++  --command "python -I -B -X utf8 tools/make_cert.py cert_out/P_F2_draft0.json --config cert_P.json; python -I -B -X utf8 tools/make_md.py cert_out/P_F2_draft0.json cert_out/P_F2_draft0.md" \
 +  --cwd S --expected "both exit 0; make_cert.py writes the JSON with every check ok but 'every item of the re-run list answered' (NO while 3.6.19, which this record answers, has no record), no PROBLEM line, no FAIL line but a FAIL record's that a later PASS re-checks, and no item MISSING but 3.6.19; the JSON's candidate.head is P's candidate $P_CAND. The certificate made into the repository with its archive (p_gate.sh cert-docs) is checked there, after this certificate: no run of a page can be inside it" \
 +  --got "$( [ -z "$bad" ] && echo "$(lf "$S/cert_out/P_F2_draft0_stdout.txt" | grep -a '^written' | cut -c1-40)...; every check ok; head $head0" || echo "differs:$bad")" \
 +  --verdict "$(verdict "$bad")" --seconds "$(secs_since "$t0")" --evidence cert_out/P_F2_draft0_stdout.txt cert_out/P_F2_draft0_md_stdout.txt
 +
 +# ---- F.2 the draft certificate in scratch
-+"$PY" -I -B "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
-+"$PY" -I -B "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_cert.py" "$SW/cert_out/B58_IDENTITY.json" --config "$SW/cert_P.json" > "$S/cert_out/make_cert_stdout.txt" 2>&1; rc=$?
++"$PY" -I -B -X utf8 "$SW/tools/make_md.py" "$SW/cert_out/B58_IDENTITY.json" "$SW/cert_out/B58_IDENTITY.md" > "$S/cert_out/make_md_stdout.txt" 2>&1; rc2=$?
 +say "F.2: make_cert exit $rc, make_md exit $rc2; $(lf "$S/cert_out/make_cert_stdout.txt" | grep -a '^written' | cut -c1-200)"
 +[ "$rc" = 0 ] && [ "$rc2" = 0 ] || { say "REFUSED: the draft was not written"; BAD=1; }
 +
````

## commit P, third install (2026-11-08): cert_P.json's page markers and make_archive.py's cap, after the re-checks

Installed by p_gate.sh cert-kit on 2026-11-08 over the second install, on the team's decision
decisions/cert_kit_page.txt (sha256 81014b1cc986997ca613fb5527c1136f1370a97ec576624299c780a3504bf4d0), quoted whole below. This install replaced
S/cert_P.json and S/tools/make_archive.py, and nothing else of the kit on S. The kit's cert_P.json differs from
the second install's in page_markers alone, checked with Python's json module: every other top-level key equal,
every marker the second install held kept; the marker added names its figure first; _what, a note, changed and names none.
make_cert.py copies page_markers into the certificate and make_md.py writes each above a table of the page; no
record and no driver check reads them; verify_docs.py reads them as markers on the page. The kit's
tools/make_archive.py is commit A's with its MAX_BYTES line alone changed, so that cert-docs' archive packs
TOOL_EDITS.md whatever its size: archive_ok requires it, and it was 643913 bytes before this section, over
MAX_BYTES (400 000). No driver runs make_archive.py; cert-docs alone does, after this install. Every other installed
kit file is the second install's, byte for byte. Section "commit P" above keeps TOOL_EDITS_commit_P.md's text as the second
install wrote it: that text is the kit's TOOL_EDITS_commit_P.md above its section "commit P, third edit", which is
quoted whole at the end of this section. S held 9 record files when this install ran, and it did not
touch them: each has the same sha256 before and after. Of the records written before this install, only
F-certificate.json's 3.6.19 record read cert_P.json, through cert_final_driver_P.sh's draft0 make, with the second
install's copy; no other record's driver reads it. Every make after this install (cert-final's draft0 and draft,
and cert-docs' certificate) reads this one. The review list: decisions/cert_kit_reviewed.txt, sha256 adf0beb8bd1b260f7fb0ae4626f3538b8fe56ad9c09a9f96ce93fc59b08bab39.
The smoke step passed again on this install: its list, sha256 0501e815e2fabca8fab1d70253f74fd47fe922d1b3adbe3f4d3291949f09a517 (the second install's:
1fc629ba6682022b7954af80f56c54780a597ec4627305dff8a677f50e739435); the two differ in the lines of cert_P.json and tools/make_archive.py alone.

```text
MODE page
WHY The first cert-final's pre-check (8 November 2026) printed "1 of 74 checks failed": verify_docs.py reads the draft page's HP7.6 row (G7-suites.json record 43, whose got is stated_counts_P.py's tally of the stated test counts) as the figure "validate.py rows inside their band" (data 8), and no RETIRED-OK marker covers it. cert-final's second run rewrites cert_out/P_F2_verify_docs_precheck.txt; this install quotes the first run's summary and WRONG lines in S/TOOL_EDITS.md's section "commit P, third install". cert-docs would copy that page into the repository and fail at drift_control_1, writing an F-certificate FAIL record that no re-check can answer. The kit's cert_P.json gains one page marker (page_markers.docs, naming the figure 11, above the docs table) and a rewritten page_markers._what, and nothing else in it changes. The page fix's first review (8 November 2026) found that cert-docs would fail later in any case: commit A's make_archive.py leaves out every file over 400 000 bytes, S/TOOL_EDITS.md is 643 913 bytes, and archive_ok requires it, by which point cert-docs has removed S's extra trees and written its F-certificate record. So the kit also gains tools/make_archive.py: commit A's, with its one MAX_BYTES line changed to exempt TOOL_EDITS.md. TOOL_EDITS_commit_P.md is the second install's text with its section "commit P, third edit" appended. A page made from S's records with the marker's first wording passed verify_docs.py in a copy of the clone ("All 74 checks pass", hand/page_fix/P_F2_verify_docs_precheck.txt). The reworded explanation adds no digit and no number word, and verify_docs.py checks it again before the install (hand/page_fix/RUN.md step 1b). This third install puts both files on S, the records untouched, so that cert-final makes the draft again before cert-docs.
DECIDED 8 November 2026 by the orchestrator (Claude, the agent running build step 2), under Ghassan's standing instruction (row 133 (2): adopt what is recommended) and his message of 7 November ("we need this ready for training as soon as possible"): the third install on this S, with the page marker and make_archive.py's exemption together, not a new S. Recorded in P's session report (section 17).
EDITED cert_P.json
EDITED tools/make_archive.py
READ p_gate.sh cert-kit (hand/page_fix/p_gate_page.patch) installs on an S that holds records only when all of these hold. This file says MODE page and has a WHY line and a DECIDED line of at least 20 characters each (DECIDED not the draft's '<...>'). cert and post have passed on this RV, candidate and tree. cert-docs has not run (S/refw ... S/candt present, the repository's certificate files RV's, no reverify.json). The second install's record exists (out/cert_kit_reinstall/installed and after/). The kit files that differ from the second install are exactly cert_P.json and tools/make_archive.py, each named by an EDITED line (TOOL_EDITS_commit_P.md: the second install's text with its section "commit P, third edit" appended). cert_P.json differs from the second install's in page_markers alone (python -I -B, json). make_archive.py differs from commit A's in its MAX_BYTES line alone. The review list holds the kit as it stands. It then installs those two files. It never touches S/cert_results. It keeps the second install's state, and the first cert-final's files that the second run rewrites, in out/cert_kit_page/before. It clears cert-kit's and cert-final's markers (RERUN=cert-kit) and keeps post's. It checks that the smoke pin moves in those two lines alone and that cert-docs' archive would hold every member archive_ok requires. One third install per S.
```

```text
INTEGRATION.md  before e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3  after e7d100fce34cf480a8ba71828751a6992a17b2c239acf831a66dd655b10962c3  unchanged
TOOL_EDITS_commit_P.md  not installed as a file; kit sha256 c3f447ace755e62e45eb998566077c8adae00bfb990c8a0f1d63b3d389145293; its first 1222 lines are the second install's text (sha256 afb6abdb8013003131098bcb753ee3e147b05428effa2007c4c12399c6fe5275, as the second install's review list signed it), then its section "commit P, third edit", quoted below
cert_P.json  before ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193  after edf33cc2ba16e3a233797a4088c557d8ae3a5b4e8025b713cdb6d3ba992f5ec6  CHANGED
env_P.sh  before bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0  after bf29d16bd52d03a593736386db3c8151f9b7dc2a2cf834afea05cd29958bc4e0  unchanged
reproduce_P.json  before b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517  after b91cc879caf8cb5f93376be5c52dfdb627f4e01191d7de9def40f9652813b517  unchanged
tools/cert_driver_P.sh  before 17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21  after 17fafdc798ac84ccc778912a68d230f9d16fe1fc201e40be7eeeaed53903fd21  unchanged
tools/cert_final_driver_P.sh  before f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1  after f5f52a226e1e373aacc78d87405a803a7531f6fd8f60c09c95aa26714abfd1d1  unchanged
tools/cert_record.py  before c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3  after c79253ebe5ac04ab863f0affc8e9139b93f186718b9c83a31df61c86cc6838d3  unchanged
tools/check_l6.sh  before 6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b  after 6f31b9635557814e4638ceb31c4dfd8c8d10f023f1e08ee7c3c4919dd07eac3b  unchanged
tools/compare_all.sh  before 2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5  after 2aee370c4eba52875d1e6278eba8734cda9959fcebd5429250b22ffc4a9ff2c5  unchanged
tools/failing_sets_P.py  before 56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc  after 56f886a5bfb18b741f6fd43a66f959e16435da83b79f89f77eff28f3639b20fc  unchanged
tools/l7_expect.py  before 72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164  after 72117ce9b6246ed99edd42bc888894c97a78ad404e7e9b466b64aa81093f6164  unchanged
tools/make_archive.py  before b536855d307597197e0b7cb4bea192a36c30eec2f56b9e150daea1a0bcc3ecd6 (commit A's, as S held it; not a kit file before this install)  after 4302eab82853161753488995820189ce370941e29242920859285adb1fd20c0f  CHANGED
tools/make_cert.py  before 28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea  after 28c89f2a4fc372abc212216be31f7406b5ff8c536941403ec8caa6dde512f7ea  unchanged
tools/make_md.py  before 44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98  after 44ae314bd958d434de08b75455b66c3ac5f7703812ac2539b22c9fdbb55d1b98  unchanged
tools/make_meta.py  before c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b  after c05401a77cad3a17fe9c0ee51c1a680b965b5ec2d9342602c4993297c359f54b  unchanged
tools/road_json_diff.py  before dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7  after dcd6a642587fa40d68be0f97f4670df982719768f34839fa71808f52f38adbe7  unchanged
tools/run_app.sh  before 5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91  after 5bfbc55661dad952ff90286b11b2ac40cf1e8f4df730cbd5ea902e81a71dbd91  unchanged
tools/run_app_extra.sh  before b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777  after b2c97b3faab8cf2e3c0522cc18bfca692ae07a50aa0231ce9ee4bb4887884777  unchanged
tools/run_drift.sh  before 98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f  after 98458b54236a640316a42d87737ce30fbf07cee853a3d40da93624f643284b4f  unchanged
tools/run_jobs.py  before 24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26  after 24b61e56bf2cb53ce667fb20314a845925bbc13ec4aa3aed6023a34f0a858b26  unchanged
tools/run_l4.sh  before 6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c  after 6d46d6b0ed0067e3d8414f2c961524bb4b3dcc380d2638e2865cdb6d5b0aec0c  unchanged
tools/run_l6.sh  before d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7  after d3783f49e9bc1265ee755f0a0588306309248d0b275c80244a0c5735dbb871a7  unchanged
tools/run_writer.sh  before 28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382  after 28308f38639663e4f1fd87237f5b3f4960ae11b25de2d4b7a7534c24504c6382  unchanged
tools/stated_counts_P.py  before 7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7  after 7d8093e5e778a8cd9ac0ddd773c4315e5227e24aa290e49f12105b47c46736a7  unchanged
TOOL_EDITS.md  before 192d734c03c30dfd9ceaa4195cb3ad8a9d18945ad1061dd7764d6177760bb4e3  after: that file with this section appended
```

### cert_P.json: the second install's copy and the third install's

```diff
--- commit P, second install: cert_P.json
+++ commit P, third install: cert_P.json
@@ -141,10 +141,11 @@
   "**A check of this page cannot be inside it.** The draft p_gate.sh reads is made from every record; the certificate p_gate.sh cert-docs makes into the repository, with its archive and the drift control on its files, is checked there (cert-docs, precommit), after these records. Anything the run did that its plan did not foresee is in P's session report, not in this config, which was reviewed before the run and not edited after it."
  ],
  "page_markers": {
-  "_what": "verify_docs.py markers make_md.py writes above a table (the key: a level, or 'control' for section 2's table), each excusing the one figure it names, in that table only (AUDIT2.md H2-6). Commit A's three, carried: the conditions jobs' names and the build_dataset count read as figures they are not. cert_final_driver_P.sh runs verify_docs.py on the draft in a copy before p_gate.sh cert-docs, so a figure these do not cover is seen before the repository is touched.",
+  "_what": "verify_docs.py markers make_md.py writes above a table (the key: a level, or 'control' for section 2's table). Each covers that table only: there its figure scan excuses the one figure the marker names and still compares every other value with the data, and, as for every marker that names a figure, the retired-figure scan skips the table (AUDIT2.md H2-6; verify_docs.py's _paragraph_is_historical). Commit A's three, carried: the conditions jobs' names and the build_dataset count read as figures they are not. cert_final_driver_P.sh runs verify_docs.py on the draft in a copy before p_gate.sh cert-docs, so a figure these do not cover is seen before the repository is touched. P's own, the fourth (commit P, third edit, 8 November 2026): 'docs', above section 3's docs table, for HP7.6's record, whose got (the stated-count tally) the first cert-final's pre-check read as validate.py's rows inside their band (its summary and WRONG lines are quoted in TOOL_EDITS.md's section 'commit P, third install'; cert-final's second run rewrote cert_out/P_F2_verify_docs_precheck.txt).",
   "control": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
   "L2": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
-  "L5": "RETIRED-OK: 11 -- G4-data.json's build_dataset record counts the derivations, one per log, in the form verify_docs.py reads as validate.py's quantities inside their band; this table's validate.py rows are still checked"
+  "L5": "RETIRED-OK: 11 -- G4-data.json's build_dataset record counts the derivations, one per log, in the form verify_docs.py reads as validate.py's quantities inside their band; this table's validate.py rows are still checked",
+  "docs": "RETIRED-OK: 11 -- HP7.6's record (G7-suites.json, written by cert_final_driver_P.sh with stated_counts_P.py) tallies the test counts README.md and full_run.py state against their runs, in the form verify_docs.py reads as validate.py's rows inside their band; it counts stated test counts, not validate.py's rows. verify_docs.py's figure scan still compares every other value in this table with the data; like every marker that names a figure, this marker takes the table out of the retired-figure scan"
  },
  "page_text": {
   "previous_certificate": "commit A's certificate",
```

### tools/make_archive.py: commit A's copy, as S held it, and the third install's

```diff
--- commit A (S's copy before this install): tools/make_archive.py
+++ commit P, third install: tools/make_archive.py
@@ -52,7 +52,7 @@
                 continue                       # the lab's value dumps: re-made by lab_dump.py
             if rel == "archive_members.txt":
                 continue                       # the previous run's listing: this run writes its own below
-            if os.path.getsize(p) > MAX_BYTES:
+            if os.path.getsize(p) > MAX_BYTES and rel != "TOOL_EDITS.md":   # (commit P, 8 Nov) archive_ok requires it; P made it larger
                 continue
             out.append((rel, p))
     return sorted(out)
```

### The first cert-final's files, before cert-final runs again

cert-final's second run rewrites these files in place (hand/page_fix/RUN.md section 4), the evidence of the first
run's F.1, HP7.6 and 3.6.19 records among them. Their sha256 as the first cert-final left them (this install kept
copies in out/cert_kit_page/before/first_cert_final/, outside S):

```text
d730ae238c8190e4e0fbc003383fb4c90cb417c727070737f7523e2396a2f2b5  cert_out/B58_IDENTITY.json
5db45cf45cb35cd9fb93615cd76b4814f67f23ac7167dc6d1faf50974c98efc5  cert_out/B58_IDENTITY.md
ba927566e3ab38a3cda8af9466840eeb379f09cf3a4516b3f35567a1c77887ff  cert_out/P_F2_draft0.json
dbac2cf8a2da89cf48238dabff53287eef9f3e75b59428b7d10945fbbd92a698  cert_out/P_F2_draft0.md
22e9ad37c63ba5e21252ba34b58e645d1f4531515e8c58f9cef2ae8d7d58b92c  cert_out/P_F2_draft0_md_stdout.txt
f70fe689245fcf7f2ebbbe0dbeb94a971bfdcea3218945f27daefd0905985b5e  cert_out/P_F2_draft0_stdout.txt
2569d31d8d13581f1fc02a5eca24fea2334f9042d2f0c756ba0a87fee7ca0413  cert_out/P_F2_verify_docs_copy.txt
5beb59f762bdac914f72a4149a4e183e429db157098c9a56e85b9d630394c2c7  cert_out/P_F2_verify_docs_precheck.txt
857c008b0e4aeb1e177fd8d58a1720b22934481bd9850d56226c73b5f83c696d  cert_out/make_cert_stdout.txt
0f302b2fe9a14d08fcc2b8d07705e7a2f6ec60fe75066e5f9a587a5dbb702c5e  cert_out/make_md_stdout.txt
5cb5442e3d6d5efe33e4d3f0d91e7ee0974ba8e5500049c1a11ab6139e64f387  manifest_end_P.txt
c51f86dc1ea1cd64567482fbe055dfd3cc199cab3b4459d6d5c71d5da96a5b4c  out/P_F0_open_fails.txt
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  out/P_F1_git_status_end.txt
dfc75b661f02882e7368e384dfc3486638500986ed0249bc12a824aca2f90934  out/P_F1_manifest.txt
b2a55c22d314d8350745d009a260286d932d5c9c2602824165421a9d54a86669  out/P_end_fp_cand.txt
fa3fd1ea93333f4df40cc25de3fac98f6ba598a0471a611a43283ec62cd739c5  suites/P_F_stated_counts.txt
```

The 3.6.19 record's evidence as the first run printed it, quoted whole: there the check 'every item of the re-run
list answered' reads NO, because 3.6.19 had no record yet; the second run is expected to print it ok (its own record
says what it printed), because the first run's 3.6.19 record answers 3.6.19.

cert_out/P_F2_draft0_stdout.txt:

````text
written C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/p_gate/cert/S/cert_out/P_F2_draft0.json | NOT CERTIFIED: see the checks
  ok  every record well formed
  ok  every record PASS, or a FAIL that a later PASS record re-checks (both kept)
  NO  every item of the re-run list answered
  ok  harness jobs BIT-IDENTICAL (compare_all.sh's reports)
  ok  every control as expected (compare_all.sh's reports)
  ok  the plant's fingerprint the same at the start and the end
  ok  derived_sha and the shared FATAL fields equal the reference's
  ok  engine_sha over build step 1's keys is build step 1's (B11)
  ok  the repository unchanged during the run (manifests), but for the files the config declares, none a plant file
  ok  every value count read
  ok  engine_sha is the previous certificate's candidate's (row 94: plant_sha moves, engine_sha does not)
  FAIL {'group': 'G1-harness', 'level': 'control', 'item': 'B9', 'got': 'differs: an exit', 'record': 'G1-harness.json record 29', 'rechecked_by': ['G1-harness.json record 57']}
  FAIL {'group': 'G3-roads', 'level': 'L4', 'item': '3.6.4', 'got': 'differs:_random last line', 'record': 'G3-roads.json record 2', 'rechecked_by': ['G3-roads.json record 9']}
  FAIL {'group': 'G5-app-lab', 'level': 'L5', 'item': '3.6.12, HA.3', 'got': 'differs: --check', 'record': 'G5-app-lab.json record 10', 'rechecked_by': ['G5-app-lab.json record 25']}
  FAIL {'group': 'G7-suites', 'level': 'suite', 'item': '3.6.15, HP7.1, B8, HP7.6', 'got': 'differs: RealTree; Ran 23 tests in 90.995s OK ', 'record': 'G7-suites.json record 12', 'rechecked_by': ['G7-suites.json record 32']}
  FAIL {'group': 'G7-suites', 'level': 'docs', 'item': 'HA.4', 'got': 'differs: no line', 'record': 'G7-suites.json record 16', 'rechecked_by': ['G7-suites.json record 36']}
  MISSING item 3.6.19: make_cert.py and make_md.py: the certificate made from the records (the draft p_gate.sh reads), then made again into the repository with the archive by p_gate.sh cert-docs, after commit A's page has moved verbatim to STATE_HISTORY.md (decision 67)
````

cert_out/P_F2_draft0_md_stdout.txt:

````text
written C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/p_gate/cert/S/cert_out/P_F2_draft0.md 464 lines
````

The first pre-check (cert_out/P_F2_verify_docs_precheck.txt, no record): its summary and WRONG lines.

````text
  WRONG  results/B58_IDENTITY.md:315
1 of 74 checks failed.
````

### TOOL_EDITS_commit_P.md's section "commit P, third edit", as the kit holds it (its lines 1224 to the end)
### commit P, third edit (page marker and archive cap, 8 November 2026)

The first cert-final (p_gate.sh cert-final, 12:55Z to 12:57Z on 8 November 2026; final_driver exit 0, 150 s) wrote its draft, every make_cert.py check ok. Its pre-check, which writes no record (verify_docs.py with the draft in a copy of the clone, `cert_out/P_F2_verify_docs_precheck.txt`), exited 1 with "1 of 74 checks failed": `results/B58_IDENTITY.md:315 says 11.0 for 'validate.py rows inside their band', data gives 8`. cert-final's second run rewrites that file; the first run's summary and WRONG lines are quoted in S/TOOL_EDITS.md's section "commit P, third install", with the sha256 of every file the second run rewrites. Line 315 was the docs table's HP7.6 row (G7-suites.json record 43, written by cert_final_driver_P.sh), whose got is stated_counts_P.py's tally: "HP7.6: 11 of 11 stated counts equal their runs; 0 not tied to a run". verify_docs.py (RV's, unchanged by P) scans every tracked document for that figure with the pattern `NUM + r"\s*\*{0,2}\s*of\s+\*{0,2}\s*11\b"` (a number, then "of 11"), so it reads the tally as validate.py's rows inside their band. The tally counts the test counts README.md and full_run.py state, not validate.py's rows. No marker covered it: cert_P.json's page_markers held commit A's three (control, L2, L5), and the docs table had none. p_gate.sh cert-docs copies the draft into the repository and runs drift_test's control first (drift_control.py: verify_docs.py in a copy of REPO); it would have failed there and written an F-certificate FAIL record, which no cert-recheck can answer (no driver group writes F-certificate).

The third edit changes two kit files: cert_P.json, inside page_markers alone, and tools/make_archive.py, which it adds to the kit with one line changed from commit A's.

**cert_P.json.** The fix is inside page_markers:

- A fourth marker, key `docs`. make_md.py writes it above section 3's docs table, as it writes the other three above theirs:
  `RETIRED-OK: 11 -- HP7.6's record (G7-suites.json, written by cert_final_driver_P.sh with stated_counts_P.py) tallies the test counts README.md and full_run.py state against their runs, in the form verify_docs.py reads as validate.py's rows inside their band; it counts stated test counts, not validate.py's rows. verify_docs.py's figure scan still compares every other value in this table with the data; like every marker that names a figure, this marker takes the table out of the retired-figure scan`
  verify_docs.py's `_historical_lines` takes the list before the first spaced double dash: the one figure 11. In a .md file the marker covers its own line to the end of its paragraph, here the table, to its last row. In the figure scan, `_paragraph_is_historical` excuses a mention there only when the value written is 11; every other value of every figure in that table is still compared with the data. The retired-figure scan (`check_retired`) passes no figure, and for a line that a marker naming figures covers, `_paragraph_is_historical` then answers True whatever the value: like commit A's three, this marker takes its whole table, the docs table, out of that scan, the rows cert-final's second run adds and cert-docs' F-certificate record included. On the page made with it below, the two mentions excused are the figure scan's 11s of the HP7.6 claim (review 1 of the page fix, by a replay of the pattern), so the retired scan excused nothing there that day. The explanation after the dash names no number.
- `_what`: its first sentence now says how far each marker reaches in both scans, as above, and its last cites the first pre-check where its lines stay readable (this file's quote, not cert_out/, which the second run rewrites).

The marker's explanation after the dash was reworded after the page fix's first review (8 November 2026). The page and the pre-check below were made with its first wording, which ended "it counts stated test counts, not validate.py's rows, and any other value in this table is still checked". The new wording adds no digit and none of verify_docs.py's number words; the list before the dash, "11", and so the marker's coverage, are unchanged. Before the install, verify_docs.py is run once more, on a page with the new wording simulated by text, in a copy of the repository's work tree (hand/page_fix/RUN.md, step 1b); after it, cert-final's own pre-check checks the page it makes.

Nothing else in cert_P.json changed. p_gate.sh's third install checks this with Python's json module: every top-level key but page_markers equal, every page_markers key of the second install's kept with its value (`_what` aside), and every marker it adds or changes naming a figure.

**tools/make_archive.py.** cert-docs' make_archive.py (commit A's, as cert-prep put it in S/tools) leaves out every file larger than MAX_BYTES, 400 000 bytes (line 55, `if os.path.getsize(p) > MAX_BYTES:`, then `continue`). S/TOOL_EDITS.md was 95 673 bytes in commit A's archive; the first install made it 431 943 bytes and the second 643 913, and the third install's section makes it larger. So cert-docs' archive would have left TOOL_EDITS.md out, and archive_ok, which requires TOOL_EDITS.md and its section "commit P" in the archive, would have stopped cert-docs after it had removed S's extra trees, written its F-certificate record and written the three certificate files into the repository; no install would have been left on this S to mend it (review 1 of the page fix, blocking item 1). Line 55 now reads
  `if os.path.getsize(p) > MAX_BYTES and rel != "TOOL_EDITS.md":   # (commit P, 8 Nov) archive_ok requires it; P made it larger`
  so that TOOL_EDITS.md is packed whatever its size, and every other file as before. No other line changed (the diff below). make_archive.py takes S from its own path, so it must sit in S/tools; the kit is the only way into S/tools, hence this kit file. No driver runs make_archive.py: p_gate.sh cert-docs alone runs it, after this install. No record of this S was made with it, and every record before this install was written beside commit A's copy, unchanged.

INTEGRATION.md does not name make_archive.py among the edited tools, and cert_P.json's tools_note lists the edits of section "commit P" only, not this one. Its not_covered also says the config "was reviewed before the run and not edited after it", which the second install and this edit have made untrue. All three are kit texts the third install cannot change (it changes cert_P.json inside page_markers only), so this section and S/TOOL_EDITS.md's section "commit P, third install" record them, and P's session report is to disclose them (hand/page_fix/RUN.md, step 9). INTEGRATION.md's open item 9 ("Whether verify_docs.py accepts the page") stays as written; this section answers it.

#### What it was checked with (8 November 2026; one Python run at a time, none in the repository, none writing in .venv)

- S/tools/make_cert.py, cmp-equal to the kit's, ran with `-I -B -X utf8` from the kit folder, so that the config is named `cert_P.json` as F.2 names it. It read S's records as they stand, the ones cert-final's last make had read, and wrote into hand/page_fix/. make_md.py then ran the same way. Both exited 0. make_cert.py's print-out is F.2's (`cert_out/make_cert_stdout.txt`) but for the output path: every check ok, and the five FAIL lines each with rechecked_by. The page is F.2's draft plus one line, the marker (its first wording), directly above the docs table's header (line 300; the table runs to line 316, HP7.6's row). The JSON differs from F.2's in page_markers and config.sha256 only.
- verify_docs.py ran as the final driver's pre-check runs it. copy_tree.py copied the clone candg into a scratch folder (1558 files), the new JSON and page went into its results/, and `python -B verify_docs.py` ran there: exit 0 in 143 s, "All 74 checks pass (967 figure mentions scanned in the documents)." Its EXEMPTIONS list names results/B58_IDENTITY.md with 2 mentions excused. Both are the HP7.6 claim, read once from its own line and once from the line above joined to it (scan_documents' window). A replay of the pattern in perl finds exactly those two values of 11 on the page, and two of 8 (lines 204-205), which equal the data.
- The page cert-final's second run will make holds four more rows: its F.1 records, its HP7.6 record and its 3.6.19 record repeat the first run's checks (F-certificate.json records 4 to 6, G7-suites.json record 44). That page was simulated by text, not made: each of the four rows copied below its first-run row with the record number changed, and the four counts of section 4 that move raised by hand. verify_docs.py on another copy of the clone with that page: exit 0, "All 74 checks pass (968 figure mentions scanned in the documents).", results/B58_IDENTITY.md with 3 mentions excused, the two HP7.6 rows. The page cert-final writes is checked by its own pre-check, which must print the same line before cert-docs runs.
- make_archive.py was not run: its one line was read against archive_ok's list of members (every one in S, each under MAX_BYTES but TOOL_EDITS.md), and cert_ready parses every kit .py before cert-final.

It reaches S through p_gate.sh cert-kit's third install (decisions/cert_kit_page.txt, MODE page, its EDITED lines naming cert_P.json and tools/make_archive.py; hand/page_fix/p_gate_page.patch). S/cert_P.json and S/tools/make_archive.py are replaced by the kit's and nothing else of S's kit; the smoke step is run again and its pin rewritten, in those two lines only. S/TOOL_EDITS.md gets the section "commit P, third install": the decision, every kit file's sha256 before and after, both diffs, this section, and the first cert-final's evidence (the sha256 of every file cert-final's second run rewrites, its two draft0 print-outs whole, its pre-check's summary and WRONG lines). S/cert_results is not touched. Then cert-final runs again (hand/page_fix/RUN.md).

#### The files the third edit changed (sha256)

| file | the second install's (S's installed copy) | after the third edit |
|---|---|---|
| `cert_P.json` | `ea67ac10c1d3cff8fc7a34923c3fadfbd3f43dc00466a51d6ede99e508346193` | `edf33cc2ba16e3a233797a4088c557d8ae3a5b4e8025b713cdb6d3ba992f5ec6` |
| `tools/make_archive.py` | `b536855d307597197e0b7cb4bea192a36c30eec2f56b9e150daea1a0bcc3ecd6` (commit A's, the archive's; not a kit file until this edit) | `4302eab82853161753488995820189ce370941e29242920859285adb1fd20c0f` |
| `TOOL_EDITS_commit_P.md` | `afb6abdb8013003131098bcb753ee3e147b05428effa2007c4c12399c6fe5275` (not installed as a file: its text opens S/TOOL_EDITS.md's section "commit P") | this file: the same text with this section appended; its sha256 is in decisions/cert_kit_reviewed.txt once that list is re-signed |

Every other kit file is unchanged: cmp-equal to the copy the second install put on S.

#### The diffs of the third edit

cert_P.json: the second install's copy (S's installed one) against the kit's.

```diff
--- commit P, second install (S's installed copy): cert_P.json
+++ commit P, third edit: cert_P.json
@@ -141,10 +141,11 @@
   "**A check of this page cannot be inside it.** The draft p_gate.sh reads is made from every record; the certificate p_gate.sh cert-docs makes into the repository, with its archive and the drift control on its files, is checked there (cert-docs, precommit), after these records. Anything the run did that its plan did not foresee is in P's session report, not in this config, which was reviewed before the run and not edited after it."
  ],
  "page_markers": {
-  "_what": "verify_docs.py markers make_md.py writes above a table (the key: a level, or 'control' for section 2's table), each excusing the one figure it names, in that table only (AUDIT2.md H2-6). Commit A's three, carried: the conditions jobs' names and the build_dataset count read as figures they are not. cert_final_driver_P.sh runs verify_docs.py on the draft in a copy before p_gate.sh cert-docs, so a figure these do not cover is seen before the repository is touched.",
+  "_what": "verify_docs.py markers make_md.py writes above a table (the key: a level, or 'control' for section 2's table). Each covers that table only: there its figure scan excuses the one figure the marker names and still compares every other value with the data, and, as for every marker that names a figure, the retired-figure scan skips the table (AUDIT2.md H2-6; verify_docs.py's _paragraph_is_historical). Commit A's three, carried: the conditions jobs' names and the build_dataset count read as figures they are not. cert_final_driver_P.sh runs verify_docs.py on the draft in a copy before p_gate.sh cert-docs, so a figure these do not cover is seen before the repository is touched. P's own, the fourth (commit P, third edit, 8 November 2026): 'docs', above section 3's docs table, for HP7.6's record, whose got (the stated-count tally) the first cert-final's pre-check read as validate.py's rows inside their band (its summary and WRONG lines are quoted in TOOL_EDITS.md's section 'commit P, third install'; cert-final's second run rewrote cert_out/P_F2_verify_docs_precheck.txt).",
   "control": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
   "L2": "RETIRED-OK: 315 -- the conditions jobs are named by their ambient air in kelvin (cond:baseline ECU:<kelvin>:...), which verify_docs.py reads as check_premise's baseline damage",
-  "L5": "RETIRED-OK: 11 -- G4-data.json's build_dataset record counts the derivations, one per log, in the form verify_docs.py reads as validate.py's quantities inside their band; this table's validate.py rows are still checked"
+  "L5": "RETIRED-OK: 11 -- G4-data.json's build_dataset record counts the derivations, one per log, in the form verify_docs.py reads as validate.py's quantities inside their band; this table's validate.py rows are still checked",
+  "docs": "RETIRED-OK: 11 -- HP7.6's record (G7-suites.json, written by cert_final_driver_P.sh with stated_counts_P.py) tallies the test counts README.md and full_run.py state against their runs, in the form verify_docs.py reads as validate.py's rows inside their band; it counts stated test counts, not validate.py's rows. verify_docs.py's figure scan still compares every other value in this table with the data; like every marker that names a figure, this marker takes the table out of the retired-figure scan"
  },
  "page_text": {
   "previous_certificate": "commit A's certificate",
```

tools/make_archive.py: commit A's (the archive's, S's installed copy) against the kit's.

```diff
--- commit A (the archive's, S's installed copy): tools/make_archive.py
+++ commit P, third edit: tools/make_archive.py
@@ -52,7 +52,7 @@
                 continue                       # the lab's value dumps: re-made by lab_dump.py
             if rel == "archive_members.txt":
                 continue                       # the previous run's listing: this run writes its own below
-            if os.path.getsize(p) > MAX_BYTES:
+            if os.path.getsize(p) > MAX_BYTES and rel != "TOOL_EDITS.md":   # (commit P, 8 Nov) archive_ok requires it; P made it larger
                 continue
             out.append((rel, p))
     return sorted(out)
```
