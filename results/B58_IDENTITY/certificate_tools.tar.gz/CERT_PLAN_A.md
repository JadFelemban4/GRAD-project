# Commit A's B58 identity certificate: the run plan (build step 2, WP1)

Written 22 October 2026, before any level ran. The certificate of build step 1
(`results/B58_IDENTITY.md` and `.json`, section 8 and the `reproduce` block) is
re-run for commit A as `docs/build_step_2/PLAN.md` section 3.6 lists it (items 1-20),
as `AMENDMENTS.md` amends it (B1, B2, B3, B8, B9, B11, and B12 where items 12 and 16
catch it), with `HANDOFFS.md`'s items for commit A and those of the review of P7.
Item 20 (L8, training) runs on the training device only (decision 61): it is
**pending**, never run here. Nothing in this plan writes to the repository except
the certificate step at the end, which is the commit step's.

The candidate: `wp1-work` at `4461a91` (WIP commits 5eb6fea..4461a91 on c47907b),
committed and clean. `fingerprint.py --engine b58` printed, when this plan was
written: plant_sha `865f8e7b7e5c2dbe`, derived_sha `326c0835548975e2`, engine_sha
`023f5589215ee68e`, plant_text_sha `00d5af4fdd2bf478`, git_dirty False. plant_sha
must read `865f8e7b7e5c2dbe` at the start and at the end of the run.

## 0. State, preconditions and rules

**Prepared (22 October, by this plan's author):**

| what | where | state |
|---|---|---|
| build step 1's evidence, snapshotted before anything overwrites it | `scratchpad/cert2_bs1_snapshot/` (outside S, so `make_archive.py` does not pack it twice) | L4 L5 L6 L7 L8 F2 F11 app lab suites logs repro, cmp/L6_* cmp/L8_*, out/fp_*.txt, manifests, tools as they were |
| build step 1's **candidate-side** evidence, moved out of S | `scratchpad/cert2_bs1_snapshot/moved_from_S/`; the list with sha256 in `S/bs1_moved.txt` (268 files) | so that no file this run writes under the same name (`cmp/L6_*.json`, `suites/cand_*.txt`, `L5/cand_*`, ...) can be read stale if a step fails to rewrite it (mistakes 19, 25). S keeps the reference evidence the run reuses (`out/ref`, `out/fp_ref.txt`, `L4/ref_*`, `L5/ref_*` and `derived_params_DERIVED_ref.json`, `L7/ref_*`, `F2/new_drive_ref.txt`, `F11/ref_*`, `app/ref*`, `suites/ref_*`) and WP1's P1-P7 evidence |
| four candidate copies, `copy_tree.py` from REPO | `S/cand` (G3 roads, G5 lab build), `S/candd` (G4), `S/candw` (G2 writers), `S/candt` (G2's L9) | 1287 files each, every one equal to `manifest_start_A.txt` |
| the reference writer copy | `S/refw` = `cp -a S/ref` (G4's build_dataset dump moves its derived file aside; `S/ref` itself is read by G1 and G6 at the same time) | `tar --compare` with `git archive cf43fbb`: 0 content or size differences |
| the tree before WP1, for item 16's "before" | `S/pre` = `git archive c47907b` | `tar --compare`: 0 differences |
| `S/ref` (cf43fbb) | unchanged | `tar --compare`: 0 differences |
| the candidate manifest at the start | `S/manifest_start_A.txt` | 1287 files, manifest sha256 `b2f45892f0842049` |
| folders | `S/L5/backup` (run_writer.sh's backups; the archive left it out), `S/L9`, `S/cert_results`, `S/cert_out` | empty |
| `make_cert.py`, `make_md.py` parametrised (amendment B9) | `S/tools/`; config `S/cert_A.json`; `S/reproduce_A.json` | recorded in `TOOL_EDITS.md`, section "commit A" |
| two new tools | `S/tools/cert_record.py` (writes the records), `S/tools/l9_check.py` (item 17) | recorded in `TOOL_EDITS.md` |
| the shell variables | `S/env_A.sh` | `source` it at the top of every block |
| `runs/extremes_dt1` (L6, L7) | REPO | present: sighted_seed0, sighted_seed4, blind_seed2, blind_seed6, each `final.zip` (3 292 743 bytes) and `meta.json`; the committed `results/agents/extremes_dt1/<tag>/eval_record.npz` and `results/phase_d_extremes_dt1_raw.json` present |
| node and npm (G5) | `C:\Program Files\nodejs` | node v24.18.0, npm 12.0.2 |
| the harness controls' plants, on the final tree | `scratchpad/cert2_b9/control_plants_preflight.py`, run in `S/cand` (records built as harness.py builds them; no job ran) | 16 of 16 as expected: every perturbed or retagged plant accepted, the one-copy LHV refused (Engine's ValueError). The B1 and B2 controls last ran at P2-P4, before P5-P7's record checks; this shows only that they still build |
| the MY2021 and MY2023 Test Car Lists (item 15) | not on this machine (neither in `S/tcl` nor in the team's data folder, which holds MY2015-MY2020) | G7.1 fetches them; that needs the network |

**Preconditions the commit step must settle before the run (each changes a repository
file, which this plan does not do):**

1. **The lab's plant_sha pin (HANDOFFS commit A item 2; PLAN.md 3.6 item 12; physics.md
   item 3).** `Explanatory Simulation/tests/test_catalog.py:97` still pins
   `ded8da308863d394`, build step 1's plant. It must read `865f8e7b7e5c2dbe`, with a comment
   naming the plant (commit A's B58). Until it does, `test_results_are_current_and_inconclusive_with_explicit_caveats`
   fails on the candidate. **Mind the trap:** that test also fails on cf43fbb (its premise pin,
   line 87), so the "no failure on the candidate alone" rule of build step 1 would file it under
   "both" and hide the pin. G5.1 checks it by name.
2. **Any other edit commit A will carry** (CHECKPOINT.md's state line, which names
   `ded8da308863d394`; mistake 11's grep of the old plant_sha and engine_sha and their
   `verify_docs.RETIRED` entries; `Explanatory Simulation/docs/SOURCE_MAP.md`, HANDOFFS P7 item 5)
   is best made **before** the run too, so that the certified tree is commit A's.
3. **After any such edit**, re-make what this plan prepared from the old tree, and nothing
   else, then check the copies against the new manifest as section 0's table did:
   ```bash
   source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh; rm -rf $S/cand $S/candd $S/candw $S/candt
   for d in cand candd candw candt; do $PY -I $SW/tools/copy_tree.py $RW $SW/$d; done
   $PY -I $SW/tools/manifest.py $RW $SW/manifest_start_A.txt
   ```
   The plant files do not change, so plant_sha stays `865f8e7b7e5c2dbe` (check it, G1.0).

**Rules for every group.**
- `source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh`
  first (PY, `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1`, REPO/RW, S/SW, `rec`). Python 3.13.2 is the
  venv's; nothing else.
- **Never edit** `data/**`, `logs/raw/**`, `validation_table.md`, `results/ENGINE_THRESHOLDS*`
  or a plant file (plant.py, thermal.py, engines.py, engine_env.py, engine_specs/**, derived.py,
  fingerprint.py). **Never run `engine_thresholds.py`.** No fit; quote no EPA row value in a
  record. Writers run in the copies named; the repository only reads.
- **REPO must hold no untracked file during the run.** `fingerprint.py` counts untracked files
  in `git_dirty`, and evaluate.py's report and every fingerprint the run records would say True.
  `test_engine_threading.py` creates `_scan_probe_*.py` in REPO for a moment
  (`test_engine_threading.py:677`): it runs **alone, first** (G7.0), before G1-G6 start.
- Labels in `S/out` are `A_<group>_...`; groups never share a label or a file. The tools that
  name their own files (`run_writer.sh`, `run_l4.sh`, `run_l6.sh`, `check_l6.sh`, `run_app.sh`,
  `run_drift.sh`) write `cand_*` names in L4, L5, L6, F2, F11, app, lab and suites, where build
  step 1's candidate evidence was (moved out, section 0); the reference evidence (`ref_*`,
  `refgit_*`) is reused and never rewritten, except L6's and finding 2's reference dumps, which
  no archive holds and G6.1 and G4.2 make again.
- A run longer than a few minutes goes in the background (`run_in_background`), and the group
  waits for its completion notification; no sleep loop. Waiting on a condition (G5's launcher):
  the Monitor tool with an until-loop.
- **Every check is one record**, written with `rec <group> --level <L> --item "<items>"
  --command "<command>" --cwd <dir> --expected "<expected>" --got "<what the output says>"
  --verdict PASS|FAIL --seconds <n> --evidence <files, S-relative or absolute>`
  (optional `--what "<short name>"`, `--environment "<variables>"`, `--difference "<an expected
  difference, for the page's section 5>"`). It appends to `S/cert_results/<group>.json`, the
  group names below (`G1-harness` ... `G7-suites`, and `F-certificate` for the final step;
  `G0-prepare.json` already holds this plan's seven preparation checks, all under item `prep`,
  which answers no item of the re-run list, with their evidence in `S/prep/`). A
  check that could not run gets **no** record: the group says so in its report. Never mark a
  check PASS that did not run, and never PASS a check whose output differs from the expected
  outcome; a difference is a finding for the report.

## 1. Order and time

| when | what | wall time (21 Oct measures, map) |
|---|---|---|
| first, alone | G7.0 `test_engine_threading.py` | about 2 min |
| then, all at once | G1, G2, G3, G4, G5, G6, G7 (G7.1 onwards) | the longest is G6 (L7 about 2.6 h); G2 about 2.5 h; G3 about 2.5 h; G1 about 1 h; G5 about 1 h; G7 about 45 min; G4 about 15 min |
| last, after every group | F: the end fingerprint and manifest, then the certificate | about 30 min, with the drift control |

Every process is single-threaded (OMP and MKL 1), so running many at once changes the time,
not a number. The pool-heavy jobs (G3's check_roads.py and check_random_road.py, up to 18
workers; G2's `ecu_shift.run_all(20)`; G6's eight L6 processes) slow each other; the order
above does not depend on it.

## 2. G1-harness (L1-L3 and every harness control)

cwd: any (the tools take the tree as an argument). Trees: REPO (candidate), `S/ref`. Records:
`cert_results/G1-harness.json`.

**G1.0 identity, and the tree checks** (level `identity`; items `3.6.1, HA.10`)
```bash
source /c/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/cert2/env_A.sh
cd $REPO && $PY -B fingerprint.py --engine b58 > $S/out/A_G1_fp_cand.txt 2>&1
cd $REPO && $PY -B engines.py > $S/out/A_G1_engines.txt 2>&1
$PY -m pip freeze > $S/pip_freeze_A.txt
cd $REPO && git archive --format=tar cf43fbb | tar --compare -C $S/ref 2>&1 \
  | grep -v -E 'Mode differs|Uid differs|Gid differs|Mod time differs' > $S/out/A_G1_ref_tar_compare.txt
git -C $REPO status --porcelain --untracked-files=all > $S/out/A_G1_git_status.txt
```
Expected: plant_sha `865f8e7b7e5c2dbe`, derived_sha `326c0835548975e2`, engine
`b58b30o1/a90-supra-zf8hp51`, engine_sha `023f5589215ee68e`, backend `cycle`, gears
`5.25 3.36 2.172 1.72 1.316 1 0.822 0.64`, final_drive 3.15, dtheta 0.25, knees 1123 and 408,
scenario `grade=0.12 t_amb=315 v_kmh=130`, episodes_sha `05a598a574268b20`, git_dirty False,
git_dirty_plant_files empty, python 3.13.2; `engines.py` lists the B58 with that engine_sha and
mazda_25t, honda_l15b7, ford_27tt "not calibrated yet"; `S/out/fp_ref.txt` (cf43fbb, build step 1)
plant_sha `3c48890dd15bc116` with the same derived_sha, gears, knees, scenario and episodes_sha;
the tar comparison and git status empty. `pip_freeze_A.txt` equals `S/pip_freeze.txt` (66 lines)
or the difference is recorded.

**G1.1 the 34 jobs** (level `L1`, items `3.6.1`; also one record each for `B3` and `HA.9`)
```bash
$PY -I $SW/tools/run_jobs.py $RW A_G1_cand $SW/tools/jobs_all.txt 6 > $S/out/A_G1_cand_run.txt   # ~1970 s, background
bash $S/tools/compare_all.sh ref A_G1_cand > $S/cmp/A_G1_ref_vs_cand.txt
$PY -I $SW/tools/control_verdict.py ref A_G1_cand $SW/tools/jobs_all.txt IDENTICAL > $S/cmp/A_G1_verdict_cand.txt
```
Expected: `DONE A_G1_cand: 34 of 34 exit 0`; every line of the comparison `VERDICT: BIT-IDENTICAL`;
`CONTROL A_G1_cand against ref: expected IDENTICAL, got IDENTICAL over 34 jobs ... PASS`; 2 685 037
values (units 115 173, premise 169 000, extremes 764 980, terrain 382 490, random road 527 328,
wideair 406 746, conditions 319 320: build step 1's counts, which the reference dumps fix).
B3: the jobs that run step() -- the two B3 names, extremes:double:12:random and terrain:single:11:neutral, and every other extremes, terrain, wideair and cond episode -- are among them, BIT-IDENTICAL.
HA.9: the six `cond:` jobs, BIT-IDENTICAL.

**G1.2 build step 1's controls** (level `control`, item `3.6.2`). After G1.1 (the DIFFERENT
controls compare against `A_G1_cand`):
```bash
$PY -I $SW/tools/run_jobs.py $SW/ref A_G1_ref2 $SW/tools/jobs_ctl.txt 2
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_cturb $SW/tools/jobs_ctl.txt 2 HARNESS_PERTURB=thermal.c_turb
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_mass  $SW/tools/jobs_ctl.txt 2 HARNESS_PERTURB=car.mass
bash $S/tools/compare_all.sh ref A_G1_ref2 > $S/cmp/A_G1_ref_vs_ref2.txt
bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_cturb > $S/cmp/A_G1_cand_vs_ctl_cturb.txt
bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_mass  > $S/cmp/A_G1_cand_vs_ctl_mass.txt
$PY -I $SW/tools/control_verdict.py ref A_G1_ref2 $SW/tools/jobs_ctl.txt IDENTICAL
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_cturb $SW/tools/jobs_ctl.txt DIFFERENT
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_mass  $SW/tools/jobs_ctl.txt DIFFERENT
```
Expected: ref2 IDENTICAL on 4 of 4 jobs (305 222 values); c_turb and mass DIFFERENT on 4 of 4
(build step 1: first difference in units `thermal_None` at [1100, 2] for c_turb, `demand` at
[0, 0] for the mass); each log's `PERTURBED` line names the field and the two values.

**G1.3 the fuel controls** (PLAN.md 3.5; level `control`, item `3.6.2`)
```bash
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_afr $SW/tools/jobs_units.txt 1 HARNESS_PERTURB=fuel.afr_st
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_lhv $SW/tools/jobs_units.txt 1 HARNESS_PERTURB=fuel.lhv_j_per_kg
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_divergent $SW/tools/jobs_units.txt 1 HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg
bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_afr; bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_lhv
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_afr $SW/tools/jobs_units.txt DIFFERENT
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_lhv $SW/tools/jobs_units.txt DIFFERENT
```
Expected: afr DIFFERENT (P7: cycle 3094/19200, cycle_dtheta 3/6, deliverable 12/58,
deliverable_probe 2/10, predict 57/288); lhv DIFFERENT **including the three `thermal_*` keys**
(the network's copy moved with the cycle's; P1: cycle 4196, thermal_* 34 each); divergent:
`DONE A_G1_ctl_divergent: 0 of 1 exit 0`, its log ending in Engine's ValueError ("the network
would burn another fuel than the cycle"), the refusal it must give (one record, `--what "one
copy of the LHV moved alone is refused"`).

**G1.4 amendment B1** (level `control`, items `3.6.2, B1`)
```bash
$PY -I $SW/tools/run_jobs.py $RW A_G1_bind $SW/tools/jobs_quick.txt 3 HARNESS_BIND_COUNT=1
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_lamf32  $SW/tools/jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_floor HARNESS_BIND_COUNT=1
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_lamf64  $SW/tools/jobs_ctl_P2.txt 1 HARNESS_PERTURB=ecu.lam_floor HARNESS_BIND_COUNT=1
$PY -I $SW/tools/run_jobs.py $RW A_G1_ctl_ceilf32 $SW/tools/jobs_ctl_P2.txt 1 HARNESS_PERTURB_F32=ecu.lam_ceiling HARNESS_BIND_COUNT=1
$PY -I $SW/tools/run_jobs.py $RW A_G1_census      $SW/tools/jobs_census_P2.txt 3 HARNESS_BIND_COUNT=1
$PY -I $SW/tools/run_jobs.py $RW A_G1_census_rest $SW/tools/jobs_census_P2_rest.txt 6 HARNESS_BIND_COUNT=1
bash $S/tools/compare_all.sh ref A_G1_bind; bash $S/tools/compare_all.sh ref A_G1_census; bash $S/tools/compare_all.sh ref A_G1_census_rest
bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_lamf32; bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_lamf64; bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_ceilf32
$PY -I $SW/tools/control_verdict.py ref A_G1_bind $SW/tools/jobs_quick.txt IDENTICAL
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_lamf32 $SW/tools/jobs_ctl_P2.txt DIFFERENT
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_lamf64 $SW/tools/jobs_ctl_P2.txt IDENTICAL
$PY -I $SW/tools/control_verdict.py A_G1_cand A_G1_ctl_ceilf32 $SW/tools/jobs_ctl_P2.txt IDENTICAL
$PY -I $SW/tools/control_verdict.py ref A_G1_census $SW/tools/jobs_census_P2.txt IDENTICAL
$PY -I $SW/tools/control_verdict.py ref A_G1_census_rest $SW/tools/jobs_census_P2_rest.txt IDENTICAL
grep -h "^BIND" $S/out/A_G1_bind/*.log $S/out/A_G1_ctl_lamf32/*.log $S/out/A_G1_census*/*.log > $S/out/A_G1_bind_lines.txt
$PY -I -c "import json,sys; c=json.load(open(sys.argv[1])); print({k['key']: k['first_index'] for k in c['keys'] if k['status']=='DIFFERENT'})" \
  $SW/cmp/A_G1_cand_vs_A_G1_ctl_lamf32/extremes_double_12_random.json > $S/out/A_G1_lamf32_first_rows.txt
```
Expected: the bind wrapper IDENTICAL on the three quick jobs, its count `floor 1 [780]` of 1099
steps in `extremes:double:12:random` (lam 0.699999988079071), ceiling 0, terrain 0 and 0;
lamf32 DIFFERENT with `info`, `obs`, `reward` and `state` first differing at row **780**, the
bind step (P2: info 119 rows, the 12 cycle and seed keys IDENTICAL); lamf64 IDENTICAL (float32
of 0.7 and of 0.7000000000000001 are one number); ceilf32 IDENTICAL, ceiling count 0 (no B58
lambda above 1 + ACT_HI[1] = 1.06); the census IDENTICAL on all 12 jobs, floor 0 and ceiling 0
in each.

**G1.5 amendment B2, the form controls** (level `control`, items `3.6.2, B2`). The values
exactly as P3fix and P4 ran them (their SET lines are in `out/ctl_P3fix_*` and `out/ctl_P4_*`):
```bash
SCHED='ecu.cam_on=1;ecu.cam_c0=10;ecu.cam_rpm_lo=800;ecu.cam_rpm_hi=7000;ecu.cam_map_lo=20;ecu.cam_map_hi=260;ecu.cam_lo=-60;ecu.cam_hi=60'
J=$SW/tools; run() { $PY -I $J/run_jobs.py $RW "$1" "$J/$2" 3 "HARNESS_SET=$3"; }
run A_G1_ctl_AB0    jobs_ctl_P3.txt   'cycle.form=A+B;cycle.ve_map=0.0'
run A_G1_ctl_ABC065 jobs_ctl_P3_C.txt 'cycle.form=A+B+C;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65'
run A_G1_ctl_ABCD0  jobs_ctl_P4.txt   'cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.ve_cam=0.0;cycle.cam_ref_deg=0.0;ecu.cam_on=1'
run A_G1_ctl_D0     jobs_ctl_P4.txt   "cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=0.0;$SCHED"
run A_G1_ctl_D1e4   jobs_ctl_P4.txt   "cycle.form=A+B+C+D;cycle.ve_map=0.0;cycle.ce_rich_slope=0.65;cycle.cam_ref_deg=0.0;cycle.ve_cam=1e-4;$SCHED"
run A_G1_ctl_ABve   jobs_ctl_P3.txt   'cycle.form=A+B;cycle.ve_map=1e-4'
run A_G1_ctl_ABCulp jobs_ctl_P3_C.txt 'cycle.form=A+B+C;cycle.ce_rich_slope=0.6500000000000001'
run A_G1_ctl_C070   jobs_ctl_P3_C.txt 'cycle.form=A+B+C;cycle.ce_rich_slope=0.7'
for l in AB0 ABC065 ABCD0 D0 C070; do bash $S/tools/compare_all.sh ref A_G1_ctl_$l; done
for l in D1e4 ABve ABCulp; do bash $S/tools/compare_all.sh A_G1_cand A_G1_ctl_$l; done
$PY -I $J/control_verdict.py ref A_G1_ctl_AB0    $J/jobs_ctl_P3.txt   IDENTICAL --allow-missing inv
$PY -I $J/control_verdict.py ref A_G1_ctl_ABC065 $J/jobs_ctl_P3_C.txt IDENTICAL --allow-missing inv
$PY -I $J/control_verdict.py ref A_G1_ctl_ABCD0  $J/jobs_ctl_P4.txt   IDENTICAL --allow-missing inv
$PY -I $J/control_verdict.py ref A_G1_ctl_D0     $J/jobs_ctl_P4.txt   IDENTICAL --allow-missing inv
$PY -I $J/control_verdict.py ref A_G1_ctl_C070   $J/jobs_ctl_P3_C.txt DIFFERENT --allow-missing inv
$PY -I $J/control_verdict.py A_G1_cand A_G1_ctl_D1e4   $J/jobs_ctl_P4.txt   DIFFERENT --allow-missing inv
$PY -I $J/control_verdict.py A_G1_cand A_G1_ctl_ABve   $J/jobs_ctl_P3.txt   DIFFERENT --allow-missing inv
$PY -I $J/control_verdict.py A_G1_cand A_G1_ctl_ABCulp $J/jobs_ctl_P3_C.txt DIFFERENT --allow-missing inv
```
Expected (P3fix's and P4's counts): AB0, ABC065, ABCD0, D0 IDENTICAL, units 76 keys with `inv`
allowed missing (each units log `INV SKIPPED`), terrain 17, extremes 17; ABCD0's log `CAM ON:
1220 cycles ... 0.0 to 0.0 deg`, D0's and D1e4's `10.0 to 10.0 deg`; D1e4 DIFFERENT in all three
jobs (units cycle 16505/19200); ABve DIFFERENT (units cycle 13156/19200, terrain reward
1099/1099); ABCulp DIFFERENT (units predict 55/288 and deliverable 1/58, cycle IDENTICAL, terrain
IDENTICAL, extremes info 111/19782 first at row 778); C070 DIFFERENT in units and extremes,
terrain IDENTICAL.

**G1.6 the reference side of the tools** (level `control`, items `3.6.2, B9`)
```bash
$PY -I $SW/tools/run_jobs.py $SW/ref A_G1_refside $SW/tools/jobs_P7.txt 3
bash $S/tools/compare_all.sh ref A_G1_refside
$PY -I $SW/tools/control_verdict.py ref A_G1_refside $SW/tools/jobs_P7.txt IDENTICAL
cd $S && sha256sum tools/*.py tools/*.sh tools/*.txt > $S/out/A_G1_tool_hashes.txt
```
Expected: IDENTICAL on the six jobs (115 173, 76 498, 76 498, 60 331, 60 331, 53 220 values):
the edited harness's reference branch is the archive's.

**G1.7 make_cert.py and make_md.py without --config are build step 1's** (level `control`, item
`B9`). In a fresh extraction of build step 1's archive, outside S (S's own build-step-1 evidence
was moved out), the unedited tools and the edited ones, side by side in one tools folder:
```bash
T=$(dirname $S)/cert2_bs1check; rm -rf $T; mkdir -p $T/bs1 && tar -xzf $REPO/results/B58_IDENTITY/certificate_tools.tar.gz -C $T/bs1
cp $S/tools/make_cert.py $T/bs1/tools/make_cert_A.py; cp $S/tools/make_md.py $T/bs1/tools/make_md_A.py
TW=$(cygpath -m $T); A=$RW/results/B58_IDENTITY/certificate_tools.tar.gz
$PY -I $TW/bs1/tools/make_cert.py $TW/orig.json $A; $PY -I $TW/bs1/tools/make_cert_A.py $TW/edit.json $A
$PY -I $TW/bs1/tools/make_md.py $TW/orig.json $TW/orig.md; $PY -I $TW/bs1/tools/make_md_A.py $TW/orig.json $TW/edit.md
cmp $T/orig.json $T/edit.json; cmp $T/orig.md $T/edit.md; diff $T/orig.md $REPO/results/B58_IDENTITY.md > $T/orig_vs_committed.txt
```
Expected (checked 22 October): both JSONs `BIT-IDENTICAL at every level` and byte-identical, both
pages byte-identical (257 lines); against the committed page, line 30 only (HEAD, and the cf43fbb
tar's sha256, which the archive cannot re-make, as its section 8 says). Remove `$T` afterwards.

## 3. G2-writers (L3, L5 writers, item 16, L9)

Trees: `S/candw` (writers, CAND=$S/candw), `S/pre` (c47907b), `S/candt` (L9). Records:
`cert_results/G2-writers.json`. `run_writer.sh` backs up `results/<file>` to
`S/L5/backup/cand_<basename>`, keeps the run's output in `S/L5/cand_<label>_*` and puts the backup
back: **never run two run_writer.sh calls on files of the same basename at once** (they share
the backup), so item 16's pre and candw runs of one script go one after the other.

**G2.1 check_premise.py** (level `L3`, item `3.6.3`)
```bash
CAND=$S/candw bash $S/tools/run_writer.sh cand premise results/premise.json check_premise.py     # ~1230 s
cmp $S/L5/cand_premise_OUT_premise.json $S/L5/ref_premise_OUT_premise.json
cmp $S/L5/cand_premise_OUT_premise.json $REPO/results/premise.json
diff $S/L5/ref_premise_stdout.txt $S/L5/cand_premise_stdout.txt
```
Expected: exit 0, `results/premise.json ... (UNCHANGED)`; the output equals the reference's and
the committed file; stdout differs only by the candidate's line `plant: b58b30o1/a90-supra-zf8hp51`
(build step 1's difference; record it with `--difference`); stderr empty.

**G2.2 generality_test.py** (level `L5`, item `3.6.7`), concurrently with G2.1 (other file)
```bash
CAND=$S/candw bash $S/tools/run_writer.sh cand generality results/generality.json generality_test.py   # ~3329 s
cmp $S/L5/cand_generality_OUT_generality.json $S/L5/ref_generality_OUT_generality.json
cmp $S/L5/cand_generality_OUT_generality.json $REPO/results/generality.json
diff $S/L5/ref_generality_stdout.txt $S/L5/cand_generality_stdout.txt
```
Expected: exit 0, UNCHANGED, equal to the reference's and the committed file, stdout identical.

**G2.3 item 16: the scripts this step edits, before and after** (level `L5`, items `3.6.16,
HA.7, B12`). After G2.1 and G2.2 finish (make_page.py reads their files). One script at a time,
`S/pre` first:
```bash
for t in pre candw; do CAND=$S/$t bash $S/tools/run_writer.sh cand A16${t}_mvd results/model_vs_data.json model_vs_data.py; done
cmp $S/L5/cand_A16pre_mvd_OUT_model_vs_data.json $S/L5/cand_A16candw_mvd_OUT_model_vs_data.json
cmp $S/L5/cand_A16candw_mvd_OUT_model_vs_data.json $REPO/results/model_vs_data.json
for t in pre candw; do CAND=$S/$t bash $S/tools/run_writer.sh cand A16${t}_substep results/substep_fit_check.json substep_fit_check.py; done
$PY -I -c "import json,sys; a,b=(json.load(open(f,encoding='utf-8')) for f in sys.argv[1:3]); [d.pop('seconds',None) for d in (a,b)]; print('EQUAL apart from seconds' if a==b else 'DIFFERENT'); sys.exit(a!=b)" \
  $SW/L5/cand_A16pre_substep_OUT_substep_fit_check.json $SW/L5/cand_A16candw_substep_OUT_substep_fit_check.json
for t in pre candw; do CAND=$S/$t bash $S/tools/run_writer.sh cand A16${t}_page results/page/index.html make_page.py; done
$PY -I -c "import difflib,sys; a,b=(open(f,encoding='utf-8').read().splitlines() for f in sys.argv[1:3]); d=[l[:300] for l in difflib.unified_diff(a,b,'c47907b','candidate',lineterm='',n=0)]; print(len(d),'diff lines'); print(*d,sep='\n')" \
  $SW/L5/cand_A16pre_page_OUT_index.html $SW/L5/cand_A16candw_page_OUT_index.html > $S/L5/A16_page_diff.txt
grep -c "engines.DamageCal.turb_knee_k\|engines.Fuel.afr_st" $S/L5/cand_A16candw_page_OUT_index.html
```
Expected: all six runs exit 0 (make_page.py's `_src` and `glossary()` checks stop the build if an
anchored text is gone: B12); model_vs_data.json byte-identical before and after (and, if it equals
the committed file, say so; if it does not, both trees differ from it alike, a stale committed file,
not a WP1 finding); substep_fit_check.json equal apart from `seconds`, and its first premise row
848.1 and 449.6 in both stdouts; the two built pages differ in exactly the two glossary-source
lines HANDOFFS commit A item 7 names (`engine_env.TURB_PROTECT_K` -> `engines.DamageCal.turb_knee_k
(1123 K on the B58); engine_env.damage_rate` and `plant.AFR_STOICH` -> `engines.Fuel.afr_st (14.7
on the B58; AFR: air-fuel ratio); car_thermal.measured_fuel_gps`), and in the build date only if
the two runs straddle midnight. HA.7: the candidate's page carries both new texts; the commit
step puts `S/L5/cand_A16candw_page_OUT_index.html` (or a rebuild in REPO) into
`results/page/index.html`.

**G2.4 L9, the contract's B58 steps in a copy** (level `L9`, item `3.6.17`). Concurrently with
G2.1-G2.3 (its own copy). Never `engine_thresholds.py`.
```bash
since=$(date +%s); echo $since > $S/L9/since.txt
cd $S/candt && s=$(date +%s) && $PY -c "from thresholds import b58_propagation as P; P.run()" > $S/L9/b58_propagation.txt 2>&1; echo "exit $? in $(( $(date +%s)-s )) s" >> $S/L9/b58_propagation.txt   # ~145 s
cd $S/candt && s=$(date +%s) && $PY -c "from thresholds import ecu_shift as U; U.run_all(20)" > $S/L9/ecu_shift.txt 2>&1; echo "exit $? in $(( $(date +%s)-s )) s" >> $S/L9/ecu_shift.txt   # ~1270 s, 20 processes
$PY -I $SW/tools/l9_check.py $SW/candt $RW/results/ENGINE_THRESHOLDS.json --since $since --json $SW/L9/l9_check.json > $S/L9/l9_check.txt
```
Expected: both exit 0; `L9: 25 of 25 step outputs equal the contract's generator_inputs_sha256
and were rewritten after <since> -> PASS` (b58_propagation.json and the 24 ecu/*.json).
`l9_check.py` on REPO's own committed files gives 25 of 25 without `--since` and 0 of 25 with
it (checked 22 October): it can fail.

## 4. G3-roads (L4, L5 roads, finding 11's road checks)

Trees: REPO (test_reward.py reads only), `S/cand` (the road writers, as `run_roads_review.sh`
runs them). Records: `cert_results/G3-roads.json`. The roads run one after another (each uses up
to 18 workers); L4 runs beside them.

**G3.1 test_reward.py** (level `L4`, item `3.6.4`)
```bash
bash $S/tools/run_l4.sh cand                 # ~1529 s, background
bash $S/tools/run_l4.sh cand --road random   # ~1930 s, background, at the same time
cmp $S/L4/cand_stdout.txt $S/L4/ref_stdout.txt; cmp $S/L4/cand_random_stdout.txt $S/L4/ref_random_stdout.txt
```
Expected: exit 0 twice; both stdouts byte-identical to cf43fbb's (2284 and 1005 bytes), stderr
empty, the last line `All checks pass. The reward is safe to train against.` Commit A's message
carries `S/L4/cand_stdout.txt` (CLAUDE.md, conventions; physics.md item 1).

**G3.2 the roads, the cand half of run_roads_review.sh** (level `L5`, item `3.6.5`)
```bash
CAND=$S/cand bash $S/tools/run_writer.sh cand roads_extremes results/training_roads_extremes.json check_roads.py --road extremes   # ~996 s
CAND=$S/cand bash $S/tools/run_writer.sh cand roads_wideair  results/training_roads_wideair.json  check_roads.py --road wideair    # ~1296 s
for r in extremes wideair; do cmp $S/L5/cand_roads_${r}_OUT_training_roads_${r}.json $S/L5/ref_roads_${r}_OUT_training_roads_${r}.json; cmp $S/L5/cand_roads_${r}_stdout.txt $S/L5/ref_roads_${r}_stdout.txt; done
cd $S/cand && cp -p results/training_roads.json $S/F11/cand_training_roads_committed.json && s=$(date +%s) \
  && $PY check_roads.py > $S/F11/cand_roads_terrain_stdout.txt 2> $S/F11/cand_roads_terrain_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/cand_roads_terrain_exit.txt; \
  cp -p results/training_roads.json $S/F11/cand_roads_terrain_OUT_training_roads.json; \
  cp -p $S/F11/cand_training_roads_committed.json results/training_roads.json          # ~608 s
cmp $S/F11/cand_roads_terrain_OUT_training_roads.json $S/F11/ref_roads_terrain_OUT_training_roads.json
cmp $S/F11/cand_roads_terrain_stdout.txt $S/F11/ref_roads_terrain_stdout.txt
cd $S/cand && s=$(date +%s) && $PY check_random_road.py > $S/F11/cand_random_road_stdout.txt 2> $S/F11/cand_random_road_stderr.txt; \
  echo "exit $? in $(( $(date +%s) - s )) s" > $S/F11/cand_random_road_exit.txt      # ~2777 s
diff $S/F11/ref_random_road_stdout.txt $S/F11/cand_random_road_stdout.txt
```
Expected: every exit 0; extremes' and wideair's outputs and stdouts identical to cf43fbb's
(`baseline past 850 C: 10 of 40 roads` and `2 of 40 roads`); wideair's equals the committed
file (UNCHANGED); extremes' differs from the committed file by `floor_nm` and `p_kpa` on every
road, as on cf43fbb (the committed file predates 06f4686; `--difference`); the 40 terrain roads
identical to cf43fbb's output and stdout (`baseline past 850 C: 14 of 40 roads`), both unlike the
committed file (stale since 75ca65f, build step 1's finding 13, for main; `--difference`);
check_random_road.py identical to cf43fbb's but for `road_sha` (`e44153fd81eeaa1e` against
`be19b3d0bcef435d`: random_road.py's code hash) and the run time, verdict PASS.

## 5. G4-data (validate, derive_params, build_dataset)

Trees: REPO (validate.py reads only), `S/candd`, `S/refw`. Records: `cert_results/G4-data.json`.

**G4.1 validate.py** (level `L5`, item `3.6.6`)
```bash
before=$(sha256sum < $REPO/validation_table.md)
cd $REPO && $PY validate.py > $S/L5/cand_validate.txt 2>&1; echo "exit $?" > $S/L5/cand_validate_exit.txt
cmp $S/L5/ref_validate.txt $S/L5/cand_validate.txt
after=$(sha256sum < $REPO/validation_table.md); [ "$before" = "$after" ] && git -C $REPO status --porcelain validation_table.md
```
Expected: exit 0; stdout byte-identical to cf43fbb's (2497 bytes, `8 of 11 quantities inside
their band`); `validation_table.md` the same bytes, git status empty. **If the output moves, it
is a finding: record FAIL and never edit the table.**

**G4.2 build_dataset with no derived file** (level `L5`, item `3.6.9`); cand and ref at once
```bash
CSVS=$(cd $REPO/logs/raw && ls *.csv)
$PY -I $SW/tools/bd_dump.py $SW/candd $SW/F2/cand.npz $CSVS > $S/F2/cand.txt 2>&1; echo "cand exit $?" >> $S/F2/cand.txt
$PY -I $SW/tools/bd_dump.py $SW/refw  $SW/F2/ref.npz  $CSVS > $S/F2/ref.txt  2>&1; echo "ref exit $?"  >> $S/F2/ref.txt
$PY -I $SW/tools/cmp.py $SW/F2/ref.npz $SW/F2/cand.npz --quiet --json $SW/F2/cmp.json > $S/F2/cmp.txt
```
Expected: eleven `derive OK` lines and `derived file restored: True` in each, both exit 0;
`VERDICT: BIT-IDENTICAL (3617501 values ...)`.

**G4.3 new_drive.py on pull01, the derived file aside** (level `L5`, item `3.6.9`); after G4.2
```bash
cd $S/candd && mv data/derived_params.json data/derived_params.json.aside \
  && $PY new_drive.py logs/raw/pull01-20260913_093527.csv > $S/F2/new_drive_candd.txt 2>&1; echo "exit $?"; \
  mv data/derived_params.json.aside data/derived_params.json
cmp $S/F2/new_drive_ref.txt $S/F2/new_drive_candd.txt
```
Expected: exit 0, identical to cf43fbb's output (2483 bytes), the derived file back.

**G4.4 derive_params.py** (level `L5`, item `3.6.8`); after G4.3 (it rewrites candd's derived file)
```bash
cd $S/candd && $PY derive_params.py > $S/L5/derive_cand.txt 2>&1; echo "exit $?" >> $S/L5/derive_cand.txt   # ~2 min
cp -p $S/candd/data/derived_params.json $S/L5/derived_params_DERIVED_cand.json
$PY -I $SW/tools/derived_check.py $RW/data/derived_params.json $SW/L5/derived_params_DERIVED_cand.json $SW/L5/derived_params_DERIVED_ref.json --json $SW/L5/derived_check.json > $S/L5/derived_check.txt
```
Expected: exit 0; derived_sha `326c0835548975e2` for the committed file, the candidate's and the
reference's (build step 1's `derived_params_DERIVED_ref.json`); every difference between them is
`/_generated` (bookkeeping), 0 values (the thermal fit now goes through
`measured_fuel_gps(afr_st=)`).

## 6. G5-app-lab (L5 app and lab)

Trees: REPO (every suite, and the lab's Python tests, as `run_app.sh` runs them), `S/cand` (the
lab's npm build and launcher, git-ignored outputs there). Records: `cert_results/G5-app-lab.json`.
Precondition 1 (the pin) first.

**G5.1 the app suites** (level `L5`, items `3.6.11, HA.3, HP7.7`; the lab's tests also `3.6.12, HA.2`)
```bash
bash $S/tools/run_app.sh cand          # ~45 min, background: test_replay --full, test_simulation, test_agents, test_results, the lab's tests
bash $S/tools/run_app_extra.sh cand    # the other eleven app/test_*.py
cd $REPO/app && node --test static/sim/*.test.mjs > $S/app/cand_node_tests.txt 2>&1; echo "exit $?" >> $S/app/cand_node_tests.txt
F='import re,sys; f=lambda p: set(re.findall(r"^(?:FAIL|ERROR): (\S+) \(", open(p,encoding="utf-8",errors="replace").read(), re.M)); c,r=f(sys.argv[1]),f(sys.argv[2]); print("candidate only:",sorted(c-r)); print("both:",sorted(c&r)); print("cf43fbb only:",sorted(r-c))'
for s in test_simulation test_agents test_results lab_tests; do echo "== $s"; $PY -I -c "$F" $SW/app/cand_$s.txt $SW/app/refgit_$s.txt; done > $S/app/A_G5_failing_sets.txt
grep -n "test_results_are_current_and_inconclusive_with_explicit_caveats" $S/app/cand_lab_tests.txt
diff $S/app/ref_test_replay_full.txt $S/app/cand_test_replay_full.txt
```
Expected: `app.test_replay --full` `59 of 59 checks pass`, differing from cf43fbb's only by M7's
label (build step 1's `--difference`); for test_simulation, test_agents, test_results and the
lab's tests, **candidate only: []** against cf43fbb's git clone (`app/refgit_*.txt`, build step
1); the two test_results tests build step 1 saw skipped "while the plant files are uncommitted"
now run, the plant files being committed (BI:190-191's "after the commit"); **the lab's
`test_results_are_current_and_inconclusive_with_explicit_caveats` ... ok** (it holds the plant_sha
pin; HA.2: FAIL here while precondition 1 is open); the eleven others OK; node: 306 tests, 306
pass, 0 fail, 0 skipped. Missing here, not failures: pwsh (an error each in test_agents and
test_results, skips in test_launcher), runs_c4/ (14 skips in test_agents). Commit A's message
carries `S/app/cand_test_replay_full.txt` (CLAUDE.md: a change under app/, `driver.html`).

**G5.2 the lab's build and launcher** (level `L5`, item `3.6.12`), in `S/cand/Explanatory Simulation`
```bash
{ node --version; npm --version; } > $S/lab/A_G5_versions.txt
L="$S/cand/Explanatory Simulation"
cd "$L" && s=$(date +%s) && npm ci > $S/lab/npm_ci.txt 2>&1; echo "exit $? in $(( $(date +%s)-s )) s" >> $S/lab/npm_ci.txt          # ~538 s, network
cd "$L" && s=$(date +%s) && npm run build > $S/lab/npm_build.txt 2>&1; echo "exit $? in $(( $(date +%s)-s )) s" >> $S/lab/npm_build.txt  # ~62 s
( cd "$L" && timeout 300 $PY launch.py --no-browser > $S/lab/launch_no_browser.txt 2>&1; echo "exit $? (124 = stopped by timeout after the check, as intended)" >> $S/lab/launch_no_browser.txt )   # background
#   wait (Monitor, until-loop) for "is ready" in launch_no_browser.txt, then:
cd "$L" && $PY launch.py --check > $S/lab/launch_check.txt 2>&1; echo "exit $?" >> $S/lab/launch_check.txt
```
Expected: npm ci exit 0 (`added ... packages`), npm run build exit 0 (`built in`), `Supra Lab is
ready: http://127.0.0.1:8765` then exit 124, `Local app healthy` exit 0. Port 8765 must be free.
Without the network npm ci cannot run: no record, say so.

**G5.3 the lab's node tests** (level `L5`, items `3.6.12, B12`), after G5.2's npm ci
```bash
cd "$S/cand/Explanatory Simulation" && CATALOG_TEST_PYTHON="$(cygpath -w $PY)" node --test src/model/*.test.mjs > $S/lab/A_G5_lab_node_tests.txt 2>&1; echo "exit $?" >> $S/lab/A_G5_lab_node_tests.txt
```
Expected: 0 fail (`command-explanations.test.mjs` anchors on `engine_env.py`'s
`base, map_b = self._track_torque` and `self.spark =`, which P4 edited around: B12). Build step 1
did not run these, so there is no cf43fbb count: a failure is a finding, classified by running
the same command in a copy of `S/ref` after its own npm ci.

**G5.4 the lab's outputs** (level `L5`, items `3.6.12, HA.8`)
```bash
$PY -I $SW/tools/lab_dump.py $SW/ref $SW/lab/lab_ref_A.json > $S/lab/lab_ref_A.log 2>&1
$PY -I $SW/tools/lab_dump.py $RW $SW/lab/lab_cand_A.json > $S/lab/lab_cand_A.log 2>&1
cmp $S/lab/lab_ref_A.json $S/lab/lab_ref_P4.json      # cf43fbb's dump of 22 October, made again
$PY -I -X utf8 $SW/tools/lab_compare.py $SW/lab/lab_ref_A.json $SW/lab/lab_cand_A.json > $S/lab/compare_A_cand_ref.txt
```
Expected: the reference dump byte-identical to P4's; `36325 leaf values compared; 178
source-line numbers moved; 88 re-worded strings; 4 other differences`, exactly
`/meta_en/concepts[4]/source/match` and `/meta_ar/...` (`m_air` -> `m_air =`) and
`/meta_en/concepts[7]/range` and `/meta_ar/...` (the clip is the engine's own bounds); `VERDICT:
DIFFERENT`, exit 1, **which is the expected outcome** (HANDOFFS commit A item 8): PASS only if the
four are exactly these and no value differs.

**G5.5 the lab's controls** (level `control`, item `3.6.12`), after G5.4
```bash
LAB_PERTURB=thermal.c_turb      $PY -I $SW/tools/lab_dump.py $RW $SW/lab/lab_A_ctl_cturb_ulp.json  > $S/lab/lab_A_ctl_cturb_ulp.log 2>&1
LAB_PERTURB=thermal.c_turb:1e-9 $PY -I $SW/tools/lab_dump.py $RW $SW/lab/lab_A_ctl_cturb_1e-9.json > $S/lab/lab_A_ctl_cturb_1e-9.log 2>&1
$PY -I -X utf8 $SW/tools/lab_compare.py $SW/lab/lab_cand_A.json $SW/lab/lab_A_ctl_cturb_ulp.json  > $S/lab/compare_A_ctl_cturb_ulp.txt
$PY -I -X utf8 $SW/tools/lab_compare.py $SW/lab/lab_cand_A.json $SW/lab/lab_A_ctl_cturb_1e-9.json > $S/lab/compare_A_ctl_cturb_1e-9.txt
```
Expected: one ulp: 0 other differences (the lab's 40-step sessions round it away: a measured
limit, recorded as such, expected IDENTICAL); 1e-9: DIFFERENT (build step 1: 1212 other
differences). The 1e-9 control is the one that must come out DIFFERENT.

## 7. G6-agents (L6, L7, finding 11's d2)

Trees: REPO, `S/ref` (read only). Records: `cert_results/G6-agents.json`.

**G6.1 L6, four X1 agents in both trees** (level `L6`, item `3.6.13`)
```bash
bash $S/tools/run_l6.sh      # 8 processes, ~1 h, background; S/L6 starts empty (build step 1's files moved out)
bash $S/tools/check_l6.sh > $S/cmp/A_G6_L6_report.txt 2>&1
```
Expected: `L6 done: 8 of 8 exit 0`; per agent, candidate against reference `VERDICT:
BIT-IDENTICAL (2128460 values ...)`; each tree against the committed files `140 of 140 equal at
full precision`, `46 fields, 1064200 values, all identical`, `VERDICT: EQUAL TO THE COMMITTED FILES`.

**G6.2 L6's controls** (level `control`, item `3.6.13`), beside G6.1
```bash
for c in "car.mass 5 mass" "thermal.c_turb 5 cturb" "car.mass:1e-9 2 mass1e-9" "car.mass:1e-6 2 mass1e-6"; do set -- $c
  HARNESS_PERTURB=$1 $PY -I $SW/tools/l6_agents.py $RW sighted_seed0 $SW/L6/A_G6_ctl_$3.npz $2 > $S/L6/A_G6_ctl_$3.log 2>&1 &
done; wait
for n in mass cturb mass1e-9 mass1e-6; do $PY -I $SW/tools/l6_check.py $SW/L6/A_G6_ctl_$n.npz sighted_seed0 --json $SW/cmp/A_G6_L6_ctl_${n}_committed.json > $S/L6/A_G6_ctl_${n}_check.txt; done
```
Expected: each `VERDICT: NOT EQUAL`, exit 1 (the expected outcome): one ulp on the mass 23 of 35
scores equal, 0 of 46 per-step fields differ (`eval_record.npz` is float32: a measured limit);
one ulp on c_turb 30 of 35; 1e-9 on the mass 2 of 14, 32 of 46 per-step fields; 1e-6 NOT EQUAL.

**G6.3 L7, evaluate.py end to end** (level `L7`, item `3.6.14`)
```bash
$PY -I $SW/tools/make_meta.py $RW $RW/runs/extremes_dt1/sighted_seed0 $SW/L7/cand_model/sighted_seed0 > $S/L7/make_meta.txt 2>&1
date +%H:%M:%S > $S/L7/cand_start.txt
cd $REPO && $PY evaluate.py --engine b58 --out $SW/L7/cand_eval.txt $SW/L7/cand_model/sighted_seed0 > $S/L7/cand_stdout.txt 2>&1; \
  { echo "exit $?"; date +%H:%M:%S; } > $S/L7/cand_exit.txt                         # ~2.6 h, background
$PY -I $SW/tools/l7_diff.py $SW/L7/ref_eval.txt $RW/runs/extremes_dt1/sighted_seed0 $SW/L7/cand_eval.txt $SW/L7/cand_model/sighted_seed0 --json $SW/L7/l7_diff.json > $S/L7/l7_diff.txt
$PY -I $SW/tools/l7_expect.py $SW/L7/cand_eval.txt > $S/L7/l7_expect.txt
```
Expected: make_meta `final.zip sha256 03e2f26f...` on both sides, `FATAL disagreements with the
live tree: none`, `schema_problem: None` (its identity_override text still says "build step 1's":
a scratch meta.json, not a result); evaluate.py exit 0 with no `--force-plant-mismatch`;
`NO DIFFERENCE` over 27 lines after the fingerprint block and the model path; `VERDICT: every
row equals the committed raw scores`. `S/L7/ref_eval.txt` is cf43fbb's, build step 1's.

**G6.4 evaluate.py --protocol d2** (level `L5`, item `3.6.10`); after G6.3's make_meta
```bash
cd $REPO && $PY evaluate.py --engine b58 --protocol d2 --out $SW/F11/cand_d2.txt > $S/F11/cand_d2_stdout.txt 2>&1; echo "exit $?" > $S/F11/cand_d2_exit.txt   # background
$PY -I $SW/tools/l7_diff.py $SW/F11/ref_d2.txt NONE $SW/F11/cand_d2.txt NONE --json $SW/F11/d2_diff.json > $S/F11/d2_diff.txt
cd $REPO && $PY evaluate.py --engine b58 --protocol d2 --out $SW/F11/cand_d2_x1.txt $SW/L7/cand_model/sighted_seed0 > $S/F11/cand_d2_x1_stdout.txt 2>&1; echo "exit $?" >> $S/F11/cand_d2_x1_stdout.txt
```
Expected: exit 0 and `NO DIFFERENCE` over 23 lines (the three hand-written policies on the twenty
frozen D2 episodes; no D2 agent is on this machine); X1's agent under d2: `PLANT MISMATCH` on the
scenario and episodes_sha, `REFUSING`, nonzero exit (the refusal is the expected outcome).

## 8. G7-suites (the suites, the documents, drift)

cwd: REPO for every suite (they read only). Records: `cert_results/G7-suites.json`. `one` is
`run_suites.sh`'s own function, written out so that the quick list runs **without**
test_engine_threading, which ran alone first. Define it in every G7 block, after `source`.
```bash
one() { local label=$1 dir=$2; shift 2; local s=$(date +%s); ( cd "$dir" && "$@" ) > $S/suites/$label.txt 2>&1; echo "$? $(( $(date +%s) - s )) $label" >> $S/suites/_status.txt; }
```

**G7.0 test_engine_threading.py, alone, before every other group** (level `suite`, items `3.6.15, HP7.6`)
```bash
one cand_test_engine_threading $REPO $PY test_engine_threading.py -v      # ~2 min
git -C $REPO status --porcelain --untracked-files=all                      # empty: the probe is gone
```
Expected: OK (P7: the count its run prints; README's count, if it states one, the same).

**G7.1 the MY2021 and MY2023 Test Car Lists** (network; for G7.2's second test_epa_map)
```bash
cd $REPO && $PY fetch_engine_data.py --target $SW/tcl --group epa-test-car-list > $S/suites/A_G7_fetch_tcl.txt 2>&1; echo "exit $?" >> $S/suites/A_G7_fetch_tcl.txt
ls $S/tcl/epa-test-car-list/MY2021 $S/tcl/epa-test-car-list/MY2023
```
Expected: exit 0, every file verified against `logs/epa/D3_AND_EPA_SOURCES.csv`'s sha256 (the
script refuses a target inside the repository and writes only there). Offline: no record, and
`cand_test_epa_map_with_2021_2023` does not run; say so.

**G7.2 run_suites.sh quick's other suites, and WP1's** (level `suite`, items `3.6.15, HP7.1, B8,
B11, HA.10, HP7.6`)
```bash
one cand_test_wide_air $REPO $PY test_wide_air.py &                        # ~1623 s
one cand_test_epa_map $REPO $PY test_epa_map.py -v &
if [ -d $S/tcl/epa-test-car-list/MY2021 ]; then TCL=$(cygpath -m $S/tcl/epa-test-car-list)
  ( export GRAD_EXTRA_DATA="$TCL/MY2021;$TCL/MY2023"; one cand_test_epa_map_with_2021_2023 $REPO $PY test_epa_map.py -v ) & fi
one cand_test_plant_guards $REPO $PY test_plant_guards.py -v &
one cand_random_road $REPO $PY random_road.py &
one cand_fingerprint $REPO $PY fingerprint.py --engine b58 &
one cand_test_cars $REPO $PY test_cars.py -v &
one cand_test_trainable $REPO $PY test_trainable.py -v &
one cand_test_fuel_forms $REPO $PY test_fuel_forms.py -v &
one cand_test_carried $REPO $PY test_carried.py -v &                       # HP7.1: run_suites.sh quick does not run it
wait
diff $S/suites/ref_random_road.txt $S/suites/cand_random_road.txt
grep -n "engine_sha .*; without" $S/suites/cand_test_fuel_forms.txt
grep -h "^Ran \|^OK\|^FAILED" $S/suites/cand_test_*.txt
```
Expected: every suite OK (P7/P7d's counts: test_plant_guards 19 with 9 skipped until the EPA
plants are calibrated, test_fuel_forms 44, test_cars 41, test_carried 16, test_trainable 10,
test_wide_air 17, test_epa_map 29, twice); random_road `SELF-TEST PASSES`, road_sha
`be19b3d0bcef435d` (the only line unlike cf43fbb's: `e44153fd81eeaa1e`); fingerprint as G1.0;
B11: `engine_sha 023f5589215ee68e; without [the 23 keys]: 99d2a9658b1258a7` and EngineSha's
control test ok; B8: test_trainable's Help, B58, Refused, Control and Registry tests ok; HA.10:
`test_plant_guards.GitDirtyPlantFiles` ok and G1.0's git_dirty_plant_files empty.

**G7.3 amendment B8's --help runs** (level `suite`, item `B8`)
```bash
for f in train train_all run_phase_d evaluate; do ( cd $REPO && $PY -B $f.py --help > $S/suites/A_G7_help_$f.txt 2>&1; echo "exit $?" >> $S/suites/A_G7_help_$f.txt ); done
grep -h -o "\-\-engine {[^}]*}" $S/suites/A_G7_help_*.txt
```
Expected: four exit 0, each usage naming `--engine {b58}` (engines.trainable(), decision 47).

**G7.4 the documents commit A carries** (level `docs`, items `HA.4, HA.5, HA.6, HA.11, HP7.6`)
```bash
grep -n "engines.py" $REPO/CLAUDE.md | grep -n "engine_specs"                                  # HA.4
for t in test_fuel_forms test_cars test_carried test_trainable; do echo "$t: README $(grep -c "$t.py" $REPO/README.md), full_run $(grep -c "$t.py" $REPO/full_run.py)"; done   # HA.5
grep -n -i "scipy" $REPO/requirements.txt                                                      # HA.6
grep -n "line 433" $REPO/engine_specs/b58.toml; grep -n "fuel properties" $REPO/engine_specs/b58.toml   # HA.11
grep -n -E "[0-9]+ tests" $REPO/README.md $REPO/full_run.py                                    # HP7.6, against G7.0 and G7.2's "Ran N tests"
```
Expected: CLAUDE.md's re-run rule names engines.py and engine_specs/; every one of the four files
named in README.md and full_run.py at least once; `scipy==1.18.1` and no "imported by nothing";
no `line 433` in b58.toml and the row cited by its text; every count README.md and full_run.py
state equal to its run's (README: test_plant_guards 19, 9 skipped; test_wide_air 17;
app.test_agents 135, against G5's run; full_run.py's six blocks).

**G7.5 verify_docs.py and drift_test** (level `docs`, item `3.6.18`), after G7.0
```bash
one cand_verify_docs $REPO $PY verify_docs.py            # ~399 s
bash $S/tools/run_drift.sh                               # ~1404 s, six parts, each with drift_test's own control
```
Expected: `All N checks pass (M figure mentions scanned in the documents).` (P7: 74 and 959;
read the run's own numbers), exit 0; `18 of 18 drifts CAUGHT (all parts)`, each part's control
passing. The drift control with the certificate in the tree is the final step's (F.3).

## 9. F-certificate (after every group; items 3.6.18's drift control and 3.6.19)

Records: `cert_results/F-certificate.json`.
```bash
# F.1 the end of the run (nothing may have changed in REPO)
cd $REPO && $PY -B fingerprint.py --engine b58 > $S/out/A_end_fp_cand.txt 2>&1
$PY -I $SW/tools/manifest.py $RW $SW/manifest_end_A.txt; cmp $S/manifest_start_A.txt $S/manifest_end_A.txt
# F.2 a draft certificate in scratch (read the verdict and every FAIL / MISSING it prints)
$PY -I $SW/tools/make_cert.py $SW/cert_out/B58_IDENTITY.json --config $SW/cert_A.json
$PY -I $SW/tools/make_md.py $SW/cert_out/B58_IDENTITY.json $SW/cert_out/B58_IDENTITY.md
```
Expected: plant_sha `865f8e7b7e5c2dbe` again (and the other fields as G1.0); the two manifests
identical (if not, list the files in `cert_A.json`'s `candidate.files_changed_note`, and a plant
file among them voids the run); make_cert prints its checks, every one `ok`, with pending L8.

F.3, the commit step's (it writes REPO; this plan does not): fill `cert_A.json`'s `date`; move
build step 1's page verbatim to the end of `STATE_HISTORY.md` (CLAUDE.md, "where things go");
copy the two draft files to `results/B58_IDENTITY.json` and `.md`; **remove the extra trees
`S/refw`, `S/candw`, `S/candt` and `S/pre` (make_archive.py's SKIP_DIRS does not name them: it would
pack their text files)**; then, as build step 1 did:
```bash
$PY -I $SW/tools/drift_control.py $RW $SW/suites/A_drift_control_with_certificate.txt       # record it: level docs, item 3.6.18
$PY -I $SW/tools/make_archive.py $RW/results/B58_IDENTITY/certificate_tools.tar.gz
$PY -I $SW/tools/make_cert.py $RW/results/B58_IDENTITY.json $RW/results/B58_IDENTITY/certificate_tools.tar.gz --config $SW/cert_A.json
$PY -I $SW/tools/make_md.py $RW/results/B58_IDENTITY.json $RW/results/B58_IDENTITY.md
$PY -I $SW/tools/drift_control.py $RW $SW/suites/A_drift_control_final.txt
cd $REPO && $PY verify_docs.py
```
The archive is made after the first drift control (it holds its output and every record) and
before make_cert (which records its sha256); the second drift control runs on the final files.
Then commit A's message: HANDOFFS commit A item 1 (WP1 followed section H's reading of the
decision sheet), the test_reward output (G3.1) and app.test_replay's (G5.1); the Desktop copy of
decision 72 (item 12). Not run here: `app.test_results` once more on commit A itself, if the
commit step wants commit A's own hash in it.

## 10. The control table

Each harness control's verdict is `control_verdict.py`'s, and `make_cert.py --config` recomputes
it from `compare_all.sh`'s reports (`cert_A.json`'s `controls`). "a" is what the control is
compared against.

| control (label) | jobs | environment | a | expected | why it can fail |
|---|---|---|---|---|---|
| A_G1_ref2 | jobs_ctl.txt: units, extremes:double:12:random, wideair:locked:45.0:80.0:11:neutral, cond:current-grade:315.0:82.0:0.13:varying | none, in S/ref | ref | IDENTICAL | a job or a harness that is not deterministic, or reference dumps that are not cf43fbb's, read DIFFERENT |
| A_G1_ctl_cturb | jobs_ctl.txt | HARNESS_PERTURB=thermal.c_turb | A_G1_cand | DIFFERENT | IDENTICAL: the housing's capacity never reaches the outputs, and no IDENTICAL level says anything about it (mistakes 12, 25) |
| A_G1_ctl_mass | jobs_ctl.txt | HARNESS_PERTURB=car.mass | A_G1_cand | DIFFERENT | IDENTICAL: the car record does not reach step() (vehicle_for, P5) |
| A_G1_ctl_afr | units | HARNESS_PERTURB=fuel.afr_st | A_G1_cand | DIFFERENT | IDENTICAL: the cycle burns a constant of its own, not the engine's fuel (P1) |
| A_G1_ctl_lhv | units | HARNESS_PERTURB=fuel.lhv_j_per_kg (with_fuel: both copies) | A_G1_cand | DIFFERENT, thermal_* among the keys | IDENTICAL, or thermal_* IDENTICAL: the cycle or the network reads its own heating value |
| A_G1_ctl_divergent | units | HARNESS_PERTURB=thermal.fuel_lhv_j_per_kg (one copy) | (record only) | exit 1, Engine's ValueError | an exit 0 means two heating values can drift apart unseen |
| A_G1_bind | jobs_quick.txt | HARNESS_BIND_COUNT=1 | ref | IDENTICAL; floor 1 at step 780 | a wrapper that changes step() reads DIFFERENT, and its count means nothing |
| A_G1_ctl_lamf32 | extremes:double:12:random | HARNESS_PERTURB_F32=ecu.lam_floor, bind count | A_G1_cand | DIFFERENT, first at row 780 | IDENTICAL: the clip does not read the engine's floor; a first difference elsewhere: it differs for another reason |
| A_G1_ctl_lamf64 | extremes:double:12:random | HARNESS_PERTURB=ecu.lam_floor, bind count | A_G1_cand | IDENTICAL | DIFFERENT: the clip compares in float64, which moves the B58's bits at a binding step (NEP 50, B10) |
| A_G1_ctl_ceilf32 | extremes:double:12:random | HARNESS_PERTURB_F32=ecu.lam_ceiling, bind count | A_G1_cand | IDENTICAL (by construction) | DIFFERENT: a B58 lambda reached 1.25, which the bind count then names; cannot show the ceiling (test_fuel_forms does, with a ceiling of 1) |
| A_G1_census, A_G1_census_rest | the 12 other random-action jobs | HARNESS_BIND_COUNT=1 | ref | IDENTICAL; floor 0, ceiling 0 | a count above 0 is a binding step no control covers |
| A_G1_ctl_AB0 | units, terrain:single:11:neutral | HARNESS_SET A+B, ve_map 0.0 | ref | IDENTICAL (inv allowed missing) | DIFFERENT: the B term adds something other than an exact 0.0 |
| A_G1_ctl_ABC065 | units, terrain:single:11:neutral, extremes:double:12:random | HARNESS_SET A+B+C, slope 0.65 | ref | IDENTICAL (inv) | DIFFERENT: form C computes the rich efficiency another way |
| A_G1_ctl_ABCD0 | jobs_ctl_P4.txt (the same three) | HARNESS_SET A+B+C+D with zeros, cam_on 1 | ref | IDENTICAL (inv); CAM ON 0.0 deg | DIFFERENT: the cam path moves a double with every term at zero |
| A_G1_ctl_D0 | jobs_ctl_P4.txt | B2's schedule (cam 10 deg), ve_cam 0.0 | ref | IDENTICAL (inv); CAM ON 10.0 deg | DIFFERENT: the cam reaches the cycle other than through ve_cam |
| A_G1_ctl_D1e4 | jobs_ctl_P4.txt | the same, ve_cam 1e-4 | A_G1_cand | DIFFERENT | IDENTICAL: the ECU's cam never reaches run_cycle, and D0 proves nothing |
| A_G1_ctl_ABve | units, terrain:single:11:neutral | HARNESS_SET A+B, ve_map 1e-4 | A_G1_cand | DIFFERENT | IDENTICAL: the B term never reaches the breathing, and AB0 proves nothing |
| A_G1_ctl_ABCulp | jobs_ctl_P3_C.txt | HARNESS_SET A+B+C, slope 0.6500000000000001 | A_G1_cand | DIFFERENT (predict at lambda 0.95, the rich episode) | IDENTICAL: form C's slope is not the record's |
| A_G1_ctl_C070 | jobs_ctl_P3_C.txt | HARNESS_SET A+B+C, slope 0.7 | ref | DIFFERENT (the pre-check) | IDENTICAL: no job of the file runs rich, so the form C controls could not fail |
| A_G1_refside | jobs_P7.txt, in S/ref | none: the edited harness's reference branch | ref | IDENTICAL | DIFFERENT: a candidate-side edit leaked into the reference branch (B9) |
| A_G6_ctl_mass / _cturb | sighted_seed0, 5 episodes | HARNESS_PERTURB=car.mass / thermal.c_turb (l6_agents.py) | the committed raw scores | NOT EQUAL (scores) | EQUAL: the full-precision score check cannot see one ulp; the per-step records cannot (float32), a stated limit |
| A_G6_ctl_mass1e-9 / 1e-6 | sighted_seed0, 2 episodes | HARNESS_PERTURB=car.mass:1e-9 / :1e-6 | the committed files | NOT EQUAL (scores and per step) | EQUAL: the per-step check is blind even to a relative step |
| lab one ulp | the lab's four sessions | LAB_PERTURB=thermal.c_turb | lab_cand_A.json | IDENTICAL (a measured limit) | DIFFERENT would only show more than build step 1 measured |
| lab 1e-9 | the same | LAB_PERTURB=thermal.c_turb:1e-9 | lab_cand_A.json | DIFFERENT | IDENTICAL: the lab never reads the plant it names |
| make_cert/make_md without --config (G1.7) | build step 1's archive, unpacked | no --config; the unedited and the edited tools in one tools folder | each other, and the committed page | byte-identical JSON and page; the committed page differs at line 30 only | any other difference: the parametrisation changed the reference side of the tool |

## 11. Item map

| item | group: checks |
|---|---|
| 3.6.1 | G1.0, G1.1 |
| 3.6.2 | G1.2-G1.7 |
| 3.6.3 | G2.1 |
| 3.6.4 | G3.1 |
| 3.6.5 | G3.2 |
| 3.6.6 | G4.1 |
| 3.6.7 | G2.2 |
| 3.6.8 | G4.4 |
| 3.6.9 | G4.2, G4.3 |
| 3.6.10 | G6.4 |
| 3.6.11 | G5.1 |
| 3.6.12 | G5.1 (lab tests), G5.2-G5.5 |
| 3.6.13 | G6.1, G6.2 |
| 3.6.14 | G6.3 |
| 3.6.15 | G7.0-G7.2 |
| 3.6.16 | G2.3 |
| 3.6.17 | G2.4 |
| 3.6.18 | G7.5, F.3's drift control |
| 3.6.19 | F (the certificate itself; no record) |
| 3.6.20 | **pending**: L8 on the training device (decision 61), never here |
| B1 | G1.4 |
| B2 | G1.5 |
| B3 | G1.1 |
| B8 | G7.2 (test_trainable), G7.3 |
| B9 | G1.6, G1.7, TOOL_EDITS.md (commit A) |
| B11 | G7.2 (test_fuel_forms.EngineSha); make_cert reads its printed line into section 1 |
| B12 | G2.3 (make_page builds), G5.3, G5.4 |
| HA.1, HA.12 | the commit step (the message; the Desktop copy of decision 72): no run |
| HA.2 | precondition 1; G5.1 |
| HA.3 | G5.1-G5.5 |
| HA.4, HA.5, HA.6, HA.11 | G7.4 |
| HA.7 | G2.3 |
| HA.8 | G5.4 |
| HA.9 | G1.1 |
| HA.10 | G1.0, G7.2 |
| HP7.1 | G7.2 |
| HP7.5 | precondition 2 (SOURCE_MAP.md), the commit step or WP7: no run |
| HP7.6 | G7.0, G7.2, G7.4 |
| HP7.7 | G5.1 |
