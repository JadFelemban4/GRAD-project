"""DIAGNOSTIC A, sweep (measurement only; modified rows, NOT T0 rows): seed 1's T0 rows with ONLY the
lowest calibration Final row's lambda replaced by a set value (deterministic, no random draw), every
other row and channel as epa_fit.t0_rows made it; S3b (epa_fit.s3b_lambda at form A's base plant, as
epa_fit._fit calls it) re-run at each value. It measures at which cell-referenced lambda of that one row
S3b's flat interval moves between [125, 125] and [123, 124].

Loader calls: calibrate_epa._load (epa_rows.calibration_contract, epa_rows.calibration_rows). No extra
noise draws. Writes only sweep.json in this folder.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import dataclasses   # noqa: E402
import json          # noqa: E402

import numpy as np   # noqa: E402

NAME = "honda_l15b7"
JOBS = 16


def main():
    import calibrate_epa
    import engine_env
    import epa_fit
    import epa_rows
    import epa_stats

    source = epa_rows.Source.repository()
    view, yield_ = calibrate_epa._load(NAME, source=source)
    dtheta = calibrate_epa.DTHETA
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    tr = truths[0]
    rows = epa_fit.t0_rows(yield_, truth=tr, seed=1, view=view, dtheta=dtheta, jobs=JOBS)
    fm = min(r.map_kpa for r in rows if epa_fit._final(r))
    idx = [i for i, r in enumerate(rows) if epa_fit._final(r) and r.map_kpa == fm]
    assert len(idx) == 1
    i = idx[0]
    r0 = rows[i]
    base = epa_fit._base_plant(NAME, "A")
    tp = epa_fit.candidate(NAME, tr.values)
    lam_truth = engine_env.BaselineECU(tp.engine.ecu).step(r0.speed_rpm, r0.map_kpa, r0.imt_k, r0.ect_k, False,
                                                           epa_fit.S3B_DWELL_S)[1]

    def run(y_cellref):
        lm = float(y_cellref + (r0.lam_ref - 1.0))
        ch = {"lam_meas": lm}
        if r0.lam_banks is not None:
            ch["lam_banks"] = (lm, lm)
        rr = list(rows)
        rr[i] = dataclasses.replace(r0, **ch)
        rr = epa_fit.cal_rows(tuple(rr))
        cens = epa_stats.censoring([r for r in rr if epa_fit._final(r)])
        st = epa_fit.s3b_lambda(rr, plant=base, view=view, censoring=cens, lam_floor=float(view.lam_floor),
                                conventions=epa_stats.NOMINAL)
        return {"y_cellref_set": float(y_cellref), "y_cellref_read": float(epa_stats.lam_cellref(rr[i])),
                "noise_equivalent_sd": float((epa_stats.lam_cellref(rr[i]) - lam_truth) / epa_fit.T0_NOISE["lam"]),
                "enr_load": st.values["enr_load"], "enr_rpm_lo": st.values["enr_rpm_lo"],
                "enr_rpm_hi": st.values["enr_rpm_hi"], "enr_depth": st.values["enr_depth"],
                "flat": st.report["flat_gates_kpa"], "sse": st.report["sse"]}

    vals = [round(0.990 + 0.0005 * k, 6) for k in range(41)]
    vals += [round(0.99997 + 1e-6 * k, 7) for k in range(31)]
    vals.append(float(epa_stats.lam_cellref(r0)))          # seed 1's own value: must give [125, 125]
    vals = sorted(set(vals))
    res = [run(v) for v in vals]
    own = run(float(epa_stats.lam_cellref(r0)))
    print("DIAGNOSTIC sweep (modified rows, not T0). Truth-commanded lambda at the row:", repr(lam_truth),
          "; seed 1's own cell-referenced lambda", repr(float(epa_stats.lam_cellref(r0))), "->", own["flat"],
          own["enr_load"])
    prev = None
    for q in res:
        key = (tuple(q["flat"]), q["enr_load"], q["enr_rpm_lo"], q["enr_rpm_hi"])
        if key != prev:
            print(f"  from y = {q['y_cellref_set']!r} (noise-equivalent {q['noise_equivalent_sd']:+.5f} sd): "
                  f"flat {q['flat']}, gate {q['enr_load']}, rpm_lo {q['enr_rpm_lo']}, rpm_hi {q['enr_rpm_hi']}, "
                  f"depth {q['enr_depth']:.6f}")
            prev = key
    with open(os.path.join(OUT, "sweep.json"), "w", encoding="utf-8") as fh:
        json.dump(epa_fit._py({"note": "DIAGNOSTIC: modified rows (one row's lambda set), not T0; no random draws",
                               "row": {"map_kpa": r0.map_kpa, "rpm": r0.speed_rpm, "lam_ref": r0.lam_ref},
                               "lam_truth": lam_truth, "own": own, "sweep": res}), fh, indent=1)
    epa_fit.close_pools()


if __name__ == "__main__":
    main()
