"""DIAGNOSTIC A: arithmetic on measure.json and sweep.json (no model run, no data read). Prints the
noise-equivalent of each seed's lambda at the lowest Final row, the sweep's bracketing values, and the
one-row break-even lambda 1 - a*d/2 at the fitted (rpm_lo, rpm_hi, depth)."""
import json
import os

D = os.path.dirname(os.path.abspath(__file__))
m = json.load(open(os.path.join(D, "measure.json"), encoding="utf-8"))
s = json.load(open(os.path.join(D, "sweep.json"), encoding="utf-8"))
lam_t = m["part1_final_rows"][0]["truth_gate_123"]["lambda_commanded"]
print("truth-commanded lambda at the lowest Final row (gate 123.43):", repr(lam_t))
print("truth enrichment fraction:", repr(m["part1_final_rows"][0]["truth_gate_123"]["enrichment_fraction"]),
      "= ", m["part1_final_rows"][0]["truth_gate_123"]["enrichment_fraction"] / 0.005, "lambda-noise sd")
for seed in (1, 2):
    y = m[f"part2_seed{seed}_lowest_final"]["gate_123"]["lam_cellref"]
    print(f"seed {seed}: cell-referenced lambda {y!r}; minus truth {y - lam_t!r} = {(y - lam_t) / 0.005:+.5f} sd")
    lr = m["part3"][str(seed)]["lowest_final_row"]
    d = m["part3"][str(seed)]["s3b_values"]["enr_depth"]
    a = lr["a_if_enriched"]
    print(f"  S3b fitted depth {d!r}; a at the row {a!r}; fitted enrichment a*d {a * d!r} "
          f"= {a * d / 0.005:.5f} sd; break-even lambda 1 - a*d/2 = {1 - a * d / 2!r} "
          f"({(1 - a * d / 2 - lam_t) / 0.005:+.5f} sd from the truth's)")
    tab = {r["gate"]: r for r in m["part3"][str(seed)]["gate_table"]}
    print(f"  SSE(124) - SSE(125) = {tab[124.0]['sse_at_fitted_lo_hi'] - tab[125.0]['sse_at_fitted_lo_hi']!r}; "
          f"SSE(122) - SSE(123) = {tab[122.0]['sse_at_fitted_lo_hi'] - tab[123.0]['sse_at_fitted_lo_hi']!r}; "
          f"SSE(126) - SSE(125) = {tab[126.0]['sse_at_fitted_lo_hi'] - tab[125.0]['sse_at_fitted_lo_hi']!r}; "
          f"best SSE {tab[125.0]['sse_at_fitted_lo_hi'] if seed == 1 else tab[124.0]['sse_at_fitted_lo_hi']!r}")
prev = None
for q in s["sweep"]:
    k = tuple(q["flat"])
    if prev is not None and k != prev[1]:
        print(f"sweep bracket: y = {prev[0]['y_cellref_set']!r} -> flat {list(prev[1])}; "
              f"y = {q['y_cellref_set']!r} -> flat {list(k)}")
    prev = (q, k)
print("sweep values run:", len(s["sweep"]), "; rpm_lo, rpm_hi over the sweep:",
      sorted({(q["enr_rpm_lo"], q["enr_rpm_hi"]) for q in s["sweep"]}))
