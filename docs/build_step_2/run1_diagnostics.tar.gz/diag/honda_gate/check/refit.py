"""CHECK of DIAGNOSTIC A's reproduce_fit.py claim (measurement only): seeds 1 and 2's form-A fit on their T0
rows (epa_fit.fit_form, in_sample_for, form_record, t0_cases, _chi2_of), compared with
results/EPA_CALIBRATION/honda_l15b7/t0.json (read only). Loader call: calibrate_epa._load once (the calibration
loader: epa_rows.calibration_contract, epa_rows.calibration_rows). No random draws beyond epa_fit.t0_rows' own
T0_STREAM seeds 1 and 2. Writes only refit.json in this folder; bytecode writing off."""
import os
import sys

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json  # noqa: E402
import time  # noqa: E402

NAME = "honda_l15b7"
JOBS = 16


def canon(x):
    return json.dumps(x, sort_keys=True)


def main():
    import calibrate_epa
    import epa_fit
    import epa_rows

    view, yield_ = calibrate_epa._load(NAME, source=epa_rows.Source.repository())
    dtheta = calibrate_epa.DTHETA
    rec = json.load(open(os.path.join(REPO, "results", "EPA_CALIBRATION", NAME, "t0.json"), encoding="utf-8"))
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    out = {"note": "CHECK re-run of the diagnostic's reproduce_fit; no extra draws"}
    for seed in (1, 2):
        t0s = time.time()
        tr = truths[seed - 1]
        rows = epa_fit.t0_rows(yield_, truth=tr, seed=seed, view=view, dtheta=dtheta, jobs=JOBS)
        fit = epa_fit.fit_form(NAME, rows, view=view, form="A", start=None, jobs=JOBS, dtheta=dtheta)
        ins = epa_fit.in_sample_for(NAME, fit, rows, view=view, jobs=JOBS, dtheta=dtheta)
        fr = epa_fit._py(epa_fit.form_record(ins))
        cases = epa_fit._py(epa_fit.t0_cases(NAME, fit, tr, rows=rows, view=view))
        c2, z = epa_fit._chi2_of(fit, tr)
        c2 = epa_fit._py(c2)
        res = {"in_sample_A_equal": canon(fr) == canon(rec["ladders"][str(seed)]["in_sample"]["A"]),
               "cases_equal": {k: canon(cases[k]["detail"]) == canon(rec["cases"][k]["detail"][seed - 1])
                               for k in epa_fit.T0_CASES},
               "chi2_rerun": c2["value"], "chi2_recorded": rec["seeds"][seed - 1]["chi2"]["value"],
               "chi2_equal": canon(c2) == canon(rec["seeds"][seed - 1]["chi2"]),
               "z_equal": canon(epa_fit._py(z)) == canon(rec["seeds"][seed - 1]["z"]),
               "s3b": fit.stages["S3b"].values, "s3b_flat": fit.stages["S3b"].report["flat_gates_kpa"],
               "seconds": time.time() - t0s}
        out[str(seed)] = res
        print(f"seed {seed}: {res}", flush=True)
    with open(os.path.join(OUT, "refit.json"), "w", encoding="utf-8") as fh:
        json.dump(epa_fit._py(out), fh, indent=1)
    epa_fit.close_pools()


if __name__ == "__main__":
    main()
