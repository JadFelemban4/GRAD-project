"""CHECK of DIAGNOSTIC A: print the recorded numbers the diagnostic claims to reproduce, from
results/EPA_CALIBRATION/honda_l15b7/t0.json and run.json (read only). Reads no EPA data; draws no noise."""
import json
import os
import sys

sys.dont_write_bytecode = True
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
D = os.path.join(REPO, "results", "EPA_CALIBRATION", "honda_l15b7")
t0 = json.load(open(os.path.join(D, "t0.json"), encoding="utf-8"))
run = json.load(open(os.path.join(D, "run.json"), encoding="utf-8"))
print("t0.json top keys:", list(t0))
print("provenance:", json.dumps(t0.get("provenance"), indent=1)[:3000])
print("cases.d2_gate:", json.dumps(t0["cases"]["d2_gate"], indent=1))
print("cases.s1_law detail fitted:", [d.get("fitted") for d in t0["cases"]["s1_law"]["detail"]])
for i, s in enumerate(t0["seeds"]):
    print(f"seed index {i}: keys {list(s)}")
    print("   chi2:", s.get("chi2", {}).get("value"), "form chosen:", s.get("chosen_form", s.get("form")))
    tr = s.get("truth")
    if isinstance(tr, dict):
        print("   truth keys:", list(tr)[:60])
print("ladders keys:", list(t0.get("ladders", {})))
for k, v in t0.get("ladders", {}).items():
    print("ladder", k, "keys", list(v), "in_sample forms", list(v.get("in_sample", {})))
print("run.json top keys:", list(run))
inv = run.get("invocation") or run.get("provenance", {}).get("invocation")
print("run.json invocation:", json.dumps(inv, indent=1)[:1500])
