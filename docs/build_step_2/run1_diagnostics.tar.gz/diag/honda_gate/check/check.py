"""CHECK of DIAGNOSTIC A (the Honda's T0 d2_gate case), measurement only.

Data read: calibrate_epa._load("honda_l15b7", source=epa_rows.Source.repository()) once -- the calibration
loader (epa_rows.calibration_contract, epa_rows.calibration_rows). No held-out reader, no EPA table, no
epa_engine.json, nothing under logs/. Records read for comparison only: results/EPA_CALIBRATION/honda_l15b7/
t0.json; the diagnostic's own measure.json. No random draw of any kind in this script: the T0 rows are
epa_fit.t0_rows' own (T0_STREAM, seeds 1 and 2). Rows with the truth's gate at 125 kPa are a DIAGNOSTIC
truth, not a T0 truth. Writes only check.json in this folder; bytecode writing is off (PYTHONDONTWRITEBYTECODE).

S3b is recomputed INDEPENDENTLY of epa_fit's grid loop: closed-form depth clip(sum(a b)/sum(a^2), 0, d_max)
(no censoring: asserted), SSE by math.fsum, the grid and tie rule rewritten from s3b_lambda's docstring.
"""
import os
import sys

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
DIAG = os.path.dirname(OUT)
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import copy          # noqa: E402
import dataclasses   # noqa: E402
import json          # noqa: E402
import math          # noqa: E402
import struct        # noqa: E402

import numpy as np   # noqa: E402

NAME = "honda_l15b7"
JOBS = 16


def bits(v):
    return struct.pack("<d", float(v)).hex()


def eqb(a, b):
    if a is None or b is None:
        return a is None and b is None
    return bits(a) == bits(b)


def fields_differing(r1, r2):
    out = []
    for f in dataclasses.fields(r1):
        a, b = getattr(r1, f.name), getattr(r2, f.name)
        if isinstance(a, float) or isinstance(b, float):
            if not eqb(a, b):
                out.append(f.name)
        elif a != b:
            out.append(f.name)
    return out


def main():
    import calibrate_epa
    import engine_env
    import epa_fit
    import epa_rows
    import epa_stats

    log, out = [], {"note": "CHECK of DIAGNOSTIC A; no random draws; gate-125 rows are a DIAGNOSTIC truth",
                    "loader_calls": ["calibrate_epa._load -> epa_rows.calibration_contract, "
                                     "epa_rows.calibration_rows (once)"]}

    def p(*a):
        s = " ".join(str(x) for x in a)
        print(s, flush=True)
        log.append(s)

    view, yield_ = calibrate_epa._load(NAME, source=epa_rows.Source.repository())
    rec = json.load(open(os.path.join(REPO, "results", "EPA_CALIBRATION", NAME, "t0.json"), encoding="utf-8"))
    diag = json.load(open(os.path.join(DIAG, "measure.json"), encoding="utf-8"))
    rd = rec["cases"]["d2_gate"]["detail"]
    dtheta = calibrate_epa.DTHETA
    p("view sha256", view.sha256, "recorded", rec["provenance"]["view_sha256"],
      "equal", view.sha256 == rec["provenance"]["view_sha256"], "; dtheta", dtheta)

    # ---------------- A. the truth ----------------
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    tr1, tr2 = truths[0], truths[1]
    ecu = tr1.values["ecu"]
    g_t = ecu["enr_load"]
    p("A. truth gate", repr(g_t), "= recorded seed1/seed2 truth_gate_kpa (bits):", eqb(g_t, rd[0]["truth_gate_kpa"]),
      eqb(g_t, rd[1]["truth_gate_kpa"]), "; seed 2's truth ECU equals seed 1's:",
      json.dumps(tr2.values["ecu"], sort_keys=True) == json.dumps(ecu, sort_keys=True))
    p("   enr_rpm_lo", ecu["enr_rpm_lo"], "enr_rpm_hi", ecu["enr_rpm_hi"], "enr_depth", repr(ecu["enr_depth"]))
    tp = epa_fit.candidate(NAME, tr1.values)
    v125 = copy.deepcopy(tr1.values)
    v125["ecu"]["enr_load"] = 125.0
    tp125 = epa_fit.candidate(NAME, v125)
    cal = tp.engine.ecu
    t_dw = float(np.clip((epa_fit.S3B_DWELL_S - cal.enr_dwell_lo) / (cal.enr_dwell_hi - cal.enr_dwell_lo), 0, 1))
    p("   truth dwell lo/hi", cal.enr_dwell_lo, cal.enr_dwell_hi, "-> t(30 s)", t_dw)

    # ---------------- B. the calibration rows near the gate ----------------
    kinds = {}
    for r in getattr(yield_, "rows", yield_):
        kinds[type(r).__name__] = kinds.get(type(r).__name__, 0) + 1
    rows = epa_fit.cal_rows(yield_)
    finals = sorted([r for r in rows if epa_fit._final(r)], key=lambda r: r.map_kpa)
    fm = finals[0].map_kpa
    below = [r.map_kpa for r in rows if not epa_fit._final(r) and r.map_kpa < fm]
    p("B. yield row types", kinds, "; cal_rows", len(rows), "(Initial rows are not cal_rows); Final rows",
      len(finals), "; lowest Final MAP", repr(fm), "; highest steady MAP below it", repr(max(below)),
      "; midpoint equals truth gate (bits):", eqb(0.5 * (max(below) + fm), g_t))

    def cmd_lam(plant, r):
        return engine_env.BaselineECU(plant.engine.ecu).step(r.speed_rpm, r.map_kpa, r.imt_k, r.ect_k, False,
                                                             epa_fit.S3B_DWELL_S)[1]

    near = sorted([r for r in rows if 121.5 < r.map_kpa < 126.5], key=lambda r: r.map_kpa)
    p("   every cal row with 121.5 < MAP < 126.5 kPa (all, lambda or not):")
    p(f"   {'kind':>6} {'MAP':>11} {'rpm':>9} lam_missing sentinel S3b_row | {'s_truth':>9} {'enr by hand':>12} "
      f"{'1-lam_ECU@123.43':>16} {'1-lam_ECU@125':>14} {'enr/0.005':>9}")
    out["near_rows"] = []
    for r in near:
        s = float(np.clip((r.speed_rpm - ecu["enr_rpm_lo"]) / (ecu["enr_rpm_hi"] - ecu["enr_rpm_lo"]), 0, 1))
        hand = ecu["enr_depth"] * s * t_dw if r.map_kpa > g_t else 0.0
        e1, e2 = 1.0 - cmd_lam(tp, r), 1.0 - cmd_lam(tp125, r)
        s3b_row = epa_fit._has_lam(r) and epa_fit._no_sentinel(r)
        kind = "final" if epa_fit._final(r) else "steady"
        out["near_rows"].append({"kind": kind, "map_kpa": r.map_kpa, "rpm": r.speed_rpm,
                                 "lambda_missing": r.lambda_missing, "sentinel": r.spark_sentinel,
                                 "s3b_row": s3b_row, "s_truth": s, "enr_hand": hand, "enr_ecu_123": e1,
                                 "enr_ecu_125": e2})
        p(f"   {kind:>6} {r.map_kpa:11.6f} {r.speed_rpm:9.3f} {str(r.lambda_missing):>11} {str(r.spark_sentinel):>8} "
          f"{str(s3b_row):>7} | {s:9.6f} {hand:12.4e} {e1:16.4e} {e2:14.4e} {e1 / 0.005:9.5f}")
    n_change = sum(1 for r in rows if not eqb(cmd_lam(tp, r), cmd_lam(tp125, r)))
    p("   cal rows whose truth-commanded lambda differs between gate 123.43 and 125:", n_change)

    # ---------------- C. T0 rows ----------------
    t0 = {}
    for seed, tr in ((1, tr1), (2, tr2)):
        ra = epa_fit.t0_rows(yield_, truth=tr, seed=seed, view=view, dtheta=dtheta, jobs=JOBS)
        t0[seed] = ra
        idx = [i for i, x in enumerate(ra) if epa_fit._final(x) and eqb(x.map_kpa, fm)]
        assert len(idx) == 1
        i = idx[0]
        x = ra[i]
        dg = diag[f"part2_seed{seed}_lowest_final"]["gate_123"]
        same_as_diag = all(eqb(getattr(x, k), dg[k]) for k in ("lam_meas", "torque_nm", "tit_c", "fuel_meter_gps"))
        fed = epa_stats.lam_fed(x, conventions=epa_stats.NOMINAL)
        y = epa_stats.lam_cellref(x)
        lam_t = cmd_lam(tp, finals[0])
        p(f"C. seed {seed}: T0 row index {i}: lam_meas {x.lam_meas!r} cellref {y!r} lam_ref {x.lam_ref} torque "
          f"{x.torque_nm!r} TIT {x.tit_c!r} meter {x.fuel_meter_gps!r}; equals diagnostic's measure.json (bits) "
          f"{same_as_diag}; lam_fed {fed}; (cellref - truth lambda)/0.005 = {(y - lam_t) / 0.005:+.6f}")
        out[f"t0_seed{seed}"] = {"index": i, "lam_meas": x.lam_meas, "cellref": y, "torque_nm": x.torque_nm,
                                 "tit_c": x.tit_c, "meter": x.fuel_meter_gps, "lam_fed": list(fed),
                                 "equals_diag": same_as_diag, "noise_equiv_sd": (y - lam_t) / 0.005}
        if seed == 1:
            tr125 = dataclasses.replace(tr1, values=copy.deepcopy(v125), label="DIAGNOSTIC gate 125")
            rb = epa_fit.t0_rows(yield_, truth=tr125, seed=1, view=view, dtheta=dtheta, jobs=JOBS)
            nd = [(j, fields_differing(a, b)) for j, (a, b) in enumerate(zip(ra, rb)) if fields_differing(a, b)]
            xb = rb[i]
            p(f"   seed 1, DIAGNOSTIC truth gate 125 (same T0 noise): rows differing {nd}; lam_meas diff "
              f"{xb.lam_meas - x.lam_meas!r}; lam_fed {epa_stats.lam_fed(xb, conventions=epa_stats.NOMINAL)}")
            out["seed1_gate125_rows_differing"] = nd
            out["seed1_gate125_lam_diff"] = xb.lam_meas - x.lam_meas

    # ---------------- D. S3b, library and independent ----------------
    speeds = epa_fit._line_speeds(epa_fit._cal_lines(view))
    out["s3b"] = {}
    for seed in (1, 2):
        rr = epa_fit.cal_rows(t0[seed])
        base = epa_fit._base_plant(NAME, "A")
        cens = epa_stats.censoring([r for r in rr if epa_fit._final(r)])
        st = epa_fit.s3b_lambda(rr, plant=base, view=view, censoring=cens, lam_floor=float(view.lam_floor),
                                conventions=epa_stats.NOMINAL)
        d2 = epa_fit.d2_gate_case(st.report["flat_gates_kpa"], g_t, [r.map_kpa for r in rr if epa_fit._final(r)],
                                  fitted_gate_kpa=st.values["enr_load"], step_kpa=epa_fit.S3B_GATE_STEP_KPA)
        d2_same = json.dumps(epa_fit._py(d2["detail"]), sort_keys=True) == json.dumps(rd[seed - 1], sort_keys=True)
        p(f"D. seed {seed}: library s3b_lambda {st.values}, flat {st.report['flat_gates_kpa']}, sse "
          f"{st.report['sse']!r}; d2_gate_case equals recorded detail (JSON) {d2_same}, ok {d2['ok']}")
        # independent recomputation
        assert not cens.censored
        use = [r for r in rr if (not r.lambda_missing) and r.lam_meas is not None and not r.spark_sentinel]
        rpm = [float(r.speed_rpm) for r in use]
        mp = [float(r.map_kpa) for r in use]
        yv = [float(r.lam_meas) - (float(r.lam_ref) - 1.0) for r in use]
        b = [1.0 - v for v in yv]
        cb = base.engine.ecu
        t = min(max((epa_fit.S3B_DWELL_S - cb.enr_dwell_lo) / (cb.enr_dwell_hi - cb.enr_dwell_lo), 0.0), 1.0)
        lamf = [float(r.lam_meas) - (float(r.lam_ref) - 1.0) for r in rr
                if epa_fit._final(r) and (not r.lambda_missing) and r.lam_meas is not None]
        c1 = 1.0 - (min(lamf) - 0.01)
        inv = 1.0 - float(view.lam_floor)
        d_max = min(c1, inv)
        lib_edges = epa_fit.depth_edges(rr, lam_floor=float(view.lam_floor), conventions=epa_stats.NOMINAL)
        fmaps = [float(r.map_kpa) for r in rr if epa_fit._final(r)]
        g_lo, g_hi = min(min(fmaps), 100.0), max(fmaps)
        gates = [g_lo + k for k in range(int(math.floor(g_hi - g_lo)) + 1)]
        lo_c = [speeds[0] - d for d in (2000.0, 1500.0, 1000.0, 500.0)] + list(speeds)
        pairs = [(lo, hi) for lo in lo_c for hi in speeds if hi >= lo + 300.0]
        tab = {}
        for lo, hi in pairs:
            sv = [min(max((q - lo) / (hi - lo), 0.0), 1.0) for q in rpm]
            for g in gates:
                a = [sv[j] * t if mp[j] > g else 0.0 for j in range(len(use))]
                A = math.fsum(v * v for v in a)
                d = 0.0 if A == 0.0 else min(max(math.fsum(a[j] * b[j] for j in range(len(a))) / A, 0.0), d_max)
                f = math.fsum((b[j] - a[j] * d) ** 2 for j in range(len(a)))
                tab[(g, lo, hi)] = (f, d)
        best = min(tab.items(), key=lambda kv: (kv[1][0], -kv[0][0], kv[0][1], kv[0][2]))
        (gb, lob, hib), (fb, db) = best
        flat = [g for g in gates if tab[(g, lob, hib)][0] == fb]
        p(f"   independent: {len(use)} rows, t {t}, d_max {d_max!r} (C1 {c1!r}, invariant approx {inv!r}; library "
          f"upper {lib_edges['upper']!r} {lib_edges['active']}); best gate {gb} lo {lob} hi {hib} depth {db!r} sse "
          f"{fb!r}; flat [{min(flat)}, {max(flat)}]; agrees with library (gate, lo, hi, flat; depth and sse to 1e-12 rel): "
          f"{gb == st.values['enr_load'] and lob == st.values['enr_rpm_lo'] and hib == st.values['enr_rpm_hi'] and [min(flat), max(flat)] == st.report['flat_gates_kpa'] and abs(db / st.values['enr_depth'] - 1) < 1e-12 and abs(fb / st.report['sse'] - 1) < 1e-12}")
        dtab = {row["gate"]: row for row in diag["part3"][str(seed)]["gate_table"]}
        p(f"   gate | SSE at ({lob},{hib}) indep. | minus best | diagnostic's value | rel diff | profile-min pair")
        rows_out = []
        for g in [float(k) for k in range(118, 129)]:
            f, d = tab[(g, lob, hib)]
            prof = min(((tab[(g, lo, hi)][0], lo, hi) for lo, hi in pairs))
            dv = dtab[g]["sse_at_fitted_lo_hi"]
            rows_out.append({"gate": g, "sse": f, "depth": d, "minus_best": f - fb, "diag_sse": dv,
                             "profile_pair": [prof[1], prof[2]], "profile_sse": prof[0]})
            p(f"   {g:5.1f} | {f!r:>24} | {f - fb:+.4e} | {dv!r:>24} | {abs(f / dv - 1):.1e} | {(prof[1], prof[2])}"
              f"{' (min equals this pair)' if prof[0] == f else ' (another pair lower)'}")
        # the lowest Final row's own contribution at gates 124 and 125, and the break-even
        j = [k for k, r in enumerate(use) if epa_fit._final(r) and eqb(r.map_kpa, fm)][0]
        s_j = min(max((rpm[j] - lob) / (hib - lob), 0.0), 1.0)
        f124, d124 = tab[(124.0, lob, hib)]
        f125, d125 = tab[(125.0, lob, hib)]
        c124 = (b[j] - s_j * t * d124) ** 2
        c125 = b[j] ** 2
        others = (f124 - c124) - (f125 - c125)
        be = 1.0 - s_j * t * d125 / 2.0
        p(f"   lowest Final row: y {yv[j]!r} b {b[j]!r} a {s_j * t!r}; contribution at 124 {c124!r}, at 125 {c125!r}; "
          f"SSE(124)-SSE(125) {f124 - f125!r}; other rows' part {others!r}; break-even y* = 1 - a d/2 = {be!r}; "
          f"y - y* = {yv[j] - be:+.6e} -> predicts {'[125,125]' if yv[j] > be else '[123,124]'}")
        out["s3b"][str(seed)] = {"library": st.values, "library_flat": st.report["flat_gates_kpa"],
                                 "library_sse": st.report["sse"], "d2_equals_recorded": d2_same,
                                 "independent": {"gate": gb, "lo": lob, "hi": hib, "depth": db, "sse": fb,
                                                 "flat": [min(flat), max(flat)], "d_max": d_max},
                                 "gate_table": rows_out, "lowest_final": {"y": yv[j], "b": b[j], "a": s_j * t,
                                                                          "c124": c124, "c125": c125,
                                                                          "sse124_minus_125": f124 - f125,
                                                                          "others": others, "break_even": be}}
    with open(os.path.join(OUT, "check.json"), "w", encoding="utf-8") as fh:
        json.dump(epa_fit._py(out), fh, indent=1)
    with open(os.path.join(OUT, "check.log.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(log) + "\n")
    epa_fit.close_pools()


if __name__ == "__main__":
    main()
