"""DIAGNOSTIC A (measurement only): the Honda's T0 d2_gate case.

Reads EPA data ONLY through calibrate_epa._load (epa_rows.calibration_contract and
epa_rows.calibration_rows: the calibration view and the calibration yield). Opens no EPA table,
no epa_engine.json, nothing under logs/; calls no held-out reader. Writes only into this folder.
Draws no new noise: the T0 rows are epa_fit.t0_rows' own (stream T0_STREAM, seeds 1 and 2).

Usage: python measure.py   (writes measure.json and prints a text log)
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json          # noqa: E402
import math          # noqa: E402
import struct        # noqa: E402
import copy          # noqa: E402
import dataclasses   # noqa: E402

import numpy as np   # noqa: E402

NAME = "honda_l15b7"
JOBS = 16


def bits(v):
    return struct.pack("<d", float(v)).hex()


def same_float(a, b):
    if a is None or b is None:
        return a is None and b is None
    return bits(a) == bits(b)


def row_diff(r1, r2):
    """Field names whose values differ between two rows (floats by bits)."""
    out = []
    for f in dataclasses.fields(r1):
        a, b = getattr(r1, f.name), getattr(r2, f.name)
        if isinstance(a, float) or isinstance(b, float):
            if not same_float(a, b):
                out.append(f.name)
        elif isinstance(a, tuple) and a and isinstance(a[0], float):
            if len(a) != len(b) or any(not same_float(x, y) for x, y in zip(a, b)):
                out.append(f.name)
        elif a != b:
            out.append(f.name)
    return out


def main():
    import calibrate_epa
    import engine_env
    import epa_fit
    import epa_rows
    import epa_stats

    log = []

    def p(*a):
        s = " ".join(str(x) for x in a)
        print(s)
        log.append(s)

    p("DIAGNOSTIC A, measure.py. Loader calls: calibrate_epa._load (epa_rows.calibration_contract, "
      "epa_rows.calibration_rows). No extra noise draws in this script (T0_STREAM seeds 1, 2 only, via epa_fit.t0_rows).")
    source = epa_rows.Source.repository()
    view, yield_ = calibrate_epa._load(NAME, source=source)
    dtheta = calibrate_epa.DTHETA
    rec = json.load(open(os.path.join(REPO, "results", "EPA_CALIBRATION", NAME, "t0.json"), encoding="utf-8"))
    rec_d2 = rec["cases"]["d2_gate"]["detail"]
    p("dtheta", dtheta, "jobs", JOBS, "yield sha256", yield_.sha256, "view sha256", view.sha256,
      "recorded view sha256", rec["provenance"]["view_sha256"])

    out = {"note": "DIAGNOSTIC A (measurement only). No extra noise draws: T0 rows are epa_fit.t0_rows' own, "
                   "stream T0_STREAM=0x70, seeds 1 and 2.",
           "loader_calls": ["calibrate_epa._load -> epa_rows.calibration_contract, epa_rows.calibration_rows"],
           "view_sha256": view.sha256, "view_sha256_recorded": rec["provenance"]["view_sha256"],
           "yield_sha256": yield_.sha256}

    # ---------------- Part 0: the truths ----------------
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    tr1, tr2 = truths[0], truths[1]
    gate_truth = tr1.values["ecu"]["enr_load"]
    p("truth gate (t0_truths)", repr(gate_truth), "recorded", repr(rec_d2[0]["truth_gate_kpa"]),
      "bitwise equal", same_float(gate_truth, rec_d2[0]["truth_gate_kpa"]))
    cyc_eq = all(same_float(tr1.values["cycle"][k], v) if k != "form" else tr1.values["cycle"][k] == v
                 for k, v in rec["seeds"][0]["truth"].items())
    p("truth cycle equals recorded seed-1 truth (bitwise, every key)", cyc_eq)
    speeds = epa_fit._line_speeds(epa_fit._cal_lines(view))
    p("calibration line speeds", speeds)
    ecu_t = tr1.values["ecu"]
    p("truth ECU enrichment: enr_load", repr(ecu_t["enr_load"]), "enr_rpm_lo", ecu_t["enr_rpm_lo"],
      "enr_rpm_hi", ecu_t["enr_rpm_hi"], "enr_depth", repr(ecu_t["enr_depth"]))
    v125 = copy.deepcopy(tr1.values)
    v125["ecu"]["enr_load"] = 125.0
    tr1_125 = dataclasses.replace(tr1, values=v125, label="DIAGNOSTIC: truth gate moved to 125.0 kPa")
    tr2_125 = dataclasses.replace(tr2, values=copy.deepcopy(v125), label="DIAGNOSTIC: truth gate moved to 125.0 kPa")
    tp = epa_fit.candidate(NAME, tr1.values)
    tp125 = epa_fit.candidate(NAME, v125)
    cal = tp.engine.ecu
    p("truth ECU (built): enr_dwell_lo", cal.enr_dwell_lo, "enr_dwell_hi", cal.enr_dwell_hi,
      "dwell evaluated", epa_fit.S3B_DWELL_S)
    t_dw = float(np.clip((epa_fit.S3B_DWELL_S - cal.enr_dwell_lo) / (cal.enr_dwell_hi - cal.enr_dwell_lo), 0.0, 1.0))
    out["truth"] = {"gate_kpa": gate_truth, "gate_recorded": rec_d2[0]["truth_gate_kpa"],
                    "enr_rpm_lo": ecu_t["enr_rpm_lo"], "enr_rpm_hi": ecu_t["enr_rpm_hi"],
                    "enr_depth": ecu_t["enr_depth"], "enr_dwell_lo": cal.enr_dwell_lo,
                    "enr_dwell_hi": cal.enr_dwell_hi, "t_at_30s": t_dw, "line_speeds": list(speeds)}

    # ---------------- Part 1: the calibration Final rows ----------------
    rows = epa_fit.cal_rows(yield_)
    finals = sorted([r for r in rows if epa_fit._final(r)], key=lambda r: r.map_kpa)
    fm = finals[0].map_kpa
    steady_below = sorted([r for r in rows if not epa_fit._final(r) and r.map_kpa < fm], key=lambda r: r.map_kpa)
    p("calibration Final rows", len(finals), "lowest Final MAP", repr(fm))

    def under(plant, r):
        c = plant.engine.ecu
        e = engine_env.BaselineECU(c)
        sp, lam, _fan = e.step(r.speed_rpm, r.map_kpa, r.imt_k, r.ect_k, False, epa_fit.S3B_DWELL_S)
        above = r.map_kpa > c.enr_load
        s = float(np.clip((r.speed_rpm - c.enr_rpm_lo) / (c.enr_rpm_hi - c.enr_rpm_lo), 0.0, 1.0))
        frac = c.enr_depth * s * t_dw if above else 0.0
        return {"above_gate": bool(above), "s_rpm": s, "t_dwell": t_dw, "enrichment_fraction": float(frac),
                "lambda_commanded": float(lam), "check_1_minus_frac_eq_lambda": same_float(1.0 - frac, lam),
                "spark_commanded": float(sp)}

    def row_info(r):
        return {"kind": "final" if epa_fit._final(r) else "steady", "table": r.table, "line": r.line,
                "map_kpa": r.map_kpa, "rpm": r.speed_rpm, "lambda_missing": r.lambda_missing,
                "has_lam_for_S3b": epa_fit._has_lam(r), "spark_sentinel": r.spark_sentinel,
                "spark_empty": r.spark_empty, "hot": r.pops.hot, "fired": r.pops.fired}

    p("")
    p("PART 1. Lowest ten calibration Final rows by MAP; truth ECU at the row's inputs (BaselineECU.step, dwell 30 s), "
      "gate 123.4287 vs gate 125.0")
    p(f"{'MAP kPa':>11} {'rpm':>8} {'line':>15} lam_missing sentinel | {'s(rpm)':>7} {'frac@123.43':>12} "
      f"{'lam@123.43':>11} | {'frac@125':>9} {'lam@125':>9}")
    out["part1_final_rows"] = []
    for r in finals[:10]:
        a, b = under(tp, r), under(tp125, r)
        d = {**row_info(r), "truth_gate_123": a, "truth_gate_125": b}
        out["part1_final_rows"].append(d)
        p(f"{r.map_kpa:11.6f} {r.speed_rpm:8.1f} {r.line:>15} {str(r.lambda_missing):>11} {str(r.spark_sentinel):>8} | "
          f"{a['s_rpm']:7.4f} {a['enrichment_fraction']:12.6f} {a['lambda_commanded']:11.6f} | "
          f"{b['enrichment_fraction']:9.6f} {b['lambda_commanded']:9.6f}")
    p("")
    p("Steady rows below the lowest Final MAP (highest five), same truth ECU:")
    out["part1_steady_below"] = []
    for r in steady_below[-5:][::-1]:
        a, b = under(tp, r), under(tp125, r)
        out["part1_steady_below"].append({**row_info(r), "truth_gate_123": a, "truth_gate_125": b})
        p(f"{r.map_kpa:11.6f} {r.speed_rpm:8.1f} {r.line:>15} lam_missing={r.lambda_missing} "
          f"sentinel={r.spark_sentinel} hot={r.pops.hot} | frac@123.43={a['enrichment_fraction']:.6f} "
          f"lam={a['lambda_commanded']:.6f} | frac@125={b['enrichment_fraction']:.6f} lam={b['lambda_commanded']:.6f}")
    hs = steady_below[-1].map_kpa
    p("highest steady MAP below the lowest Final MAP", repr(hs), "; midpoint", repr(0.5 * (hs + fm)),
      "= truth gate:", same_float(0.5 * (hs + fm), gate_truth))
    out["highest_steady_below_lowest_final_kpa"] = hs
    # every calibration row: does any row change commanded lambda between gate 123.43 and 125?
    changed = [r for r in rows if not same_float(under(tp, r)["lambda_commanded"], under(tp125, r)["lambda_commanded"])]
    in_between = [r for r in rows if gate_truth < r.map_kpa <= 125.0]
    p("calibration rows with MAP in (123.4287, 125.0]:", [(round(r.map_kpa, 6), r.speed_rpm, row_info(r)["kind"])
                                                            for r in in_between])
    p("calibration rows whose truth-commanded lambda differs between gate 123.43 and gate 125:", len(changed))
    out["rows_map_between_gates"] = [row_info(r) for r in in_between]
    out["rows_lambda_changes_between_gates"] = len(changed)

    # ---------------- Part 2: seed 1's T0 rows at the lowest Final row ----------------
    p("")
    p("PART 2. T0 rows (epa_fit.t0_rows), truth gate 123.43 and the same truth with gate 125.0, same seed/noise")
    t0 = {}
    for seed, tr, trm in ((1, tr1, tr1_125), (2, tr2, tr2_125)):
        ra = epa_fit.t0_rows(yield_, truth=tr, seed=seed, view=view, dtheta=dtheta, jobs=JOBS)
        rb = epa_fit.t0_rows(yield_, truth=trm, seed=seed, view=view, dtheta=dtheta, jobs=JOBS)
        t0[seed] = ra
        diffs = [(i, row_diff(x, y)) for i, (x, y) in enumerate(zip(ra, rb))]
        nd = [(i, d) for i, d in diffs if d]
        p(f"seed {seed}: {len(ra)} T0 rows; rows differing between gate 123.43 and gate 125 (any field, floats by bits): "
          f"{len(nd)} {nd[:5]}")
        low = [x for x in ra if epa_fit._final(x) and same_float(x.map_kpa, fm)]
        lowb = [x for x in rb if epa_fit._final(x) and same_float(x.map_kpa, fm)]
        assert len(low) == 1 and len(lowb) == 1
        x, y = low[0], lowb[0]
        tol = {"lam": epa_fit.T0_NOISE["lam"], "torque_nm": epa_fit.T0_NOISE["torque_rel"] * x.torque_nm,
               "tit_k": epa_fit.T0_NOISE["tit_k"]}
        lam_x = None if x.lam_meas is None else float(x.lam_meas)
        lam_y = None if y.lam_meas is None else float(y.lam_meas)
        info = {"map_kpa": x.map_kpa, "rpm": x.speed_rpm,
                "gate_123": {"lam_meas": lam_x, "lam_cellref": epa_stats.lam_cellref(x), "lam_ref": x.lam_ref,
                             "torque_nm": x.torque_nm, "tit_c": x.tit_c, "fuel_meter_gps": x.fuel_meter_gps,
                             "spark_btdc": x.spark_btdc, "pops": dataclasses.asdict(x.pops)},
                "gate_125": {"lam_meas": lam_y, "lam_cellref": epa_stats.lam_cellref(y), "torque_nm": y.torque_nm,
                             "tit_c": y.tit_c, "fuel_meter_gps": y.fuel_meter_gps, "spark_btdc": y.spark_btdc},
                "difference": {"lam": None if lam_x is None else lam_y - lam_x, "torque_nm": y.torque_nm - x.torque_nm,
                               "tit_k": y.tit_c - x.tit_c,
                               "fuel_meter_gps": None if x.fuel_meter_gps is None else y.fuel_meter_gps - x.fuel_meter_gps},
                "t0_noise_sd": tol, "fields_differing": row_diff(x, y)}
        out[f"part2_seed{seed}_lowest_final"] = info
        out[f"part2_seed{seed}_rows_differing"] = nd
        p(f"  seed {seed} row MAP {x.map_kpa!r} rpm {x.speed_rpm}: lam_meas {lam_x!r} (cell-ref "
          f"{epa_stats.lam_cellref(x)!r}, lam_ref {x.lam_ref!r}), torque {x.torque_nm!r} N m, TIT {x.tit_c!r} C, "
          f"meter {x.fuel_meter_gps!r} g/s")
        p(f"  gate 125: lam_meas {lam_y!r}, torque {y.torque_nm!r}, TIT {y.tit_c!r}, meter {y.fuel_meter_gps!r}")
        p(f"  differences: {info['difference']}; T0 noise sd: lam {tol['lam']}, torque {tol['torque_nm']:.4f} N m, "
          f"TIT {tol['tit_k']} K; fields differing: {info['fields_differing']}")

    # noise-free channels at the row, both truths (no noise: RowModel.result at the row's inputs)
    p("")
    p("Noise-free model outputs at the lowest Final row's T0 inputs, truth gate 123.43 vs gate 125 (no noise added):")
    out["part2_noise_free"] = {}
    for label, plant, trx in (("gate_123", tp, tr1), ("gate_125", tp125, tr1_125)):
        model = epa_fit.RowModel(plant, fuels=view.fuel_by_table)
        r = finals[0]
        ecu = engine_env.BaselineECU(plant.engine.ecu)
        sp_t, lam_t, _f = ecu.step(r.speed_rpm, r.map_kpa, r.imt_k, r.ect_k, False, epa_fit.S3B_DWELL_S)
        ch = {}
        if not r.spark_sentinel:
            ch["spark_btdc"] = float(sp_t)
        if not r.lambda_missing:
            ch["lam_meas"] = float(lam_t + (r.lam_ref - 1.0))
            if r.lam_banks is not None:
                ch["lam_banks"] = (ch["lam_meas"], ch["lam_meas"])
        r1 = dataclasses.replace(r, **ch)
        xin = epa_stats.row_inputs(r1, fuel=epa_stats.fuel_of(r1, view=view, conventions=epa_stats.NOMINAL),
                                   conventions=epa_stats.NOMINAL, model=model)
        o = model.result(xin, dtheta=dtheta)
        out["part2_noise_free"][label] = {"lam_commanded": lam_t, "lam_fed": xin.lam, "lam_source": xin.lam_source,
                                          "spark": xin.spark_btdc, "torque_nm": o.torque_nm, "egt_c": o.egt_c,
                                          "mdot_fuel_gps": o.mdot_fuel_gps}
        p(f"  {label}: lambda commanded {lam_t!r}, fed {xin.lam!r} ({xin.lam_source}), torque {o.torque_nm!r}, "
          f"EGT {o.egt_c!r}, fuel {o.mdot_fuel_gps!r}")

    # ---------------- Part 3: S1, S3a, S3b at form A, seeds 1 and 2 ----------------
    p("")
    p("PART 3. S1, S3a, S3b at form A on the T0 rows, as epa_fit._fit calls them")
    out["part3"] = {}
    for seed in (1, 2):
        rr = epa_fit.cal_rows(t0[seed])
        base = epa_fit._base_plant(NAME, "A")
        cens = epa_stats.censoring([r for r in rr if epa_fit._final(r)])
        st1 = epa_fit.s1_backpressure(rr, view=view)
        st3a = epa_fit.s3a_spark(rr, plant=base, view=view)
        st3b = epa_fit.s3b_lambda(rr, plant=base, view=view, censoring=cens, lam_floor=float(view.lam_floor),
                                  conventions=epa_stats.NOMINAL)
        rep = st3b.report
        rd = rec_d2[seed - 1]
        d2 = epa_fit.d2_gate_case(rep["flat_gates_kpa"], gate_truth,
                                  [r.map_kpa for r in rr if epa_fit._final(r)],
                                  fitted_gate_kpa=st3b.values["enr_load"], step_kpa=epa_fit.S3B_GATE_STEP_KPA)
        same_d2 = json.dumps(epa_fit._py(d2["detail"]), sort_keys=True) == json.dumps(rd, sort_keys=True)
        s1_rec = rec["cases"]["s1_law"]["detail"][seed - 1]["fitted"]
        s1_same = all(same_float(st1.values[k], s1_rec[k]) for k in s1_rec)
        p(f"seed {seed}: S1 {st1.values} (recorded {s1_rec}; bitwise equal {s1_same})")
        p(f"seed {seed}: S3a values {st3a.values}")
        p(f"seed {seed}: S3b values {st3b.values}, flat {rep['flat_gates_kpa']}, sse {rep['sse']!r}, "
          f"flags {st3b.flags}, censoring {cens.censored} value {cens.value}")
        p(f"seed {seed}: d2_gate_case on the re-run equals recorded detail (JSON, every key): {same_d2}; "
          f"ok {d2['ok']} (recorded case ok over seeds: {rec['cases']['d2_gate']['ok']})")

        # grid replica: S3b's inner loop, every (gate, lo, hi), verified against S3b's own result
        cal_b = base.engine.ecu
        use = [r for r in rr if epa_fit._has_lam(r) and epa_fit._no_sentinel(r)]
        rpm = np.array([r.speed_rpm for r in use], dtype=float)
        mp = np.array([r.map_kpa for r in use], dtype=float)
        y = np.array([epa_fit._lam_target(r, epa_stats.NOMINAL) for r in use], dtype=float)
        b = 1.0 - y
        cm = epa_fit._censored_mask(use, cens)
        t = float(np.clip((epa_fit.S3B_DWELL_S - cal_b.enr_dwell_lo) / (cal_b.enr_dwell_hi - cal_b.enr_dwell_lo),
                          0.0, 1.0))
        edges = epa_fit.depth_edges(rr, lam_floor=float(view.lam_floor), conventions=epa_stats.NOMINAL)
        d_max = edges["upper"]
        fmaps = [r.map_kpa for r in rr if epa_fit._final(r)]
        g_lo, g_hi = min(min(fmaps), epa_fit.S3B_GATE_DESIGN_KPA), max(fmaps)
        gates = [g_lo + k * epa_fit.S3B_GATE_STEP_KPA
                 for k in range(int(math.floor((g_hi - g_lo) / epa_fit.S3B_GATE_STEP_KPA)) + 1)]
        lo_c = [speeds[0] - dd for dd in sorted(epa_fit.S3B_RPM_LO_BELOW, reverse=True)] + list(speeds)
        pairs = [(lo, hi) for lo in lo_c for hi in speeds if hi >= lo + epa_fit.S3B_RPM_SPAN_MIN]
        table = {}
        best = None
        for (lo, hi) in pairs:
            s = np.clip((rpm - lo) / (hi - lo), 0.0, 1.0)
            for g in sorted(gates, reverse=True):
                a = np.where(mp > g, s * t, 0.0)
                f, d = epa_fit._depth_1d(a, b, cm, d_max)
                table[(g, lo, hi)] = (f, d)
                if best is None or f < best[0] or (f == best[0] and (-g, lo, hi) < (-best[1], best[2], best[3])):
                    best = (f, g, lo, hi, d)
        sse, gate, lo, hi, depth = best
        flat = [g for g in gates if table[(g, lo, hi)][0] == sse]
        replica_ok = (same_float(sse, rep["sse"]) and gate == st3b.values["enr_load"]
                      and lo == st3b.values["enr_rpm_lo"] and hi == st3b.values["enr_rpm_hi"]
                      and same_float(depth, st3b.values["enr_depth"]) and [min(flat), max(flat)] == rep["flat_gates_kpa"])
        p(f"seed {seed}: grid replica reproduces S3b (sse bits, gate, lo, hi, depth bits, flat): {replica_ok}")
        p(f"seed {seed}: S3b rows used {len(use)}; t {t!r}; depth upper {d_max!r} ({edges['active']}); "
          f"rpm_lo candidates {lo_c}")
        s_fit = np.clip((rpm - lo) / (hi - lo), 0.0, 1.0)
        i_low = [i for i, r in enumerate(use) if epa_fit._final(r) and same_float(r.map_kpa, fm)]
        rows_tab = []
        p(f"seed {seed}: objective (S3b's SSE) by gate at the fitted (rpm_lo {lo}, rpm_hi {hi}), and the profile "
          "minimum over every (rpm_lo, rpm_hi) pair at that gate")
        p(f"  {'gate':>6} {'SSE@fit lo,hi':>22} {'depth':>10} {'SSE-best':>12} {'rows>gate':>9} | "
          f"{'profile min SSE':>22} {'argmin lo,hi':>16} {'depth':>10}")
        for g in [float(k) for k in range(118, 129)]:
            if g not in table and (g, lo, hi) not in table:
                continue
            f, d = table[(g, lo, hi)]
            prof = min(((table[(g, l2, h2)][0], l2, h2, table[(g, l2, h2)][1]) for (l2, h2) in pairs),
                       key=lambda q: (q[0], q[1], q[2]))
            n_above = int((mp > g).sum())
            row_low = None
            if i_low:
                i = i_low[0]
                aa = float(s_fit[i] * t) if mp[i] > g else 0.0
                res = float(b[i] - aa * d)
                row_low = {"a": aa, "residual": res, "contribution": (max(res, 0.0) if cm[i] else res) ** 2}
            rows_tab.append({"gate": g, "sse_at_fitted_lo_hi": f, "depth_at_fitted_lo_hi": d, "sse_minus_best": f - sse,
                             "rows_above_gate": n_above, "profile_min_sse": prof[0], "profile_argmin_lo": prof[1],
                             "profile_argmin_hi": prof[2], "profile_depth": prof[3], "lowest_final_row": row_low})
            p(f"  {g:6.1f} {f!r:>22} {d:10.6f} {f - sse:12.3e} {n_above:9d} | {prof[0]!r:>22} "
              f"{str((prof[1], prof[2])):>16} {prof[3]:10.6f}")
        # the lowest Final row in S3b's arrays
        low_detail = None
        if i_low:
            i = i_low[0]
            low_detail = {"map_kpa": float(mp[i]), "rpm": float(rpm[i]), "lam_target_y": float(y[i]), "b_1_minus_y": float(b[i]),
                          "censored": bool(cm[i]), "s_at_fitted_lo_hi": float(s_fit[i]), "a_if_enriched": float(s_fit[i] * t)}
            p(f"seed {seed}: lowest Final row in S3b: MAP {mp[i]!r} rpm {rpm[i]} target lambda {y[i]!r} "
              f"(b = 1 - y = {b[i]!r}); censored {bool(cm[i])}; s at fitted lo/hi {s_fit[i]!r}; a if enriched "
              f"{s_fit[i] * t!r}")
            for row in rows_tab:
                if row["gate"] in (123.0, 124.0, 125.0, 126.0):
                    lr = row["lowest_final_row"]
                    p(f"    gate {row['gate']}: depth {row['depth_at_fitted_lo_hi']!r}; this row a={lr['a']!r}, "
                      f"residual {lr['residual']!r}, contribution {lr['contribution']!r}; SSE of the other rows "
                      f"{row['sse_at_fitted_lo_hi'] - lr['contribution']!r}")
        else:
            p(f"seed {seed}: the lowest Final row is not among S3b's rows (no lambda or sentinel)")
        # rows that switch between consecutive gates 120..127
        sw = {}
        for g in range(120, 128):
            idx = [i for i in range(len(use)) if g < mp[i] <= g + 1]
            sw[f"({g},{g + 1}]"] = [{"map_kpa": float(mp[i]), "rpm": float(rpm[i]),
                                      "kind": "final" if epa_fit._final(use[i]) else "steady",
                                      "y": float(y[i]), "s_fit": float(s_fit[i])} for i in idx]
        p(f"seed {seed}: S3b rows whose MAP lies in each 1 kPa step 120..128: "
          + "; ".join(f"{k}: {[(round(q['map_kpa'], 4), q['rpm'], q['kind']) for q in v]}" for k, v in sw.items()))
        out["part3"][str(seed)] = {"s1": st1.values, "s1_recorded": s1_rec, "s1_bitwise_equal": s1_same,
                                   "s3a": st3a.values, "s3b_values": st3b.values, "s3b_report": rep,
                                   "s3b_flags": list(st3b.flags), "d2_gate_case_rerun": epa_fit._py(d2),
                                   "d2_detail_equals_recorded": same_d2, "grid_replica_reproduces_s3b": replica_ok,
                                   "rpm_lo_candidates": lo_c, "t": t, "depth_upper": d_max,
                                   "gate_table": rows_tab, "lowest_final_row": low_detail, "rows_per_step": sw}

    with open(os.path.join(OUT, "measure.json"), "w", encoding="utf-8") as fh:
        json.dump(epa_fit._py(out), fh, indent=1)
    with open(os.path.join(OUT, "measure.log.txt"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(log) + "\n")
    epa_fit.close_pools()


if __name__ == "__main__":
    main()
