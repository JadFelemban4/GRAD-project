"""DIAGNOSTIC A, reproduction check (measurement only): seeds 1 and 2's form-A fit on their T0 rows,
epa_fit.fit_form + epa_fit.in_sample_for + epa_fit.t0_cases + epa_fit._chi2_of, compared with the
recorded results/EPA_CALIBRATION/honda_l15b7/t0.json (read only). This re-runs the recorded numbers that
depend on the T0 rows' torque, meter and TIT channels (the in-sample statistics, the chi-square), so that
measure.py's Part 2 values come from rows shown to be the recorded run's.

Loader calls: calibrate_epa._load (epa_rows.calibration_contract, epa_rows.calibration_rows). No extra
noise draws. Writes only reproduce_fit.json in this folder.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json   # noqa: E402
import time   # noqa: E402

NAME = "honda_l15b7"
JOBS = 16


def canon(x):
    return json.dumps(x, sort_keys=True)


def main():
    import calibrate_epa
    import epa_fit
    import epa_rows

    source = epa_rows.Source.repository()
    view, yield_ = calibrate_epa._load(NAME, source=source)
    dtheta = calibrate_epa.DTHETA
    rec = json.load(open(os.path.join(REPO, "results", "EPA_CALIBRATION", NAME, "t0.json"), encoding="utf-8"))
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    out = {"note": "DIAGNOSTIC A reproduction; no extra noise draws (T0_STREAM seeds 1, 2 via epa_fit.t0_rows)",
           "loader_calls": ["calibrate_epa._load -> epa_rows.calibration_contract, epa_rows.calibration_rows"]}
    for seed in (1, 2):
        t_start = time.time()
        tr = truths[seed - 1]
        rows = epa_fit.t0_rows(yield_, truth=tr, seed=seed, view=view, dtheta=dtheta, jobs=JOBS)
        fit = epa_fit.fit_form(NAME, rows, view=view, form="A", start=None, jobs=JOBS, dtheta=dtheta)
        ins = epa_fit.in_sample_for(NAME, fit, rows, view=view, jobs=JOBS, dtheta=dtheta)
        fr = epa_fit.form_record(ins)
        cases = epa_fit._py(epa_fit.t0_cases(NAME, fit, tr, rows=rows, view=view))
        c2, z = epa_fit._chi2_of(fit, tr)
        c2 = epa_fit._py(c2)
        rec_in = rec["ladders"][str(seed)]["in_sample"]["A"]
        rec_seed = rec["seeds"][seed - 1]
        res = {"in_sample_A_equal": canon(fr) == canon(rec_in),
               "in_sample_A_rerun": fr,
               "passes": bool(ins.passes),
               "cases_equal": {k: canon(cases[k]["detail"]) == canon(rec["cases"][k]["detail"][seed - 1])
                               for k in epa_fit.T0_CASES},
               "chi2_equal": canon(c2) == canon(rec_seed["chi2"]),
               "chi2_value_rerun": c2["value"], "chi2_value_recorded": rec_seed["chi2"]["value"],
               "z_equal": canon(epa_fit._py(z)) == canon(rec_seed["z"]),
               "s3b_values": fit.stages["S3b"].values, "s3b_flat": fit.stages["S3b"].report["flat_gates_kpa"],
               "seconds": time.time() - t_start}
        out[str(seed)] = res
        print(f"seed {seed}: in-sample A equal {res['in_sample_A_equal']}; passes {res['passes']}; cases equal "
              f"{res['cases_equal']}; chi2 equal {res['chi2_equal']} ({c2['value']!r} vs "
              f"{rec_seed['chi2']['value']!r}); z equal {res['z_equal']}; S3b {res['s3b_values']} flat "
              f"{res['s3b_flat']}; {res['seconds']:.1f} s", flush=True)
    with open(os.path.join(OUT, "reproduce_fit.json"), "w", encoding="utf-8") as fh:
        json.dump(epa_fit._py(out), fh, indent=1)
    epa_fit.close_pools()


if __name__ == "__main__":
    main()
