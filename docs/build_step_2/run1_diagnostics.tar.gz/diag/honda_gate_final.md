I could not write report.md to the scratch folder: the Write tool refuses report files from a subagent. The full report follows here. Every other output is in that folder.

# Diagnostic A: the Honda's T0 d2_gate case (measurement only)

**Result: case (a) holds.** Under the truth, the lowest calibration Final row (124.677 kPa) is enriched by only 3.18e-05 in lambda, which is 0.0064 of the lambda noise sd. Moving the truth's gate to 125 kPa changes no other channel and no other row. S3b's objective then differs by about 1e-7 between gates 123/124 and 125, and the sign of the noise on that one row decides which side wins.

**Scratch folder:** `C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/diag/honda_gate`

**Commands.** Each was run from `C:/Users/badcl/Desktop/GRAD-project` with `C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe`:

| script | what it does | outputs |
|---|---|---|
| `measure.py` | Parts 1–3 | `measure.json`, `measure.log.txt` |
| `reproduce_fit.py` | the form-A fit for seeds 1 and 2, compared with t0.json | `reproduce_fit.json`, `reproduce_fit.log.txt` |
| `sweep.py` | DIAGNOSTIC: one row's lambda set to fixed values | `sweep.json`, `sweep.log.txt` |
| `summarise.py` | arithmetic on `measure.json` and `sweep.json` only | `summarise.log.txt` |

**Conditions.**
- HEAD 0147f93. Afterwards `git status` showed only the two untracked Run 1 paths, so the tracked tree is unchanged.
- Python 3.13.2, NumPy 2.5.3, SciPy 1.18.1, the same as t0.json's provenance.
- dtheta = `calibrate_epa.DTHETA` = 0.25, jobs 16 (as in run.json's invocation).
- The view sha256 (8c6a700c…b2da58) equals the recorded one.

**Loader calls.**
- `measure.py`, `reproduce_fit.py` and `sweep.py` each call `calibrate_epa._load("honda_l15b7", source=epa_rows.Source.repository())` once. That runs `epa_rows.calibration_contract` and `epa_rows.calibration_rows`.
- No other EPA data was read and no held-out reader was called.
- No EPA table or epa_engine.json was opened directly; only the loader opens them internally. Nothing under logs/ was opened.
- `results/EPA_CALIBRATION/honda_l15b7/t0.json` was read only for comparison.
- No calibrate_epa subcommand and no validate_epa.py was run.

**Noise.** I made no extra noise draws. The T0 rows are `epa_fit.t0_rows`' own (stream T0_STREAM, seeds 1 and 2). `sweep.py` uses no random draw. Its rows are modified rows, not T0 rows.

## Reproduction first (mistakes 19, 22)

Every check below matched bit for bit, as the JSON repr of doubles.
- **Truth:** `t0_truths` gives the gate 123.42867067468251, equal to the recorded value. Every key of the seed-1 truth cycle is equal too (`measure.log.txt`).
- **S1, seeds 1 and 2:** {exh_bp_ratio 1.4500341366888145, exh_bp_min_kpa 101.93739980922366}, equal to `cases.s1_law` (`measure.log.txt`).
- **d2_gate_case on the re-run S3b:** every key equals the recorded detail (`measure.log.txt`).
  - Seed 1: flat [125, 125], fitted 125, widened [124.677341349365, 125.60961538461535], ok False.
  - Seed 2: flat [123, 124], fitted 124, ok True.
- **Grid replica:** my copy of S3b's inner loop reproduces S3b's SSE, gate, rpm_lo, rpm_hi, depth and flat interval for both seeds.
- **Full form-A fit** (`fit_form`, `in_sample_for`, `t0_cases`, `_chi2_of`; `reproduce_fit.log.txt`):
  - For both seeds, the in-sample record equals `ladders[seed].in_sample.A` on every key.
  - All four cases' details are equal.
  - chi2 is 16.600950587741785 (seed 1) and 6.050660941588217 (seed 2), both equal to the record; z is equal.
  - This covers the torque, meter and TIT channels of the T0 rows used in Part 2.

## 1. Calibration Final rows under the truth's ECU (`measure.log.txt`, Part 1)

**The truth's enrichment:**
- enr_load 123.42867067468251.
- enr_rpm_lo 1500 (= speeds[1]); the line speeds are 1000, 1500, 1600, 1700, 1750, 1800, 2250, 2500, 3500, 4000, 5000.
- enr_rpm_hi 5000, enr_depth 0.15.
- The engine's enr_dwell_lo is 1.5 s and enr_dwell_hi 3.0 s, so t(30 s) = 1.

There are 49 Final rows. Each was evaluated with `BaselineECU.step(rpm, MAP, IAT, ECT, False, 30 s)`.

| MAP kPa | rpm | line | lam_missing | sentinel | s(rpm) | frac @123.43 | lam @123.43 | frac @125 | lam @125 |
|---|---|---|---|---|---|---|---|---|---|
| 124.677341 | 1500.7 | 1500 | F | F | 0.0002 | 0.000032 | 0.999968 | 0 | 1.000000 |
| 125.609615 | 4999.7 | 5000 | F | F | 0.9999 | 0.149987 | 0.850013 | 0.149987 | 0.850013 |
| 126.971787 | 1500.7 | 1500 | F | F | 0.0002 | 0.000031 | 0.999969 | 0.000031 | 0.999969 |
| 128.369651 | 1600.9 | 1600 | F | F | 0.0288 | 0.004325 | 0.995675 | same | same |
| 130.069069 | 4999.6 | 5000 | F | F | 0.9999 | 0.149984 | 0.850016 | same | same |
| 130.144880 | 3994.6 | 4000 | F | F | 0.7128 | 0.106913 | 0.893087 | same | same |
| 131.264642 | 4005.8 | 4000 | F | F | 0.7159 | 0.107390 | 0.892610 | same | same |
| 132.041351 | 4999.8 | 5000 | F | F | 0.9999 | 0.149991 | 0.850009 | same | same |
| 132.624427 | 1800.5 | 1700/1750/1800 | F | F | 0.0859 | 0.012879 | 0.987121 | same | same |
| 132.874884 | 1500.7 | 1500 | F | F | 0.0002 | 0.000032 | 0.999968 | same | same |

- **The lowest row:**
  - Commanded lambda: 0.9999681649012311 at gate 123.43, 1.0 at gate 125.
  - Enrichment fraction 3.1835e-05, which is 0.0064 of the 0.005 lambda noise sd (`summarise.log.txt`).
  - Its rpm, 1500.74, is 0.74 rpm above enr_rpm_lo = 1500, so s = 0.000212.
- **Highest steady MAP below 124.677:** 122.18 kPa (3995 rpm, line 4000, lambda published, no sentinel, not hot).
  - The truth gate is exactly the midpoint of 122.18 and 124.677 (bitwise).
  - That row is unenriched under both gates, and so are the next ones down: 122.08 (3500 rpm), 121.18, 121.00 and 116.41.
- The 124.677 Final row is the only calibration row with MAP in (123.4287, 125.0]. It is also the only row whose commanded lambda changes between the two gates.

## 2. Seed 1's T0 rows at the lowest Final row (`measure.log.txt`, Part 2)

I ran `t0_rows` for seed 1 twice with the same noise: once with the truth as recorded, once with its gate at 125.0. Of the 164 T0 rows, only row 115 (the 124.677 row) differs, and only in the field lam_meas.

| channel | gate 123.43 | gate 125 | difference | T0 noise sd |
|---|---|---|---|---|
| lam_meas (cell-referenced) | 0.992853489290898 (1.002853489290898) | 0.9928853243896669 | +3.1835e-05 | 0.005 |
| torque, N m | 129.50830970777463 | same bits | 0 | 0.6475 (0.5 %) |
| TIT, °C | 340.3791382605847 | same bits | 0 | 3 K |
| meter, g/s | 1.6524803137364388 | same bits | 0 | 0.5 % |

- Spark and the populations are also identical.
- Without noise, the model is fed lambda 1.0 ("snapped") at this row under both gates. Torque (130.95982981672944), EGT (340.59268097015763) and fuel (1.6644870631317283) are bitwise identical.
- Seed 2 behaves the same way: only lam_meas of row 115 differs, by +3.1835e-05.
- Measured against the truth's commanded value: seed 1's lambda at this row is +0.0028853 (+0.577 sd) and seed 2's is −0.0009914 (−0.198 sd).

## 3. S3b on seeds 1 and 2, form A (`measure.log.txt`, Part 3)

I ran S1, S3a and then S3b as `_fit` calls them. S3b used 157 rows, t = 1, and the depth's upper edge was C1's.

| seed | enr_load | rpm_lo | rpm_hi | depth | SSE | flat |
|---|---|---|---|---|---|---|
| 1 | 125 | 1500 | 5000 | 0.1475608884699102 | 0.0029098719808152225 | [125, 125] |
| 2 | 124 | 1500 | 5000 | 0.15078752376023125 | 0.004140774841759909 | [123, 124] |

SSE by gate at the fitted (1500, 5000). At every gate from 118 to 128 this pair is also the minimum over all (rpm_lo, rpm_hi) pairs.

| gate | seed 1 SSE | seed 1 minus best | seed 2 SSE | seed 2 minus best | rows that switch at this step |
|---|---|---|---|---|---|
| 120 | 0.03377763506645557 | +3.087e-2 | 0.03448625480992214 | +3.035e-2 | |
| 121 | 0.03266449116441292 | +2.975e-2 | 0.032696619885050515 | +2.856e-2 | steady 121.00 |
| 122 | 0.022091082152160175 | +1.918e-2 | 0.023255222583256994 | +1.911e-2 | steady 121.18 |
| 123 | 0.002910051689507178 | +1.797e-7 | 0.004140774841759909 | 0 | steady 122.08 (s 0.571) and 122.18 (s 0.713) |
| 124 | 0.002910051689507178 | +1.797e-7 | 0.004140774841759909 | 0 | none |
| 125 | 0.0029098719808152225 | 0 | 0.004140839308726647 | +6.447e-8 | Final 124.677 (s 0.000212) |
| 126 | 0.03631875358434916 | +3.341e-2 | 0.042764568549278986 | +3.862e-2 | steady 125.52, steady 125.58, Final 125.61 (4999.7 rpm) |
| 127 | 0.036433450524173024 | +3.352e-2 | 0.04279889645497529 | +3.866e-2 | steady 126.11, 126.81, Final 126.97 |

**Why 123 and 124 fall outside seed 1's interval.** Between gates 124 and 125 the only S3b row that switches is the 124.677 Final row.
- Seed 1's target at that row is 1.002853489290898, so b = −0.0028535.
- At gates 123 and 124 the fit enriches the row by a·d = 0.000212234 × 0.147561 = 3.1317e-05.
- Its residual moves from −0.0028535 to −0.0028848, and its contribution rises from 8.142401e-06 to 8.322110e-06.
- The other 156 rows' SSE differs by 2.9e-14 between the two gates.
- So SSE(124) − SSE(125) = +1.797086919552715e-07, which is 6.2e-5 of the best SSE.

**Seed 2.** The target is 0.998976772918312. Enriching the row lowers its contribution from 1.046994e-06 to 9.825267e-07, so SSE(124) − SSE(125) = −6.4467e-08. That gives the flat interval [123, 124], and the tie rule takes 124.

**Sweep** (`sweep.py`, DIAGNOSTIC; modified rows, not T0). I set only this row's cell-referenced lambda in seed 1's rows, at 72 values from 0.990 to 1.010:
- y ≤ 0.999984 gives flat [123, 124] and gate 124.
- y ≥ 0.999985 gives flat [125, 125] and gate 125.
- rpm_lo and rpm_hi stay at (1500, 5000) throughout.
- The break-even 1 − a·d/2 = 0.9999843412818037 lies in that bracket, +0.00324 sd above the truth's commanded 0.9999681649012311 (`summarise.log.txt`).

**What bounds the gate visibly in the data:**
- Below: the steady rows at 122.08 and 122.18 kPa. Moving the gate from 123 to 122 costs +0.0192 (seed 1) and +0.0191 (seed 2).
- Above: the rows in (125, 126]. Moving from 125 to 126 costs +0.0334 and +0.0386.
- Between 122.18 and 125.52 kPa, the only S3b row is the 124.677 Final row.

## 4. Verdict: case (a)

**Under the truth the row is barely enriched.** The lowest Final row (124.677 kPa, 1500.74 rpm) is enriched by 3.1835e-05 in lambda, because its speed is 0.74 rpm above enr_rpm_lo = 1500. That is 0.0064 of the noise sd.

**Moving the truth's gate from 123.43 to 125.0 kPa changes:**
- this row's lam_meas, by 3.1835e-05;
- its torque, meter, TIT, spark and populations, by exactly 0 (bitwise), in seeds 1 and 2;
- no other T0 row.

**What the fit sees.** It feeds lambda 1.00 at this row under both gates. S3b's objective differs between gates 123 and 125 by 1.8e-7 (seed 1) and 6.4e-8 (seed 2), out of 2.9e-3 and 4.1e-3. The side is decided by whether the row's lambda lies below or above 0.99998434, which is +0.0032 sd from the truth's value:
- seed 1 is at +0.577 sd and gets [125, 125];
- seed 2 is at −0.198 sd and gets [123, 124].

**Why this is not case (b).** Seed 1's gate-125 fit leaves the row unenriched. At gates 123/124 the fit would enrich it by 3.13e-05, the same size as the truth's 3.18e-05, and both are below the noise. So, in every channel the fit reads, gates in (122.18, 124.677) cannot be told apart from gates in [124.677, 125.52) using these data.

**Not measured:** how often the flat interval lands on each side across noise draws. I made no extra draws, so this report gives no frequency.

===== CHECK
{
 "verdict": "confirmed_with_corrections",
 "corrections": [
  "Summary line 'the sign of the noise on that one row decides which side wins' is not what was measured. The side is decided by whether the row's cell-referenced lambda lies above or below the break-even y* = 1 - a*d/2: 0.9999843412818037 for seed 1 and 0.99998400 for seed 2. That is +0.0032 sd above the truth's commanded 0.9999681649012311, not at zero noise, so a draw between 0 and +0.0032 sd would still give [123, 124]. This is established for seed 1's other rows held fixed (the sweep) plus seed 2's single outcome, not across draws. Printed by check.py (check.log.txt, section D: seed 1 y - y* = +2.869148e-03 predicts [125,125]; seed 2 y - y* = -1.007226e-03 predicts [123,124]) and by the diagnostic's summarise.py.",
  "Section 4, 'What the fit sees. It feeds lambda 1.00 at this row under both gates': the diagnostic measured 'fed 1.0 (snapped)' only for the noise-free row inside T0's generator. S3b, the stage that places the gate, does not read the fed lambda. It reads the unsnapped cell-referenced lambda (_lam_target): for seed 1 that is 1.002853489290898 at gate 123.43 and 1.0028853243896669 at gate 125, differing by 3.1835e-05. check.py measured lam_fed on the actual noisy T0 row: (1.0, 'snapped') for seeds 1 and 2, and for seed 1 at both gates, since |lam_meas - 0.99| is at most 0.0029, inside LAM_BAND 0.02. So the stages that run the model are fed 1.00 there, while S3b sees the 3.18e-05 difference (check.log.txt, section C).",
  "'Gates in (122.18, 124.677) cannot be told apart from gates in [124.677, 125.52)' has the wrong upper end and overstates exactness. The 125.52 kPa steady row runs at 1501 rpm: s = 0.000286, truth enrichment 4.2857e-05, which is 0.0086 sd, also below the noise. The first row above the gate that the truth enriches visibly is the 125.58 kPa steady row (4006 rpm, enrichment 0.1074, 21.5 sd), then the 125.61 Final row (4999.7 rpm, 0.1500, 30 sd). Below, the visible bound is 122.18 kPa (3995 rpm, s 0.713). So the sub-noise span is (122.18, 125.58) and holds two sub-noise rows. 'Cannot be told apart' means the data differ by 3.18e-05 (0.0064 sd) in one row's lambda and are bitwise identical elsewhere; they are not identical. The diagnostic enumerated all rows only for (123.43, 125.0]. My enumeration of all 164 cal_rows between 121.5 and 126.5 kPa, lambda or not, found no other row in (122.18, 125.52), so the extension to every gate in those spans holds (check.log.txt, section B).",
  "Population: 'the only calibration row with MAP in (123.4287, 125.0]' and 'the only row whose commanded lambda changes' were measured over the 164 rows of epa_fit.cal_rows (115 steady + 49 Final). The yield's 49 High Load Initial rows (yield row types printed by check.py, section B) were not examined. Neither T0 nor any fit stage reads them, so the conclusion is unaffected, but the population should be named.",
  "Undisclosed side effect: four git-ignored bytecode files in the repo's top-level __pycache__ (calibrate_epa, epa_coefficients, epa_fit and epa_stats .cpython-313.pyc) were rewritten at 18:40:18-20. That falls inside measure.py's run (written 18:39:57, outputs 18:40:26), and the diagnostic's scripts do not disable bytecode writing. A sibling diagnostic (diag/mazda_probe/run_case.py, written 18:40:09) ran in the same window, so I cannot attribute the writes. No tracked file changed, and nothing under results/, data/, logs/, thresholds/ or engine_specs/ was written after 18:30 (find over the repo excluding .venv and .git). 'The tracked tree is unchanged' is true; 'nothing changed' would not be.",
  "Two numbers in the report were printed by no script (mistake 22). '2.9e-14' (the other 156 rows' SSE change) is now printed by check.py as 2.859648282060867e-14 (seed 1; seed 2 3.38e-15). '6.2e-5 of the best SSE' is hand arithmetic, 1.797e-7 / 2.90987e-3 = 6.18e-5.",
  "'This covers the torque, meter and TIT channels of the T0 rows' is an indirect reproduction: t0.json holds no T0 row values, so those channels are reproduced only through the statistics computed from them (in-sample A, chi2, z, the four cases). My refit.py re-run confirmed those statistics bitwise against the record for both seeds. My check.py run reproduced the diagnostic's Part 2 row values bitwise, run to run, not against the record."
 ],
 "rules_kept": true,
 "rules_evidence": "All scripts and outputs are in C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/diag/honda_gate/check/. Each was run from C:/Users/badcl/Desktop/GRAD-project as `PYTHONDONTWRITEBYTECODE=1 C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe -B <script>`, with the Python 3.13.2, NumPy 2.5.3 and SciPy 1.18.1 that t0.json's provenance records.\n\n**Scripts and outputs.**\n- read_record.py -> read_record.log.txt\n- check.py -> check.log.txt, check.json, check.stdout.txt (18.8 s)\n- refit.py -> refit.log.txt, refit.json (seed 1 307 s, seed 2 136 s)\n\n**Loader calls.**\n- check.py and refit.py each call calibrate_epa._load(\"honda_l15b7\", source=epa_rows.Source.repository()) once, which runs epa_rows.calibration_contract and epa_rows.calibration_rows. That is the same _load the t0 subcommand uses; calibrate_epa's main builds its source the same way (line 2681).\n- No held-out reader was called. epa_fit calls only canonical_json, canonical_sha256 and populations from epa_rows.\n- No EPA table, no epa_engine.json and nothing under logs/ was opened.\n- Records read only for comparison: results/EPA_CALIBRATION/honda_l15b7/t0.json and run.json, and the diagnostic's measure.json.\n- No calibrate_epa subcommand and no validate_epa.py was run.\n- I grepped the diagnostic's four scripts (measure.py, reproduce_fit.py, sweep.py, summarise.py). Their only data read is calibrate_epa._load; they read t0.json for comparison and write only in their own folder. They make no RNG call; the only noise is epa_fit.t0_rows' own T0_STREAM seeds 1 and 2.\n\n**Noise.** I made no random draws. The gate-125 rows are a DIAGNOSTIC truth with T0's own noise, labelled as such.\n\n**Tree state.**\n- `git status --short` before and after shows only `?? data/engines/mazda_25t/derived_params.json` and `?? results/EPA_CALIBRATION/`, at HEAD 0147f93.\n- The Run 1 files predate the diagnostic: t0.json 18:00:46, run.json 18:00:47, derived_params.json 17:51.\n- A find over the repo (excluding .venv and .git) for files newer than 18:30 lists only the four git-ignored __pycache__/*.pyc files at 18:40:18-20, not attributable (see corrections). None is newer than 18:41, so my runs wrote no bytecode.\n\n**report.md.** I did not write report.md: this session's instructions bar a subagent from writing report .md files, so the report is returned here.\n\n**Reproductions** (all bitwise, or JSON-equal, against the record):\n- view sha256 8c6a700c...b2da58.\n- Truth gate 123.42867067468251.\n- S3b seed 1: gate 125, (1500, 5000), depth 0.1475608884699102, flat [125, 125], SSE 0.0029098719808152225.\n- S3b seed 2: gate 124, depth 0.15078752376023125, flat [123, 124].\n- d2_gate_case detail for both seeds, JSON-equal to cases.d2_gate.detail. Seed 1 widened [124.677341349365, 125.60961538461535], ok False; seed 2 ok True.\n- refit.py: in-sample A record, all four cases, chi2 16.600950587741785 (seed 1) and 6.050660941588217 (seed 2), and z, all equal to t0.json.\n- My independent S3b grid (closed-form clipped depth, math.fsum, rewritten tie rule) gives the same gate, rpm_lo, rpm_hi and flat interval. Its depth and SSE agree to within 1e-12 relative, and its gate-table SSEs match the diagnostic's measure.json to at most 2.2e-16 relative for gates 118-128. At every gate, (1500, 5000) is the profile minimum over all (rpm_lo, rpm_hi) pairs.",
 "what_it_shows": "Case (a) holds. Under the T0 truth, the Honda's lowest calibration Final row (124.677 kPa, 1500.74 rpm, 0.74 rpm above enr_rpm_lo = 1500, s = 0.000212) is enriched by 3.1835e-05 in lambda, 0.0064 of the 0.005 noise sd; moving the truth's gate to 125 kPa changes only that row's lam_meas, by that amount, and leaves torque, TIT, meter, spark and populations bitwise unchanged in seeds 1 and 2 (check.log.txt). S3b's SSE between gates 124 and 125 differs by +1.797e-07 (seed 1) and -6.447e-08 (seed 2), against 2.91e-3 and 4.14e-3; the side is set by whether the row's cell-referenced lambda exceeds the break-even 0.99998434 (+0.0032 sd above the truth): seed 1 at +0.577 sd gets [125, 125] and fails, seed 2 at -0.198 sd gets [123, 124]. The data bound the gate visibly only between the 122.18 kPa steady row (3995 rpm) and the 125.58 kPa steady row (4006 rpm, 21.5 sd); the 125.52 kPa row at 1501 rpm is also below the noise (0.0086 sd)."
}