"""Extra statistics over the S2-only diagnostic draws (rng [0x7D, k]; not T0 seeds); reads this folder only."""
import glob
import json
import os

import numpy as np
from scipy.stats import chi2, norm

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ds = []
    for p in sorted(glob.glob(os.path.join(HERE, "mcs2_diag_*.json"))):
        with open(p, encoding="utf-8") as f:
            ds.append(json.load(f))
    ds.sort(key=lambda d: d["draw"])
    P = np.array([d["blocks"]["S2"]["profile"]["truth_offset_along_weakest_in_sd"] for d in ds])
    W = np.array([d["blocks"]["S2"]["wald_contribution"] for d in ds])
    L = np.array([d["blocks"]["S2"]["lr"]["delta_ssr_over_s2"] for d in ds])
    print("DIAGNOSTIC draws (rng [0x7D, k]; not T0 seeds): n", len(ds))
    i = np.argsort(-np.abs(P))[:5]
    print("largest |offset along weakest| (draw, sd, Wald, LR):",
          [(ds[j]["draw"], round(float(P[j]), 3), round(float(W[j]), 3), round(float(L[j]), 3)) for j in i])
    j = np.argsort(-L)[:5]
    print("largest S2 LR (draw, LR, Wald, offset sd):",
          [(ds[k]["draw"], round(float(L[k]), 3), round(float(W[k]), 3), round(float(P[k]), 3)) for k in j])
    j = np.argsort(-W)[:5]
    print("largest S2 Wald (draw, Wald, LR, offset sd):",
          [(ds[k]["draw"], round(float(W[k]), 3), round(float(L[k]), 3), round(float(P[k]), 3)) for k in j])
    print("offset quantiles 0.5/2.5/50/97.5/99.5 %:", np.round(np.percentile(P, [0.5, 2.5, 50, 97.5, 99.5]), 3))
    print("normal tail P(|x| >= 4.359) with sd 1.034: %.3g; with sd 1: %.3g"
          % (2 * norm.sf(4.359 / 1.034), 2 * norm.sf(4.359)))
    print("draws with offset > +3 sd:", int((P > 3).sum()), " < -3 sd:", int((P < -3).sum()))
    SW = np.array([d["blocks"]["S2"]["eigen"]["scale"]["chi2_contribution"][0] for d in ds])
    print("weakest-direction Wald part: mean %.3f (chi2(1) mean 1), > %.2f (chi2(1) 0.99): %d, > %.2f (0.995): %d of %d"
          % (SW.mean(), chi2.ppf(0.99, 1), (SW > chi2.ppf(0.99, 1)).sum(), chi2.ppf(0.995, 1),
             (SW > chi2.ppf(0.995, 1)).sum(), len(SW)))
    PR = []
    for d in ds:
        pf = d["blocks"]["S2"]["profile"]
        t = pf["truth_offset_along_weakest_scale_units"]
        pp = [p for p in pf["profile"] if abs(p["t_scale_units"] - t) < 1e-15][0]
        PR.append((pf["truth_offset_along_weakest_in_sd"], pp["delta_ssr_over_s2"], pp["quadratic"]))
    PR = np.array(PR)
    m = np.abs(PR[:, 0]) >= 2
    pos, neg = m & (PR[:, 0] > 0), m & (PR[:, 0] < 0)
    print("profile/quadratic at the truth's projection, |offset| >= 2 sd: n %d; ratio median %.3f; truth on + side: %s;"
          " on - side: %s" % (m.sum(), np.median(PR[m, 1] / PR[m, 2]), np.round(np.sort(PR[pos, 1] / PR[pos, 2]), 3),
                              np.round(np.sort(PR[neg, 1] / PR[neg, 2]), 3)))
    print("binomial sd of the 0.95 exceedance count at n=400: %.2f; of the 0.90: %.2f"
          % (np.sqrt(400 * .05 * .95), np.sqrt(400 * .1 * .9)))
    with open(os.path.join(HERE, "case_ford_27tt_s1.json"), encoding="utf-8") as f:
        s1 = json.load(f)
    b2, b4 = s1["blocks"]["S2"], s1["blocks"]["S4"]
    s2v = b2["residual_variance"]
    print("seed 1 S2 Wald at the nominal noise variance (0.005/0.04)^2 = 0.015625 in place of s2 %r: %.3f"
          % (s2v, b2["wald_contribution"] * s2v / 0.015625))
    w2, w4 = b2["wald_contribution"], b4["wald_contribution"]
    l2, l4 = b2["lr"]["delta_ssr_over_s2"], b4["lr"]["delta_ssr_over_s2"]
    pf = b2["profile"]
    t = pf["truth_offset_along_weakest_scale_units"]
    prof = [p for p in pf["profile"] if abs(p["t_scale_units"] - t) < 1e-15][0]["delta_ssr_over_s2"]
    for label, v, k in (("seed 1 Wald total", w2 + w4, 13), ("seed 1 LR S2+S4", l2 + l4, 13), ("seed 1 S2 Wald", w2, 4),
                        ("seed 1 S2 LR", l2, 4), ("seed 1 S4 Wald", w4, 9), ("seed 1 S4 LR", l4, 9),
                        ("seed 1 S2 profile at the truth's projection on the weakest direction", prof, 1)):
        print("%s %.4f on %d: chi2 sf %.3g" % (label, v, k, chi2.sf(v, k)))
    print("chi2 0.995 quantiles: 1 %.3f, 4 %.3f, 9 %.3f, 13 %.3f"
          % (chi2.ppf(0.995, 1), chi2.ppf(0.995, 4), chi2.ppf(0.995, 9), chi2.ppf(0.995, 13)))
    print("seed 1: share of the total Wald on S2's weakest direction (scale metric) %.4f / %.4f = %.3f"
          % (b2["eigen"]["scale"]["chi2_contribution"][0], w2 + w4, b2["eigen"]["scale"]["chi2_contribution"][0] / (w2 + w4)))


if __name__ == "__main__":
    main()
