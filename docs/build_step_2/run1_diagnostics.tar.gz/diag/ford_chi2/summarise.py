"""Summaries of diagnostic B's outputs (reads only this folder's JSON). Prints the tables the report
quotes. DIAGNOSTIC draws (rng [0x7D, k]) are listed apart from the T0 seeds' re-runs."""
import glob
import math
import json
import os
import sys

import numpy as np
from scipy.stats import chi2

HERE = os.path.dirname(os.path.abspath(__file__))


def load(pattern):
    out = []
    for p in sorted(glob.glob(os.path.join(HERE, pattern))):
        with open(p, encoding="utf-8") as f:
            out.append((os.path.basename(p), json.load(f)))
    return out


def case_line(fn, d):
    b2, b4 = d["blocks"]["S2"], d["blocks"]["S4"]
    rp = d.get("reproduced") or {}
    e2s, e2c = b2["eigen"]["scale"], b2["eigen"]["corr"]
    pf = b2.get("profile", {})
    return (f"{fn}: {d['engine']} seed/draw {d.get('draw', d['seed'])} chi2 {d['chi2_of']['value']:.4f}/"
            f"{d['chi2_of']['dof']} [band {d['chi2_of']['quantile_99_lo']:.2f}-{d['chi2_of']['quantile_99_hi']:.2f}]"
            f" repro chi2 {rp.get('chi2_bit_for_bit')} z {rp.get('z_bit_for_bit')}\n"
            f"   S2 Wald {b2['wald_contribution']:.4f} LR {b2['lr']['delta_ssr_over_s2']:.4f} LR/W {b2['lr']['lr_over_wald']:.3f}"
            f" | S4 Wald {b4['wald_contribution']:.4f} LR {b4['lr']['delta_ssr_over_s2']:.4f} LR/W {b4['lr']['lr_over_wald']:.3f}\n"
            f"   S2 rows {b2['rows_used']} s2 {b2['residual_variance']:.5g} (truth ms/dof {b2['lr']['data_mean_square_at_truth_over_dof']:.5g});"
            f" S4 rows {b4['rows_used']} s2 {b4['residual_variance']:.5g} (truth ms/dof {b4['lr']['data_mean_square_at_truth_over_dof']:.5g})\n"
            f"   S2 z {', '.join(f'{k} {v:+.3f}' for k, v in b2['z'].items())}\n"
            f"   S2 corr(base,amp) {b2['correlations']['ve_base']['ve_amp']:+.4f} corr(base,width) "
            f"{b2['correlations']['ve_base']['ve_width']:+.4f} corr(amp,width) {b2['correlations']['ve_amp']['ve_width']:+.4f}"
            f" corr(base,rpm) {b2['correlations']['ve_base']['ve_rpm']:+.4f}\n"
            f"   S2 [scale] cov eig {np.array2string(np.array(e2s['cov_eigenvalues_weakest_first']), precision=4)}"
            f" cond {e2s['cov_condition_number']:.4g}; chi2 per dir {np.round(e2s['chi2_contribution'], 3)}"
            f" weakest share {e2s['share_weakest']:.3f}; weakest vec {np.round(e2s['weakest_eigenvector'], 3)}\n"
            f"   S2 [corr]  cov eig {np.array2string(np.array(e2c['cov_eigenvalues_weakest_first']), precision=4)}"
            f" cond {e2c['cov_condition_number']:.4g}; chi2 per dir {np.round(e2c['chi2_contribution'], 3)}"
            f" weakest share {e2c['share_weakest']:.3f}; weakest vec {np.round(e2c['weakest_eigenvector'], 3)}\n"
            + (f"   S2 truth offset along weakest {pf['truth_offset_along_weakest_in_sd']:+.3f} sd;"
               f" slice at truth's projection {[p['delta_ssr_over_s2'] for p in pf['slice'] if abs(p['t_scale_units'] - pf['truth_offset_along_weakest_scale_units']) < 1e-15][0]:.3f}"
               f" profile {[p['delta_ssr_over_s2'] for p in pf['profile'] if abs(p['t_scale_units'] - pf['truth_offset_along_weakest_scale_units']) < 1e-15][0]:.3f}"
               f" quadratic {pf['truth_offset_along_weakest_in_sd'] ** 2:.3f}\n" if pf else "")
            + f"   S2 conv {b2['convergence']['status']} nfev {b2['convergence']['nfev']} active {b2['bounds_active']} flags {b2['flags']} clip {len(b2.get('clip_rows', []))};"
              f" S4 conv {b4['convergence']['status']} nfev {b4['convergence']['nfev']} active {b4['bounds_active']} flags {b4['flags']}"
            + (f"\n   S4 line s: {[(p['s'], round(p['delta_ssr_over_s2'], 3), round(p['quadratic'], 3)) for p in b4['line_estimate_to_truth']]}"
               if "line_estimate_to_truth" in b4 else ""))


def s2_only():
    t0s = load("mcs2_t0_*.json")
    draws = sorted(load("mcs2_diag_*.json"), key=lambda x: x[1]["draw"])
    cases = {d["seed"]: d for fn, d in load("case_ford_27tt_s*.json")}
    print("\n== S2-only path (diaglib.fit_A_through_S2)")
    for fn, d in t0s:
        w = d["blocks"]["S2"]["wald_contribution"]
        full = cases.get(d["seed"])
        print(f"{fn}: T0 seed {d['seed']} S2 Wald {w!r}; full fit's {full['blocks']['S2']['wald_contribution']!r};"
              f" bit-for-bit {w == full['blocks']['S2']['wald_contribution']}; estimates equal "
              f"{d['blocks']['S2']['estimate'] == full['blocks']['S2']['estimate']}")
    full = {d["draw"]: d for _, d in load("mc_diag_*.json")}
    same = [(k, d["blocks"]["S2"]["estimate"] == full[k]["blocks"]["S2"]["estimate"]
             and d["blocks"]["S2"]["wald_contribution"] == full[k]["blocks"]["S2"]["wald_contribution"])
            for _, d in draws for k in [d["draw"]] if k in full]
    print(f"draws in both paths: {len(same)}; S2 estimate and Wald bit-for-bit equal on all: {all(s for _, s in same)}")
    if not draws:
        return
    W = np.array([d["blocks"]["S2"]["wald_contribution"] for _, d in draws])
    L = np.array([d["blocks"]["S2"]["lr"]["delta_ssr_over_s2"] for _, d in draws])
    Z = np.array([[d["blocks"]["S2"]["z"][n] for n in ("ve_base", "ve_amp", "ve_rpm", "ve_width")] for _, d in draws])
    P = np.array([d["blocks"]["S2"]["profile"]["truth_offset_along_weakest_in_sd"] for _, d in draws])
    SH = np.array([d["blocks"]["S2"]["eigen"]["scale"]["share_weakest"] for _, d in draws])
    S2v = np.array([d["blocks"]["S2"]["residual_variance"] for _, d in draws])
    MT = np.array([d["blocks"]["S2"]["lr"]["data_mean_square_at_truth_over_n"] for _, d in draws])
    CN = np.array([d["blocks"]["S2"]["eigen"]["scale"]["cov_condition_number"] for _, d in draws])
    secs = np.array([d["seconds"] for _, d in draws])
    q = {p: chi2.ppf(p, 4) for p in (0.5, 0.9, 0.95, 0.99, 0.995)}
    n = len(W)
    print(f"DIAGNOSTIC draws k = {draws[0][1]['draw']}..{draws[-1][1]['draw']} (rng [0x7D, k]; not T0 seeds): n {n};"
          f" seconds mean {secs.mean():.2f} total {secs.sum():.1f}")
    print(f"S2 Wald: mean {W.mean():.3f} (chi2(4) 4) median {np.median(W):.3f} (chi2(4) {q[0.5]:.3f}) max {W.max():.3f};"
          f" exceed chi2(4) 0.90/0.95/0.99/0.995 = {q[0.9]:.2f}/{q[0.95]:.2f}/{q[0.99]:.2f}/{q[0.995]:.2f}:"
          f" {[int((W > q[p]).sum()) for p in (0.9, 0.95, 0.99, 0.995)]} of {n}"
          f" (expected {[round(n * (1 - p), 1) for p in (0.9, 0.95, 0.99, 0.995)]})")
    print(f"S2 LR:   mean {L.mean():.3f} median {np.median(L):.3f} max {L.max():.3f};"
          f" exceed 0.90/0.95/0.99/0.995: {[int((L > q[p]).sum()) for p in (0.9, 0.95, 0.99, 0.995)]} of {n}")
    print(f"S2 Wald >= 24.977 (seed 1's): {int((W >= 24.977089873264273).sum())} of {n}; LR >= 15.598: {int((L >= 15.597947221696153).sum())}")
    print(f"LR/Wald: median {np.median(L / W):.3f}; quartiles {np.round(np.percentile(L / W, [5, 25, 75, 95]), 3)}")
    for lo, hi in ((0, 1), (1, 2), (2, 3), (3, 99)):
        m = (np.abs(P) >= lo) & (np.abs(P) < hi)
        if m.any():
            print(f"  |offset along weakest| in [{lo},{hi}) sd: n {int(m.sum())}, LR/Wald median {np.median(L[m] / W[m]):.3f}"
                  f" min {np.min(L[m] / W[m]):.3f} max {np.max(L[m] / W[m]):.3f}; signed offsets mean {P[m].mean():+.3f}")
    pos, neg = P > 1, P < -1
    if pos.any():
        print(f"  offset > +1 sd (seed 1's side): n {int(pos.sum())} LR/Wald median {np.median(L[pos] / W[pos]):.3f}")
    if neg.any():
        print(f"  offset < -1 sd: n {int(neg.sum())} LR/Wald median {np.median(L[neg] / W[neg]):.3f}")
    print(f"z means (bias in sd units) ve_base {Z[:, 0].mean():+.3f} ve_amp {Z[:, 1].mean():+.3f} ve_rpm {Z[:, 2].mean():+.3f}"
          f" ve_width {Z[:, 3].mean():+.3f}; z sd {np.round(Z.std(axis=0, ddof=1), 3)}; se of a mean {1 / math.sqrt(n):.3f}")
    print(f"offset of truth along weakest, sd units (truth - estimate): mean {P.mean():+.3f} sd {P.std(ddof=1):.3f};"
          f" |offset| >= 4.36 (seed 1's): {int((np.abs(P) >= 4.359).sum())}")
    print(f"share of S2 Wald along the weakest direction: median {np.median(SH):.3f}")
    print(f"S2 s2: mean {S2v.mean():.5f} sd {S2v.std(ddof=1):.5f}; data mean square at truth /n: mean {MT.mean():.5f};"
          f" (0.005/R_air)^2 = {(0.005 / draws[0][1]['residual_scales']['air']) ** 2:.6f} with R_air {draws[0][1]['residual_scales']['air']}")
    print(f"S2 cond (scale) median {np.median(CN):.4g} range {CN.min():.4g}-{CN.max():.4g}")
    print(f"chi2(4) cdf of S2 Wald, deciles of the draws: {np.round(np.percentile(chi2.cdf(W, 4), np.arange(10, 100, 10)), 3)}")
    print(f"chi2(4) cdf of S2 LR, deciles of the draws:   {np.round(np.percentile(chi2.cdf(L, 4), np.arange(10, 100, 10)), 3)}")


def main():
    print("== re-runs of recorded T0 seeds (T0_STREAM 0x70)")
    for fn, d in load("case_*.json") + load("mc_t0_*.json"):
        print(case_line(fn, d))
    s2_only()
    draws = load("mc_diag_*.json")
    if not draws:
        return
    print(f"\n== DIAGNOSTIC draws (numpy.random.default_rng([0x7D, k]); not T0 seeds): {len(draws)}")
    for fn, d in sorted(draws, key=lambda x: x[1]["draw"]):
        print(case_line(fn, d))
    W = np.array([d["chi2_of"]["value"] for _, d in draws])
    W2 = np.array([d["blocks"]["S2"]["wald_contribution"] for _, d in draws])
    W4 = np.array([d["blocks"]["S4"]["wald_contribution"] for _, d in draws])
    L2 = np.array([d["blocks"]["S2"]["lr"]["delta_ssr_over_s2"] for _, d in draws])
    L4 = np.array([d["blocks"]["S4"]["lr"]["delta_ssr_over_s2"] for _, d in draws])
    secs = np.array([sum(d["seconds"].values()) for _, d in draws])
    hi13, lo13 = chi2.ppf(0.995, 13), chi2.ppf(0.005, 13)
    print(f"\nWald total: n {len(W)} mean {W.mean():.3f} median {np.median(W):.3f} min {W.min():.3f} max {W.max():.3f};"
          f" > {hi13:.2f}: {int((W > hi13).sum())}; < {lo13:.2f}: {int((W < lo13).sum())}; chi2(13) mean 13, median {chi2.median(13):.3f}")
    print(f"Wald S2: mean {W2.mean():.3f} median {np.median(W2):.3f} max {W2.max():.3f} (chi2(4) mean 4, median {chi2.median(4):.3f},"
          f" 0.995 {chi2.ppf(0.995, 4):.3f}: {int((W2 > chi2.ppf(0.995, 4)).sum())} above)")
    print(f"Wald S4: mean {W4.mean():.3f} median {np.median(W4):.3f} max {W4.max():.3f} (chi2(9) mean 9, median {chi2.median(9):.3f},"
          f" 0.995 {chi2.ppf(0.995, 9):.3f}: {int((W4 > chi2.ppf(0.995, 9)).sum())} above)")
    L = L2 + L4
    print(f"LR total (S2+S4): mean {L.mean():.3f} median {np.median(L):.3f} max {L.max():.3f}; > {hi13:.2f}: {int((L > hi13).sum())}")
    print(f"LR S2: mean {L2.mean():.3f} median {np.median(L2):.3f} max {L2.max():.3f}; LR S4: mean {L4.mean():.3f} median {np.median(L4):.3f} max {L4.max():.3f}")
    print(f"LR/Wald S2: {np.round(L2 / W2, 3)}")
    print(f"LR/Wald S4: {np.round(L4 / W4, 3)}")
    print(f"Wald totals sorted: {np.round(np.sort(W), 3)}")
    print(f"Wald S2 sorted: {np.round(np.sort(W2), 3)}")
    print(f"LR S2 sorted: {np.round(np.sort(L2), 3)}")
    # empirical CDF against chi2 quantiles (probability integral transform)
    print(f"chi2(13) cdf of Wald totals: {np.round(np.sort(chi2.cdf(W, 13)), 3)}")
    print(f"chi2(4) cdf of S2 Wald: {np.round(np.sort(chi2.cdf(W2, 4)), 3)}; of S2 LR: {np.round(np.sort(chi2.cdf(L2, 4)), 3)}")
    print(f"chi2(9) cdf of S4 Wald: {np.round(np.sort(chi2.cdf(W4, 9)), 3)}; of S4 LR: {np.round(np.sort(chi2.cdf(L4, 9)), 3)}")
    print(f"seconds per draw: mean {secs.mean():.1f} total {secs.sum():.1f}")


if __name__ == "__main__":
    main()
