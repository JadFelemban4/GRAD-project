"""Step 5's supplement: the S2 block alone over more DIAGNOSTIC draws of the Ford's form-A truth
(numpy.random.default_rng([0x7D, k]); NOT T0 seeds). _fit's form-A path through S2 only
(diaglib.fit_A_through_S2); S2's estimate there is checked bit for bit against the full form-A fits of
mc.py on the draws both ran, and against T0 seed 1's re-run.
Usage: mc_s2.py JOBS DEADLINE_EPOCH K_FIRST K_LAST [T0SEED ...]. MEASUREMENT ONLY."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diaglib  # noqa: E402


def main(argv):
    import time
    jobs, deadline, k1, k2 = int(argv[0]), float(argv[1]), int(argv[2]), int(argv[3])
    name = "ford_27tt"
    items = [("T0", int(s)) for s in argv[4:]] + [("DIAG", k) for k in range(k1, k2 + 1)]
    for kind, k in items:
        if time.time() > deadline:
            print(f"deadline passed: {kind} {k} and later not started", flush=True)
            break
        t0 = time.perf_counter()
        if kind == "T0":
            tr, rows = diaglib.t0_rows_recorded(name, k, jobs=jobs)
            tag, stream = f"t0_{name}_s{k}", "T0_STREAM 0x70 (the recorded T0 seed's own rows)"
        else:
            tr, rows = diaglib.diag_rows(name, k, jobs=jobs)
            tag, stream = f"diag_{name}_k{k}", "DIAGNOSTIC numpy.random.default_rng([0x7D, %d]); not a T0 seed" % k
        fit, caps = diaglib.fit_A_through_S2(name, rows, jobs=jobs)
        out = diaglib.analyse(name, fit, caps, tr, record=None, stages=("S2",))
        out.update(kind=kind, draw=k, noise_stream=stream, seconds=time.perf_counter() - t0,
                   loader_calls=list(diaglib.LOADER_CALLS),
                   residual_scales=diaglib.epa_fit._scales(diaglib.VIEW[name]))
        diaglib.dump(out, os.path.join(diaglib.HERE, f"mcs2_{tag}.json"))
        b2 = out["blocks"]["S2"]
        print(f"{tag}: S2 Wald {b2['wald_contribution']!r} (chi2_of lines {out['chi2_of']['S2_only_wald_by_chi2_of_lines']!r})"
              f" LR {b2['lr']['delta_ssr_over_s2']:.4f} z {[round(v, 3) for v in b2['z'].values()]}"
              f" s2 {b2['residual_variance']:.5g} {out['seconds']:.1f}s", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
    import epa_fit
    epa_fit.close_pools()
