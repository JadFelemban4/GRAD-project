"""Prints the four reproduced T0 cases' S2/S4 details from case_*.json (this folder only)."""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
FILES = ("case_ford_27tt_s1.json", "case_ford_27tt_s2.json", "case_mazda_25t_s1.json", "case_honda_l15b7_s1.json")


def main():
    for f in FILES:
        with open(os.path.join(HERE, f), encoding="utf-8") as fh:
            d = json.load(fh)
        rp = d["reproduced"]
        print("=====", f, "chi2", repr(d["chi2_of"]["value"]), "recorded", repr(rp["chi2_recorded"]),
              "bit-for-bit", rp["chi2_bit_for_bit"], "z bit-for-bit", rp["z_bit_for_bit"])
        for st in ("S2", "S4"):
            b = d["blocks"][st]
            c = b["convergence"]
            print(" ", st, "rows", b["rows_used"], "n_data", b["n_data_residuals"], "ridge rows", b["n_ridge_rows"],
                  "s2 %.6g" % b["residual_variance"], "status", c["status"], repr(c["message"]), "nfev", c["nfev"],
                  "njev", c["njev"], "grad_norm %.3g" % c["grad_norm"], "second", c["second_attempt"],
                  "active", b["bounds_active"], "at bound", b["at_bound_within_1e-9_rel"], "flags", b["flags"])
            for n in b["params"]:
                print("    %-10s est %.6g truth %.6g sd %.4g z %+.3f bounds %s"
                      % (n, b["estimate"][n], b["truth"][n], b["sd"][n], b["z"][n], b["bounds"][n]))
            print("    data_or_prior", set(b["data_or_prior"].values()))
            if st == "S2":
                n = b["params"]
                print("    corr:")
                for a in n:
                    print("      %-9s" % a, " ".join("%+.4f" % b["correlations"][a][bb] for bb in n))
                for m in ("scale", "corr"):
                    e = b["eigen"][m]
                    print("    [%s] cov eig" % m, ["%.4g" % x for x in e["cov_eigenvalues_weakest_first"]],
                          "cond %.4g" % e["cov_condition_number"], "weakest", np.round(e["weakest_eigenvector"], 4),
                          "stiffest", np.round(e["stiffest_eigenvector"], 4), "chi2 per dir",
                          np.round(e["chi2_contribution"], 3), "weakest share %.3f" % e["share_weakest"])
                pf = b["profile"]
                print("    profile: weakest(scale) v", np.round(pf["weakest_direction_scale_units"], 4),
                      "info eig %.4g" % pf["info_eigenvalue_scale_units"], "sd %.4g" % pf["weakest_sd_scale_units"],
                      "offset %.4f = %.3f sd perp %.4f" % (pf["truth_offset_along_weakest_scale_units"],
                                                           pf["truth_offset_along_weakest_in_sd"],
                                                           pf["truth_offset_perpendicular_norm_scale_units"]))
                t = pf["truth_offset_along_weakest_scale_units"]
                pt = [p for p in pf["slice"] if abs(p["t_scale_units"] - t) < 1e-15][0]
                pp = [p for p in pf["profile"] if abs(p["t_scale_units"] - t) < 1e-15][0]
                print("    at truth projection: slice %.4f profile %.4f quad %.4f"
                      % (pt["delta_ssr_over_s2"], pp["delta_ssr_over_s2"], pt["quadratic"]))
                print("    ends (t = -/+1.5 x offset): slice %.3f / %.3f, profile %.3f / %.3f, quadratic %.3f"
                      % (pf["slice"][0]["delta_ssr_over_s2"], pf["slice"][-1]["delta_ssr_over_s2"],
                         pf["profile"][0]["delta_ssr_over_s2"], pf["profile"][-1]["delta_ssr_over_s2"],
                         pf["slice"][0]["quadratic"]))
                print("    line estimate->truth s: " + ", ".join(
                    "%.1f: %.3f (q %.3f)" % (p["s"], p["delta_ssr_over_s2"], p["quadratic"])
                    for p in pf["line_estimate_to_truth"] if round(p["s"], 6) in (-0.5, 0.5, 1.0, 1.5)))
                print("    clip rows", len(b["clip_rows"]))
            lr = b["lr"]
            print("    Wald %.4f LR %.4f (data %.4f ridge %.4f) LR/W %.4f; truth data ms/dof %.6g"
                  % (b["wald_contribution"], lr["delta_ssr_over_s2"], lr["delta_data_ssr_over_s2"],
                     lr["delta_ridge_ssr_over_s2"], lr["lr_over_wald"], lr["data_mean_square_at_truth_over_dof"]))
        print("  seconds", {k: round(v, 1) for k, v in d["seconds"].items()})
        print("  loader calls", d["loader_calls"])


if __name__ == "__main__":
    main()
