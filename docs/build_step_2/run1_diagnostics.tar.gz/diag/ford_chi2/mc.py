"""Step 5 of diagnostic B: a DIAGNOSTIC Monte Carlo of the Ford's form-A truth (T0 seed 1's truth).
Draw k uses numpy.random.default_rng([0x7D, k]) (diaglib.diag_rows); these are NOT T0 seeds and replace
nothing. Each draw is fitted at form A exactly as T0 fits a seed (epa_fit.fit_form, form A, start None),
the Wald chi-square by epa_fit._chi2_of, the LR of step 3 per block.

Usage: mc.py JOBS DEADLINE_EPOCH item [item ...], item = T0:engine:seed or DIAG:engine:k.
No new item starts after DEADLINE_EPOCH. MEASUREMENT ONLY."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diaglib  # noqa: E402


def main(argv):
    import time
    jobs, deadline = int(argv[0]), float(argv[1])
    diaglib.S4_LINE = (-0.5, 0.25, 0.5, 0.75, 1.0, 1.25)
    for item in argv[2:]:
        if time.time() > deadline:
            print(f"deadline passed: {item} and later not started")
            break
        kind, name, k = item.split(":")
        k = int(k)
        t0 = time.perf_counter()
        if kind == "T0":
            tr, rows = diaglib.t0_rows_recorded(name, k, jobs=jobs)
            rec = diaglib.recorded(name, k)
            stream = "T0_STREAM 0x70 (the recorded T0 seed's own rows)"
            tag = f"t0_{name}_s{k}"
        else:
            tr, rows = diaglib.diag_rows(name, k, jobs=jobs)
            rec = None
            stream = "DIAGNOSTIC numpy.random.default_rng([0x7D, %d]); not a T0 seed" % k
            tag = f"diag_{name}_k{k}"
        t1 = time.perf_counter()
        fit, caps = diaglib.fit_A(name, rows, jobs=jobs)
        t2 = time.perf_counter()
        out = diaglib.analyse(name, fit, caps, tr, record=rec)
        t3 = time.perf_counter()
        out.update(kind=kind, draw=k, noise_stream=stream,
                   seconds={"rows": t1 - t0, "fit_A": t2 - t1, "analysis": t3 - t2},
                   loader_calls=list(diaglib.LOADER_CALLS),
                   residual_scales=diaglib.epa_fit._scales(diaglib.VIEW[name]),
                   t0_noise=dict(diaglib.epa_fit.T0_NOISE))
        path = os.path.join(diaglib.HERE, f"mc_{tag}.json")
        diaglib.dump(out, path)
        b2, b4 = out["blocks"]["S2"], out["blocks"]["S4"]
        rp = out.get("reproduced")
        print(f"{tag}: [{stream}] wald {out['chi2_of']['value']:.4f} (S2 {b2['wald_contribution']:.4f} S4 "
              f"{b4['wald_contribution']:.4f}) LR S2 {b2['lr']['delta_ssr_over_s2']:.4f} S4 "
              f"{b4['lr']['delta_ssr_over_s2']:.4f}; s2 S2 {b2['residual_variance']:.5g} S4 {b4['residual_variance']:.5g};"
              f" S2 weakest share {b2['eigen']['scale']['share_weakest']:.3f}; flags {list(fit.flags)};"
              f" {t3 - t0:.1f}s" + (f"; reproduced chi2 {rp['chi2_bit_for_bit']} z {rp['z_bit_for_bit']}" if rp else ""),
              flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
    import epa_fit
    epa_fit.close_pools()
