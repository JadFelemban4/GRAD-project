"""Diagnostic B library: re-runs of T0 form-A fits outside the audit, with S2's and S4's
objectives captured, for the Wald / likelihood-ratio comparison. MEASUREMENT ONLY.

EPA data are read only through calibrate_epa._load (epa_rows.calibration_contract and
epa_rows.calibration_rows). Nothing here writes outside this scratch folder.

Extra noise draws use numpy.random.default_rng([0x7D, k]) by setting epa_fit.T0_STREAM
to 0x7D IN THIS PROCESS'S MEMORY ONLY for the duration of one t0_rows call (diag_rows);
these are DIAGNOSTIC draws, never T0 seeds.
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS"):
    os.environ[_v] = "1"

REPO = r"C:\Users\badcl\Desktop\GRAD-project"
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json      # noqa: E402
import math      # noqa: E402
import time      # noqa: E402
from dataclasses import asdict, is_dataclass  # noqa: E402

import numpy as np                       # noqa: E402
from scipy.optimize import least_squares  # noqa: E402

import calibrate_epa  # noqa: E402
import epa_fit        # noqa: E402
import epa_rows       # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DTHETA = calibrate_epa.DTHETA
DIAG_STREAM = 0x7D
S4_LINE = ()               # the S4 line points (fractions of estimate -> truth); set by a caller
LOADER_CALLS = []          # every loader call this process makes, for the report


def load(name):
    """The calibration loader calibrate_epa._load uses, and nothing else."""
    source = epa_rows.Source.repository()
    LOADER_CALLS.append(f"calibrate_epa._load({name!r}, source=epa_rows.Source.repository())"
                        " -> epa_rows.calibration_contract + epa_rows.calibration_rows")
    view, yield_ = calibrate_epa._load(name, source=source)
    return view, yield_


# ---------------------------------------------------------------------------
# capture of S2's and S4's least-squares objectives (epa_fit._solve wrapped; result unchanged)
# ---------------------------------------------------------------------------
_CAPTURE = []
_ORIG_SOLVE = epa_fit._solve


def _rec_solve(fun, jac, x0, *, lb, ub, x_scale, tol):
    out = _ORIG_SOLVE(fun, jac, x0, lb=lb, ub=ub, x_scale=x_scale, tol=tol)
    _CAPTURE.append({"fun": fun, "jac": jac, "x0": np.array(x0, dtype=float), "lb": np.array(lb, dtype=float),
                     "ub": np.array(ub, dtype=float), "x_scale": np.array(x_scale, dtype=float), "tol": tol,
                     "out": out})
    return out


def fit_A(name, rows, *, jobs):
    """epa_fit.fit_form at form A from the B58's start (start=None), as the ladder's first rung does
    (t0_ladders -> ladder -> _ladder -> fit_form(form='A', start=None)), with the objectives captured."""
    del _CAPTURE[:]
    epa_fit._solve = _rec_solve
    try:
        fit = epa_fit.fit_form(name, rows, view=VIEW[name], form="A", start=None, jobs=jobs, dtheta=DTHETA)
    finally:
        epa_fit._solve = _ORIG_SOLVE
    caps = list(_CAPTURE)
    del _CAPTURE[:]
    s2 = [c for c in caps if c["tol"] is epa_fit.TOLERANCES["S2"]]
    s4 = [c for c in caps if c["tol"] is not epa_fit.TOLERANCES["S2"]]
    assert len(s2) == 1, len(s2)
    assert len(s4) >= 6, len(s4)
    m = s4[0]["fun"].__self__
    assert all(c["fun"].__self__ is m for c in s4)
    return fit, {"S2": s2[0], "S4": s4, "S4_model": m}


VIEW = {}
YIELD = {}


def engine(name):
    if name not in VIEW:
        VIEW[name], YIELD[name] = load(name)
    return VIEW[name], YIELD[name]


def t0_rows_recorded(name, seed, *, jobs):
    """T0's rows for seed `seed` exactly as t0_ladders makes them (T0_STREAM 0x70)."""
    view, yield_ = engine(name)
    assert epa_fit.T0_STREAM == 0x70
    truths = epa_fit.t0_truths(name, view=view, yield_=yield_)
    tr = truths[seed - 1]
    assert tr.seed == seed
    rows = epa_fit.t0_rows(yield_, truth=tr, seed=tr.seed, view=view, dtheta=DTHETA, jobs=jobs)
    return tr, rows


def diag_rows(name, k, *, jobs):
    """DIAGNOSTIC draw k of the form-A truth (seed 1's truth): t0_rows with epa_fit.T0_STREAM set to
    0x7D in memory for this call only, so its rng is numpy.random.default_rng([0x7D, k]). Not a T0 seed."""
    view, yield_ = engine(name)
    truths = epa_fit.t0_truths(name, view=view, yield_=yield_)
    tr = truths[0]
    assert tr.expected_form == "A" and tr.out_of_form is None
    old = epa_fit.T0_STREAM
    assert old == 0x70
    epa_fit.T0_STREAM = DIAG_STREAM
    try:
        rows = epa_fit.t0_rows(yield_, truth=tr, seed=int(k), view=view, dtheta=DTHETA, jobs=jobs)
    finally:
        epa_fit.T0_STREAM = old
    assert epa_fit.T0_STREAM == 0x70
    return tr, rows


# ---------------------------------------------------------------------------
# analysis
# ---------------------------------------------------------------------------
def _ssr(fun, th):
    r = np.asarray(fun(np.asarray(th, dtype=float)), dtype=float)
    return float(np.dot(r, r)), r


def _eig_contrib(C, d, S):
    """Eigen-decomposition of the covariance block in two metrics and the Wald chi-square split
    along each eigenvector. Metric 'scale': parameters divided by X_SCALE (the fit's x_scale);
    metric 'corr': parameters divided by their standard deviation (the correlation matrix).
    Directions are sorted weakest first (largest covariance eigenvalue = smallest information)."""
    out = {}
    sd = np.sqrt(np.diag(C))
    for metric, unit in (("scale", S), ("corr", sd)):
        Cm = C / np.outer(unit, unit)
        dm = d / unit
        w, V = np.linalg.eigh(Cm)
        order = np.argsort(w)[::-1]
        w, V = w[order], V[:, order]
        proj = V.T @ dm
        contrib = proj ** 2 / w
        out[metric] = {"cov_eigenvalues_weakest_first": w.tolist(),
                       "cov_condition_number": float(w[0] / w[-1]),
                       "info_eigenvalues_weakest_first": (1.0 / w).tolist(),
                       "eigenvectors_columns_weakest_first": V.tolist(),
                       "weakest_eigenvector": V[:, 0].tolist(),
                       "stiffest_eigenvector": V[:, -1].tolist(),
                       "offset_projection": proj.tolist(),
                       "chi2_contribution": contrib.tolist(),
                       "chi2_sum": float(contrib.sum()),
                       "share_weakest": float(contrib[0] / contrib.sum())}
    return out


def _conv(c):
    return None if c is None else (asdict(c) if is_dataclass(c) else c)


class _FitS2:
    """What _chi2_of and analyse read of a fit, for the S2-only path: stages and values."""
    def __init__(self, form, stages, values):
        self.form, self.stages, self.values = form, stages, values


def fit_A_through_S2(name, rows, *, jobs):
    """_fit's form-A path up to and including S2 (S1, S3a, S3b, S3c, then S2 on the candidate of their
    values from the B58's start), the same calls in the same order with the same arguments; S4, S6 and
    verify are not run. S2 depends on nothing after it, so its estimate is the full fit's (checked bit for
    bit against full fits by the caller)."""
    view = VIEW[name]
    form = "A"
    rows = epa_fit.cal_rows(rows)
    base = epa_fit._base_plant(name, form)
    cens = epa_fit.epa_stats.censoring([r for r in rows if epa_fit._final(r)])
    conv = epa_fit.epa_stats.NOMINAL
    st = {"S1": epa_fit.s1_backpressure(rows, view=view),
          "S3a": epa_fit.s3a_spark(rows, plant=base, view=view),
          "S3b": epa_fit.s3b_lambda(rows, plant=base, view=view, censoring=cens, lam_floor=float(view.lam_floor),
                                    conventions=conv),
          "S3c": epa_fit.s3c_envelope(rows, plant=base, view=view, conventions=conv)}
    cyc0 = epa_fit._start_cycle(None)
    values = epa_fit._assemble(form, cyc0, st)
    del _CAPTURE[:]
    epa_fit._solve = _rec_solve
    try:
        st["S2"] = epa_fit.s2_breathing(rows, plant=epa_fit.candidate(name, values), view=view, form=form,
                                        conventions=conv, dtheta=DTHETA, jobs=jobs)
    finally:
        epa_fit._solve = _ORIG_SOLVE
    caps = list(_CAPTURE)
    del _CAPTURE[:]
    assert len(caps) == 1 and caps[0]["tol"] is epa_fit.TOLERANCES["S2"]
    values = epa_fit._assemble(form, cyc0, st)
    return _FitS2(form, st, values), {"S2": caps[0]}


def s2_wald_like_chi2_of(fit, truth):
    """_chi2_of's S2 block alone, its own lines (the same pick, the same solve)."""
    rep = fit.stages["S2"].report
    names = list(rep["params"])
    pick = [i for i, n in enumerate(names) if rep["data_or_prior"][n] == "data-dominated"
            and n in truth.values["cycle"]]
    C = np.array(rep["covariance"], dtype=float)[np.ix_(pick, pick)]
    d = np.array([fit.values["cycle"][names[i]] - truth.values["cycle"][names[i]] for i in pick])
    return float(d @ np.linalg.solve(C, d))


def analyse(name, fit, caps, tr, *, profile=True, lr_s4=True, record=None, stages=("S2", "S4")):
    """Steps 1-3 on one fitted seed. Returns a JSON-able dict."""
    if stages == ("S2", "S4"):
        c2, z = epa_fit._chi2_of(fit, tr)
    else:
        c2, z = {"S2_only_wald_by_chi2_of_lines": s2_wald_like_chi2_of(fit, tr)}, None
    out = {"engine": name, "seed": tr.seed, "truth_label": tr.label, "form": fit.form,
           "chi2_of": c2, "z": z, "blocks": {}}
    if record is not None:
        out["recorded"] = record
        out["reproduced"] = {
            "chi2_bit_for_bit": float(c2["value"]) == float(record["chi2"]["value"]),
            "z_bit_for_bit": all(float(z[k]) == float(record["z"][k]) for k in record["z"]) and set(z) == set(record["z"]),
            "chi2_recorded": record["chi2"]["value"], "chi2_rerun": c2["value"],
            "max_abs_z_diff": max(abs(float(z[k]) - float(record["z"][k])) for k in record["z"])}
    total_parts = []
    for stage in stages:
        st = fit.stages[stage]
        rep = st.report
        names = list(rep["params"])
        est = np.array([fit.values["cycle"][n] for n in names])
        tru = np.array([tr.values["cycle"][n] for n in names])
        d = est - tru
        C = np.array(rep["covariance"], dtype=float)
        pick = [i for i, n in enumerate(names) if rep["data_or_prior"][n] == "data-dominated"
                and n in tr.values["cycle"]]
        assert pick == list(range(len(names))), (stage, pick)
        s2 = float(rep["residual_variance"])
        wald = float(d @ np.linalg.solve(C, d))
        total_parts.append(wald)
        S = np.array([epa_fit.X_SCALE[n] for n in names])
        if stage == "S2":
            cap = caps["S2"]
            fun, jac = cap["fun"], cap["jac"]
            x_kept = np.asarray(cap["out"][0], dtype=float)
            lb, ub = cap["lb"], cap["ub"]
            bounds = {n: list(rep["bounds"][n]) for n in names}
        else:
            m = caps["S4_model"]
            fun, jac = m.fun, m.jac
            x_kept = np.array([st.values[n] for n in names])
            lb = np.array([epa_fit.BOUNDS[n][0] for n in names])
            ub = np.array([epa_fit.BOUNDS[n][1] for n in names])
            bounds = {n: list(epa_fit.BOUNDS[n]) for n in names}
        assert np.array_equal(x_kept, est), (stage, x_kept, est)
        ssr_hat, r_hat = _ssr(fun, est)
        J = np.asarray(jac(est), dtype=float)
        n_data = len(r_hat) - (len(names) if stage == "S4" else sum(1 for n in names if n in epa_fit.SCALES))
        r_data = r_hat[:n_data]
        s2_chk = float(np.dot(r_data, r_data)) / max(n_data - len(names), 1)
        C_chk = s2_chk * np.linalg.inv(J.T @ J)
        wald_lin = float(d @ (J.T @ J) @ d) / s2
        blk = {"params": names, "estimate": dict(zip(names, est.tolist())), "truth": dict(zip(names, tru.tolist())),
               "estimate_minus_truth": dict(zip(names, d.tolist())),
               "z": {n: float(d[i] / math.sqrt(C[i, i])) for i, n in enumerate(names)},
               "sd": {n: float(math.sqrt(C[i, i])) for i, n in enumerate(names)},
               "bounds": bounds, "bounds_active": list(st.bounds_active), "flags": list(st.flags),
               "at_bound_within_1e-9_rel": [n for i, n in enumerate(names)
                                             if abs(est[i] - lb[i]) <= 1e-9 * max(1.0, abs(lb[i]))
                                             or abs(est[i] - ub[i]) <= 1e-9 * max(1.0, abs(ub[i]))],
               "convergence": _conv(st.convergence), "rows_used": st.rows_used,
               "n_data_residuals": int(n_data), "n_ridge_rows": int(len(r_hat) - n_data),
               "residual_variance": s2, "residual_variance_recomputed": s2_chk,
               "covariance_recomputed_max_rel_diff": float(np.max(np.abs(C_chk - C) / np.abs(C))),
               "data_or_prior": rep["data_or_prior"],
               "correlations": rep["correlations"],
               "wald_contribution": wald, "wald_via_JtJ_over_s2": wald_lin,
               "eigen": _eig_contrib(C, d, S),
               "objective_cost_at_estimate_half_ssr": 0.5 * ssr_hat,
               "objective_cost_reported_by_solver": (float(st.convergence.cost) if st.convergence else None),
               "ridge_ssr_at_estimate": float(np.dot(r_hat[n_data:], r_hat[n_data:]))}
        if stage == "S2":
            blk["clip_rows"] = rep["clip_rows"]
            blk["start"] = rep["start"]
            blk["profile_min_cost"] = rep["profile_min_cost"]
        else:
            blk["starts"] = rep["starts"]
            blk["best_start"] = rep["best_start"]
            blk["polish"] = rep["polish"]
            blk["resolution"] = rep["resolution"]
            blk["s4_weakest_direction_report"] = rep["weakest_direction"]
            blk["s4_condition_number_report"] = rep["condition_number"]
        # step 3: likelihood ratio, the stage's own objective (data + ridge rows)
        if stage == "S2" or lr_s4:
            ssr_tru, r_tru = _ssr(fun, tru)
            blk["lr"] = {"ssr_at_truth": ssr_tru, "ssr_at_estimate": ssr_hat,
                         "delta_ssr_over_s2": (ssr_tru - ssr_hat) / s2,
                         "delta_data_ssr_over_s2": (float(np.dot(r_tru[:n_data], r_tru[:n_data]))
                                                    - float(np.dot(r_data, r_data))) / s2,
                         "delta_ridge_ssr_over_s2": (float(np.dot(r_tru[n_data:], r_tru[n_data:]))
                                                     - float(np.dot(r_hat[n_data:], r_hat[n_data:]))) / s2,
                         "data_mean_square_at_truth_over_dof": float(np.dot(r_tru[:n_data], r_tru[:n_data]))
                         / max(n_data - len(names), 1),
                         "data_mean_square_at_truth_over_n": float(np.dot(r_tru[:n_data], r_tru[:n_data])) / n_data,
                         "wald_contribution": wald,
                         "lr_minus_wald": (ssr_tru - ssr_hat) / s2 - wald,
                         "lr_over_wald": ((ssr_tru - ssr_hat) / s2) / wald}
        if stage == "S2" and profile:
            blk["profile"] = _profile_s2(fun, jac, est, tru, S, s2, lb, ub, J)
        if stage == "S4" and S4_LINE:
            H = J.T @ J
            wl = float(d @ H @ d) / s2
            pts = []
            dd = tru - est
            for s in S4_LINE:
                pts.append({"s": float(s), "delta_ssr_over_s2": (_ssr(fun, est + s * dd)[0] - ssr_hat) / s2,
                            "quadratic": float(s * s * wl)})
            blk["line_estimate_to_truth"] = pts
        out["blocks"][stage] = blk
    out["chi2_sum_of_blocks"] = float(total_parts[0] + total_parts[1]) if len(total_parts) == 2 else None
    return out


def _profile_s2(fun, jac, est, tru, S, s2, lb, ub, J):
    """S2's objective along (a) the straight line estimate -> truth, (b) the weakest eigen-direction of
    the information in X_SCALE units (a slice, other directions held) and (c) the profile along that
    direction (the other three directions re-minimised at each point). Each as delta SSR / s2 beside the
    quadratic the linearisation predicts."""
    ssr_hat, _ = _ssr(fun, est)
    d = tru - est
    H = J.T @ J
    wald_line = float(d @ H @ d) / s2
    line = []
    for s in np.linspace(-0.5, 1.5, 21):
        th = est + s * d
        line.append({"s": float(s), "delta_ssr_over_s2": (_ssr(fun, th)[0] - ssr_hat) / s2,
                     "quadratic": float(s * s * wald_line)})
    Hs = H * np.outer(S, S)
    w, V = np.linalg.eigh(Hs)
    v = V[:, 0]
    v = v if v[np.argmax(np.abs(v))] > 0 else -v
    p_truth = float(v @ (d / S))                 # truth's offset along v, scale units
    resid_perp = (d / S) - p_truth * v
    lam = float(w[0])
    span = max(abs(p_truth) * 1.5, 1e-6)
    ts = np.unique(np.concatenate([np.linspace(-span, span, 21), [p_truth]]))
    B = V[:, 1:]                                   # orthonormal complement of v (eigh's other vectors)
    sl, pr = [], []
    a0 = np.zeros(B.shape[1])
    for t in ts:
        th = est + S * (t * v)
        sl.append({"t_scale_units": float(t), "delta_ssr_over_s2": (_ssr(fun, th)[0] - ssr_hat) / s2,
                   "quadratic": float(t * t * lam / s2),
                   "within_bounds": bool(np.all(th >= lb) and np.all(th <= ub))})

        def f_a(a, t=t):
            return np.asarray(fun(est + S * (t * v + B @ a)), dtype=float)

        def j_a(a, t=t):
            return np.asarray(jac(est + S * (t * v + B @ a)), dtype=float) @ (np.diag(S) @ B)

        res = least_squares(f_a, a0, jac=j_a, method="lm", xtol=1e-14, ftol=1e-14, gtol=1e-14, max_nfev=2000)
        th = est + S * (t * v + B @ res.x)
        pr.append({"t_scale_units": float(t), "delta_ssr_over_s2": (2.0 * res.cost - ssr_hat) / s2,
                   "quadratic": float(t * t * lam / s2), "status": int(res.status),
                   "theta": th.tolist(), "within_bounds": bool(np.all(th >= lb) and np.all(th <= ub))})
    return {"line_estimate_to_truth": line, "wald_along_line": wald_line,
            "weakest_direction_scale_units": v.tolist(), "info_eigenvalue_scale_units": lam,
            "weakest_sd_scale_units": float(math.sqrt(s2 / lam)),
            "info_eigenvalues_scale_units": w.tolist(),
            "truth_offset_along_weakest_scale_units": p_truth,
            "truth_offset_along_weakest_in_sd": p_truth / math.sqrt(s2 / lam),
            "truth_offset_perpendicular_norm_scale_units": float(np.linalg.norm(resid_perp)),
            "slice": sl, "profile": pr}


def jsonable(o):
    if isinstance(o, dict):
        return {str(k): jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, np.ndarray):
        return jsonable(o.tolist())
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if is_dataclass(o):
        return jsonable(asdict(o))
    return o


def dump(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(jsonable(obj), f, indent=1)


def recorded(name, seed):
    p = os.path.join(REPO, "results", "EPA_CALIBRATION", name, "t0.json")
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    for s in d["seeds"]:
        if s["seed"] == seed:
            return {"chi2": s["chi2"], "z": s["z"], "judged_at": s["judged_at"]}
    raise KeyError(seed)
