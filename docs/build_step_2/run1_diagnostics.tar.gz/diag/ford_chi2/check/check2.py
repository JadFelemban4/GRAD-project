"""CHECK of diagnostic B (ford_chi2), part 2: re-runs. MEASUREMENT ONLY.

EPA data are read ONLY through calibrate_epa._load (epa_rows.calibration_contract + epa_rows.calibration_rows), via
the byte-identical copy of the diagnostic's diaglib.py in this folder (diaglib.load) and nowhere else. No held-out
reader, no EPA table or epa_engine.json opened, nothing under logs/. Outputs go to this folder only.

 A. the current diaglib re-runs Mazda seed 1 and Honda seed 1 (T0_STREAM 0x70, the recorded rows) at form A, compared
    field by field with the diagnostic's case_*.json, which an EARLIER diaglib (before its 18:50:09 edit) wrote;
 B. the S2-only path for T0 Ford seed 1 and for DIAGNOSTIC draws k = 103 and 154 (numpy.random.default_rng([0x7D, k]);
    not T0 seeds), compared bit for bit with the diagnostic's mcs2_*.json;
 C. an INDEPENDENT reconstruction of S2's objective for Ford seed 1 from s2_breathing's formula (no captured closure):
    the SSR at the estimate against the solver's cost, the SSR at the truth's S2 parameters, the LR; a finite-difference
    J'J of the reconstructed residuals, its weakest direction in X_SCALE units and the truth's offset along it; the
    slice and an independently computed profile at the truth's projection.
Usage: check2.py JOBS [A] [B] [C]"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import diaglib  # noqa: E402  (the copy in this folder; sets the BLAS variables, inserts the repo on sys.path)

import json  # noqa: E402
import math  # noqa: E402
import time  # noqa: E402
from dataclasses import replace  # noqa: E402

import numpy as np  # noqa: E402
from scipy.optimize import least_squares, minimize  # noqa: E402

epa_fit = diaglib.epa_fit
assert diaglib.HERE == HERE


def jl(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def diff(a, b, path=""):
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                out.append(f"{path}/{k}: only in {'rerun' if k in a else 'diag'}")
            else:
                out += diff(a[k], b[k], f"{path}/{k}")
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: len {len(a)} vs {len(b)}")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                out += diff(x, y, f"{path}[{i}]")
    elif a != b:
        out.append(f"{path}: {a!r} vs {b!r}")
    return out


def norm_json(o):
    return json.loads(json.dumps(diaglib.jsonable(o)))


SKIP = {"seconds", "loader_calls", "kind", "draw", "noise_stream", "residual_scales", "t0_noise"}


def part_a(jobs):
    print("== A. full form-A re-runs with the current diaglib (T0_STREAM 0x70)", flush=True)
    for name in ("mazda_25t", "honda_l15b7"):
        t0 = time.perf_counter()
        tr, rows = diaglib.t0_rows_recorded(name, 1, jobs=jobs)
        fit, caps = diaglib.fit_A(name, rows, jobs=jobs)
        out = norm_json(diaglib.analyse(name, fit, caps, tr, record=diaglib.recorded(name, 1)))
        dt = time.perf_counter() - t0
        diaglib.dump(dict(out, seconds=dt, loader_calls=list(diaglib.LOADER_CALLS)),
                     os.path.join(HERE, f"rerun_case_{name}_s1.json"))
        old = jl(os.path.join(os.path.dirname(HERE), f"case_{name}_s1.json"))
        dd = diff({k: v for k, v in out.items() if k not in SKIP}, {k: v for k, v in old.items() if k not in SKIP})
        print(f"{name} seed 1: {dt:.1f}s; chi2 {out['chi2_of']['value']!r} (record {out['recorded']['chi2']['value']!r});"
              f" fields differing from the diagnostic's case file: {len(dd)}", flush=True)
        for x in dd[:15]:
            print("   ", x)


def part_b(jobs):
    print("== B. S2-only path: T0 Ford seed 1; DIAGNOSTIC draws k = 103, 154 (rng [0x7D, k]; not T0 seeds)", flush=True)
    name = "ford_27tt"
    for kind, k in (("T0", 1), ("DIAG", 103), ("DIAG", 154)):
        t0 = time.perf_counter()
        if kind == "T0":
            tr, rows = diaglib.t0_rows_recorded(name, k, jobs=jobs)
            ref = os.path.join(os.path.dirname(HERE), f"mcs2_t0_{name}_s{k}.json")
        else:
            tr, rows = diaglib.diag_rows(name, k, jobs=jobs)
            ref = os.path.join(os.path.dirname(HERE), f"mcs2_diag_{name}_k{k}.json")
        assert epa_fit.T0_STREAM == 0x70
        fit, caps = diaglib.fit_A_through_S2(name, rows, jobs=jobs)
        out = norm_json(diaglib.analyse(name, fit, caps, tr, record=None, stages=("S2",)))
        old = jl(ref)
        dd = diff({k2: v for k2, v in out.items() if k2 not in SKIP}, {k2: v for k2, v in old.items() if k2 not in SKIP})
        b = out["blocks"]["S2"]
        print(f"{kind} {k}: {time.perf_counter() - t0:.1f}s; S2 Wald {b['wald_contribution']!r} LR"
              f" {b['lr']['delta_ssr_over_s2']!r} offset {b['profile']['truth_offset_along_weakest_in_sd']!r} sd;"
              f" fields differing from {os.path.basename(ref)}: {len(dd)}", flush=True)
        for x in dd[:10]:
            print("   ", x)


def part_c(jobs):
    print("== C. independent reconstruction of S2's objective, Ford T0 seed 1 (T0_STREAM 0x70)", flush=True)
    name = "ford_27tt"
    view, yield_ = diaglib.engine(name)
    truths = epa_fit.t0_truths(name, view=view, yield_=yield_)
    tr = truths[0]
    rows = epa_fit.t0_rows(yield_, truth=tr, seed=1, view=view, dtheta=diaglib.DTHETA, jobs=jobs)
    # _fit's form-A path up to S2, called here directly (no capture)
    rc = epa_fit.cal_rows(rows)
    base = epa_fit._base_plant(name, "A")
    cens = epa_fit.epa_stats.censoring([r for r in rc if epa_fit._final(r)])
    conv = epa_fit.epa_stats.NOMINAL
    st = {"S1": epa_fit.s1_backpressure(rc, view=view),
          "S3a": epa_fit.s3a_spark(rc, plant=base, view=view),
          "S3b": epa_fit.s3b_lambda(rc, plant=base, view=view, censoring=cens, lam_floor=float(view.lam_floor),
                                    conventions=conv),
          "S3c": epa_fit.s3c_envelope(rc, plant=base, view=view, conventions=conv)}
    cyc0 = epa_fit._start_cycle(None)
    values = epa_fit._assemble("A", cyc0, st)
    plant = epa_fit.candidate(name, values)
    s2 = epa_fit.s2_breathing(rc, plant=plant, view=view, form="A", conventions=conv, dtheta=diaglib.DTHETA, jobs=jobs)
    rep = s2.report
    names = list(rep["params"])
    est = np.array([s2.values[n] for n in names])
    tru = np.array([tr.values["cycle"][n] for n in names])
    # the reconstruction, from s2_breathing's docstring and lines: (ln eta_model - ln eta_target)/R_air + ridge rows
    e = plant.engine
    use = epa_fit._s2_use(rc)
    rpm = np.array([r.speed_rpm for r in use], dtype=float)
    mp = np.array([r.map_kpa for r in use], dtype=float)
    iat = np.array([r.imt_k for r in use], dtype=float)
    air = np.array([epa_fit.epa_stats.air_cal(r, view=view, conventions=conv) for r in use], dtype=float)
    eta_t = air / epa_fit._air_at_unit_ve(e, rpm, mp, iat)
    sig = epa_fit._scales(view)["air"]
    centre = epa_fit.ridge_centre()
    ridge = [n for n in names if n in epa_fit.SCALES]

    def res(th):
        ee = replace(e, cycle=replace(e.cycle, **dict(zip(names, (float(v) for v in th)))))
        r = (np.log(epa_fit.plant_ve(rpm, mp, None, ee)) - np.log(eta_t)) / sig
        rr = [math.sqrt(epa_fit.RIDGE_W) * (th[names.index(n)] - centre[n]) / epa_fit.SCALES[n] for n in ridge]
        return np.concatenate([r, rr])

    def ssr(th):
        r = res(th)
        return float(r @ r)

    n_data = len(use)
    r_hat = res(est)
    s2v = float(r_hat[:n_data] @ r_hat[:n_data]) / (n_data - len(names))
    print(f"rows {n_data}; ridge rows {len(ridge)}; half SSR at estimate {0.5 * ssr(est)!r} vs solver cost"
          f" {s2.convergence.cost!r}; s2 recomputed {s2v!r} vs report {rep['residual_variance']!r}")
    C = np.array(rep["covariance"])
    d = est - tru
    wald = float(d @ np.linalg.solve(C, d))
    lr = (ssr(tru) - ssr(est)) / s2v
    print(f"S2 Wald (report covariance) {wald!r}; SSR truth {ssr(tru)!r} SSR est {ssr(est)!r}; LR {lr!r}; LR/W {lr / wald:.4f}")
    # finite-difference J of the reconstruction (central, relative step), in X_SCALE units
    S = np.array([epa_fit.X_SCALE[n] for n in names])
    J = np.zeros((len(r_hat), len(names)))
    for j in range(len(names)):
        h = 1e-6 * S[j]
        ep = est.copy(); ep[j] += h
        em = est.copy(); em[j] -= h
        J[:, j] = (res(ep) - res(em)) / (2 * h)
    C_fd = s2v * np.linalg.inv(J.T @ J)
    print(f"FD covariance vs report: max rel diff {np.max(np.abs(C_fd - C) / np.abs(C)):.3g}; Wald with FD cov"
          f" {float(d @ np.linalg.solve(C_fd, d)):.6f}")
    Hs = (J.T @ J) * np.outer(S, S)
    w, V = np.linalg.eigh(Hs)
    v = V[:, 0]
    v = v if v[np.argmax(np.abs(v))] > 0 else -v
    sdw = math.sqrt(s2v / w[0])
    pt = float(v @ (-d / S))
    print(f"weakest direction (scale units) {np.round(v, 4)}; J'J eig {w[0]:.5g}; sd {sdw:.5f}; truth offset {pt:.5f} ="
          f" {pt / sdw:.4f} sd; perpendicular {np.linalg.norm(-d / S - pt * v):.4f}; cond (eig ratio) {w[-1] / w[0]:.5g},"
          f" (singular-value ratio) {math.sqrt(w[-1] / w[0]):.4g}")
    sl = (ssr(est + S * pt * v) - ssr(est)) / s2v
    print(f"slice at the truth's projection {sl:.4f}; quadratic {pt * pt * w[0] / s2v:.4f}")
    # independent profile: minimise SSR subject to v.((th - est)/S) = pt, by SLSQP from two starts, and by trf on a
    # complement from numpy's QR (not eigh's vectors), finite-difference Jacobian
    best = []
    for start in (est + S * pt * v, tru):
        r1 = minimize(lambda x: ssr(est + S * x) / s2v, (start - est) / S, method="SLSQP",
                      constraints=[{"type": "eq", "fun": lambda x: float(v @ x) - pt}],
                      options={"ftol": 1e-14, "maxiter": 2000})
        best.append((float(r1.fun) - ssr(est) / s2v, bool(r1.success), r1.message))
    Q, _ = np.linalg.qr(np.column_stack([v, np.eye(len(names))[:, :len(names) - 1]]))
    B = Q[:, 1:]
    r2 = least_squares(lambda a: res(est + S * (pt * v + B @ a)), np.zeros(B.shape[1]), method="trf", x_scale=1.0,
                       xtol=1e-15, ftol=1e-15, gtol=1e-15, max_nfev=5000)
    prof_trf = (2 * r2.cost - ssr(est)) / s2v
    print(f"profile at the truth's projection: SLSQP from the slice point {best[0][0]:.4f} ({best[0][1]}), from the truth"
          f" {best[1][0]:.4f} ({best[1][1]}); trf on a QR complement {prof_trf:.4f} (status {r2.status})")
    # the straight line at s = -0.5, 0.5, 1.0, 1.5
    print("line estimate->truth: " + ", ".join(
        f"{s:+.1f}: {(ssr(est - s * d) - ssr(est)) / s2v:.4f}" for s in (-0.5, 0.1, 0.5, 1.0, 1.5)))
    print(f"loader calls this process: {diaglib.LOADER_CALLS}")


def main(argv):
    jobs = int(argv[0])
    parts = set(argv[1:]) or {"A", "B", "C"}
    t0 = time.time()
    print(f"start {time.strftime('%H:%M:%S')}; jobs {jobs}; parts {sorted(parts)}", flush=True)
    if "C" in parts:
        part_c(jobs)
    if "B" in parts:
        part_b(jobs)
    if "A" in parts:
        part_a(jobs)
    print(f"end {time.strftime('%H:%M:%S')}; {time.time() - t0:.1f}s; loader calls {diaglib.LOADER_CALLS}", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
    epa_fit.close_pools()
