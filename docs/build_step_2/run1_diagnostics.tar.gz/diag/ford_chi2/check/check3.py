"""CHECK of diagnostic B, part 3 (no EPA data read; the diagnostic's JSON only). The weak direction's linearised sd at
each fit's own estimate, and the truth's offset along it in X_SCALE units as well as in that fit's own sd, over the
400 S2-only DIAGNOSTIC draws (numpy.random.default_rng([0x7D, k]); not T0 seeds), beside T0 Ford seeds 1 and 2.
MEASUREMENT ONLY; prints to stdout."""
import glob
import json
import os

import numpy as np

DIAG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def jl(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


ds = sorted((jl(p) for p in glob.glob(os.path.join(DIAG, "mcs2_diag_ford_27tt_k*.json"))), key=lambda d: d["draw"])
t0 = {s: jl(os.path.join(DIAG, f"mcs2_t0_ford_27tt_s{s}.json")) for s in (1, 2)}


def row(d):
    pf = d["blocks"]["S2"]["profile"]
    return (pf["weakest_sd_scale_units"], pf["truth_offset_along_weakest_scale_units"],
            pf["truth_offset_along_weakest_in_sd"], d["blocks"]["S2"]["estimate"]["ve_amp"],
            d["blocks"]["S2"]["estimate"]["ve_width"], d["blocks"]["S2"]["wald_contribution"],
            d["blocks"]["S2"]["lr"]["delta_ssr_over_s2"])


A = np.array([row(d) for d in ds])
sd, off, offsd, amp, wid, W, L = A.T
print(f"DIAGNOSTIC draws (rng [0x7D, k]; not T0 seeds): n {len(ds)}")
print(f"weak-direction sd (scale units) at each draw's own estimate: median {np.median(sd):.4f} min {sd.min():.4f}"
      f" max {sd.max():.4f}; 1/2.5/97.5/99 % {np.round(np.percentile(sd, [1, 2.5, 97.5, 99]), 4)}")
print(f"offset along it, scale units: mean {off.mean():+.4f} sd {off.std(ddof=1):.4f}; min {off.min():+.4f} max {off.max():+.4f};"
      f" 0.5/99.5 % {np.round(np.percentile(off, [0.5, 99.5]), 4)}")
for s, d in t0.items():
    r = row(d)
    print(f"T0 seed {s}: sd {r[0]:.4f}, offset {r[1]:+.4f} scale units = {r[2]:+.3f} own sd = "
          f"{r[1] / off.std(ddof=1):+.3f} of the draws' sd of the offset; draws with offset >= it {int((off >= r[1]).sum())},"
          f" with |offset| >= |it| {int((np.abs(off) >= abs(r[1])).sum())}; draws with sd <= its sd {int((sd <= r[0]).sum())};"
          f" ve_amp {r[3]:.4f} ve_width {r[4]:.1f}")
print(f"corr(own sd, ve_amp estimate) {np.corrcoef(sd, amp)[0, 1]:+.3f}; corr(own sd, offset in scale units)"
      f" {np.corrcoef(sd, off)[0, 1]:+.3f}")
m = off > 0.3
print(f"draws with offset > +0.3 scale units: {int(m.sum())}; their own sd {np.round(np.sort(sd[m]), 4)}; offsets in own sd"
      f" {np.round(np.sort(offsd[m]), 3)}")
lo = sd < 0.15
print(f"draws with own sd < 0.15 scale units: {int(lo.sum())}; their offsets (scale) {np.round(np.sort(off[lo]), 3)}")
