"""CHECK of diagnostic B (ford_chi2), part 1: no EPA data read. Reads only the diagnostic's JSON outputs (its
folder) and the recorded results/EPA_CALIBRATION/<engine>/t0.json (read-only), and recomputes the deciding numbers
with independent numpy/scipy code. The diagnostic's draws are DIAGNOSTIC draws (numpy.random.default_rng([0x7D, k])),
not T0 seeds. MEASUREMENT ONLY; prints to stdout."""
import glob
import json
import math
import os

import numpy as np
from scipy.stats import chi2, norm

DIAG = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REPO = r"C:\Users\badcl\Desktop\GRAD-project"


def jl(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def rec(name):
    return jl(os.path.join(REPO, "results", "EPA_CALIBRATION", name, "t0.json"))


def section(t):
    print("\n==== " + t)


# ---------------------------------------------------------------- 1. recorded values against the record
section("1. recorded t0.json values (read-only) against what the task and the report quote")
for name in ("ford_27tt", "mazda_25t", "honda_l15b7"):
    r = rec(name)
    for s in r["seeds"]:
        c = s["chi2"]
        zs = s["z"]
        big = {k: round(v, 3) for k, v in zs.items() if abs(v) > 1.05}
        print(f"{name} seed {s['seed']} judged_at {s['judged_at']} stops_at {s['ladder_stops_at']} chi2 {c['value']!r}/"
              f"{c['dof']} band {c['quantile_99_lo']:.4f}-{c['quantile_99_hi']:.4f} ok {c['ok']} seed ok {s['ok']};"
              f" |z|>1.05: {big}; max other |z| {max([abs(v) for k, v in zs.items() if abs(v) <= 1.05] or [0]):.4f}")
    o = r["out_of_form_seed"]
    print(f"{name} out-of-form seed {o['seed']} chi2 {o['chi2']['value']:.4f}/{o['chi2']['dof']} judged_at {o['judged_at']}"
          f" ok {o['chi2']['ok']}; T0 pass {r['pass']}")

# ---------------------------------------------------------------- 2. case files against the record, bit for bit
section("2. the diagnostic's re-runs against the record (bit for bit)")
cases = {}
for fn in ("case_ford_27tt_s1.json", "case_ford_27tt_s2.json", "case_mazda_25t_s1.json", "case_honda_l15b7_s1.json",
           "mc_t0_ford_27tt_s1.json"):
    d = jl(os.path.join(DIAG, fn))
    cases[fn] = d
    r = [s for s in rec(d["engine"])["seeds"] if s["seed"] == d["seed"]][0]
    same_c = d["chi2_of"] == r["chi2"]
    same_z = d["z"] == r["z"]
    print(f"{fn}: chi2_of dict == record {same_c}; z dict == record {same_z}; value {d['chi2_of']['value']!r}"
          f" record {r['chi2']['value']!r}; loader_calls {d['loader_calls']}; noise {d['noise_stream']}")


# ---------------------------------------------------------------- 3. C1 (old diaglib) vs C3 (current diaglib)
def diff(a, b, path=""):
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                out.append(f"{path}/{k}: only in {'a' if k in a else 'b'}")
            else:
                out += diff(a[k], b[k], f"{path}/{k}")
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: len {len(a)} vs {len(b)}")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                out += diff(x, y, f"{path}[{i}]")
    elif a != b:
        out.append(f"{path}: {a!r} vs {b!r}")
    return out


section("3. case_ford_27tt_s1.json (C1, diaglib before its 18:50:09 edit) vs mc_t0_ford_27tt_s1.json (C3, current)")
a, b = cases["case_ford_27tt_s1.json"], cases["mc_t0_ford_27tt_s1.json"]
skip = {"seconds", "kind", "draw", "noise_stream", "loader_calls", "residual_scales", "t0_noise"}
dd = diff({k: v for k, v in a.items() if k not in skip}, {k: v for k, v in b.items() if k not in skip})
print(f"differences ({len(dd)}):")
for x in dd[:20]:
    print("  ", x)

# ---------------------------------------------------------------- 4. independent recomputation per case
section("4. independent recomputation from each case's stage reports")
for fn, d in cases.items():
    if fn.startswith("mc_t0"):
        continue
    tot = 0.0
    print(f"-- {fn}")
    for st in ("S2", "S4"):
        b = d["blocks"][st]
        n = b["params"]
        est = np.array([b["estimate"][k] for k in n])
        tru = np.array([b["truth"][k] for k in n])
        dlt = est - tru
        # covariance from sd and correlations (the stage's own reported correlations)
        sd = np.array([b["sd"][k] for k in n])
        R = np.array([[b["correlations"][p][q] for q in n] for p in n])
        C = R * np.outer(sd, sd)
        w = float(dlt @ np.linalg.solve(C, dlt))
        tot += w
        s2 = b["residual_variance"]
        lr = (b["lr"]["ssr_at_truth"] - b["lr"]["ssr_at_estimate"]) / s2
        # eigen split in correlation units
        Cm = R
        dm = dlt / sd
        ev, V = np.linalg.eigh(Cm)
        o = np.argsort(ev)[::-1]
        ev, V = ev[o], V[:, o]
        contrib = (V.T @ dm) ** 2 / ev
        print(f"   {st}: Wald from sd+corr {w:.6f} (diag {b['wald_contribution']:.6f}); LR {lr:.6f} (diag"
              f" {b['lr']['delta_ssr_over_s2']:.6f}); LR/W {lr / w:.4f}; corr-metric eig {np.array2string(ev, precision=4)}"
              f" cond {ev[0] / ev[-1]:.4g}; chi2 by dir {np.round(contrib, 3)} (sum {contrib.sum():.4f})")
        print(f"       half SSR at estimate {0.5 * b['lr']['ssr_at_estimate']!r} vs solver cost {b['convergence']['cost']!r};"
              f" SSR truth {b['lr']['ssr_at_truth']:.6f} est {b['lr']['ssr_at_estimate']:.6f}; s2 {s2:.6g};"
              f" data/ridge LR parts {b['lr']['delta_data_ssr_over_s2']:.4f}/{b['lr']['delta_ridge_ssr_over_s2']:.4f}")
        if st == "S4":
            es = b["eigen"]["scale"]
            Vs = np.array(es["eigenvectors_columns_weakest_first"])
            print(f"       S4 scale-metric cov cond {es['cov_condition_number']:.4g}; sqrt {math.sqrt(es['cov_condition_number']):.1f}"
                  f" (stage report's SVD cond {b['s4_condition_number_report']:.1f}); weakest sd sqrt(eig) "
                  f"{math.sqrt(es['cov_eigenvalues_weakest_first'][0]):.4f} (stage report's sd {b['s4_weakest_direction_report']['sd']:.4f},"
                  f" at the best of three starts)")
            print(f"       scale-metric chi2 by dir {np.round(es['chi2_contribution'], 3)}; largest at index"
                  f" {int(np.argmax(es['chi2_contribution']))} of 9 (8 = stiffest)")
            k = int(np.argmax(es["chi2_contribution"]))
            print(f"       its eigenvector {dict(zip(n, np.round(Vs[:, k], 3)))}")
            ec = b["eigen"]["corr"]
            Vc = np.array(ec["eigenvectors_columns_weakest_first"])
            k = int(np.argmax(ec["chi2_contribution"]))
            print(f"       corr-metric largest part {ec['chi2_contribution'][k]:.3f} at index {k} (8 = stiffest), cov eig "
                  f"{ec['cov_eigenvalues_weakest_first'][k]:.4g}, cond {ec['cov_condition_number']:.4g}; vector "
                  f"{dict(zip(n, np.round(Vc[:, k], 3)))}")
            print(f"       starts {[(q['from'], round(q['cost'], 4), q['status']) for q in b['starts']]}; best"
                  f" {b['best_start']}; polish kept {b['polish']['kept']} status {b['polish']['status']} nfev"
                  f" {b['polish']['nfev']} departure {b['polish']['departure_norm_scale_units']:.3g}; conv"
                  f" {b['convergence']['status']} nfev {b['convergence']['nfev']} njev {b['convergence']['njev']}"
                  f" grad {b['convergence']['grad_norm']:.3g}")
            if "line_estimate_to_truth" in b:
                print(f"       S4 line {[(p['s'], round(p['delta_ssr_over_s2'], 3), round(p['quadratic'], 3)) for p in b['line_estimate_to_truth']]}")
    print(f"   total Wald {tot:.6f} (diag chi2 {d['chi2_of']['value']:.6f}); sum of LRs"
          f" {d['blocks']['S2']['lr']['delta_ssr_over_s2'] + d['blocks']['S4']['lr']['delta_ssr_over_s2']:.4f}")
    pf = d["blocks"]["S2"]["profile"]
    t0 = pf["truth_offset_along_weakest_scale_units"]
    sdw = pf["weakest_sd_scale_units"]
    print(f"   S2 weakest sd (scale) {sdw:.5f}; J'J eigenvalue {pf['info_eigenvalue_scale_units']:.5g}; 1/cov eig (scale) "
          f"{1 / d['blocks']['S2']['eigen']['scale']['cov_eigenvalues_weakest_first'][0]:.4g}; offset {t0:.5f} = {t0 / sdw:.4f} sd")
    print("   slice/profile along the weakest direction (t in sd; slice, profile, quadratic, ratios):")
    for sp, pp in zip(pf["slice"], pf["profile"]):
        assert sp["t_scale_units"] == pp["t_scale_units"]
        t = sp["t_scale_units"] / sdw
        q = sp["quadratic"]
        print(f"     t {t:+7.3f} sd: slice {sp['delta_ssr_over_s2']:9.4f} profile {pp['delta_ssr_over_s2']:9.4f} quad {q:9.4f}"
              f"  slice/q {sp['delta_ssr_over_s2'] / q if q else float('nan'):.3f} prof/q {pp['delta_ssr_over_s2'] / q if q else float('nan'):.3f}"
              f" prof<=slice {pp['delta_ssr_over_s2'] <= sp['delta_ssr_over_s2'] + 1e-12} status {pp['status']} inb {pp['within_bounds']}")
    print("   line estimate->truth: " + ", ".join(f"{p['s']:+.1f}: {p['delta_ssr_over_s2']:.3f}/{p['quadratic']:.3f}"
                                               for p in pf["line_estimate_to_truth"]))

# ---------------------------------------------------------------- 5. chi-square tail values
section("5. chi-square quantiles and survival functions quoted")
print(f"chi2(13) 0.005/0.995 {chi2.ppf(0.005, 13):.4f}/{chi2.ppf(0.995, 13):.4f}; chi2(4) 0.995 {chi2.ppf(0.995, 4):.4f};"
      f" chi2(4) 0.90/0.95/0.99 {chi2.ppf(0.9, 4):.3f}/{chi2.ppf(0.95, 4):.3f}/{chi2.ppf(0.99, 4):.3f}; chi2(1) 0.99/0.995"
      f" {chi2.ppf(0.99, 1):.3f}/{chi2.ppf(0.995, 1):.3f}")
s1 = cases["case_ford_27tt_s1.json"]
w2, w4 = s1["blocks"]["S2"]["wald_contribution"], s1["blocks"]["S4"]["wald_contribution"]
l2, l4 = s1["blocks"]["S2"]["lr"]["delta_ssr_over_s2"], s1["blocks"]["S4"]["lr"]["delta_ssr_over_s2"]
print(f"seed 1: Wald {w2 + w4:.4f} sf13 {chi2.sf(w2 + w4, 13):.3g}; LR {l2 + l4:.4f} sf13 {chi2.sf(l2 + l4, 13):.3g};"
      f" S2 LR sf4 {chi2.sf(l2, 4):.3g}; S2 W/LR {w2 / l2:.4f}; S4 W/LR {w4 / l4:.4f}")

# ---------------------------------------------------------------- 6. the 400 S2-only diagnostic draws
section("6. the S2-only DIAGNOSTIC draws (rng [0x7D, k]; not T0 seeds), recomputed")
files = glob.glob(os.path.join(DIAG, "mcs2_diag_ford_27tt_k*.json"))
ds = sorted((jl(p) for p in files), key=lambda d: d["draw"])
ks = [d["draw"] for d in ds]
print(f"files {len(files)}; draws {ks[0]}..{ks[-1]}; set == 1..400 {sorted(ks) == list(range(1, 401))};"
      f" every noise_stream label names 0x7D: {all(d['noise_stream'] == 'DIAGNOSTIC numpy.random.default_rng([0x7D, %d]); not a T0 seed' % d['draw'] for d in ds)};"
      f" every kind DIAG {all(d['kind'] == 'DIAG' for d in ds)}")
est = np.array([[d["blocks"]["S2"]["estimate"][k] for k in ("ve_base", "ve_amp", "ve_rpm", "ve_width")] for d in ds])
print(f"distinct S2 estimates {len({tuple(r) for r in est})} of {len(ds)}; truths identical "
      f"{len({json.dumps(d['blocks']['S2']['truth'], sort_keys=True) for d in ds}) == 1} ({ds[0]['blocks']['S2']['truth']})")
W, L, P = (np.array(x) for x in zip(*[(d["blocks"]["S2"]["wald_contribution"], d["blocks"]["S2"]["lr"]["delta_ssr_over_s2"],
                                     d["blocks"]["S2"]["profile"]["truth_offset_along_weakest_in_sd"]) for d in ds]))
# independent Wald from sd and correlations, every draw
Wi = []
for d in ds:
    b = d["blocks"]["S2"]
    n = b["params"]
    dl = np.array([b["estimate"][k] - b["truth"][k] for k in n])
    sd = np.array([b["sd"][k] for k in n])
    R = np.array([[b["correlations"][p][q] for q in n] for p in n])
    Wi.append(float(dl @ np.linalg.solve(R * np.outer(sd, sd), dl)))
Wi = np.array(Wi)
print(f"independent Wald vs diag: max rel diff {np.max(np.abs(Wi - W) / W):.3g}")
qs = {p: chi2.ppf(p, 4) for p in (0.9, 0.95, 0.99, 0.995)}
print(f"Wald mean {W.mean():.4f} median {np.median(W):.4f} max {W.max():.4f}; > q.90/.95/.99/.995 "
      f"{[int((W > qs[p]).sum()) for p in qs]}; LR mean {L.mean():.4f} max {L.max():.4f} > {[int((L > qs[p]).sum()) for p in qs]}")
print(f"binomial: P(X >= 30 | n 400, p .05) = {1 - __import__('scipy.stats', fromlist=['binom']).binom.cdf(29, 400, 0.05):.4f};"
      f" (30 - 20)/sd {(30 - 20) / math.sqrt(400 * .05 * .95):.3f}; P(X >= 49 | p .1) {1 - __import__('scipy.stats', fromlist=['binom']).binom.cdf(48, 400, 0.1):.4f}")
print(f"offset: mean {P.mean():+.4f} sd {P.std(ddof=1):.4f} se {P.std(ddof=1) / 20:.4f}; quantiles 0.5/99.5 "
      f"{np.percentile(P, 0.5):.3f}/{np.percentile(P, 99.5):.3f}; max |P| {np.abs(P).max():.3f}; >3: {(P > 3).sum()} <-3: {(P < -3).sum()}")
print(f"skew of offsets (sample) {float(((P - P.mean()) ** 3).mean() / P.std() ** 3):+.3f}; se of skew ~ {math.sqrt(6 / 400):.3f}")
r = L / W
for lo, hi in ((0, 1), (1, 2), (2, 3), (3, 99)):
    m = (np.abs(P) >= lo) & (np.abs(P) < hi)
    print(f"  |P| in [{lo},{hi}): n {m.sum()} LR/W median {np.median(r[m]):.3f} range {r[m].min():.3f}-{r[m].max():.3f}"
          f" 5-95% {np.round(np.percentile(r[m], [5, 95]), 3)}")
print(f"  P > +1: n {(P > 1).sum()} median {np.median(r[P > 1]):.3f}; P < -1: n {(P < -1).sum()} median {np.median(r[P < -1]):.3f}")
print(f"draws with S2 Wald >= seed 1's 24.977: {(W >= 24.977089873264273).sum()}; S2 LR >= 15.598: {(L >= 15.597947221696153).sum()}"
      f" (draws {[ks[i] for i in np.where(L >= 15.597947221696153)[0]]})")
SW = np.array([d["blocks"]["S2"]["eigen"]["scale"]["chi2_contribution"][0] for d in ds])
print(f"weakest-direction part: mean {SW.mean():.4f}; > 6.635: {(SW > chi2.ppf(.99, 1)).sum()}; > 7.879: {(SW > chi2.ppf(.995, 1)).sum()};"
      f" equals offset^2? max |SW - P^2| {np.max(np.abs(SW - P ** 2)):.3g}")
secs = np.array([d["seconds"] for d in ds])
print(f"seconds per draw: sum {secs.sum():.1f} mean {secs.mean():.3f}")
# the draws' S2 residual variance, against the nominal
s2v = np.array([d["blocks"]["S2"]["residual_variance"] for d in ds])
print(f"S2 s2 mean {s2v.mean():.6f} sd {s2v.std(ddof=1):.6f}; nominal (0.005/{ds[0]['residual_scales']['air']})^2 = "
      f"{(0.005 / ds[0]['residual_scales']['air']) ** 2:.6f}")

# ---------------------------------------------------------------- 7. the seven full draws
section("7. the seven full form-A DIAGNOSTIC draws")
fd = sorted((jl(p) for p in glob.glob(os.path.join(DIAG, "mc_diag_ford_27tt_k*.json"))), key=lambda d: d["draw"])
for d in fd:
    m = [x for x in ds if x["draw"] == d["draw"]][0]
    print(f"k {d['draw']}: noise {d['noise_stream']!r}; chi2_of {d['chi2_of']['value']:.4f} ok {d['chi2_of']['ok']};"
          f" S2 est == S2-only path {d['blocks']['S2']['estimate'] == m['blocks']['S2']['estimate']}; seconds"
          f" {sum(d['seconds'].values()):.1f}")
print(f"sum of seconds {sum(sum(d['seconds'].values()) for d in fd):.1f}")
