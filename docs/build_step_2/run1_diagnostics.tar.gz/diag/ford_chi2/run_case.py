"""Steps 1-4 of diagnostic B: re-run T0 seeds (T0_STREAM 0x70, the recorded rows) at form A outside the
audit, reproduce the recorded chi-square and z, then the S2/S4 reports, the chi-square's split and the
likelihood-ratio check. Usage: run_case.py JOBS engine:seed [engine:seed ...]. MEASUREMENT ONLY."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diaglib  # noqa: E402  (sets the BLAS variables before NumPy)


def main(argv):
    import time
    import numpy as np
    jobs = int(argv[0])
    for spec in argv[1:]:
        name, seed = spec.split(":")
        seed = int(seed)
        t0 = time.perf_counter()
        tr, rows = diaglib.t0_rows_recorded(name, seed, jobs=jobs)
        t1 = time.perf_counter()
        fit, caps = diaglib.fit_A(name, rows, jobs=jobs)
        t2 = time.perf_counter()
        out = diaglib.analyse(name, fit, caps, tr, record=diaglib.recorded(name, seed))
        t3 = time.perf_counter()
        out["seconds"] = {"rows": t1 - t0, "fit_A": t2 - t1, "analysis": t3 - t2}
        out["loader_calls"] = list(diaglib.LOADER_CALLS)
        out["noise_stream"] = "T0_STREAM 0x70 (the recorded T0 seed's own rows)"
        path = os.path.join(diaglib.HERE, f"case_{name}_s{seed}.json")
        diaglib.dump(out, path)
        rp = out["reproduced"]
        print(f"== {name} seed {seed}: rows {t1 - t0:.1f}s fit {t2 - t1:.1f}s analysis {t3 - t2:.1f}s -> {path}")
        print(f"   chi2 rerun {rp['chi2_rerun']!r} recorded {rp['chi2_recorded']!r} bit-for-bit {rp['chi2_bit_for_bit']}"
              f"; z bit-for-bit {rp['z_bit_for_bit']} (max |dz| {rp['max_abs_z_diff']:.3g})")
        print(f"   sum of block Walds {out['chi2_sum_of_blocks']!r}")
        for st in ("S2", "S4"):
            b = out["blocks"][st]
            cv = b["convergence"]
            print(f"   {st}: rows {b['rows_used']} n_data {b['n_data_residuals']} s2 {b['residual_variance']:.6g}"
                  f" Wald {b['wald_contribution']:.4f} (J'J/s2 {b['wald_via_JtJ_over_s2']:.4f})"
                  f" LR {b['lr']['delta_ssr_over_s2']:.4f}  LR/Wald {b['lr']['lr_over_wald']:.4f}"
                  f" status {cv['status']} nfev {cv['nfev']} active {b['bounds_active']} flags {b['flags']}")
            print(f"      z {', '.join(f'{k} {v:+.3f}' for k, v in b['z'].items())}")
            for metric in ("scale", "corr"):
                e = b["eigen"][metric]
                print(f"      [{metric}] cov eig (weakest first) {np.array(e['cov_eigenvalues_weakest_first'])}"
                      f" cond {e['cov_condition_number']:.4g}")
                print(f"      [{metric}] chi2 per direction {np.round(e['chi2_contribution'], 4)}"
                      f" weakest share {e['share_weakest']:.4f}")
                print(f"      [{metric}] weakest eigvec {np.round(e['weakest_eigenvector'], 4)}")
            print(f"      cov recomputed max rel diff {b['covariance_recomputed_max_rel_diff']:.3g};"
                  f" cost 0.5SSR {b['objective_cost_at_estimate_half_ssr']!r} solver {b['objective_cost_reported_by_solver']!r}")
            print(f"      data mean square at truth /dof {b['lr']['data_mean_square_at_truth_over_dof']:.6g}"
                  f" (s2 at estimate {b['residual_variance']:.6g})")
        pf = out["blocks"]["S2"]["profile"]
        print(f"   S2 truth offset along weakest (scale units) {pf['truth_offset_along_weakest_scale_units']:.4f}"
              f" = {pf['truth_offset_along_weakest_in_sd']:.3f} sd; perpendicular norm"
              f" {pf['truth_offset_perpendicular_norm_scale_units']:.4f}")
        for p in pf["line_estimate_to_truth"]:
            if p["s"] in (0.5, 1.0, 1.5) or abs(p["s"] - 1.0) < 1e-12:
                print(f"      line s={p['s']:.2f}: dSSR/s2 {p['delta_ssr_over_s2']:.4f} quadratic {p['quadratic']:.4f}")
        sys.stdout.flush()


if __name__ == "__main__":
    main(sys.argv[1:])
    import epa_fit
    epa_fit.close_pools()
