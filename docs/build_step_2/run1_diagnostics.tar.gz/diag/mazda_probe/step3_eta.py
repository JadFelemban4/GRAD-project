"""Diagnostic C, item 3 addendum: plant.combustion_efficiency at lambda 0.85, 0.95, 1.0 under the frozen
slope and +- the recorded worth-R1 probe (the function the slope enters; no clip on its rich branch,
plant.py:70-71). No EPA data; no random draws."""
import cdiag
from cdiag import epa_fit, plant_model

pf, checks = cdiag.build_pf()
assert checks["engine_sha_equal"]
spec = cdiag.recorded()["e6_probes"]["row9"]["ce_rich_slope"]
v0, P = float(spec["value"]), float(spec["size"])
print("diag C item 3 addendum: combustion_efficiency (engine_sha", checks["engine_sha"], ")")
for tag, s in (("frozen", v0), ("+probe", v0 + P), ("-probe", v0 - P), ("+10%", v0 * 1.1), ("-10%", v0 * 0.9)):
    eng = epa_fit.with_rich_slope_probe(pf, slope=float(s)).engine
    vals = {lam: float(plant_model.combustion_efficiency(lam, engine=eng)) for lam in (0.7554733753204346, 0.815016, 0.85, 0.918491, 0.95, 1.0)}
    print(f"  {tag:>7} slope {s!r}: " + ", ".join(f"lam {k:.6g} -> {v:.6g}" for k, v in vals.items()))
