"""Diagnostic C, step 0: build the frozen Mazda plant as calibrate_epa.complete builds pf and
check it against complete.json's engine_sha. No EPA loader call; no random draws."""
import sys
import time
import platform

import cdiag

t = time.time()
pf, checks = cdiag.build_pf()
print("diag C step 0 (no EPA loader call; no random draws)")
for k, v in checks.items():
    print(f"  {k}: {v}")
print(f"  build seconds: {time.time() - t:.1f}")
import numpy, scipy  # noqa: E401
print(f"  python {platform.python_version()}, numpy {numpy.__version__}, scipy {scipy.__version__}, "
      f"{platform.platform()}")
print("  files opened (non-.py, outside .venv):")
for p in sorted(set(cdiag.OPENED)):
    print("    ", p)
if not checks["engine_sha_equal"]:
    sys.exit(1)
