"""Diagnostic C, step 0: print the recorded e6 probe records (rows 5, 6, 9)
from results/EPA_CALIBRATION/mazda_25t/complete.json, read only.
No EPA table is opened; this reads only the recorded JSON."""
import json
import sys

REC = "C:/Users/badcl/Desktop/GRAD-project/results/EPA_CALIBRATION/mazda_25t/complete.json"
d = json.load(open(REC))
p = d["e6_probes"]
print("top-level e6_probes keys:", list(p.keys()))
for row in ("row5", "row6", "row9"):
    r = p[row]
    det = r["detail"] if "detail" in r else r
    print("=====", row, "keys:", list(r.keys()))
    for name, v in det.items():
        if not isinstance(v, dict) or "value" not in v:
            print("  (non-probe key)", name, json.dumps(v)[:300])
            continue
        print(" ", name, json.dumps({k: v[k] for k in v if k not in (
            "worth_b_why", "not_visible_at_r1", "worth_r1_why", "counted_excluded_why")}))
        if v.get("not_visible_at_r1"):
            print("     not_visible:", v["not_visible_at_r1"][:400])
for k in p:
    if k not in ("row5", "row6", "row9"):
        print("=====", k)
        print(json.dumps(p[k], indent=1)[:3000])
