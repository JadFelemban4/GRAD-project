"""Diagnostic C: print the per-probe lambda records and rich-branch steps saved in step1_3.json
(no computation, no plant, no EPA data)."""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "step1_3.json"), encoding="utf-8"))
print("base climb rich-branch steps:", d["item1"]["base_ce_calls"]["rich_steps"],
      "lams:", d["item1"]["base_ce_calls"]["rich_lams_sample"])
for k in ("+1%", "-1%", "+10%", "-10%", "+50%", "-50%", "+100%", "-100%", "+R1", "-R1"):
    r = d["item1"]["per_probe_records"][k]
    c = d["item1"]["per_probe_ce_calls"][k]
    print(f"{k:>6}: window lam [{r['lam_window_min']}, {r['lam_window_max']}], steps lam<1 window {r['steps_lam_below_1_window']}"
          f" all {r['steps_lam_below_1_all']}; rich calls {c['rich_total']} (window {c['rich_in_window']});"
          f" rich steps {c['rich_steps'][:6]}{' ...' if len(c['rich_steps']) > 6 else ''}"
          f" ({len(c['rich_steps'])} steps listed, list capped at 80)")
for r in d["item2"]:
    print(f"{r['probe']:>5}: cell lam + {r['lam_plus']} - {r['lam_minus']}")
