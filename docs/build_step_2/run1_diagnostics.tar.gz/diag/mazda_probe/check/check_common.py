"""CHECK of diagnostic C (the Mazda's E6 rich-slope probe): shared setup. MEASUREMENT ONLY.

Written independently of the diagnostic's cdiag.py. Builds the frozen Mazda plant the way
calibrate_epa.complete builds pf (calibrate_epa._frozen_fit, epa_freeze.read_json and check_frozen on
data/engines/mazda_25t/derived_params.json, calibrate_epa._completed, calibrate_epa._plant) and checks
engines.engine_sha against complete.json.

NO EPA LOADER IS CALLED (not calibrate_epa._load, not epa_rows.calibration_contract or calibration_rows,
not the held-out reader). No random draws are made.

An audit hook, installed at import in every process (pool workers import this module too), REFUSES and
COUNTS: any write inside the repository, any open under logs/, any epa_*.csv or epa_engine.json, and any
file under data/engines/ other than a derived_params.json. Refusals are appended to REFUSED before the
PermissionError is raised, so a refusal swallowed by a caller still shows in the output.
"""
import os
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["DERIVING_PARAMS"] = "1"
sys.dont_write_bytecode = True

REPO = "C:/Users/badcl/Desktop/GRAD-project"
_REPO_NC = os.path.normcase(os.path.abspath(REPO))
NAME = "mazda_25t"
COMPLETE = REPO + "/results/EPA_CALIBRATION/mazda_25t/complete.json"

OPENED = set()
REFUSED = []


def _hook(event, args):
    if event != "open" or not args:
        return
    p = args[0]
    try:
        if isinstance(p, bytes):
            p = p.decode("utf-8", "replace")
        if isinstance(p, int):
            return
        p = os.path.normcase(os.path.abspath(os.fspath(p)))
    except Exception:
        return
    if not (p == _REPO_NC or p.startswith(_REPO_NC + os.sep)):
        return
    rel = os.path.relpath(p, _REPO_NC).replace("\\", "/")
    mode = args[1] if len(args) > 1 else None
    flags = args[2] if len(args) > 2 else 0
    w = (isinstance(mode, str) and any(ch in mode for ch in "wax+")) or (
        isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_APPEND | os.O_TRUNC)))
    base = rel.rsplit("/", 1)[-1]
    why = None
    if w:
        why = "write inside the repository"
    elif rel.startswith("logs/"):
        why = "open under logs/"
    elif (base.startswith("epa_") and base.endswith(".csv")) or base == "epa_engine.json":
        why = "open of an EPA table or epa_engine.json"
    elif rel.startswith("data/engines/") and base != "derived_params.json":
        why = "open of a file under data/engines/ other than a derived_params.json"
    if why:
        REFUSED.append((rel, why))
        raise PermissionError(f"check: refused {why}: {rel}")
    if not rel.startswith(".venv/") and "__pycache__" not in rel and not rel.endswith(".py"):
        OPENED.add(rel)


sys.addaudithook(_hook)
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json  # noqa: E402

import engines  # noqa: E402
import epa_freeze  # noqa: E402
import epa_rows  # noqa: E402  (Source.repository() only: no loader)
import calibrate_epa  # noqa: E402


def recorded():
    with open(COMPLETE, encoding="utf-8") as fh:
        return json.load(fh)


def build_pf():
    source = epa_rows.Source.repository()
    root = source.root
    _fz, _rec, frozen = calibrate_epa._frozen_fit(NAME, source=source)
    file_values = epa_freeze.read_json(epa_freeze.derived_path(NAME, root=root), root=root)
    epa_freeze.check_frozen(NAME, file_values, root=root)
    table = [(int(r), float(t)) for r, t in file_values["deliverable_torque"]]
    values = calibrate_epa._completed(frozen.values, table=table, knee=float(file_values["k3"]["turb_knee_k"]),
                                      floor=float(file_values["loop"]["torque_floor_nm"]))
    pf = calibrate_epa._plant(NAME, values)
    calibrate_epa._assert_finite(pf, excluded=set(), step="check")
    rec = recorded()
    sha = engines.engine_sha(pf)
    if sha != rec["engine_sha"] or frozen.frozen_sections_sha256 != rec["frozen_sections_sha256"]:
        raise SystemExit(f"check: the plant built is not complete.json's ({sha} vs {rec['engine_sha']})")
    return pf, {"engine_sha": sha, "engine_sha_recorded": rec["engine_sha"], "form": frozen.form,
                "ce_rich_slope": float(pf.engine.cycle.ce_rich_slope)}


def audit_summary():
    return {"refused": list(REFUSED), "opened_non_py": sorted(OPENED)}
