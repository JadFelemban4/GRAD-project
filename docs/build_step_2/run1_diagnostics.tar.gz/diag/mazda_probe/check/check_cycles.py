"""CHECK of diagnostic C, item 3 and item 5's plant half: single cycles on the frozen Mazda (built as
complete builds pf, engine_sha checked) at the recorded climb point's inputs and at epa_fit.synthetic_grid's
points; no climb, no EPA row, no loader call, no random draws.
Run: python -B check_cycles.py > check_cycles.out"""
import math

import numpy as np

import check_common as C
import epa_fit
import epa_coefficients as ec
import plant as pm


def main():
    pf, chk = C.build_pf()
    rec = C.recorded()
    pr = rec["e6_probes"]
    pt = pr["climb_cell"]["point"]
    s = pr["row9"]["ce_rich_slope"]
    v0, P = float(s["value"]), float(s["size"])
    print("CHECK items 3 and 5 (single cycles; no EPA row; no loader call; no random draws)")
    print("plant:", chk)
    print("climb point inputs:", {k: pt[k] for k in ("rpm", "map", "iat", "ect", "spark", "lam")})
    slopes = {"frozen": v0, "+P": v0 + P, "-P": v0 - P}
    plants = {k: epa_fit.with_rich_slope_probe(pf, slope=float(x)) for k, x in slopes.items()}
    for k, p in plants.items():
        print(f"  eta_comb {k} slope {slopes[k]!r}: " + ", ".join(
            f"lam {lam} -> {float(pm.combustion_efficiency(lam, engine=p.engine)):.6f}" for lam in (0.85, 1.0)))
    for lam in (0.85, 1.0):
        line = []
        for k, p in plants.items():
            r = ec.cyc(p, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam)
            line.append(f"{k}: {r['torque']:.4f} Nm, EGT {r['egt']:.4f} C")
        print(f"  climb point inputs, lam {lam}: " + "; ".join(line))
    # the frozen plant through with_rich_slope_probe at its own slope against pf itself (form keeps C)
    a = ec.cyc(pf, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], 0.85)
    b = ec.cyc(plants["frozen"], pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], 0.85)
    print("  retag at own slope identical at lam 0.85:", all(float(a[k]).hex() == float(b[k]).hex() for k in a))
    grid = [g for g in epa_fit.synthetic_grid(pf) if g[5] in (0.85, 1.0)]
    res = {k: epa_fit._grid_results(p.engine, grid, C.calibrate_epa.DTHETA, p.engine) for k, p in plants.items()}
    for lam in (0.85, 1.0):
        idx = [i for i, g in enumerate(grid) if g[5] == lam]
        summ = {k: (min(res[k][i].torque_nm for i in idx), max(res[k][i].torque_nm for i in idx),
                    min(res[k][i].egt_c for i in idx), max(res[k][i].egt_c for i in idx)) for k in plants}
        same = all(float(res[k][i].torque_nm).hex() == float(res["frozen"][i].torque_nm).hex() and
                   float(res[k][i].egt_c).hex() == float(res["frozen"][i].egt_c).hex() for k in plants for i in idx)
        print(f"  grid lam {lam}: {len(idx)} points; (torque min, max, EGT min, max) "
              + "; ".join(f"{k} ({a_:.1f}, {b_:.1f}, {c_:.1f}, {d_:.1f})" for k, (a_, b_, c_, d_) in summ.items())
              + f"; all bit-identical to frozen: {same}")
        # the review's four numbers, anywhere on the grid (+-1 % of the quoted value)
        for k, key, val in (("+P", "torque_nm", -132.5), ("+P", "egt_c", -172.0), ("-P", "torque_nm", 10255.0),
                            ("-P", "egt_c", 8770.0)):
            hits = [grid[i][:5] for i in idx if abs(getattr(res[k][i], key) - val) <= 0.01 * abs(val)]
            if lam == 0.85:
                print(f"    review's {k} {key} {val}: grid points within 1 %: {hits}")
    # item 5: each zero-crossing probe at v0 - size, built through epa_fit.perturbed (with_rich_slope_probe for the slope)
    print("item 5: probes at v0 - size (v0 + size for comparison), cycles at the climb point inputs")
    fz = {lam: ec.cyc(pf, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam) for lam in (1.0, 0.85)}
    print(f"  frozen: lam 1 {fz[1.0]['torque']:.4f} Nm {fz[1.0]['egt']:.4f} C; lam 0.85 {fz[0.85]['torque']:.4f} Nm "
          f"{fz[0.85]['egt']:.4f} C")
    for f in ("conrod", "t_head_k", "port_pickup_k", "burn_res", "delay_res", "fres_a", "fres_b"):
        sp = pr["row9"][f]
        for sg in (-1, 1):
            val = float(sp["value"]) + sg * float(sp["size"])
            try:
                p = epa_fit.perturbed(pf, record=sp["record"], field=f, value=val)
            except Exception as exc:
                print(f"  {f} {val:.6g}: REFUSED at build: {type(exc).__name__}: {exc}")
                continue
            got = []
            for lam in (1.0, 0.85):
                try:
                    with np.errstate(all="ignore"):
                        r = ec.cyc(p, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam)
                    got.append(f"lam {lam}: {r['torque']:.4f} Nm {r['egt']:.4f} C finite "
                               f"{all(math.isfinite(r[k]) for k in r)}")
                except Exception as exc:
                    got.append(f"lam {lam}: RAISED {type(exc).__name__}: {exc}")
            extra = ""
            if f == "conrod":
                g = p.engine.geometry
                th = np.arange(g.ivc_deg, g.evo_deg + C.calibrate_epa.DTHETA, C.calibrate_epa.DTHETA)
                with np.errstate(all="ignore"):
                    vv = np.array([g.volume(t) for t in th])
                extra = f" | V(TDC) {g.volume(0.0):.6e} m3, V<0 at {int((vv < 0).sum())} of {len(th)} steps"
            if f in ("fres_a", "fres_b"):
                extra = f" | f_res used {float(pm.residual_fraction(pt['map'], engine=p.engine)):.6f}"
            print(f"  {f} {val:.6g} ({'record ' + sp['record']}): built; " + "; ".join(got) + extra)
    print(f"  frozen f_res at the climb MAP {float(pm.residual_fraction(pt['map'], engine=pf.engine)):.6f}")
    print("audit:", C.audit_summary())


if __name__ == "__main__":
    main()
