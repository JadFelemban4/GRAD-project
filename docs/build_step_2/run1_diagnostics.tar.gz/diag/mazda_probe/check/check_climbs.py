"""CHECK of diagnostic C, items 1 and 2: the climb cell's lambda and its housing response to ce_rich_slope.

Each climb goes through the LIBRARY epa_coefficients.climb_cell (the task complete ran per probe), in a
fresh spawn worker; epa_coefficients.run_climb is wrapped only to keep a reference to the step records
climb_cell medians (the wrapper returns run_climb's own output unchanged), and plant.combustion_efficiency
is wrapped to count its calls, each call attributed AFTER SupervisoryTunerEnv.step returns to that env's
k (the records' t). Probes: +-1, 10, 50, 100 % of the frozen slope (complete's arithmetic v0 + sg*rel*|v0|)
and +- the recorded worth-R1 size (validate_epa's v0 + sg*size). The resolution climb is
epa_coefficients.climb_cell_resolution. No EPA row, no loader call, no random draws.
Run: python -B check_climbs.py > check_climbs.out ; writes check_climbs.json beside itself."""
import json
import math
import multiprocessing
import os
import time

import check_common as C

HERE = os.path.dirname(os.path.abspath(__file__))
F = "ce_rich_slope"


def job(item):
    label, plant, kind = item
    import epa_coefficients as ec
    import plant as pm
    import engine_env as E
    calls, pending, recs = [], [], []
    orig_ce, orig_step, orig_rc = pm.combustion_efficiency, E.SupervisoryTunerEnv.step, ec.run_climb

    def ce(lam, *, engine):
        pending.append(float(lam))
        return orig_ce(lam, engine=engine)

    def step(self, action):
        before = len(pending)
        out = orig_step(self, action)
        for lam in pending[before:]:
            calls.append((int(self.k), lam))
        del pending[before:]
        return out

    def rc(p, *, bias):
        rec, summ = orig_rc(p, bias=bias)
        recs.append(rec)
        return rec, summ
    pm.combustion_efficiency, E.SupervisoryTunerEnv.step, ec.run_climb = ce, step, rc
    out = {"label": label, "kind": kind}
    try:
        if kind == "resolution":
            out["resolution"] = ec.climb_cell_resolution(plant)
        else:
            out["cell"] = ec.climb_cell(plant)
    except Exception as exc:
        out["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        pm.combustion_efficiency, E.SupervisoryTunerEnv.step, ec.run_climb = orig_ce, orig_step, orig_rc
    t0, t1 = ec.CLIMB_S
    if recs:
        rec = recs[-1]
        out["n_records"] = len(rec)
        out["t_first_last"] = [rec[0]["t"], rec[-1]["t"]]
        out["rich_records"] = [(int(r["t"]), float(r["lam"])) for r in rec if float(r["lam"]) < 1.0][:12]
        out["n_rich_records"] = sum(1 for r in rec if float(r["lam"]) < 1.0)
        win = [float(r["lam"]) for r in rec if t0 <= r["t"] <= t1]
        out["window"] = {"n": len(win), "lam_min": min(win), "lam_max": max(win),
                         "n_rich": sum(1 for x in win if x < 1.0)}
    rich = [(t, l) for t, l in calls if l < 1.0]
    out["ce"] = {"calls": len(calls), "pending_outside_step": len(pending), "rich": len(rich),
                 "rich_in_window": sum(1 for t, _ in rich if t0 <= t <= t1),
                 "rich_steps": sorted({t for t, _ in rich})[:12], "n_rich_steps": len({t for t, _ in rich})}
    out["audit"] = C.audit_summary()
    return out


def main():
    t_start = time.time()
    import epa_fit
    import epa_coefficients as ec
    pf, chk = C.build_pf()
    rec = C.recorded()
    pr = rec["e6_probes"]
    spec = pr["row9"][F]
    v0 = float(pf.engine.cycle.ce_rich_slope)
    assert v0 == float(spec["value"])
    rel10 = float(pr["probe_rel"])
    P = float(spec["size"])
    probes = {}
    for rel in (0.01, rel10, 0.5, 1.0):
        for sg in (1, -1):
            probes[f"{'+' if sg > 0 else '-'}{rel * 100:g}%"] = v0 + sg * rel * abs(v0)
    probes["+R1"], probes["-R1"] = v0 + P, v0 - P
    items = [("base", pf, "cell"), ("resolution", pf, "resolution")]
    items += [(k, epa_fit.with_rich_slope_probe(pf, slope=float(v)), "cell") for k, v in probes.items()]
    with multiprocessing.get_context("spawn").Pool(len(items)) as pool:
        res = {r["label"]: r for r in pool.map(job, items, chunksize=1)}
    base_rec, hs_rec = pr["climb_cell"]["point"], pr["climb_cell"]["housing"]
    noise_rec = float(pr["numerical_noise"]["housing_k"])
    out = {"note": "check of diagnostic C; library climb_cell per probe; no EPA loader call; no random draws",
           "plant": chk, "probes": probes, "results": res}
    base = res["base"]["cell"]
    out["base_point_bits_equal"] = {k: float(base[k]).hex() == float(base_rec[k]).hex() for k in base_rec}
    hs = ec.housing(pf, base["egt"], base["mdot"], t_amb_c=ec.T_AMB_C)
    out["housing_bits_equal"] = {k: float(hs[k]).hex() == float(hs_rec[k]).hex() for k in hs_rec}
    rs = res["resolution"]["resolution"]
    nz = C.calibrate_epa.numerical_noise_k(hs, rs)
    out["noise"] = {"recomputed": nz, "recorded": noise_rec, "bits_equal": nz.hex() == noise_rec.hex(),
                    "egt_res_equal": float(rs["egt_resolution_k"]).hex() == float(pr["numerical_noise"]["egt_resolution_k"]).hex(),
                    "mdot_res_equal": float(rs["mdot_resolution_gps"]).hex() == float(pr["numerical_noise"]["mdot_resolution_gps"]).hex(),
                    "samples": rs["samples"]}

    def h(cell):
        return ec.housing_equivalent(hs_rec, cell["egt"] - base_rec["egt"], math.log(cell["mdot"] / base_rec["mdot"]))
    rows = []
    for tag, step in [(f"{r * 100:g}%", r * abs(v0)) for r in (0.01, rel10, 0.5, 1.0)] + [("R1", P)]:
        cp, cm = res[f"+{tag}"], res[f"-{tag}"]
        if "error" in cp or "error" in cm:
            rows.append({"probe": tag, "error": [cp.get("error"), cm.get("error")]})
            continue
        hp, hm = h(cp["cell"]), h(cm["cell"])
        rows.append({"probe": tag, "step": step, "h_plus": hp, "h_minus": hm, "response": abs(hp - hm) / 2,
                     "over_noise": abs(hp - hm) / 2 / noise_rec, "k_per_unit": (hp - hm) / (2 * step),
                     "d_egt": [cp["cell"]["egt"] - base_rec["egt"], cm["cell"]["egt"] - base_rec["egt"]],
                     "d_mdot": [cp["cell"]["mdot"] - base_rec["mdot"], cm["cell"]["mdot"] - base_rec["mdot"]],
                     "cell_lam": [cp["cell"]["lam"], cm["cell"]["lam"]]})
    out["responses"] = rows
    r10p, r10m = h(res[f"+{rel10 * 100:g}%"]["cell"]), h(res[f"-{rel10 * 100:g}%"]["cell"])
    out["ten_pct_vs_record"] = {"h_plus": [r10p, spec["housing_eq_k"]["+"], r10p.hex() == float(spec["housing_eq_k"]["+"]).hex()],
                                "h_minus": [r10m, spec["housing_eq_k"]["-"], r10m.hex() == float(spec["housing_eq_k"]["-"]).hex()],
                                "response": [abs(r10p - r10m) / 2, spec["response_k"],
                                             (abs(r10p - r10m) / 2).hex() == float(spec["response_k"]).hex()]}
    out["seconds"] = time.time() - t_start
    out["audit_main"] = C.audit_summary()
    with open(os.path.join(HERE, "check_climbs.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, default=str)

    print("CHECK of diagnostic C, items 1-2 (library climb_cell per probe; no EPA loader call; no random draws)")
    print("plant:", chk)
    print("base climb point bit for bit vs complete.json:", all(out["base_point_bits_equal"].values()),
          "| housing record bit for bit:", all(out["housing_bits_equal"].values()))
    print("noise:", out["noise"])
    print("+-10 % vs record:", out["ten_pct_vs_record"])
    for lab in ["base"] + list(probes):
        r = res[lab]
        print(f"  {lab:>6}: n_records {r.get('n_records')} t {r.get('t_first_last')} | rich records "
              f"{r.get('n_rich_records')} first {r.get('rich_records')} | window {r.get('window')} | ce {r['ce']}"
              + (f" | ERROR {r['error']}" if 'error' in r else ""))
    print("responses (noise %r K):" % noise_rec)
    for row in rows:
        if "error" in row:
            print("  ", row)
            continue
        print(f"  {row['probe']:>5} step {row['step']:.6g}: h+ {row['h_plus']:+.6e} h- {row['h_minus']:+.6e} "
              f"resp {row['response']:.6e} ({row['over_noise']:.4f} x noise) {row['k_per_unit']:+.4e} K/unit "
              f"dEGT {row['d_egt'][0]:+.4e}/{row['d_egt'][1]:+.4e} dmdot {row['d_mdot'][0]:+.4e}/{row['d_mdot'][1]:+.4e} "
              f"cell lam {row['cell_lam']}")
    refused = [r["audit"]["refused"] for r in res.values()] + [out["audit_main"]["refused"]]
    print("audit refusals (main and every worker):", refused)
    print("files opened, main:", out["audit_main"]["opened_non_py"])
    print("files opened, workers (union):", sorted({p for r in res.values() for p in r["audit"]["opened_non_py"]}))
    print(f"seconds {out['seconds']:.1f}")


if __name__ == "__main__":
    main()
