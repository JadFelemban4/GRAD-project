"""CHECK of diagnostic C, item 4 and item 5's record half: from complete.json and e6/ only.

Independent of step4_classify.py: epa_fit.BOUNDS is taken from the imported module (not parsed from its
text), and each probe's class is re-derived from calibrate_epa.probe_sizes' own rule as written (bracket
first; then not visible -> fallback; then worth -> probe), re-run with the recorded h+ and h- through
probe_sizes itself, which needs no climb: base cell and cells are rebuilt so that housing_equivalent returns
the recorded h. Readings: (i) response > noise; (ii) response >= 2 noise; (iii) a probe-method size whose
v0 +- size leaves epa_fit.BOUNDS falls back to +-10 %. No plant is run, no EPA data, no random draws.
Run: python -B check_records.py > check_records.out"""
import glob
import json
import math
import os

import check_common as C
import epa_fit

HERE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = C.REPO + "/results/EPA_CALIBRATION/mazda_25t"


def main():
    rec = C.recorded()
    pr = rec["e6_probes"]
    noise = float(pr["numerical_noise"]["housing_k"])
    rel = float(pr["probe_rel"])
    r1 = float(pr["r1_housing_k"])
    hs = pr["climb_cell"]["housing"]
    # recompute decision 85's noise from the record's own fields
    rs = pr["numerical_noise"]
    mdot = float(pr["climb_cell"]["point"]["mdot"])
    nz = abs(hs["f"]) * rs["egt_resolution_k"] + abs(hs["dTh_per_unit_ln_mdot"]) * rs["mdot_resolution_gps"] / mdot
    print("CHECK item 4 (records only; no plant run; no EPA data; no random draws)")
    print(f"noise recorded {noise!r}; recomputed from the record's resolution and housing {nz!r}; "
          f"bits equal {nz.hex() == noise.hex()}; r1 {r1}; probe_rel {rel}")
    e6 = {}
    for f in sorted(glob.glob(os.path.join(REC_DIR, "e6", "*.json"))):
        txt = open(f, encoding="utf-8").read()
        e6[os.path.basename(f)] = [k for k in ("response_k", "worth_r1", "visible_at_r1", "housing_eq_k") if k in txt]
    print("e6/ files and probe keys found in their text:", e6)
    entries = [(5, f, s) for f, s in pr["row5"]["detail"].items()] + [(6, f, s) for f, s in pr["row6"]["detail"].items()] \
        + [(9, f, s) for f, s in pr["row9"].items()]
    print(f"{len(entries)} probes")
    B = epa_fit.BOUNDS
    hdr = ("row", "constant", "value", "method", "size", "v-size", "v+size", "h+", "h-", "resp", "resp/noise",
           "bounds", "out", "x0", "rec vis/excl", "(i)", "(ii)", "(iii)", "(ii)+(iii)")
    print(" | ".join(hdr))
    changes = {"ii": [], "iii": [], "ii+iii": [], "x0": []}
    i_mismatch = []
    for row, f, s in entries:
        v, size, method = float(s["value"]), float(s["size"]), s["method"]
        hp, hm = float(s["housing_eq_k"]["+"]), float(s["housing_eq_k"]["-"])
        resp = abs(hp - hm) / 2.0
        assert resp.hex() == float(s["response_k"]).hex(), f
        lo, hi = v - size, v + size
        b = B.get(f)
        out = None if b is None else (lo < b[0] or hi > b[1])
        x0 = (lo < 0.0 < v) or (hi > 0.0 > v)
        is_bracket = method == "bracket"

        def cls(vis, bounds_fb):
            if is_bracket:
                return "bracket"
            if not vis:
                return "fallback/not-visible/excluded"
            if bounds_fb:
                return "fallback(bounds)/visible"
            if s["worth_r1"] is None and method == "fallback":
                return "fallback(no worth)/visible"
            return "probe/visible"
        ci = cls(resp > noise, False)
        cii = cls(resp >= 2 * noise, False)
        ciii = cls(resp > noise, bool(out) and method == "probe")
        cboth = cls(resp >= 2 * noise, bool(out) and method == "probe")
        recd = ("bracket" if is_bracket else
                ("fallback/not-visible/excluded" if s["counted_excluded"] else
                 ("probe/visible" if method == "probe" else "fallback(no worth)/visible")))
        if ci != recd:
            i_mismatch.append(f)
        if not is_bracket and (resp > noise) != bool(s["visible_at_r1"]):
            i_mismatch.append(f + " (visible flag)")
        for k, c in (("ii", cii), ("iii", ciii), ("ii+iii", cboth)):
            if c != ci:
                changes[k].append(f)
        if x0:
            changes["x0"].append(f)
        print(" | ".join(str(x) for x in (row, f, f"{v:.6g}", method, f"{size:.6g}", f"{lo:.6g}", f"{hi:.6g}",
                                          f"{hp:+.4g}", f"{hm:+.4g}", f"{resp:.4g}", f"{resp / noise:.4g}", b,
                                          "-" if out is None else ("YES" if out else "no"), "YES" if x0 else "no",
                                          f"{s['visible_at_r1']}/{s['counted_excluded']}", ci, cii, ciii, cboth)))
    print("class (i) differs from the recorded class for:", i_mismatch or "none")
    print("changes against (i):", json.dumps(changes))
    print("probe-method ratios, ascending (first 4):",
          sorted((float(s["response_k"]) / noise, f) for _r, f, s in entries if s["method"] == "probe")[:4])
    print("constants with a BOUNDS entry among the probes:", [f for _r, f, _s in entries if f in B])
    # re-run probe_sizes itself on the recorded h's for ce_rich_slope, at noise and at 2 x noise
    s = pr["row9"]["ce_rich_slope"]
    base = {"egt": 0.0, "mdot": 1.0}
    hs_unit = {"f": 1.0, "dTh_per_unit_ln_mdot": 0.0}
    cells = {("ce_rich_slope", 1): {"egt": float(s["housing_eq_k"]["+"]), "mdot": 1.0},
             ("ce_rich_slope", -1): {"egt": float(s["housing_eq_k"]["-"]), "mdot": 1.0}}
    for lab, nk in (("noise", noise), ("2 x noise", 2 * noise)):
        z = C.calibrate_epa.probe_sizes(base, hs_unit, cells, r1_k=r1, rel=rel, else_rel=rel, else_cad=10.0,
                                        fields=(("cycle", "ce_rich_slope"),), brackets={},
                                        v0={"ce_rich_slope": float(s["value"])},
                                        sigmas={"ce_rich_slope": s.get("sigma")}, noise_k=nk)["ce_rich_slope"]
        print(f"probe_sizes(ce_rich_slope) at noise_k = {lab}: method {z['method']}, size {z['size']!r}, "
              f"visible {z['visible_at_r1']}, counted_excluded {z['counted_excluded']}, worth_r1 {z['worth_r1']!r}, "
              f"slope {z['slope_k_per_unit']!r}")
    print("record's ce_rich_slope: size", s["size"], "worth", s["worth_r1"], "slope", s["slope_k_per_unit"],
          "probe_housing_change_k", s["probe_housing_change_k"], "sigma", s.get("sigma"), "band", s.get("band"),
          "housing_change_k", s["housing_change_k"], "load_bearing", s["load_bearing"])
    print("item 5 records:")
    for f in ("n_poly", "t_head_k", "port_pickup_k", "burn_res", "delay_res", "conrod", "fres_a", "fres_b"):
        s = pr["row9"][f]
        v, size = float(s["value"]), float(s["size"])
        st = rel * abs(v)
        print(f"  {f}: value {v!r} size {size!r} -> [{v - size!r}, {v + size!r}]; h+ {s['housing_eq_k']['+']!r} "
              f"h- {s['housing_eq_k']['-']!r}; slope {s['slope_k_per_unit']!r} (recomputed "
              f"{(s['housing_eq_k']['+'] - s['housing_eq_k']['-']) / (2 * st)!r}); worth {s['worth_r1']!r}")
    print("brackets:", {k: v["bracket"] for k, v in pr["brackets"].items()})
    for f in ("ivc_deg", "evo_deg"):
        s = pr["row9"][f]
        print(f"  {f}: value {s['value']} size {s['size']} -> [{s['value'] - s['size']:.6g}, {s['value'] + s['size']:.6g}]")
    print("audit:", C.audit_summary())


if __name__ == "__main__":
    main()
