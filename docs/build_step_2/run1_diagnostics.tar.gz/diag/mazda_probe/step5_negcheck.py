"""Diagnostic C, item 5's plant half: for every recorded row 9 probe whose value - size crosses zero,
does building the probed plant refuse it, and what does one cycle give at the recorded climb point's
inputs (lambda 1.0, the climb's) and at lambda 0.85? Synthetic inputs only: no EPA row, no EPA
loader call, no random draws. Writes step5_negcheck.json; prints a summary."""
import json
import math
import os

import numpy as np

import cdiag
from cdiag import epa_coefficients, epa_fit, plant_model

HERE = os.path.dirname(os.path.abspath(__file__))
CONSTS = ("conrod", "t_head_k", "port_pickup_k", "burn_res", "delay_res", "fres_a", "fres_b", "ce_rich_slope")


def main():
    pf, checks = cdiag.build_pf()
    assert checks["engine_sha_equal"], checks
    rec = cdiag.recorded()
    pr = rec["e6_probes"]
    pt = pr["climb_cell"]["point"]
    out = {"note": "diagnostic C; synthetic inputs (the recorded climb point's rpm, map, iat, ect, spark); "
                   "no EPA row; no random draws", "engine_sha": checks["engine_sha"], "rows": []}
    geo = pf.engine.geometry
    out["geometry"] = {"bore": geo.bore, "stroke": geo.stroke, "crank": geo.crank, "conrod": geo.conrod,
                       "comp_ratio": geo.comp_ratio, "ivc_deg": geo.ivc_deg, "evo_deg": geo.evo_deg, "vc": geo.vc,
                       "vd_cyl": geo.vd_cyl}
    c = pf.engine.cycle
    out["fres_clip"] = {"fres_lo": c.fres_lo, "fres_hi": c.fres_hi, "fres_map_min": c.fres_map_min,
                        "f_res_frozen_at_climb_map": float(plant_model.residual_fraction(pt["map"], engine=pf.engine))}
    for f in CONSTS:
        s = pr["row9"][f]
        record = s["record"]
        v0, size = float(s["value"]), float(s["size"])
        for tag, val in (("-size", v0 - size), ("+size", v0 + size)):
            row = {"constant": f, "record": record, "probe": tag, "value": val}
            try:
                p = (epa_fit.with_rich_slope_probe(pf, slope=float(val)) if f == "ce_rich_slope"
                     else epa_fit.perturbed(pf, record=record, field=f, value=float(val)))
                row["built"] = True
            except Exception as exc:
                row["built"] = False
                row["build_error"] = f"{type(exc).__name__}: {exc}"
                out["rows"].append(row)
                continue
            for lam in (1.0, 0.85):
                try:
                    with np.errstate(all="ignore"):
                        r = epa_coefficients.cyc(p, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam)
                    row[f"lam{lam:g}"] = {"torque_nm": r["torque"], "egt_c": r["egt"], "mdot_gps": r["mdot"],
                                          "ki": r["ki"],
                                          "finite": all(math.isfinite(r[k]) for k in ("torque", "egt", "mdot", "ki"))}
                except Exception as exc:
                    row[f"lam{lam:g}"] = {"error": f"{type(exc).__name__}: {exc}"}
            if f == "conrod":
                g = p.engine.geometry
                th = np.arange(g.ivc_deg, g.evo_deg + 0.25, 0.25)
                with np.errstate(all="ignore"):
                    vols = np.array([g.volume(t) for t in th])
                row["volume"] = {"at_tdc": float(g.volume(0.0)), "at_ivc": float(g.volume(g.ivc_deg)),
                                 "at_evo": float(g.volume(g.evo_deg)), "min_over_cycle": float(np.nanmin(vols)),
                                 "negative_steps": int(np.sum(vols < 0)), "nan_steps": int(np.sum(~np.isfinite(vols)))}
            if f in ("fres_a", "fres_b"):
                raw = (p.engine.cycle.fres_a + p.engine.cycle.fres_b / max(pt["map"], p.engine.cycle.fres_map_min))
                row["f_res"] = {"unclipped_at_climb_map": float(raw),
                                "used_at_climb_map": float(plant_model.residual_fraction(pt["map"], engine=p.engine))}
            if f in ("burn_res", "delay_res"):
                row["factor_1_plus_x_fres_over_clip"] = [1.0 + val * c.fres_lo, 1.0 + val * c.fres_hi]
            out["rows"].append(row)
    # the frozen plant itself at the same inputs, for comparison
    out["frozen"] = {f"lam{lam:g}": epa_coefficients.cyc(pf, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam)
                     for lam in (1.0, 0.85)}
    with open(os.path.join(HERE, "step5_negcheck.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, default=str)
    print("diag C item 5 (plant half): engine_sha", checks["engine_sha"], "== recorded", checks["engine_sha_equal"])
    print("no EPA row; no random draws; inputs: the recorded climb point's rpm, map, iat, ect, spark")
    print("geometry:", out["geometry"])
    print("residual clip:", out["fres_clip"])
    fz = out["frozen"]
    print(f"frozen: lam 1 torque {fz['lam1']['torque']:.4f} Nm EGT {fz['lam1']['egt']:.4f} C;"
          f" lam 0.85 torque {fz['lam0.85']['torque']:.4f} Nm EGT {fz['lam0.85']['egt']:.4f} C")
    for row in out["rows"]:
        line = f"  {row['constant']:<14} {row['probe']}: value {row['value']:.6g} built {row['built']}"
        if not row["built"]:
            line += " " + row["build_error"]
        else:
            for lam in ("lam1", "lam0.85"):
                d = row[lam]
                if "error" in d:
                    line += f" | {lam} ERROR {d['error']}"
                else:
                    line += (f" | {lam} T {d['torque_nm']:.4f} EGT {d['egt_c']:.4f} mdot {d['mdot_gps']:.4f}"
                             f" finite {d['finite']}")
            for k in ("volume", "f_res", "factor_1_plus_x_fres_over_clip"):
                if k in row:
                    line += f" | {k} {row[k]}"
        print(line)


if __name__ == "__main__":
    main()
