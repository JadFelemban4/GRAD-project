"""Diagnostic C (the Mazda's E6 rich-slope probe): shared setup. MEASUREMENT ONLY.

Builds the frozen Mazda plant as calibrate_epa.complete builds its final plant pf:
calibrate_epa._frozen_fit (freeze.json and fit_<form>.json, hash-checked), the derived
file's completion values (data/engines/mazda_25t/derived_params.json, read with
epa_freeze.read_json and checked with epa_freeze.check_frozen), calibrate_epa._completed
and calibrate_epa._plant (engines.build_candidate). It then checks engines.engine_sha(pf)
against complete.json's engine_sha.

NO EPA LOADER IS CALLED: not calibrate_epa._load, not epa_rows.calibration_contract, not
epa_rows.calibration_rows, not the held-out reader. An audit hook refuses any open of a
file under data/engines/ other than a derived_params.json, any epa_*.csv or epa_engine.json,
anything under logs/, and any write inside the repository; every opened path is logged.
No random draws are made anywhere in this diagnostic.
"""
import os
import sys

# as calibrate_epa's prelude: one BLAS thread before NumPy, DERIVING_PARAMS=1 as complete runs
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["DERIVING_PARAMS"] = "1"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True

REPO = "C:/Users/badcl/Desktop/GRAD-project"
REPO_NC = os.path.normcase(os.path.abspath(REPO))
NAME = "mazda_25t"
COMPLETE_JSON = REPO + "/results/EPA_CALIBRATION/mazda_25t/complete.json"

OPENED = []
_HOOKED = [False]


def _norm(p):
    try:
        if isinstance(p, bytes):
            p = p.decode("utf-8", "replace")
        if not isinstance(p, str):
            p = os.fspath(p)
        return os.path.normcase(os.path.abspath(p))
    except Exception:
        return None


def _hook(event, args):
    if event != "open":
        return
    path = _norm(args[0]) if args else None
    if path is None:
        return
    mode = args[1] if len(args) > 1 else None
    flags = args[2] if len(args) > 2 else 0
    writing = False
    if isinstance(mode, str) and any(c in mode for c in "wax+"):
        writing = True
    if isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_APPEND | os.O_TRUNC):
        writing = True
    inside = path.startswith(REPO_NC + os.sep) or path == REPO_NC
    if inside:
        rel = os.path.relpath(path, REPO_NC).replace("\\", "/")
        base = os.path.basename(rel)
        if writing:
            raise PermissionError(f"diag C: refused write inside the repository: {rel}")
        if rel.startswith("logs/"):
            raise PermissionError(f"diag C: refused open under logs/: {rel}")
        if rel.startswith("data/engines/") and base != "derived_params.json":
            raise PermissionError(f"diag C: refused open of an EPA engine file: {rel}")
        if (base.startswith("epa_") and base.endswith(".csv")) or base == "epa_engine.json":
            raise PermissionError(f"diag C: refused open of an EPA table: {rel}")
        if not rel.startswith(".venv/") and not rel.endswith(".py") and "__pycache__" not in rel:
            OPENED.append(rel)


def install_hook():
    if not _HOOKED[0]:
        sys.addaudithook(_hook)
        _HOOKED[0] = True


install_hook()
if REPO not in sys.path:
    sys.path.insert(0, REPO)

import json      # noqa: E402
import math      # noqa: E402

import numpy as np                      # noqa: E402
import engines                          # noqa: E402
import epa_freeze                       # noqa: E402
import epa_fit                          # noqa: E402
import epa_rows                         # noqa: E402  (only its Source dataclass is used: no loader call)
import epa_coefficients                 # noqa: E402
import calibrate_epa                    # noqa: E402
import engine_env as E                  # noqa: E402
import plant as plant_model             # noqa: E402
from thresholds.contract import T_AMB_C  # noqa: E402


def recorded():
    with open(COMPLETE_JSON, encoding="utf-8") as fh:
        return json.load(fh)


def build_pf():
    """The final plant as complete measured it; returns (pf, checks)."""
    source = epa_rows.Source.repository()
    root = source.root
    fz, fit_rec, frozen = calibrate_epa._frozen_fit(NAME, source=source)
    dpath = epa_freeze.derived_path(NAME, root=root)
    file_values = epa_freeze.read_json(dpath, root=root)
    epa_freeze.check_frozen(NAME, file_values, root=root)
    table = [(int(r), float(t)) for r, t in file_values["deliverable_torque"]]
    knee = float(file_values["k3"]["turb_knee_k"])
    floor = float(file_values["loop"]["torque_floor_nm"])
    values = calibrate_epa._completed(frozen.values, table=table, knee=knee, floor=floor)
    pf = calibrate_epa._plant(NAME, values)
    calibrate_epa._assert_finite(pf, excluded=set(), step="diag C")
    rec = recorded()
    checks = {
        "form": frozen.form,
        "frozen_sections_sha256": frozen.frozen_sections_sha256,
        "frozen_sha_equals_complete": frozen.frozen_sections_sha256 == rec["frozen_sections_sha256"],
        "engine_sha": engines.engine_sha(pf),
        "engine_sha_recorded": rec["engine_sha"],
        "engine_sha_equal": engines.engine_sha(pf) == rec["engine_sha"],
        "knee_k": knee, "floor_nm": floor, "table_rows": len(table),
        "ce_rich_slope": float(pf.engine.cycle.ce_rich_slope),
    }
    return pf, checks


# ------------------------------------------------------------------ instrumentation (in-process only)
STATE = {"t": None, "calls": []}
_INSTR = [False]


def instrument():
    """Wrap plant.combustion_efficiency (log every lam it is called with, and the env step) and
    SupervisoryTunerEnv.step (set the step's record time t = k + 1, as run_climb records it).
    The wrappers return the originals' values unchanged; the patches live in this process only."""
    if _INSTR[0]:
        return
    orig_ce = plant_model.combustion_efficiency
    orig_step = E.SupervisoryTunerEnv.step

    def ce(lam, *, engine):
        STATE["calls"].append((STATE["t"], float(lam)))
        return orig_ce(lam, engine=engine)

    def step(self, action):
        STATE["t"] = int(self.k) + 1
        return orig_step(self, action)
    plant_model.combustion_efficiency = ce
    E.SupervisoryTunerEnv.step = step
    _INSTR[0] = True


def worker_init():
    install_hook()
    instrument()


def climb_job(item):
    """(label, plant, mode): mode 'lib_cell' runs epa_coefficients.climb_cell (uninstrumented
    output; the counter still runs), 'resolution' climb_cell_resolution, 'instr' run_climb at
    bias 0.0 and median_point over CLIMB_S (climb_cell's own body) with the rich-branch census."""
    label, p, mode = item
    instrument()
    STATE["t"], STATE["calls"] = None, []
    out = {"label": label, "mode": mode}
    try:
        if mode == "lib_cell":
            out["cell"] = epa_coefficients.climb_cell(p)
        elif mode == "resolution":
            out["resolution"] = epa_coefficients.climb_cell_resolution(p)
        else:
            rec, _summ = epa_coefficients.run_climb(p, bias=0.0)
            out["cell"] = epa_coefficients.median_point(rec, *epa_coefficients.CLIMB_S)
            t0, t1 = epa_coefficients.CLIMB_S
            win = [r for r in rec if t0 <= r["t"] <= t1]
            lw = [float(r["lam"]) for r in win]
            la = [float(r["lam"]) for r in rec]
            out["records"] = {"n": len(rec), "n_window": len(win),
                              "lam_window_min": min(lw), "lam_window_max": max(lw),
                              "lam_all_min": min(la), "lam_all_max": max(la),
                              "steps_lam_below_1_window": sum(1 for x in lw if x < 1.0),
                              "steps_lam_below_1_all": sum(1 for x in la if x < 1.0),
                              "t_lam_below_1_all": [int(r["t"]) for r in rec if float(r["lam"]) < 1.0][:50]}
    except Exception as exc:          # a probe climb that cannot run is recorded, not hidden
        out["error"] = f"{type(exc).__name__}: {exc}"
    calls = STATE["calls"]
    t0, t1 = epa_coefficients.CLIMB_S
    rich = [(t, l) for t, l in calls if l < 1.0]
    out["ce_calls"] = {
        "total": len(calls),
        "in_window": sum(1 for t, _l in calls if t is not None and t0 <= t <= t1),
        "rich_total": len(rich),
        "rich_in_window": sum(1 for t, _l in rich if t is not None and t0 <= t <= t1),
        "rich_before_window": sum(1 for t, _l in rich if t is not None and t < t0),
        "rich_after_window": sum(1 for t, _l in rich if t is not None and t > t1),
        "rich_at_reset": sum(1 for t, _l in rich if t is None),
        "lam_min_called": min((l for _t, l in calls), default=None),
        "lam_min_called_window": min((l for t, l in calls if t is not None and t0 <= t <= t1), default=None),
        "rich_steps": sorted({t for t, _l in rich if t is not None})[:80],
        "rich_lams_sample": sorted({l for _t, l in rich})[:20],
    }
    STATE["calls"] = []
    return out


def bits(x):
    return float(x).hex()
