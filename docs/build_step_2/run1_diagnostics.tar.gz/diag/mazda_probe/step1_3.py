"""Diagnostic C, items 1-3, on the frozen Mazda plant (cdiag.build_pf, engine_sha checked):
  1. the climb cell's lambda and a census of combustion_efficiency's rich branch over the climb;
  2. the climb cell's housing response to ce_rich_slope at +-1, 10, 50, 100 % of its value and at
     the recorded worth-R1 probe, after reproducing the recorded +-10 % record;
  3. torque and EGT at lambda 0.85 and 1.0 under +- the recorded probe (the climb point's inputs,
     and epa_fit.synthetic_grid's points).
Synthetic operating points and the climb only: no EPA row, no EPA loader call, no random draws.
Writes step1_3.json beside this file; prints a summary."""
import json
import math
import multiprocessing
import os
import time

import cdiag
from cdiag import epa_coefficients, epa_fit, calibrate_epa, plant_model, E, T_AMB_C

HERE = os.path.dirname(os.path.abspath(__file__))
F = "ce_rich_slope"


def main():
    t_start = time.time()
    pf, checks = cdiag.build_pf()
    assert checks["engine_sha_equal"], checks
    rec = cdiag.recorded()
    pr = rec["e6_probes"]
    spec = pr["row9"][F]
    base_rec = pr["climb_cell"]["point"]
    hs_rec = pr["climb_cell"]["housing"]
    noise_rec = pr["numerical_noise"]["housing_k"]
    v0 = float(pf.engine.cycle.ce_rich_slope)
    assert v0 == float(spec["value"])
    rel10 = float(pr["probe_rel"])
    P = float(spec["size"])          # the recorded worth-R1 probe
    lo, hi = epa_fit.BOUNDS[F]

    # the probe set: label -> slope value
    probes = {}
    for rel in (0.01, rel10, 0.50, 1.00):
        for sg, s in ((1, "+"), (-1, "-")):
            probes[f"{s}{rel * 100:g}%"] = v0 + sg * rel * abs(v0)     # complete's arithmetic (calibrate_epa:2408)
    probes["+R1"] = v0 + P
    probes["-R1"] = v0 - P

    items = [("base_instr", pf, "instr"), ("base_lib", pf, "lib_cell"), ("resolution", pf, "resolution")]
    for lab, val in probes.items():
        items.append((lab, epa_fit.with_rich_slope_probe(pf, slope=float(val)), "instr"))
    ctx = multiprocessing.get_context("spawn")
    with ctx.Pool(len(items), initializer=cdiag.worker_init) as pool:
        res = pool.map(cdiag.climb_job, items, chunksize=1)
    by = {r["label"]: r for r in res}
    climb_s = time.time() - t_start

    out = {"note": "diagnostic C; no EPA loader call; no random draws (no noise stream used)",
           "plant_checks": checks, "probe_values": probes, "bounds": [lo, hi]}

    # --- reproduce the recorded climb cell, housing, noise
    base = by["base_instr"]["cell"]
    base_lib = by["base_lib"]["cell"]
    same_point = {k: (cdiag.bits(base[k]) == cdiag.bits(base_rec[k]), base[k], base_rec[k]) for k in base_rec}
    same_lib = all(cdiag.bits(base_lib[k]) == cdiag.bits(base_rec[k]) for k in base_rec)
    hs = epa_coefficients.housing(pf, base["egt"], base["mdot"], t_amb_c=T_AMB_C)
    same_hs = {k: (cdiag.bits(hs[k]) == cdiag.bits(hs_rec[k])) for k in hs_rec}
    resol = by["resolution"]["resolution"]
    noise = calibrate_epa.numerical_noise_k(hs_rec, resol)
    out["reproduction"] = {
        "climb_point_bit_for_bit_instrumented": all(v[0] for v in same_point.values()),
        "climb_point_bit_for_bit_library_climb_cell": same_lib,
        "climb_point_per_channel": same_point,
        "housing_bit_for_bit": same_hs,
        "resolution": resol,
        "resolution_egt_bits_equal": cdiag.bits(resol["egt_resolution_k"]) == cdiag.bits(pr["numerical_noise"]["egt_resolution_k"]),
        "resolution_mdot_bits_equal": cdiag.bits(resol["mdot_resolution_gps"]) == cdiag.bits(pr["numerical_noise"]["mdot_resolution_gps"]),
        "noise_k": noise, "noise_k_recorded": noise_rec,
        "noise_bits_equal": cdiag.bits(noise) == cdiag.bits(noise_rec),
    }

    # --- item 1: lambda and the rich-branch census
    out["item1"] = {"climb_point_lam": base["lam"], "climb_point_lam_recorded": base_rec["lam"],
                    "base_records": by["base_instr"].get("records"), "base_ce_calls": by["base_instr"]["ce_calls"],
                    "per_probe_ce_calls": {lab: by[lab]["ce_calls"] for lab in probes},
                    "per_probe_records": {lab: by[lab].get("records") for lab in probes}}

    # --- item 2: responses
    def h_of(cell):
        return epa_coefficients.housing_equivalent(hs_rec, cell["egt"] - base_rec["egt"],
                                                   math.log(cell["mdot"] / base_rec["mdot"]))
    rows = []
    pairs = [(f"{rel * 100:g}%", rel * abs(v0)) for rel in (0.01, rel10, 0.50, 1.00)] + [("R1", P)]
    for tag, step in pairs:
        cp, cm = by[f"+{tag}"], by[f"-{tag}"]
        if "error" in cp or "error" in cm:
            rows.append({"probe": tag, "step": step, "error_plus": cp.get("error"), "error_minus": cm.get("error")})
            continue
        hp, hm = h_of(cp["cell"]), h_of(cm["cell"])
        resp = abs(hp - hm) / 2.0
        rows.append({"probe": tag, "step": step, "slope_plus": v0 + step, "slope_minus": v0 - step,
                     "outside_bounds_plus": not (lo <= v0 + step <= hi), "outside_bounds_minus": not (lo <= v0 - step <= hi),
                     "h_plus_k": hp, "h_minus_k": hm, "response_k": resp, "response_over_noise": resp / noise_rec,
                     "slope_k_per_unit": (hp - hm) / (2.0 * step),
                     "d_egt_plus": cp["cell"]["egt"] - base_rec["egt"], "d_egt_minus": cm["cell"]["egt"] - base_rec["egt"],
                     "d_mdot_plus": cp["cell"]["mdot"] - base_rec["mdot"], "d_mdot_minus": cm["cell"]["mdot"] - base_rec["mdot"],
                     "lam_plus": cp["cell"]["lam"], "lam_minus": cm["cell"]["lam"],
                     "rich_calls_window_plus": cp["ce_calls"]["rich_in_window"],
                     "rich_calls_window_minus": cm["ce_calls"]["rich_in_window"]})
    out["item2"] = rows

    # reproduce the recorded +-10 % record through calibrate_epa.probe_sizes itself
    cells = {(F, 1): by[f"+{rel10 * 100:g}%"]["cell"], (F, -1): by[f"-{rel10 * 100:g}%"]["cell"]}
    sz = calibrate_epa.probe_sizes(base_rec, hs_rec, cells, r1_k=float(pr["r1_housing_k"]), rel=rel10, else_rel=rel10,
                                   else_cad=10.0, fields=(("cycle", F),), brackets={}, v0={F: v0},
                                   sigmas={F: spec.get("sigma")}, noise_k=noise_rec)[F]
    cmp_keys = ("method", "size", "slope_k_per_unit", "worth_r1", "response_k", "housing_change_k",
                "probe_housing_change_k", "visible_at_r1", "counted_excluded", "load_bearing")
    out["item2_reproduce_10pct"] = {
        "fields": {k: {"recomputed": sz[k], "recorded": spec[k],
                       "bit_for_bit": (cdiag.bits(sz[k]) == cdiag.bits(spec[k])) if isinstance(sz[k], float) else sz[k] == spec[k]}
                   for k in cmp_keys},
        "housing_eq_plus_bits_equal": cdiag.bits(sz["housing_eq_k"]["+"]) == cdiag.bits(spec["housing_eq_k"]["+"]),
        "housing_eq_minus_bits_equal": cdiag.bits(sz["housing_eq_k"]["-"]) == cdiag.bits(spec["housing_eq_k"]["-"]),
    }

    # --- item 3: synthetic cycles under +- the recorded probe
    pt = base_rec
    slopes = {"frozen": v0, "+probe": v0 + P, "-probe": v0 - P}
    engs = {k: epa_fit.with_rich_slope_probe(pf, slope=float(s)) for k, s in slopes.items()}
    climb_pts = {}
    for lam in (0.85, 1.0):
        climb_pts[f"{lam:g}"] = {}
        for k, p in engs.items():
            r = epa_coefficients.cyc(p, pt["rpm"], pt["map"], pt["iat"], pt["ect"], pt["spark"], lam)
            climb_pts[f"{lam:g}"][k] = {"torque_nm": r["torque"], "egt_c": r["egt"], "mdot_gps": r["mdot"]}
    grid = epa_fit.synthetic_grid(pf)
    gres = {}
    for k, p in engs.items():
        gres[k] = epa_fit._grid_results(p.engine, grid, calibrate_epa.DTHETA, p.engine)
    grid_rows = []
    for i, g in enumerate(grid):
        if g[5] not in (0.85, 1.0):
            continue
        row = {"rpm": g[0], "map": g[1], "iat": g[2], "ect": g[3], "spark": g[4], "lam": g[5]}
        for k in slopes:
            row[f"torque_{k}"] = gres[k][i].torque_nm
            row[f"egt_{k}"] = gres[k][i].egt_c
        grid_rows.append(row)
    summary = {}
    for lam in (0.85, 1.0):
        rs = [r for r in grid_rows if r["lam"] == lam]
        s = {"points": len(rs)}
        for k in slopes:
            s[f"torque_{k}_min"] = min(r[f"torque_{k}"] for r in rs)
            s[f"torque_{k}_max"] = max(r[f"torque_{k}"] for r in rs)
            s[f"egt_{k}_min"] = min(r[f"egt_{k}"] for r in rs)
            s[f"egt_{k}_max"] = max(r[f"egt_{k}"] for r in rs)
        if lam == 1.0:
            s["identical_bits_all_points"] = all(
                cdiag.bits(r[f"torque_{k}"]) == cdiag.bits(r["torque_frozen"]) and
                cdiag.bits(r[f"egt_{k}"]) == cdiag.bits(r["egt_frozen"]) for r in rs for k in slopes)
        summary[f"{lam:g}"] = s
    # where, if anywhere, the review's four numbers appear (rounded as quoted)
    quoted = {"+probe torque -132.5": ("torque_+probe", -132.5, 0.05), "+probe egt -172": ("egt_+probe", -172.0, 0.5),
              "-probe torque 10255": ("torque_-probe", 10255.0, 0.5), "-probe egt 8770": ("egt_-probe", 8770.0, 0.5)}
    matches = {}
    for q, (key, val, tol) in quoted.items():
        matches[q] = [{"rpm": r["rpm"], "map": r["map"], "spark": r["spark"], "lam": r["lam"], "value": r[key]}
                      for r in grid_rows if abs(r[key] - val) <= tol]
        k2 = key.split("_", 1)
        cp_ = climb_pts["0.85"][k2[1]]["torque_nm" if k2[0] == "torque" else "egt_c"]
        matches[q].append({"climb_point_lam_0.85": cp_, "matches": abs(cp_ - val) <= tol})
    out["item3"] = {"probe": P, "slopes": slopes, "climb_point_inputs": {k: pt[k] for k in ("rpm", "map", "iat", "ect", "spark")},
                    "climb_point": climb_pts, "grid_summary": summary, "grid_rows": grid_rows,
                    "review_numbers_located": matches}
    out["seconds"] = time.time() - t_start
    out["climb_seconds"] = climb_s
    with open(os.path.join(HERE, "step1_3.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, default=str)

    # ---- print
    print("diag C items 1-3 (frozen Mazda, engine_sha", checks["engine_sha"], "== recorded:", checks["engine_sha_equal"], ")")
    print("no EPA loader call; no random draws")
    r = out["reproduction"]
    print("REPRODUCTION: climb point bit for bit (instrumented run_climb+median_point):",
          r["climb_point_bit_for_bit_instrumented"], "; library climb_cell:", r["climb_point_bit_for_bit_library_climb_cell"])
    print("  housing hs bit for bit:", r["housing_bit_for_bit"])
    print(f"  noise {r['noise_k']!r} recorded {r['noise_k_recorded']!r} bits equal {r['noise_bits_equal']}"
          f" (egt res equal {r['resolution_egt_bits_equal']}, mdot res equal {r['resolution_mdot_bits_equal']})")
    rp = out["item2_reproduce_10pct"]
    print("  +-10 % record via calibrate_epa.probe_sizes:")
    for k, v in rp["fields"].items():
        print(f"    {k}: {v['recomputed']!r} vs {v['recorded']!r} -> {v['bit_for_bit']}")
    print("    housing_eq + equal:", rp["housing_eq_plus_bits_equal"], " - equal:", rp["housing_eq_minus_bits_equal"])
    i1 = out["item1"]
    print("ITEM 1: climb point lam", i1["climb_point_lam"], "(recorded", i1["climb_point_lam_recorded"], ")")
    print("  base climb records:", i1["base_records"])
    print("  base combustion_efficiency calls:", {k: v for k, v in i1["base_ce_calls"].items()})
    for lab, c in i1["per_probe_ce_calls"].items():
        print(f"  {lab:>7}: calls {c['total']}, rich total {c['rich_total']}, rich in window {c['rich_in_window']},"
              f" before {c['rich_before_window']}, after {c['rich_after_window']}, at reset {c['rich_at_reset']},"
              f" min lam called {c['lam_min_called']}, min lam in window {c['lam_min_called_window']}")
    print("ITEM 2: housing response to ce_rich_slope (noise", noise_rec, "K)")
    for row in rows:
        if "error_plus" in row:
            print("  ", row)
            continue
        print(f"  {row['probe']:>5} step {row['step']:.6g}: slopes {row['slope_plus']:.6g}/{row['slope_minus']:.6g}"
              f" h+ {row['h_plus_k']:+.6e} h- {row['h_minus_k']:+.6e} response {row['response_k']:.6e}"
              f" ({row['response_over_noise']:.4f} x noise) slope {row['slope_k_per_unit']:+.6e} K/unit;"
              f" dEGT {row['d_egt_plus']:+.3e}/{row['d_egt_minus']:+.3e} dmdot {row['d_mdot_plus']:+.3e}/{row['d_mdot_minus']:+.3e}"
              f" rich-in-window {row['rich_calls_window_plus']}/{row['rich_calls_window_minus']}")
    print("ITEM 3: probe", P)
    for lam, d in climb_pts.items():
        print(f"  climb point inputs at lam {lam}: " + "; ".join(
            f"{k} {v['torque_nm']:.4f} Nm EGT {v['egt_c']:.4f} C" for k, v in d.items()))
    for lam, s in summary.items():
        print(f"  synthetic grid lam {lam}: {s}")
    print("  review numbers located:", json.dumps(matches))
    print(f"seconds {out['seconds']:.1f} (climbs {climb_s:.1f})")


if __name__ == "__main__":
    main()
