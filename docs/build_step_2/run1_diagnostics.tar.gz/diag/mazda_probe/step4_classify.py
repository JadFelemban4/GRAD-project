"""Diagnostic C, item 4 and the record half of item 5: from the recorded e6 records only
(results/EPA_CALIBRATION/mazda_25t/complete.json; e6/ listed and checked for row 5/6/9 probes),
every row 5, 6 and 9 probe, and how three readings classify it, without changing code:
  (i)   decision 85 as implemented: visible when response > noise (calibrate_epa.probe_sizes);
  (ii)  visible only when response >= 2 x noise;
  (iii) a probe whose value +- size leaves epa_fit.BOUNDS is not a probe: it falls back to +-10 %.
(iii-z), reported beside (iii) and labelled so, applies (iii)'s fallback to a probe that takes the
constant across zero as well. No plant is built here; no EPA data; no random draws.
Writes step4_classify.json; prints the table."""
import glob
import json
import os
import sys

sys.path.insert(0, "C:/Users/badcl/Desktop/GRAD-project")
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
REC_DIR = "C:/Users/badcl/Desktop/GRAD-project/results/EPA_CALIBRATION/mazda_25t"


def bounds():
    """epa_fit.BOUNDS, read from the source text (no import, so no plant or derived file is touched)."""
    import ast
    src = open("C:/Users/badcl/Desktop/GRAD-project/epa_fit.py", encoding="utf-8").read()
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(getattr(t, "id", None) == "BOUNDS" for t in node.targets):
            return ast.literal_eval(node.value)
    raise RuntimeError("no BOUNDS")


def main():
    B = bounds()
    rec = json.load(open(os.path.join(REC_DIR, "complete.json"), encoding="utf-8"))
    pr = rec["e6_probes"]
    noise = float(pr["numerical_noise"]["housing_k"])
    rel = float(pr["probe_rel"])
    # e6/: does any file hold a row 5, 6 or 9 probe?
    e6 = {}
    for f in sorted(glob.glob(os.path.join(REC_DIR, "e6", "*.json"))):
        d = json.load(open(f, encoding="utf-8"))
        e6[os.path.basename(f)] = {"row": d.get("row"), "variant": d.get("variant"), "keys": sorted(d.keys()),
                                   "has_probe_keys": any(k in json.dumps(d) for k in ("response_k", "worth_r1", "visible_at_r1"))}
    probes = []
    for row, key in ((5, "row5"), (6, "row6")):
        for f, s in pr[key]["detail"].items():
            probes.append((row, f, s))
    for f, s in pr["row9"].items():
        probes.append((9, f, s))

    table = []
    for row, f, s in probes:
        v, size, resp, method = float(s["value"]), float(s["size"]), float(s["response_k"]), s["method"]
        lo_v, hi_v = v - size, v + size
        b = B.get(f)
        outside = None if b is None else bool(lo_v < b[0] or hi_v > b[1])
        crosses = bool((lo_v < 0.0 < v) or (hi_v > 0.0 > v) or (v > 0 and lo_v == 0.0))
        # (i) recomputed from the record's own numbers, checked against the record's flags
        vis_i = resp > noise
        assert (method == "bracket") or (vis_i == bool(s["visible_at_r1"])), (f, vis_i, s["visible_at_r1"])

        def cls(visible, fallback_by_bounds):
            if method == "bracket":
                return "bracket (kept; a band, not a visibility probe)"
            if not visible:
                return f"fallback +-{rel * 100:g} %, not visible at R1, counted excluded"
            if fallback_by_bounds:
                return f"fallback +-{rel * 100:g} % (probe leaves its bounds), visible, not excluded"
            return "probe at worth-R1 size, visible, not excluded"
        c_rec = ("bracket (kept; a band, not a visibility probe)" if method == "bracket" else
                 (f"fallback +-{rel * 100:g} %, not visible at R1, counted excluded" if s["counted_excluded"] else
                  "probe at worth-R1 size, visible, not excluded"))
        c_i = cls(vis_i, False)
        c_ii = cls(resp >= 2.0 * noise, False)
        c_iii = cls(vis_i, bool(outside) and method == "probe")
        c_iiiz = cls(vis_i, (bool(outside) or crosses) and method == "probe")
        c_ii_iii = cls(resp >= 2.0 * noise, bool(outside) and method == "probe")
        table.append({"row": row, "constant": f, "record": s["record"], "value": v, "method": method, "size": size,
                      "value_minus_size": lo_v, "value_plus_size": hi_v,
                      "h_plus_k": s["housing_eq_k"]["+"], "h_minus_k": s["housing_eq_k"]["-"],
                      "response_k": resp, "response_over_noise": resp / noise,
                      "bounds": b, "outside_bounds": outside, "crosses_zero": crosses,
                      "visible_at_r1_recorded": s["visible_at_r1"], "counted_excluded_recorded": s["counted_excluded"],
                      "class_recorded": c_rec, "class_i": c_i, "class_ii": c_ii, "class_iii": c_iii,
                      "class_iii_z": c_iiiz, "class_ii_and_iii": c_ii_iii,
                      "fallback_size_if_falls_back": rel * abs(v)})
    changes = {k: [t["constant"] for t in table if t[k] != t["class_i"]]
               for k in ("class_ii", "class_iii", "class_iii_z", "class_ii_and_iii")}
    i_equals_recorded = all(t["class_i"] == t["class_recorded"] for t in table)
    out = {"note": "records only; no plant built; no EPA data; no random draws", "noise_k": noise,
           "two_noise_k": 2 * noise, "probe_rel": rel, "bounds": {k: v for k, v in B.items()},
           "e6_files": e6, "table": table, "changes_vs_i": changes, "class_i_equals_recorded": i_equals_recorded}
    with open(os.path.join(HERE, "step4_classify.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1)

    print("diag C item 4 (records only: complete.json; no plant; no EPA data; no random draws)")
    print(f"noise {noise!r} K; 2 x noise {2 * noise!r} K; probe_rel {rel}")
    print("e6/ files:", {k: (v["row"], v["variant"], "probe keys" if v["has_probe_keys"] else "no probe keys") for k, v in e6.items()})
    hdr = (f"{'row':>3} {'constant':<15} {'value':>12} {'method':<8} {'size':>12} {'v-size':>12} {'v+size':>12}"
           f" {'response K':>11} {'resp/noise':>11} {'outBOUNDS':>9} {'x0':>5}  class(i)=recorded? | (ii) | (iii) | (iii-z)")
    print(hdr)
    for t in table:
        ob = "-" if t["outside_bounds"] is None else ("YES" if t["outside_bounds"] else "no")
        short = {"probe at worth-R1 size, visible, not excluded": "probe/vis",
                 f"fallback +-{rel * 100:g} %, not visible at R1, counted excluded": "fallback/NOTvis/excl",
                 f"fallback +-{rel * 100:g} % (probe leaves its bounds), visible, not excluded": "fallback(bounds)/vis",
                 "bracket (kept; a band, not a visibility probe)": "bracket"}
        print(f"{t['row']:>3} {t['constant']:<15} {t['value']:>12.6g} {t['method']:<8} {t['size']:>12.6g}"
              f" {t['value_minus_size']:>12.6g} {t['value_plus_size']:>12.6g} {t['response_k']:>11.4g}"
              f" {t['response_over_noise']:>11.4g} {ob:>9} {'YES' if t['crosses_zero'] else 'no':>5}  "
              f"{short[t['class_i']]}={'Y' if t['class_i'] == t['class_recorded'] else 'N'} | {short[t['class_ii']]} | "
              f"{short[t['class_iii']]} | {short[t['class_iii_z']]}")
    print("class (i) equals the recorded class for every probe:", i_equals_recorded)
    print("probes that change class against (i):", json.dumps(changes))
    print("record check, review item 5:")
    for f in ("n_poly", "t_head_k", "port_pickup_k", "burn_res", "delay_res"):
        t = next(x for x in table if x["constant"] == f)
        print(f"  {f}: value {t['value']!r} size {t['size']!r} -> [{t['value_minus_size']!r}, {t['value_plus_size']!r}];"
              f" h+ {t['h_plus_k']!r} h- {t['h_minus_k']!r}")
    print("  every probe whose value - size < 0 < value:",
          [(t["constant"], t["value"], t["size"], t["value_minus_size"]) for t in table if t["crosses_zero"]])


if __name__ == "__main__":
    main()
