DIAGNOSTIC C: the Mazda's E6 rich-slope probe. Measurement only.

**Report file:** the Write tool refused to create `report.md` ("Subagents should return findings as text"), so this text is the only copy of the report.

Every script, output and JSON file is in `C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/diag/mazda_probe`. Each script was run from that folder as `C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe -B <script>.py > <script>.out`.

## Setup and provenance

- **Environment:** Python 3.13.2, NumPy 2.5.3, SciPy 1.18.1, Windows-11-10.0.26200. These are the versions in `complete.json`'s provenance. One BLAS thread, and DERIVING_PARAMS=1 as complete runs (step0_build.out).
- **Plant:** built the way `calibrate_epa.complete` builds pf. The source is step0_build.py, the output step0_build.out.
  - `calibrate_epa._frozen_fit` reads freeze.json and fit_A+B+C+D.json and checks the hash.
  - `data/engines/mazda_25t/derived_params.json` is read with `epa_freeze.read_json` and checked with `epa_freeze.check_frozen`.
  - Then `calibrate_epa._completed`, `calibrate_epa._plant` and `_assert_finite`.
  - The result: engine_sha 2558cb2bcad4f2c6, which equals complete.json's. Form A+B+C+D, ce_rich_slope 0.43470705817534516.
- **Loader calls: none.** No call to `calibrate_epa._load`, `epa_rows.calibration_contract`, `epa_rows.calibration_rows` or the held-out reader. From `epa_rows`, only the `Source.repository()` dataclass is used.
- **Files opened, other than .py:**
  - complete.json, freeze.json and fit_A+B+C+D.json
  - `data/engines/mazda_25t/derived_params.json`
  - `data/derived_params.json` (the B58's file, opened by engines at import)
  - `engine_specs/*.toml`
- **Audit hook:** installed in every process, workers included. It refuses to open any epa_*.csv, any epa_engine.json, anything else under data/engines/, and anything under logs/. It also refuses any write inside the repository. It never fired, and git status is the same as at the start.
- **Random draws:** none were made, so no noise stream was used, including [0x7D, k].
- **Data:** only synthetic operating points and the climb. No EPA row.

## Reproductions, done first

Source: step1_3.py; outputs step1_3.out and step1_3.json.

- **Climb point:** all 11 channels reproduce bit for bit. That holds through the library's `epa_coefficients.climb_cell`, and also through `run_climb` plus `median_point` with my instrumentation.
- **Housing record:** all six fields (f, tau_s, dTh_per_unit_ln_mdot, ua_gas_turb, ua_turb_amb, c_turb) reproduce bit for bit.
- **Noise:** `climb_cell_resolution` followed by `calibrate_epa.numerical_noise_k` gives 1.821936093778558e-4 K, bit for bit. The EGT and mdot resolutions are bit for bit too.
- **The ±10 % record:** recomputed through `calibrate_epa.probe_sizes`, every field equals the record bit for bit:
  - h+ = +1.7633729286405125e-4 K and h- = -1.9654957618808652e-4 K
  - response_k 1.8644343452606888e-4 K (1.023 times the noise)
  - slope 0.004288944267632855 K per unit
  - size = worth_r1 = 2331.576111973863
  - housing_change_k 2.0059625645895492e-4
  - visible True, counted_excluded False, load_bearing False

## 1. Lambda in the climb cell

Sources: step1_3.out, and show_extra.py → show_extra.out.

- **Climb point:** lambda 1.0, the median over t = 400–718 s (319 samples). The recorded value is also 1.0.
- **Inside the window:** all 319 steps are at lambda exactly 1.0. Of the 1914 calls to `plant.combustion_efficiency` there, none takes the rich branch.
- **Whole climb (719 steps):** the rich branch is taken only at t = 19 and 20, at lambda 0.81502 and 0.91849. That is 12 calls, none at reset and none after the window.
- **Every probe from ±1 % to ±100 %** shows the same 12 calls at the same two steps.
- **The only reader:** grep finds plant.py:71 as the only line in plant or environment code that reads ce_rich_slope. So inside the climb the constant acts only through those 12 calls, all before the window. Which state carries their effect into the window was not measured.

## 2. Housing response to ce_rich_slope

Source: step1_3.out. The noise is 1.821936e-4 K.

| probe | step | h+ (K) | h- (K) | response (K) | / noise | K per unit |
|---|---|---|---|---|---|---|
| ±1 % | 0.0043471 | +1.981319e-05 | -2.219396e-05 | 2.100358e-05 | 0.1153 | 4.832e-03 |
| ±10 % | 0.043471 | +1.763373e-04 | -1.965496e-04 | 1.864434e-04 | 1.0233 | 4.289e-03 |
| ±50 % | 0.21735 | +9.004053e-04 | -8.989496e-04 | 8.996775e-04 | 4.9380 | 4.139e-03 |
| ±100 % | 0.43471 | +1.786128e-03 | -1.784726e-03 | 1.785427e-03 | 9.7996 | 4.107e-03 |
| ±worth R1 | 2331.576 | -9.165045e+02 | -4.723495e-02 | 4.582286e+02 | 2.52e6 | -1.965e-01 |

**From ±1 % to ±100 %, the response scales with the probe:**
- The sign is consistent: h+ > 0 and h- < 0 at every probe. EGT and flow also move with a consistent sign.
- The response grows 85-fold while the probe grows 100-fold.
- The response per unit of slope stays between 4.11e-3 and 4.83e-3 K.
- At ±1 % the response is 0.115 times the noise and still keeps its sign.
- The 1.02× reading at ±10 % is a point on this line, not a reading of random sign at the noise level.
- These probes stay inside [0, 1.5]; at -100 % the slope is exactly 0.

**At the worth-R1 probe the response is 458.2 K, not the 10 K the linear slope sized it for:**
- **+R1 (slope 2332.01):** the whole window runs at lambda 0.75547. 701 of 719 steps are rich (4206 calls). The cell's EGT moves -1100 K, its flow +76.5 g/s, and h+ is -916.5 K.
- **-R1 (slope -2331.14):** the window stays at lambda 1.0, with the rich branch taken only at step 19 (6 calls). h- is -0.047 K.
- Both sides lower the housing, and neither climb terminated.
- Why the +R1 climb runs rich was not measured.

## 3. The synthetic check, repeated independently

Sources: step1_3.out, and step3_eta.py → step3_eta.out.

**At the recorded climb point's inputs** (rpm 4107.16, MAP 166.87 kPa, IAT 330.07 K, ECT 366.09 K, spark 11.567), run through `epa_coefficients.cyc` with the ECU's cam and the backpressure law:

| lambda | frozen slope | +probe (2332.01) | -probe (-2331.14) |
|---|---|---|---|
| 0.85 | 293.7575 Nm, EGT 829.2593 C | -144.2799 Nm, EGT -188.2106 C | 17144.2782 Nm, EGT 13216.6560 C |
| 1.0 | 309.5422 Nm, EGT 884.9988 C | identical | identical |

**At `epa_fit.synthetic_grid`'s points (40 per lambda):**
- At lambda 0.85:
  - +probe: torque -203.8 to -33.4 Nm, EGT -209.8 to 97.3 C.
  - -probe: torque 1129.5 to 29659 Nm, EGT 1510 to 14285 C.
  - Frozen, for comparison: 32.2 to 493.5 Nm, 294.2 to 843.5 C.
- At lambda 1.0, every point is bit-identical under all three slopes.

**`plant.combustion_efficiency` itself:**
- At lambda 0.85: 0.934794 frozen, -348.802 at +probe, +350.671 at -probe.
- At lambda 1.0: 1 under all three slopes.
- The rich branch (plant.py:70-71) has no clip.

**The review's four numbers** (-132.5 Nm, -172 C, 10255 Nm, 8770 C) appear neither at the climb point nor at any of the 40 grid points at lambda 0.85. The task does not give the review's operating point, so those exact numbers are not reproduced. The pattern does reproduce: at 0.85 the +probe reverses the sign of torque and EGT and the -probe raises both by an order of magnitude; at 1.0 nothing changes.

## 4. Every row 5, 6 and 9 probe, from the records

Source: step4_classify.py; outputs step4_classify.out and step4_classify.json.

- The table comes from complete.json alone. The e6/ files (row1, row2, row3, row7_090, row7_110) are refit variants and hold no row 5, 6 or 9 probe.
- The noise is 1.821936e-4 K, so twice the noise (2u) is 3.643872e-4 K.
- In the x0 column, YES means value - size < 0 < value.
- The last column is the class as recorded. Reading (i), recomputed from the recorded numbers, matches it for all 24 probes.

| row | constant | value | method | size | v - size | v + size | response (K) | / noise | BOUNDS | outside | x0 | class as recorded |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 5 | exh_bp_ratio | 1.11693 | probe | 0.0493463 | 1.06759 | 1.16628 | 22.63 | 1.24e5 | (1.0, 2.5) | no | no | probe, visible |
| 5 | exh_bp_min_kpa | 104.992 | fallback | 10.4992 | 94.4924 | 115.491 | 4.604e-5 | 0.2527 | (80, 140) | no | no | fallback ±10 %, not visible, excluded |
| 6 | ua_port | 21.8257 | probe | 2.40095 | 19.4247 | 24.2266 | 9.09 | 4.99e4 | (0, 1000) | no | no | probe, visible |
| 9 | conrod | 0.152615 | probe | 0.268179 | -0.115565 | 0.420794 | 0.5691 | 3123 | none | - | YES | probe, visible |
| 9 | ivc_deg | -140 | bracket | 59.702 | -199.702 | -80.298 | 10.99 | 6.03e4 | none | - | no | bracket |
| 9 | evo_deg | 140 | bracket | 28.606 | 111.394 | 168.606 | 11.5 | 6.31e4 | none | - | no | bracket |
| 9 | t_head_k | 90 | probe | 129.558 | -39.5578 | 219.558 | 0.6947 | 3813 | none | - | YES | probe, visible |
| 9 | port_pickup_k | 12 | probe | 24.3907 | -12.3907 | 36.3907 | 0.492 | 2700 | none | - | YES | probe, visible |
| 9 | t_residual_k | 780 | probe | 93.3994 | 686.601 | 873.399 | 8.351 | 4.58e4 | none | - | no | probe, visible |
| 9 | cp_exh | 1150 | probe | 125.418 | 1024.58 | 1275.42 | 9.169 | 5.03e4 | none | - | no | probe, visible |
| 9 | burn_res | 2 | probe | 4.46753 | -2.46753 | 6.46753 | 0.4477 | 2457 | none | - | YES | probe, visible |
| 9 | delay_res | 1.5 | probe | 1.822 | -0.321998 | 3.322 | 0.8233 | 4519 | none | - | YES | probe, visible |
| 9 | flame_lam | 0.9 | probe | 0.0932909 | 0.806709 | 0.993291 | 9.647 | 5.30e4 | none | - | no | probe, visible |
| 9 | flame_width | 0.42 | probe | 0.310897 | 0.109103 | 0.730897 | 1.351 | 7415 | none | - | no | probe, visible |
| 9 | flame_floor | 0.25 | fallback | 0.025 | 0.225 | 0.275 | 0 | 0 | none | - | no | fallback, not visible, excluded |
| 9 | wiebe_a | 5 | probe | 4.45052 | 0.549482 | 9.45052 | 1.123 | 6166 | none | - | no | probe, visible |
| 9 | wiebe_m | 2 | probe | 0.616527 | 1.38347 | 2.61653 | 3.244 | 1.78e4 | none | - | no | probe, visible |
| 9 | ce_rich_slope | 0.434707 | probe | 2331.58 | -2331.14 | 2332.01 | 1.864e-4 | 1.023 | (0, 1.5) | YES | YES | probe, visible |
| 9 | fres_a | 0.035 | probe | 0.0624899 | -0.0274899 | 0.0974899 | 0.5601 | 3074 | none | - | YES | probe, visible |
| 9 | fres_b | 6.5 | probe | 10.4498 | -3.94983 | 16.9498 | 0.622 | 3414 | none | - | YES | probe, visible |
| 9 | fres_map_min | 25 | fallback | 2.5 | 22.5 | 27.5 | 0 | 0 | none | - | no | fallback, not visible, excluded |
| 9 | fres_lo | 0.03 | fallback | 0.003 | 0.027 | 0.033 | 0 | 0 | none | - | no | fallback, not visible, excluded |
| 9 | fres_hi | 0.18 | fallback | 0.018 | 0.162 | 0.198 | 0 | 0 | none | - | no | fallback, not visible, excluded |
| 9 | n_poly | 1.32 | probe | 0.0307326 | 1.28927 | 1.35073 | 42.95 | 2.36e5 | none | - | no | probe, visible |

**The three readings:**
- **(i) Decision 85 as implemented (response > noise):** for all 24 probes, the class equals the recorded class.
- **(ii) Visible only at response ≥ 2 × noise:** only ce_rich_slope changes. Its ratio is 1.023, so it becomes not visible, falls back to ±0.0434707 and is counted excluded.
  - Among the other probes the method uses, the smallest ratio is burn_res's 2457. exh_bp_min_kpa is already not visible.
  - So any threshold between 1.023 and 2457 times the noise changes ce_rich_slope alone.
- **(iii) A probe that leaves `epa_fit.BOUNDS` falls back to ±10 %:** only ce_rich_slope changes. Its probe spans [-2331.14, 2332.01] against bounds of (0, 1.5), so it falls back to ±0.0434707.
  - Only 4 of the 24 probed constants have a BOUNDS entry (exh_bp_ratio, exh_bp_min_kpa, ua_port, ce_rich_slope). The other three stay inside.
  - Under (iii) alone, ce_rich_slope stays visible (1.023 > 1) and is not excluded. Under (ii) and (iii) together it is fallback, not visible and excluded.
- **Supplementary, not one of the three readings (iii-z):** if crossing zero also made a probe fall back, 8 would change: conrod, t_head_k, port_pickup_k, burn_res, delay_res, ce_rich_slope, fres_a and fres_b.

**Brackets:** validate_epa.py:2196 applies a bracket as v0 ± size.
- For ivc_deg that gives [-199.702, -80.298], against the bracket [-154.269, -80.298].
- For evo_deg it gives [111.394, 168.606], against [119.822, 168.606].
- Neither constant has a BOUNDS entry, and no reading reclassifies them.

## 5. The review's notes, checked against the records and the code

Sources: step4_classify.out, and step5_negcheck.py → step5_negcheck.out and step5_negcheck.json. The cycles were run at the climb point's inputs. Probed plants are built with `epa_fit.perturbed`, which goes through `dataclasses.replace` and therefore the classes' `__post_init__` checks.

What those checks cover:
- `CycleCal.__post_init__` (engines.py:264-302) checks only the type and finiteness of ve_map, ve_map_ref_kpa, ce_rich_slope, ve_cam and cam_ref_deg, and that each term fits the form.
- `Engine.__post_init__` (engines.py:558-619) checks the fuel's two copies, the lambda clip and cam_on.
- `Geometry.__post_init__` (engines.py:154-160) only computes derived lengths.

**n_poly: confirmed.**
- At ±10 % of 1.32: h+ = +85.89981756746283 K, h- = -0.0024597432934898235 K.
- The response is 42.95 K, the slope 325.39 K per unit, and the worth-R1 size 0.030733.
- These are two points, and I ran no sweep. Whether there is a kink between them was not measured.

**t_head_k: confirmed.** 90 ± 129.5578 reaches -39.558.
- Code: used linearly at plant.py:222 (t_wall = 0.5 ect + 0.5 (ect + t_head_k)). Not clipped, not rejected.
- Builds; the cycle is finite (309.149 Nm, 873.124 C at lambda 1).

**port_pickup_k: confirmed.** 12 ± 24.3907 reaches -12.391.
- Code: used linearly at plant.py:228. Not clipped, not rejected.
- Builds; the cycle is finite (312.509 Nm, 876.506 C).

**burn_res: confirmed.** 2.0 ± 4.4675 reaches -2.4675.
- Code: plant.py:122 does not clip it, and nothing rejects it.
- f_res is clipped to [0.03, 0.18] at plant.py:135, so at the -probe the factor (1 + burn_res·f_res) lies in [0.556, 0.926].
- The cycle is finite (311.387 Nm, 876.800 C).

**delay_res: confirmed.** 1.5 ± 1.8220 reaches -0.3220.
- Code: plant.py:128, the same pattern as burn_res. Not clipped, not rejected.
- The factor at the -probe lies in [0.942, 0.990].
- The cycle is finite (311.645 Nm, 876.516 C).

**Correction: four more probes cross zero.** The review's list of four leaves these out:
- conrod 0.152615 ± 0.268179 reaches -0.115565.
- fres_a 0.035 ± 0.062490 reaches -0.027490.
- fres_b 6.5 ± 10.4498 reaches -3.9498.
- ce_rich_slope 0.434707 ± 2331.576 reaches -2331.141.

How the code handles each:
- **conrod:** no clip and no rejection.
  - `Geometry.volume` uses l = conrod in sqrt(l² - a² sin²), and V = vc + A(l + a - s).
  - The plant builds without error. At the -probe, V is negative at all 1121 crank steps (-1.372e-3 m³ at TDC).
  - The cycle returns torque NaN and EGT NaN at lambda 1.0 and 0.85 without raising. The +probe is finite (307.096 Nm).
- **fres_a and fres_b:** not rejected.
  - plant.py:135 clips the residual fraction to [0.03, 0.18].
  - At the climb MAP the -probe gives an unclipped 0.01146 (fres_a) and 0.01133 (fres_b), so the clip binds at 0.03. The frozen value is 0.07395.
  - The cycles are finite (326.712 Nm).
- **ce_rich_slope:** `CycleCal` checks only that it is a finite Python float and that the form has C. There is no sign or range check, and the rich branch has no clip.
  - `epa_fit.BOUNDS` (0, 1.5) is S5's Brent interval (epa_fit.py:2099); the plant does not read it.
  - The cycles are finite at both lambdas (values in section 3).

## What the measurements show

1. **Lambda:** the climb cell sits at lambda 1.0 for its whole window. The rich branch is the only code that reads ce_rich_slope, and in the climb it is taken only at seconds 19 and 20, before the window. The constant reaches the cell only through what those two steps carry forward.
2. **The response is real, not noise:** that route gives a small, smooth response with a consistent sign, 4.1–4.8e-3 K per unit of slope from ±1 % to ±100 %. It scales with the probe and keeps its sign even at 0.115 times decision 85's noise. The recorded 1.864e-4 K at ±10 % is reproduced bit for bit and lies on that line.
3. **The worth-R1 probe does not do what it was sized for:** decision 85 passes the probe by a ratio of 1.023. Extrapolating linearly gives a probe of 2331.6, about 5364 times the value and 1554 times the width of BOUNDS.
   - On the climb, the + side runs at lambda 0.755 and moves the housing -916.5 K; the - side moves it -0.047 K.
   - At single synthetic cycles it gives combustion efficiencies of -348.8 and +350.7 at lambda 0.85, and no change at lambda 1.0.
4. **Readings (ii) and (iii)** each reclassify one probe, ce_rich_slope. If crossing zero also counted, eight would change.
5. **Zero-crossing probes:** nothing in plant.py or engines.py rejects any of the eight. Only conrod's gives a non-finite cycle at the climb inputs.

===== CHECK
{
 "verdict": "confirmed_with_corrections",
 "corrections": [
  "Order of the two rich steps is reversed. The report says 'the rich branch is taken only at t = 19 and 20, at lambda 0.81502 and 0.91849'. The climb records give t=19 at lambda 0.9184911251068115 and t=20 at 0.8150161504745483. At -R1 only t=19 (0.918) is rich, and t=20 runs at lambda 1.0. Source: check_climbs.out, the base row and the -R1 row.",
  "There is no report.md in the diagnostic's folder (C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/diag/mazda_probe/report.md does not exist). The diagnostic says so itself. The task text's statement that the report is 'also at .../report.md' is wrong.",
  "'Audit hook: installed in every process' holds only for the scripts that import cdiag: step0_build, step1_3 and its workers, step3_eta and step5_negcheck. step4_classify.py, dump_records.py and show_extra.py ran without the hook. From their source, they open only complete.json, e6/*.json, epa_fit.py as text, and the diagnostic's own step1_3.json. No number changes.",
  "'It never fired' cannot be shown from the diagnostic's outputs, because its hook raises without keeping a count. My hook does count refusals, and it recorded none on the same code paths: the main process and all 12 workers in check_climbs.out, plus check_cycles.out and check_records.out.",
  "The diagnostic cites step0_build.out for 'one BLAS thread and DERIVING_PARAMS=1'. That file does not print either setting; they are set in cdiag.py lines 20-24.",
  "The 'Files opened' list is step0_build's main process only. step1_3's workers and the later scripts printed no list.",
  "CycleCal.__post_init__ also checks that form is a str and is one of CYCLE_FORMS. It is not limited to the five fields' type and finiteness plus the form-term checks. This does not change any conclusion.",
  "'n_poly: confirmed' confirms the two recorded numbers only: h+ +85.89981756746283 K and h- -0.0024597432934898235 K. As the diagnostic says itself, nothing measures whether there is a kink between them."
 ],
 "rules_kept": true,
 "rules_evidence": "Loader calls: none, in the diagnostic's scripts or in mine. A grep of both script sets finds no calibrate_epa._load, no epa_rows.calibration_contract or calibration_rows, no held-out reader, no cal_rows or valve_brackets, and no random draws (no default_rng). epa_rows is used only for Source.repository(). No EPA row is read.\n\nMy audit hook refuses and counts any write inside the repository, any open of logs/, epa_*.csv or epa_engine.json, and any file under data/engines/ other than a derived_params.json. It counted 0 refusals in every process.\n\ngit status --short, before and after, shows only '?? data/engines/mazda_25t/derived_params.json' and '?? results/EPA_CALIBRATION/'.\n\nThe Mazda Run 1 files were last modified between 17:13 and 17:53. The diagnostic's earliest file is from 18:34 and my check ran from 19:02. The SHA-256 of the derived file (04539bff...) and of the five e6 files equal the hashes complete.json records.\n\nFiles under honda_l15b7/ and ford_27tt/ in results/EPA_CALIBRATION changed at 18:00-18:11. That is before either diagnostic ran, so neither made those changes.\n\nAll my scripts and outputs are in C:/Users/badcl/AppData/Local/Temp/claude/c--Users-badcl-Desktop-GRAD-project/14077827-1e2d-4826-b805-20b70e9c81f2/scratchpad/diag/mazda_probe/check/. I did not write report.md: this session's standing instruction to subagents forbids writing report .md files, and the diagnostic's attempt was refused for the same reason. The report is this structured output.",
 "what_it_shows": "I re-ran the deciding numbers independently and they reproduce. Each climb went through the library epa_coefficients.climb_cell in fresh workers, on the frozen plant (engine_sha 2558cb2bcad4f2c6, Python 3.13.2, NumPy 2.5.3, as complete.json records). Commands, run from the check folder: `C:/Users/badcl/Desktop/GRAD-project/.venv/Scripts/python.exe -B check_climbs.py > check_climbs.out`, then check_records.py and check_cycles.py the same way.\n\n**Reproductions, bit for bit:**\n- The climb point.\n- The housing record.\n- Decision 85's noise, 1.821936093778558e-4 K.\n- The +-10 % probe: h+ +1.7633729286405125e-4 K, h- -1.9654957618808652e-4 K, response 1.8644343452606888e-4 K.\n\n**Item 1, the climb cell's lambda:**\n- All 319 window samples run at lambda 1.0, and none of the 1914 combustion_efficiency calls in the window is rich.\n- The rich branch is taken only at t=19 (lambda 0.9185) and t=20 (lambda 0.8150): 12 calls, all before the window.\n- plant.py:71 is the only plant or environment line that reads ce_rich_slope.\n\n**Item 2, the response scales with the probe, with one sign throughout:**\n\n| probe | response (K) | x noise |\n|---|---|---|\n| +-1 % | 2.100e-5 | 0.115 |\n| +-10 % | 1.864e-4 | 1.023 |\n| +-50 % | 8.997e-4 | 4.94 |\n| +-100 % | 1.785e-3 | 9.80 |\n\nThat is 4.11e-3 to 4.83e-3 K per unit of slope, with h+ > 0 and h- < 0 at every size.\n\n**Item 2, the worth-R1 probe:**\n- The probe is +-2331.58: 5364 times the value and outside BOUNDS (0, 1.5).\n- +R1 runs the window at lambda 0.7555 and moves the housing -916.5 K; -R1 moves it -0.047 K.\n- The response is 458.2 K, against the 10 K it was sized for.\n\n**Item 3, single cycles at the climb inputs:**\n- At lambda 0.85: frozen 293.7575 Nm, +R1 -144.2799 Nm (EGT -188.21 C), -R1 17144.28 Nm (EGT 13216.66 C).\n- At lambda 1.0 nothing moves, bit for bit.\n- The review's four numbers (-132.5 Nm, -172 C, 10255 Nm, 8770 C) are not reproduced at any single synthetic-grid point. At 1 % tolerance, -132.5 Nm and 8770 C each appear only at different points, and the other two at none.\n\n**Item 4, classification under the three readings:**\n- Reading (i), recomputed, matches all 24 recorded classes.\n- Readings (ii) and (iii) each change only ce_rich_slope. Its ratio is 1.023; the next-smallest probe ratio is burn_res's 2457.\n\n**Item 5, probes that cross zero:**\n- 8 probes take their constant below zero: conrod, t_head_k, port_pickup_k, burn_res, delay_res, fres_a, fres_b and ce_rich_slope.\n- No code rejects any of them. Only conrod's -probe gives a non-finite cycle: V < 0 at all 1121 crank steps, and torque and EGT are NaN.\n\n**Not asked, from the records:** besides n_poly, the +-10 % responses of flame_lam (+2.07 / +21.37 K) and wiebe_m (+1.64 / +8.12 K) have the same sign on both sides."
}