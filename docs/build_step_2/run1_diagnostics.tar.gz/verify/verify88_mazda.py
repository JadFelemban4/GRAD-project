"""Verification of decision 88 as implemented (measurement only; implementer's check, 29 October 2026).

The frozen Mazda of Run 1's second pass, built as calibrate_epa.complete builds its final plant (diagnostic C's
cdiag.build_pf, its audit hook installed: no EPA loader call, no EPA table, no write inside the repository), and
every worth-R1 probe complete.json recorded for rows 5, 6 and 9 (method "probe", at the size recorded), judged by
the working tree's calibrate_epa.range_cycles and range_tests against epa_fit.BOUNDS at the recorded climb point.
Writes only beside this script.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "diag", "mazda_probe"))
import cdiag  # noqa: E402  (sets one BLAS thread, DERIVING_PARAMS=1, the audit hook; puts the repo on sys.path)

import calibrate_epa  # noqa: E402
import epa_fit  # noqa: E402


def main():
    rec = cdiag.recorded()
    pf, checks = cdiag.build_pf()
    if not checks["engine_sha_equal"]:
        raise SystemExit("the plant is not complete.json's")
    probes = rec["e6_probes"]
    point = probes["climb_cell"]["point"]
    recs = {}
    for key in ("row5", "row6"):
        recs.update(probes[key]["detail"])
    recs.update(probes["row9"])
    first = {}
    for f, r in recs.items():
        if r["method"] == "probe":
            v, s = float(r["value"]), float(r["size"])
            first[f] = {"method": "probe", "record": r["record"], "values": {"+": v + s, "-": v - s}}
    cycles = calibrate_epa.range_cycles(pf, point, first)
    out = {"engine_sha_equal": checks["engine_sha_equal"], "point": {k: point[k] for k in
                                                                    ("rpm", "map", "iat", "ect", "spark", "lam")},
           "probes": {}}
    for f in sorted(first):
        r = recs[f]
        t = calibrate_epa.range_tests(f, float(r["value"]), float(r["size"]), bounds=epa_fit.BOUNDS, cycles=cycles)
        failed = [k for k in calibrate_epa.RANGE_TESTS if t[k]["fails"]]
        out["probes"][f] = {"value": r["value"], "worth_r1": r["size"], "failed": failed, "tests": t}
        c = t["finite"]["cycles"]
        print(f"{f:16s} v0 {r['value']:.6g} worth {r['size']:.6g}: [{r['value'] - r['size']:.6g}, "
              f"{r['value'] + r['size']:.6g}] BOUNDS {t['bounds']['entry']} -> fails {failed}; torque +/- "
              f"{c['+']['torque']} / {c['-']['torque']}, egt +/- {c['+']['egt']} / {c['-']['egt']}")
    print("beyond range:", sorted(f for f, v in out["probes"].items() if v["failed"]))
    print("files opened (non-.py):", sorted(set(cdiag.OPENED)))
    with open(os.path.join(HERE, "verify88_mazda.json"), "w", encoding="utf-8") as fh:
        json.dump(calibrate_epa.epa_fit.json_safe(out), fh, indent=1, allow_nan=False)


if __name__ == "__main__":
    main()
