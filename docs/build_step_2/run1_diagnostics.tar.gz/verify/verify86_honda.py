"""Verification of decision 86 as implemented (measurement only; implementer's check, 29 October 2026).

The Honda's T0 seeds 1-3 rows (epa_fit.t0_rows, T0_STREAM's own seeds; no extra draw), the fitted flat
intervals as Run 1's second pass recorded them (results/EPA_CALIBRATION/honda_l15b7/t0.json, read only), and the
working tree's epa_fit.d2_gate_case with the truth's ECU and the T0 rows. Reads EPA data ONLY through
calibrate_epa._load (the calibration view and yield); no held-out reader; writes only beside this script.
"""
import json
import os
import struct
import sys

os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.dont_write_bytecode = True
REPO = r"C:\Users\badcl\Desktop\GRAD-project"
OUT = os.path.dirname(os.path.abspath(__file__))
if REPO not in sys.path:
    sys.path.insert(0, REPO)
NAME = "honda_l15b7"
JOBS = 16


def bits(v):
    return struct.pack("<d", float(v)).hex()


def main():
    import calibrate_epa
    import epa_fit
    import epa_rows
    source = epa_rows.Source.repository()
    view, yield_ = calibrate_epa._load(NAME, source=source)
    rec = json.load(open(os.path.join(REPO, "results", "EPA_CALIBRATION", NAME, "t0.json"), encoding="utf-8"))
    rec_d2 = rec["cases"]["d2_gate"]["detail"]
    truths = epa_fit.t0_truths(NAME, view=view, yield_=yield_)
    inform = [t for t in truths if not t.out_of_form]
    out = {"loader_calls": ["calibrate_epa._load (epa_rows.calibration_contract, epa_rows.calibration_rows)"],
           "dtheta": calibrate_epa.DTHETA, "seeds": {}}
    for tr, rd in zip(inform, rec_d2):
        rows = epa_fit.t0_rows(yield_, truth=tr, seed=tr.seed, view=view, dtheta=calibrate_epa.DTHETA, jobs=JOBS)
        cal = epa_fit.cal_rows(rows)
        tcand = epa_fit.candidate(NAME, tr.values)
        got = epa_fit.d2_gate_case(rd["flat_gates_kpa"], tr.values["ecu"]["enr_load"],
                                   [r.map_kpa for r in cal if epa_fit._final(r)], fitted_gate_kpa=rd["fitted_gate_kpa"],
                                   step_kpa=epa_fit.S3B_GATE_STEP_KPA, truth_ecu=tcand.engine.ecu, rows=cal)
        d = got["detail"]
        old_keys = [k for k in rd if k != "rule"]
        same = {k: (json.dumps(d[k], sort_keys=True) == json.dumps(rd[k], sort_keys=True)) for k in old_keys}
        out["seeds"][str(tr.seed)] = {"recorded_ok_case": None, "ok": got["ok"], "detail": d,
                                      "decision_84_fields_equal_to_record": same,
                                      "truth_gate_bits": bits(tr.values["ecu"]["enr_load"])}
        e = d["decision_86"]
        print(f"seed {tr.seed}: flat {d['flat_gates_kpa']} truth {d['truth_gate_kpa']!r} ok {got['ok']} "
              f"(grid {d['within_grid_step']}, final gap {d['within_final_gap']}, decision 86 {e['indistinguishable']}); "
              f"sum {e['sum_sq_over_noise']!r}, rows {e['rows']}, changed {e['lam_changed_rows']}, "
              f"max |dlam| {e['max_abs_dlam']!r}; recorded decision-84 fields equal: {all(same.values())}")
    with open(os.path.join(OUT, "verify86_honda.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, allow_nan=False)


if __name__ == "__main__":
    main()
