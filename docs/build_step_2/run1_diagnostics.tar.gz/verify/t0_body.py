"""The T0 record body of an engine without a decision-87 entry, from a given code tree (implementer's check).

Usage: python -B t0_body.py <code root> <out.json>

epa_fit.run_t0 on test_epa_fit's synthetic rows (no EPA row: the synthetic Mazda of that file), the ladder
replaced by the forms up to each truth's own (the stand-in of test_epa_fit's T0 judge test), at its DTH and JOBS.
Run once on HEAD 0147f93's tree and once on the working tree, the two bodies are compared by t0_body_diff.py.
"""
import json
import os
import sys


def main(root, out):
    sys.path.insert(0, root)
    os.chdir(root)
    import epa_fit
    import test_epa_fit as T
    v, view, rows = T.dataset()
    truths = epa_fit.t0_truths(T.NAME, view=view, yield_=rows)
    ab = {epa_fit.t0_rows(rows, truth=tr, seed=tr.seed, view=view, dtheta=T.DTH, jobs=T.JOBS)
          for tr in truths if tr.expected_form == "A+B"}
    made = {}

    def ladder(name, r, *, view, jobs, dtheta):
        if r not in made:
            fa = epa_fit.fit_form(name, r, view=view, form="A", start=None, jobs=jobs, dtheta=dtheta)
            fits = (fa,)
            if r in ab:
                fits += (epa_fit.fit_form(name, r, view=view, form="A+B", start=fa, jobs=jobs, dtheta=dtheta),)
            made[r] = epa_fit.Ladder(engine=name, fits=fits, in_sample={f.form: T.OK_STAGE for f in fits},
                                     chosen=fits[-1].form, reason="test")
        return made[r]

    epa_fit.ladder = ladder
    body = epa_fit.run_t0(T.NAME, rows, view=view, jobs=T.JOBS, dtheta=T.DTH)
    epa_fit.close_pools()
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(body, fh, indent=1, sort_keys=True, allow_nan=False)
    print("pass", body["pass"], "seeds", [s["seed"] for s in body["seeds"]], "wrote", out)


if __name__ == "__main__":
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    sys.dont_write_bytecode = True
    main(sys.argv[1], sys.argv[2])
