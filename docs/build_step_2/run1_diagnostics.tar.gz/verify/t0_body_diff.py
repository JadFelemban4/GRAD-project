"""Compare two T0 bodies (t0_body.py's), path by path: every leaf that differs, every key only one side has.

Usage: python -B t0_body_diff.py <head.json> <work.json>
"""
import json
import sys


def walk(a, b, path, out):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a:
                out.append(("only in work", f"{path}/{k}"))
            elif k not in b:
                out.append(("only in head", f"{path}/{k}"))
            else:
                walk(a[k], b[k], f"{path}/{k}", out)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(("list length", f"{path}: {len(a)} vs {len(b)}"))
        for i, (x, y) in enumerate(zip(a, b)):
            walk(x, y, f"{path}[{i}]", out)
    elif json.dumps(a) != json.dumps(b):
        out.append(("value", f"{path}: {json.dumps(a)[:120]} -> {json.dumps(b)[:120]}"))


head = json.load(open(sys.argv[1], encoding="utf-8"))
work = json.load(open(sys.argv[2], encoding="utf-8"))
out = []
walk(head, work, "", out)
for kind, p in out:
    print(kind, p)
print(f"{len(out)} difference(s)")
